# Prompts para imagens por estilo

### **📘 Guia: MidJourney V6 — O que muda**

**Resumo** — (MidLibrary, In-depth Review V6 Pt. 1, Andrei Kovalev)

O V6 marca um salto de **hiper-realismo**: fotorrealismo impressionante com imperfeições realistas (aberrações de lente, áreas superexpostas, desfoques acidentais, efeitos de filme).

**Principais mudanças vs. V5.2:**

- Segue prompts com mais precisão (e lida melhor com **prompts longos**)
- Mais coerência e **detalhes "insanos"** — texturas recuperadas (grão de filme, pinceladas)
- **Texto em imagens** agora funciona
- Modo `--style raw` "sem opinião" (parecido com V5.2)
- 2 upscalers novos: **Subtle** e **Creative** (ambos 2×)
- **Composição não convencional**: assimetria e sujeito fora do centro — para voltar ao clássico, adicione `central composition` e/ou `symmetrical` ao prompt
- **Mais variabilidade**: as 4 variações de um mesmo prompt diferem bem mais (como um `--chaos` padrão mais alto)

**Dica prática:** estilos artísticos ficam mais fiéis e criativos no V6; nos estilos fotográficos, o hiper-realismo pode "exagerar na nitidez" — use `--style raw` para suavizar.

---

### **🧩 Técnica: Super-Tiling (imagens gigantes sem upscale)**

**Resumo** — (MidLibrary, guia de Gordon Au)

Combina `--tile` + **Vary (Region)** (inpainting) para criar imagens enormes e contínuas (até 4096×4096 px) que não parecem repetidas.

**Passo a passo básico:**

1. Gere uma imagem repetível com o parâmetro `--tile`
2. Use **Vary (Region)** e selecione **todo o miolo da imagem**, preservando as bordas externas (que conectam os tiles)
3. Monte os tiles: o resultado parece uma imagem única gigante — e continua sendo repetível

**Variações direcionais:**

- **Panorama horizontal**: preserve só as bordas esquerda/direita no inpainting
- **Imagem alta vertical**: preserve só topo/base
- Deixe alguns trechos sem inpainting para manter estilo, escala e perspectiva consistentes

**Usos:** pôsteres grandes, mapas de jogos, padrões para tecido/papel de parede, cenas estilo "Onde está Wally?"

---

### **🔄 Técnica: Image-to-Text (engenharia reversa de prompts)**

**Resumo** — (MidLibrary, guia de Andrei Kovalev)

Use uma IA de **imagem-para-texto** (CLIP Interrogator 2, grátis no Hugging Face) para analisar qualquer imagem e gerar um prompt aproximado — depois rode esse prompt no MidJourney ou em outro gerador.

**Para que serve:**

- Descobrir o "prompt por trás" de imagens que você admira
- **Reimaginar seu próprio portfólio** com olhos novos
- Destravar bloqueios criativos com combinações inesperadas

**Nível avançado:** pegue o prompt "caótico" gerado e peça ao ChatGPT para reescrevê-lo como texto coerente ou uma **micro-história** — e use essa versão como prompt. Os resultados ficam surpreendentemente próximos do original, com novas camadas narrativas.

**Nota:** é exatamente o processo que usamos nesta página — traduzir estética visual em prompts universais de texto.

---

### **📊 Referência: Midlibrary Benchmark (os 9 prompts de teste)**

**Resumo** — (MidLibrary, Benchmark Explained, Andrei Kovalev)

Todo estilo catalogado na MidLibrary é testado com os mesmos **9 prompts padronizados**, para revelar como o estilo se comporta em situações diferentes:

1. **Cyberpunk character** (sci-fi/personagem)
2. **Nazgul over sleeping town** (fantasia sombria/cena épica)
3. **Decaying peonies** (natureza/still life melancólico)
4. **Tech genius teenage girl** (retrato/personagem contemporâneo)
5. **Cute Mainecoon cat** (fofura/animal)
6. **Chernobog** (mitologia/criatura — o mais imprevisível)
7. **Bioarchitecture** (arquitetura/conceito futurista)
8. **Thom Yorke** (retrato de pessoa real)
9. **Francis D.** (image prompt — retrato fotográfico como referência)

**Dica prática:** use essa mesma lógica para testar seus próprios estilos e srefs — rode um conjunto fixo de temas variados (pessoa, animal, natureza, cena, conceito) e compare como cada estilo responde.

---

### **👧 Guia: MidJourney com crianças (3–5 anos)**

**Resumo** — (MidLibrary, guia de Andrei Kovalev)

Ideias para usar o MidJourney de forma educativa e criativa com crianças pequenas (sempre com mediação dos adultos):

- **"Eu sou artista"**: a criança descreve uma cena, o adulto transforma em prompt, e juntos ajustam até chegar no que ela imaginou — desenvolve vocabulário visual e senso de autoria
- **Personagem favorito**: dar vida a personagens de histórias de ninar da família — cada criança cria sua própria versão
- **Cantigas ilustradas**: gerar uma imagem por verso da música para conectar palavra e imagem
- **Alfabeto e números personalizados**: cartões temáticos com o interesse da criança (ex.: pássaros)

**Dicas técnicas para letras/números:** letras difíceis (G, E, F, H, Q, L, M, P, W, Y) resolvem com re-rolls; se o estilo não renderiza uma letra, troque o artista/técnica; para I, J e T use **image prompt** de uma letra parecida; guarde os "erros" (pediu 7, veio 2 — o 2 vai servir!)

- **Conversas sensíveis**: ilustrações para apoiar temas como diversidade, inclusão e empatia

---

### **💌 Guia: Postais de Feriados**

**Resumo** — (MidLibrary, guia de Andrei Kovalev)

Fórmula testada para criar postais únicos para qualquer data comemorativa:

`[feriado] postcard by [artista] --ar 2:3 --v 4` ou `[feriado] postcard in style of [técnica ou gênero] --ar 2:3 --v 4`

**Artistas e estilos que funcionaram bem nos testes:**

- **Natal**: Ivan Bilibin, Tyrus Wong, Beatrix Potter, Felice Casorati, Alson Skinner Clark, Photogram
- **Ano Novo**: John Bauer, Robert Delaunay, Folk art, Art Déco
- **Ano Novo Chinês**: William Morris, Yoh Nagao, Okuda San Miguel (especifique o animal do ano no prompt!)
- **São Valentim**: William Morris, Kawacy, Fairy Kei, Fractal art
- **Páscoa**: Beatrix Potter, Tyrus Wong, Cloisonnism
- **Halloween / Dia dos Mortos**: Franz Marc, Paul Rand, Ravi Zupa, Aubrey Beardsley, Alphons Mucha
- **Aniversário**: Ralph Steadman, Alan Fletcher, Keith Negley, Pixel art

**Personalização** (o segredo do guia): inclua detalhes da pessoa no prompt — ex.: `Merry Christmas to an introvert postcard by Edward Gorey` ou `Happy Birthday to a cute geeky girl postcard. Pixel art`

**Pós-produção:** remova textos sem sentido e adicione o seu (Photoshop/Content-aware fill); para imprimir, faça upscale com Lightroom Super Resolution ou Gigapixel AI (chega a 4096px+ — suficiente para prints de 20×30 cm)

---

### **🖼️ Guia: Poster Art (série In Focus)**

**Resumo** — (MidLibrary, In Focus, Andrei Kovalev & Maria Laikova)

Como criar pôsteres artísticos explorando técnicas de impressão, movimentos e designers icônicos — tudo testado no **V6**, que já renderiza texto nas imagens.

**Fórmulas de prompt:**

- **Técnica de impressão**: `lithographic poster --v 6 --style raw` (variações: halftone, woodblock print, screen print, linocut, copperplate engraving, aquatint, chromolithographic)
- **Movimento/época**: `poster in Constructivism style --v 6` (variações: Bauhaus School, 1960s Psychedelic, Minimalism, 1990s Grunge, Renaissance)
- **Tema/gênero**: `movie poster --v 6` (variações: political, theatrical, WW1/WW2, Cold War propaganda, Olympic Games, punk/death-metal/hip-hop music poster, Fillmore)
- **Designer**: `poster designed by Shepard Fairey --v 6 --style raw` (variações: Milton Glaser, Alphonse Mucha, Alexander Rodchenko, Paula Scher, Stefan Sagmeister, Peter Saville, Emory Douglas)

**Prompts complexos com texto** (força do V6):

- `1950s American poster with pancakes "Wow pancakes" text --v 6`
- `large letters text "Punk's not dead!" on screen print poster in Punk style --stylize 245 --v 6`
- Combine elementos: época + tema + artista, ex. `1930s vintage poster advertising night mountain hiking by Tamara de Lempicka --v 6`

---

### **Vintage Ethereal Moods**

**Atmosfera e mood**

**Foto vintage etérea** — (MidLibrary, 15 Vintage Photography SREF)

Retratos com clima de sonho e delicadeza — luz difusa, grão de filme e leves vazamentos de luz, como fotos antigas de Hollywood.

**Paleta de cores** tons desbotados e suaves

**Melhores usos:** retratos nostálgicos, moda vintage, cenas de época

**MidJourney:** `--sref 1378340489 --sw 1000`

**Prompt universal:** `vintage photograph with ethereal dreamy mood, soft diffused light, film grain and gentle light leaks, faded muted tones, early Hollywood portrait aesthetic, nostalgic timeless atmosphere`

---

### **Vintage Sepia Passage**

**Atmosfera e mood**

**Sépia clássico de época** — (MidLibrary, 15 Vintage Photography SREF)

Estética de fotografia do início do séc. XX — grão, poeira e arranhões, textura de papel envelhecido.

**Paleta de cores** sépia e marrons monocromáticos quentes

**Melhores usos:** retratos ancestrais, fotos históricas, storytelling de memória

**MidJourney:** `--sref 2434720771 --sw 1000`

**Prompt universal:** `sepia-toned vintage photograph, early 1900s aesthetic, film grain dust and scratches, aged paper texture, warm brown monochrome, timeless historical portrait mood`

---

### **Nostalgic Surreal Kitsch**

**Atmosfera e mood**

**Kitsch retrô surreal** — (MidLibrary, 15 Vintage Photography SREF)

Cores saturadas de revista antiga com encenações levemente surreais — charme de anúncio mid-century com humor.

**Paleta de cores** saturadas com desvios de cor de filme antigo

**Melhores usos:** editoriais retrô divertidos, visuais irônicos, anúncios vintage

**MidJourney:** `--sref 2446228844 --sw 1000`

**Prompt universal:** `nostalgic kitsch photography with surreal touches, saturated retro magazine colors, mid-century advertising aesthetic, playful staged scenes, vintage film color shifts`

---

### **Retro Grid Surrealism**

**Atmosfera e mood**

**Surrealismo retrô gráfico** — (MidLibrary, 15 Vintage Photography SREF)

Composições geométricas com elementos de grade e clima anos 70–80 — foto conceitual com textura de filme.

**Paleta de cores** tons retrô das décadas de 70–80

**Melhores usos:** editoriais conceituais, capas gráficas, visuais experimentais

**MidJourney:** `--sref 3710374291 --sw 1000`

**Prompt universal:** `retro surrealist photography with graphic grid elements, 1970s-80s color palette, geometric composition, vintage film texture, conceptual editorial style`

---

### **Atomic Wright Revival**

**Atmosfera e mood**

**Era atômica mid-century** — (MidLibrary, 15 Vintage Photography SREF)

Estética dos anos 1950 e da era espacial — elegância arquitetônica e americana nostálgica com grão de filme.

**Paleta de cores** tons vintage quentes

**Melhores usos:** cenas de época 1950s, arquitetura retrô, anúncios nostálgicos

**MidJourney:** `--sref 181103373 --sw 1000`

**Prompt universal:** `mid-century atomic age photography aesthetic, 1950s retro-futuristic design, warm vintage tones, architectural elegance, nostalgic americana mood, film grain`

---

### **Enigmatic Surrealism**

**Atmosfera e mood**

**Surrealismo enigmático** — (MidLibrary, 15 Vintage Photography SREF)

Encenações misteriosas e oníricas em fotografia vintage — atmosfera cinematográfica levemente inquietante.

**Paleta de cores** tons envelhecidos e apagados

**Melhores usos:** narrativas de mistério, capas conceituais, retratos enigmáticos

**MidJourney:** `--sref 2412597767 --sw 1000`

**Prompt universal:** `enigmatic surrealist vintage photograph, mysterious dreamlike staging, muted aged tones, film grain and soft shadows, cinematic uncanny atmosphere`

---

### **Haunting Scandinavian Dreams**

**Atmosfera e mood**

**Melancolia nórdica poética** — (MidLibrary, 15 Vintage Photography SREF)

Luz fria escandinava e cenas mínimas silenciosas — beleza quieta com um toque assombrado.

**Paleta de cores** dessaturada e fria

**Melhores usos:** visuais introspectivos, paisagens nórdicas, retratos melancólicos

**MidJourney:** `--sref 2815753609 --sw 1000`

**Prompt universal:** `haunting Scandinavian photography, cold nordic light, melancholic minimal scenes, muted desaturated palette, vintage film grain, quiet eerie poetic atmosphere`

---

### **Nostalgic Retrovisions**

**Atmosfera e mood**

**Retrô anos 60–70** — (MidLibrary, 15 Vintage Photography SREF)

Estética de filme kodachrome desbotado — desvios de cor quentes, vazamentos de luz e cenas espontâneas.

**Paleta de cores** tons quentes desbotados de filme analógico

**Melhores usos:** lifestyle nostálgico, cenas de família vintage, editoriais retrô

**MidJourney:** `--sref 1691777625 --sw 1000`

**Prompt universal:** `nostalgic retro photography, 1960s-70s film aesthetic, warm color shifts and light leaks, faded kodachrome tones, candid vintage scenes`

---

### **Timeless Monochrome**

**Atmosfera e mood**

**P&B clássico atemporal** — (MidLibrary, 15 Vintage Photography SREF)

Fotografia monocromática de filme com rica gama tonal e grão fino — qualidade documentária elegante.

**Paleta de cores** preto e branco com tons ricos

**Melhores usos:** retratos atemporais, fotografia documentária, elegância clássica

**MidJourney:** `--sref 1023471748 --sw 1000`

**Prompt universal:** `timeless black and white photography, classic monochrome film aesthetic, rich tonal range, fine grain, elegant timeless composition, documentary portrait quality`

---

### **Complex Narrative Vision**

**Atmosfera e mood**

**Narrativa cinematográfica em camadas** — (MidLibrary, 15 Vintage Photography SREF)

Cenas encenadas que contam histórias complexas — riqueza de detalhe e clima de fotograma de filme antigo.

**Paleta de cores** tons de filme apagados e dramáticos

**Melhores usos:** storytelling visual, cenas com múltiplos personagens, capas narrativas

**MidJourney:** `--sref 2640228480 --sw 1000`

**Prompt universal:** `cinematic vintage photograph with complex layered narrative, staged storytelling scene, rich detail, muted film tones, dramatic composition, mysterious plot`

---

### **Neon Noir Vector**

**Atmosfera e mood**

**Noir neon gráfico** — (MidLibrary, 15 Vintage Photography SREF)

Cenas noturnas com acentos neon brilhantes e acabamento gráfico quase vetorial — clima anos 80 de alto contraste.

**Paleta de cores** escuros profundos com neons vibrantes

**Melhores usos:** visuais noturnos estilizados, capas retrô-tech, cenas urbanas

**MidJourney:** `--sref 1104268036 --sw 1000`

**Prompt universal:** `neon noir retro aesthetic, dark scenes with glowing neon accents, graphic vector-like finish, 1980s night mood, high contrast cinematic style`

---

### **Nostalgic Surreal Flourish**

**Atmosfera e mood**

**Floreio surreal nostálgico** — (MidLibrary, 15 Vintage Photography SREF)

Fotografia vintage com ornamentação e composições sonhadoras — romantismo retrô com toque surreal.

**Paleta de cores** tons suaves envelhecidos

**Melhores usos:** retratos românticos, editoriais poéticos, visuais delicados de época

**MidJourney:** `--sref 3472064746 --sw 1000`

**Prompt universal:** `nostalgic vintage photography with surreal ornamental flourishes, dreamy staged composition, soft aged tones, romantic retro atmosphere, film texture`

---

### **Monochrome Zen Repetitions**

**Atmosfera e mood**

**Zen monocromático rítmico** — (MidLibrary, 15 Vintage Photography SREF)

Padrões e formas que se repetem meditativamente — abstração P&B mínima e elegante.

**Paleta de cores** preto e branco minimalista

**Melhores usos:** arte meditativa, composições abstratas, visuais de calma e ritmo

**MidJourney:** `--sref 2763218373 --sw 1000`

**Prompt universal:** `zen monochrome photography, meditative repeating patterns and forms, minimal black and white composition, quiet rhythmic elegance, fine art abstraction`

---

### **Surreal Extravagant Elegance**

**Atmosfera e mood**

**Elegância extravagante surreal** — (MidLibrary, 15 Fantasy Illustration SREF)

Figuras místicas com figurinos ornamentados em pintura ricamente detalhada — fantasia dramática e encantada.

**Paleta de cores** tons ricos e teatrais

**Melhores usos:** contos de fadas, personagens mágicos, ilustração épica

**MidJourney:** `--sref 2540517565 --sw 1000`

**Prompt universal:** `fantasy illustration with surreal extravagant elegance, ornate costumes and mystical characters, richly detailed painterly style, dramatic enchanted atmosphere`

---

### **Glamour Sorrows Luxe**

**Atmosfera e mood**

**Glamour melancólico luxuoso** — (MidLibrary, 15 Fantasy Illustration SREF)

Fantasia dark elegante — personagens glamourosos com tristeza poética e detalhes opulentos.

**Paleta de cores** escuros ricos com brilhos opulentos

**Melhores usos:** fantasia gótica refinada, retratos dramáticos, capas sombrias elegantes

**MidJourney:** `--sref 2788365553 --sw 1000`

**Prompt universal:** `luxurious melancholic fantasy illustration, glamorous sorrowful characters, rich dark palette with opulent details, elegant gothic fairy tale mood`

---

### **Dynamic Contrast Canvas**

**Atmosfera e mood**

**Contraste dinâmico épico** — (MidLibrary, 15 Fantasy Illustration SREF)

Pincelada energética com luz e sombra dramáticas — ideal para batalhas e cenas de ação.

**Paleta de cores** contrastes fortes e vibrantes

**Melhores usos:** batalhas épicas, ação dinâmica, capas de fantasia heroica

**MidJourney:** `--sref 130675016 --sw 1000`

**Prompt universal:** `dynamic fantasy illustration with bold contrast, energetic painterly brushwork, epic battle scenes, dramatic light and shadow, powerful action composition`

---

### **Retro Abstraction Syndicate**

**Atmosfera e mood**

**Abstração retrô de fantasia** — (MidLibrary, 15 Fantasy Illustration SREF)

Formas gráficas vintage e figuras estilizadas — influência de ilustração mid-century com cores chapadas.

**Paleta de cores** cores chapadas ousadas retrô

**Melhores usos:** livros ilustrados estilizados, pôsteres de fantasia, design imaginativo

**MidJourney:** `--sref 208392084 --sw 1000`

**Prompt universal:** `retro abstract fantasy illustration, vintage graphic shapes and stylized figures, mid-century illustration influence, bold flat colors, imaginative storybook design`

---

### **Opulent Flourish Realm**

**Atmosfera e mood**

**Reino de floreios opulentos** — (MidLibrary, 15 Fantasy Illustration SREF)

Ornamentação com influência art nouveau e detalhe mágico intrincado — fantasia rica e majestosa.

**Paleta de cores** tons de joia profundos

**Melhores usos:** reinos encantados, personagens nobres, ilustração decorativa

**MidJourney:** `--sref 3999070822 --sw 1000`

**Prompt universal:** `opulent fantasy illustration with decorative flourishes, ornamental art nouveau influence, rich jewel tones, intricate magical detail, regal enchanted realm`

---

### **Pop Abstract Expression**

**Atmosfera e mood**

**Expressionismo abstrato pop** — (MidLibrary, 15 Fantasy Illustration SREF)

Formas gestuais ousadas com energia de arte moderna — fantasia estilizada, viva e lúdica.

**Paleta de cores** cores vivas expressivas

**Melhores usos:** personagens estilizados, arte vibrante, ilustração contemporânea

**MidJourney:** `--sref 237123999 --sw 1000`

**Prompt universal:** `pop abstract fantasy illustration, vivid expressive colors, bold gestural shapes, playful modern art energy, imaginative stylized characters`

---

### **Vibrant Pop Luminosity**

**Atmosfera e mood**

**Luminosidade pop vibrante** — (MidLibrary, 15 Fantasy Illustration SREF)

Luz mágica radiante com cores pop saturadas — mundos coloridos de impacto imediato.

**Paleta de cores** saturadas e brilhantes

**Melhores usos:** mundos mágicos vibrantes, capas chamativas, cenas radiantes

**MidJourney:** `--sref 2511775221 --sw 1000`

**Prompt universal:** `vibrant luminous fantasy illustration, glowing saturated pop colors, radiant magical light, energetic composition, striking colorful world`

---

### **Dynamic Artirography**

**Atmosfera e mood**

**Traço expressivo em movimento** — (MidLibrary, 15 Fantasy Illustration SREF)

Linhas varridas e energéticas com fluxo pictórico — narrativa visual cheia de dinamismo.

**Paleta de cores** vívidas com movimento

**Melhores usos:** cenas de movimento, ilustração narrativa, ação fluida

**MidJourney:** `--sref 2145721723 --sw 1000`

**Prompt universal:** `dynamic expressive fantasy illustration, sweeping energetic linework, painterly motion and flow, dramatic composition, vivid storytelling energy`

---

### **Bold Narrative Expressionism**

**Atmosfera e mood**

**Expressionismo narrativo ousado** — (MidLibrary, 15 Fantasy Illustration SREF)

Pinceladas grossas e expressivas com cores e emoção intensas — storytelling épico de fantasia.

**Paleta de cores** intensas e emotivas

**Melhores usos:** cenas épicas, ilustração emocional, capas dramáticas

**MidJourney:** `--sref 2378232426 --sw 1000`

**Prompt universal:** `bold expressionist fantasy illustration, strong narrative scenes, thick expressive brushstrokes, intense colors and emotion, epic storytelling`

---

### **Neonflux Chronicles**

**Atmosfera e mood**

**Crônicas em neon fluido** — (MidLibrary, 15 Fantasy Illustration SREF)

Cores brilhantes que fluem sobre fundos escuros — energia mágica cinematográfica com acentos elétricos.

**Paleta de cores** escuros com neons fluidos

**Melhores usos:** fantasia moderna, magia luminosa, mundos noturnos encantados

**MidJourney:** `--sref 2942895933 --sw 1000`

**Prompt universal:** `neon-infused fantasy illustration, flowing glowing colors, dark backgrounds with electric accents, otherworldly chronicle mood, cinematic magical energy`

---

### **Vivid Fusion Chronicles**

**Atmosfera e mood**

**Fusão vívida de técnicas** — (MidLibrary, 15 Fantasy Illustration SREF)

Mistura de pintura e linguagem gráfica com paleta intensa — cenas mágicas ricas em detalhe.

**Paleta de cores** saturadas e intensas

**Melhores usos:** mundos detalhados, ilustração híbrida, narrativas visuais ricas

**MidJourney:** `--sref 2034953953 --sw 1000`

**Prompt universal:** `vivid mixed-style fantasy illustration, fusion of painterly and graphic techniques, intense saturated palette, dynamic magical scenes, rich detailed storytelling`

---

### **Ethereal Tones of Enchantment**

**Atmosfera e mood**

**Encantamento etéreo suave** — (MidLibrary, 15 Fantasy Illustration SREF)

Tons mágicos delicados e atmosfera luminosa — contos de fadas gentis com beleza mística.

**Paleta de cores** suaves e luminosas

**Melhores usos:** contos de fadas delicados, visuais místicos suaves, imaginação guiada

**MidJourney:** `--sref 1472470459 --sw 1000`

**Prompt universal:** `ethereal enchanted fantasy illustration, soft magical tones, delicate luminous atmosphere, dreamy fairy tale scenes, gentle mystical beauty`

---

### **Opulent East Nouveau**

**Atmosfera e mood**

**Art nouveau oriental opulento** — (MidLibrary, 15 Fantasy Illustration SREF)

Motivos orientais ornamentados com linhas decorativas fluidas — cenas míticas elegantes e ricas.

**Paleta de cores** dourados e tons de joia

**Melhores usos:** mitologia oriental, ilustração decorativa, cenas majestosas

**MidJourney:** `--sref 401699206 --sw 1000`

**Prompt universal:** `opulent eastern art nouveau fantasy illustration, ornate oriental motifs, flowing decorative lines, rich gold and jewel tones, elegant mythic scenes`

---

### **Playful Abstraction**

**Atmosfera e mood**

**Abstração lúdica** — (MidLibrary, 15 Fantasy Illustration SREF)

Formas simplificadas e caprichosas com cores alegres — charme moderno de livro infantil.

**Paleta de cores** alegres e leves

**Melhores usos:** ilustração infantil, cenas divertidas, storytelling leve

**MidJourney:** `--sref 1152035651 --sw 1000`

**Prompt universal:** `playful abstract fantasy illustration, whimsical simplified shapes, cheerful colors, lighthearted imaginative composition, modern storybook charm`

---

### **Binary Futurism**

**Atmosfera e mood**

**Futurismo digital** — (MidLibrary, 15 Fantasy Illustration SREF)

Fusão de fantasia com estética tech — motivos de código e glitch em paleta futurista luminosa.

**Paleta de cores** luminosas futuristas

**Melhores usos:** fantasia sci-fi, mundos digitais, visuais de tecnologia mágica

**MidJourney:** `--sref 1250067898 --sw 1000`

**Prompt universal:** `binary futurist fantasy illustration, digital tech-inspired aesthetic, glitch and code motifs, sleek sci-fi fantasy fusion, luminous futuristic palette`

---

### **📸 FÓRMULA EDITORIAL DE LUXO — prompts com fator “uau”**

**Por que os prompts anteriores não geravam “eye candy”**

Eles descreviam a *estética* (paleta, referência histórica), mas não davam *direção de arte fotográfica*. O que separa uma imagem genérica de uma de capa é briefar a IA como um diretor de criação briefa um fotógrafo.

**Estrutura em 8 camadas (nessa ordem)**

1. **Tipo de shot** — `high fashion editorial photograph`, `full body editorial fashion shot`, `editorial portrait`, `macro fashion photography`
2. **Modelo + pose** — pose com verbo e atitude: `statuesque contrapposto pose`, `mid-stride`, `powerful direct gaze`, `arched back over-the-shoulder gaze`, `avant-garde contortion`
3. **Peça + tecido + cor** — nunca “roupa bonita”: `sculptural coat in deep emerald velvet`, `flowing crimson silk charmeuse gown with dramatic draping`, `architectural origami-inspired couture dress`
4. **Cenário cinematográfico** — `abandoned marble palazzo`, `brutalist concrete wall`, `rain-slicked street at dusk`, `pure white cyclorama studio`
5. **Luz com direção** — `single hard light from camera left creating sharp sculptural shadow`, `directional golden hour sunlight`, `harsh on-camera flash`, `chiaroscuro`, `single overhead strobe`
6. **Referência de publicação/fotógrafo** — `Vogue Italia editorial style`, `Tim Walker inspired`, `Peter Lindbergh realism`, `Irving Penn minimalism`, `Helmut Newton drama`
7. **Câmera + lente** — `shot on Hasselblad H6D 80mm`, `85mm f/1.4 shallow depth of field`, `medium format film`, `35mm film with grain`
8. **Grading + qualidade** — `rich cinematic color grading with deep shadows and warm highlights`, `ultra photorealistic, 8k, raw photographic quality`

**Parâmetros MidJourney para editorial**

`--ar 4:5` (retrato de revista) ou `--ar 9:16` (corpo inteiro/Reels) · `--s 350–450` · `--chaos 10–20` · `--sref CODE` para travar a estética na série · `--cref` para manter a mesma modelo

**Regra de série coesa:** mantenha luz, cenário, câmera e grading idênticos em todos os prompts da série; mude apenas roupa e pose.

**Exemplo — antes e depois (Retrofuturistic)**

*Antes:* `retrofuturistic image, chrome and atomic age optimism, raygun gothic architecture`

*Depois:* `High fashion editorial photograph of a statuesque model in a chrome-finned atomic-age gown of liquid-silver lamé with a sculpted bubble collar, posing on the observation deck of a raygun-gothic tower at dusk, turquoise and tangerine neon reflecting off polished aluminum surfaces, single hard key light from camera left carving sculptural shadows, retrofuturistic Vogue Italia editorial, shot on Hasselblad with 80mm lens, rich cinematic grading with deep shadows and glowing highlights, ultra photorealistic, 8k --ar 4:5 --s 400 --chaos 15`

**Como aplicar à biblioteca**

Pegue qualquer estilo da página e preencha as 8 camadas usando a **paleta** e o **mood** do bloco como camadas 4–8. O `--sref` do bloco continua valendo — ele tinge o estilo; a fórmula é o que cria o impacto editorial.

---

### **Jacek Yerka**

**Atmosfera e mood**

**Surrealismo detalhado onírico** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Pintor polonês: paisagens oníricas meticulosamente detalhadas que desafiam a física — magia, fantasia e capricho infantil em cores vívidas.

**Paleta de cores** cores vívidas em atmosfera de sonho

**Melhores usos:** mundos impossíveis, realismo mágico, cenários surreais

**MidJourney:** `[tema] by Jacek Yerka --niji`

**Prompt universal:** `surrealist painting in the style of Jacek Yerka, meticulously detailed dreamlike landscape, physics-defying whimsical scenes, vivid colors and magical realism`

---

### **Asaf Hanuka**

**Atmosfera e mood**

**Ilustração expressiva profunda** — (MidLibrary, Top 13 Non-anime + Top 10 Cyberpunk)

Ilustrador israelense: cores vívidas ousadas e detalhes intrincados — imagens surreais e provocativas com profundidade psicológica. Também excelente para sci-fi com `--v 4`.

**Paleta de cores** paletas vibrantes com linhas finas

**Melhores usos:** graphic novel, ilustração editorial, cenas emocionais

**MidJourney:** `[tema] by Asaf Hanuka --niji`

**Prompt universal:** `expressive illustration in the style of Asaf Hanuka, bold vivid colors and intricate details, surreal thought-provoking imagery, emotional psychological depth, graphic novel aesthetic`

---

### **Martine Johanna**

**Atmosfera e mood**

**Pintura expressiva fluida** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista holandesa: figuras femininas em cor vibrante e texturas exuberantes — abstração e distorção fluidas com intensidade emocional.

**Paleta de cores** cores ousadas em camadas vibrantes

**Melhores usos:** retratos femininos expressivos, arte emocional, fluidez dinâmica

**MidJourney:** `[tema] by Martine Johanna --niji`

**Prompt universal:** `expressive contemporary painting in the style of Martine Johanna, bold vibrant color and lush textures, female figures with fluid abstraction, raw emotional intensity`

---

### **Pop Art**

**Atmosfera e mood**

**Cultura pop gráfica** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Movimento dos anos 50–60 (Warhol, Lichtenstein): cores brilhantes chapadas, técnicas de impressão comercial, humor e sátira do consumismo.

**Paleta de cores** cores brilhantes ousadas chapadas

**Melhores usos:** arte pop, pôsteres icônicos, sátira visual

**MidJourney:** `[tema] in Pop art style --niji`

**Prompt universal:** `Pop art style, bright bold colors and flat shapes, commercial silkscreen print aesthetic, halftone dots, playful satirical pop culture imagery`

---

### **Bob Layzell**

**Atmosfera e mood**

**Linhas limpas dinâmicas** — (MidLibrary, Top 13 Non-anime + Top 10 Cyberpunk)

Ilustrador britânico: ilustrações brilhantes e profundas com linhas limpas e formas simples em cenas expressivas e dinâmicas. Também ótimo para sci-fi com `--v 4`.

**Paleta de cores** cores brilhantes e profundas

**Melhores usos:** ilustração dinâmica, cenas retrô-futuristas, arte gráfica limpa

**MidJourney:** `[tema] by Bob Layzell --niji`

**Prompt universal:** `bright dynamic illustration in the style of Bob Layzell, clean lines and simple shapes, deep vivid colors, expressive energetic scenes`

---

### **Bernie Wrightson**

**Atmosfera e mood**

**Horror a nanquim magistral** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista americano de horror e fantasia: nanquim P&B intrincado com crosshatching denso — monstros góticos e atmosfera macabra (colaborou com Stephen King).

**Paleta de cores** preto e branco texturizado dramático

**Melhores usos:** horror ilustrado, monstros góticos, quadrinhos dark

**MidJourney:** `[tema] by Bernie Wrightson --niji`

**Prompt universal:** `dark horror illustration in the style of Bernie Wrightson, intricate black and white pen and ink, dense crosshatching and dramatic shading, macabre gothic monsters`

---

### **John Kenn Mortensen**

**Atmosfera e mood**

**Monstros em post-its** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista dinamarquês: desenhos de tinta sombrios e sobrenaturais — criaturas monstruosas em paisagens desoladas, contraste e espaço negativo.

**Paleta de cores** preto e branco de contraste severo

**Melhores usos:** horror atmosférico, criaturas assombrosas, ilustração sombria

**MidJourney:** `[tema] by John Kenn Mortensen --niji`

**Prompt universal:** `eerie ink drawing in the style of John Kenn Mortensen, monstrous otherworldly creatures looming in bleak landscapes, stark contrast and negative space, haunting apocalyptic atmosphere`

---

### **Aaron Jasinski**

**Atmosfera e mood**

**Surrealismo pop nostálgico** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista americano: surrealismo, cultura pop e design vintage — personagens caprichosos em cores vibrantes com jogo de luz e sombra.

**Paleta de cores** cores vibrantes com luz nostálgica

**Melhores usos:** pop surrealismo, personagens retrô, cenas lúdicas

**MidJourney:** `[tema] by Aaron Jasinski --niji`

**Prompt universal:** `pop surrealism in the style of Aaron Jasinski, whimsical characters and retro design elements, bold vibrant colors, interplay of light and shadow, nostalgic playful mood`

---

### **Farel Dalrymple**

**Atmosfera e mood**

**Quadrinhos experimentais orgânicos** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista americano de quadrinhos: linhas intrincadas orgânicas com tinta, aquarela e efeitos digitais — atmosfera onírica com sci-fi e mitologia.

**Paleta de cores** aquarelas suaves com tinta expressiva

**Melhores usos:** quadrinhos alternativos, cenas oníricas, ilustração eclética

**MidJourney:** `[tema] by Farel Dalrymple --niji`

**Prompt universal:** `experimental comic art in the style of Farel Dalrymple, intricate organic linework with ink and watercolor, dreamlike surreal atmosphere, eclectic sci-fi and mythology influences`

---

### **Gary Panter**

**Atmosfera e mood**

**Punk psicodélico primitivo** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista americano influente: cartum primitivo com punk, pop e psicodelia — linhas ousadas, cores vívidas e energia underground.

**Paleta de cores** cores vívidas cruas

**Melhores usos:** arte underground, cartum punk, colagem pop

**MidJourney:** `[tema] by Gary Panter --niji`

**Prompt universal:** `punk psychedelic cartoon art in the style of Gary Panter, primitive bold lines and vivid colors, underground comix energy, raw pop culture collage aesthetic`

---

### **Chesley Bonestell**

**Atmosfera e mood**

**Arte espacial clássica** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Pioneiro da arte espacial: paisagens planetárias vívidas e pictóricas com espaçonaves retrô elaboradas — era de ouro da exploração espacial.

**Paleta de cores** cores vívidas cósmicas pintadas

**Melhores usos:** paisagens alienígenas, sci-fi retrô, arte espacial épica

**MidJourney:** `[tema] by Chesley Bonestell --v 4`

**Prompt universal:** `classic space art in the style of Chesley Bonestell, vivid painterly planetary landscapes, elaborate retro spaceships, golden age of space exploration illustration`

---

### **Jae Lee**

**Atmosfera e mood**

**Quadrinhos sombrios atmosféricos** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Artista de quadrinhos: estilo escuro e atmosférico com sombras dramáticas, pretos profundos e traços rápidos expressivos — perfeito para pôsteres sci-fi.

**Paleta de cores** pretos profundos com acentos dramáticos

**Melhores usos:** pôsteres sci-fi, quadrinhos sombrios, cenas misteriosas

**MidJourney:** `[tema] by Jae Lee --v 4`

**Prompt universal:** `dark moody comic art in the style of Jae Lee, dramatic shadows and deep blacks, quick expressive strokes, mysterious atmospheric sci-fi poster composition`

---

### **Richard Misrach**

**Atmosfera e mood**

**Fotografia de deserto pós-apocalíptica** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Fotógrafo americano: paisagens em larga escala do oeste americano com intervenção humana — sensação pós-apocalíptica e escala cinematográfica.

**Paleta de cores** tons naturais desbotados com névoa

**Melhores usos:** paisagens desoladas, fotografia conceitual, cenários distópicos

**MidJourney:** `[tema] by Richard Misrach --v 4`

**Prompt universal:** `large-scale color landscape photography in the style of Richard Misrach, vast desert scenes with human intervention, post-apocalyptic haze, muted natural light and cinematic scale`

---

### **Takeshi Obata**

**Atmosfera e mood**

**Mangá detalhado dinâmico** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Mangaká de Death Note e Hikaru no Go: composições dinâmicas de alta energia, atmosfera forte, cores belas e detalhes intrincados de personagem.

**Paleta de cores** cores intensas com sombras dramáticas

**Melhores usos:** mangá sci-fi, personagens estilizados, cenas urbanas intensas

**MidJourney:** `[tema] by Takeshi Obata --niji`

**Prompt universal:** `detailed manga illustration in the style of Takeshi Obata, high-energy dynamic composition, strong atmosphere and beautiful colors, intricate character detail, dark seinen aesthetic`

---

### **Dan Matutina**

**Atmosfera e mood**

**Minimalismo geométrico híbrido** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Ilustrador filipino: linhas ousadas, formas simples e paleta limitada e bela — mistura de texturas feitas à mão com técnicas digitais.

**Paleta de cores** paleta limitada harmoniosa

**Melhores usos:** ilustração vetorial, sci-fi minimalista, design editorial

**MidJourney:** `[tema] by Dan Matutina --v 4`

**Prompt universal:** `minimalist geometric illustration in the style of Dan Matutina, bold lines and simple shapes, limited beautiful color palette, hand-drawn meets digital texture`

---

### **Ashley Wood**

**Atmosfera e mood**

**Matte painting expressivo** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Artista australiano (Popbot, World War Robot): pintura com aspecto de matte painting, paleta apagada e pincelada solta — luz sonhadora em cenas com robôs.

**Paleta de cores** tons apagados com luz difusa

**Melhores usos:** robôs e mechas, sci-fi pictórico, atmosferas melancólicas

**MidJourney:** `[tema] by Ashley Wood --v 4`

**Prompt universal:** `matte painterly illustration in the style of Ashley Wood, muted color palette, loose expressive brushwork, dreamy light sci-fi scenes with robots`

---

### **Jakub Rozalski**

**Atmosfera e mood**

**Dieselpunk rural 1920+** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Artista polonês (universo “1920+” / Scythe): paisagens rurais dos anos 1920 com robôs gigantes — realismo pictórico, nostalgia e futurismo em grande escala.

**Paleta de cores** paleta fria com respingos quentes

**Melhores usos:** dieselpunk, robôs gigantes em paisagens, história alternativa

**MidJourney:** `[tema] by Jakub Rozalski --v 4`

**Prompt universal:** `painterly dieselpunk scene in the style of Jakub Rozalski, rural 1920s landscape with giant robots and machinery, cold color palette with warm accents, nostalgic futurism, massive scale`

---

### **Bob Eggleton**

**Atmosfera e mood**

**Capas sci-fi vívidas** — (MidLibrary, Top 10 Cyberpunk & Sci-Fi)

Ilustrador vencedor do Hugo: cenas imaginativas de conto de fadas altamente detalhadas com cores fortes saturadas — estética de capa de livro épica.

**Paleta de cores** cores fortes saturadas

**Melhores usos:** capas de livro, dragões e monstros, fantasia cósmica

**MidJourney:** `[tema] by Bob Eggleton --v 4`

**Prompt universal:** `vivid science fiction illustration in the style of Bob Eggleton, highly detailed imaginative fairytale scenes, strong saturated colors, epic fantasy book cover art`

---

### **Fang Lijun**

**Atmosfera e mood**

**Realismo cínico chinês** — (MidLibrary, Top 10 New Styles wk 13)

Pintor contemporâneo chinês: pinceladas expressivas e paleta de forte contraste — figuras carecas satíricas e surreais, entre o irônico e o inquietante.

**Paleta de cores** contrastes profundos intensos

**Melhores usos:** arte contemporânea, retratos satíricos, expressionismo

**MidJourney:** `[tema] by Fang Lijun --v 4`

**Prompt universal:** `Chinese contemporary painting in the style of Fang Lijun, expressive brushstrokes, deep contrasting color palette, satirical surreal figures, cynical realism`

---

### **Winifred Knights**

**Atmosfera e mood**

**Realismo britânico melancólico** — (MidLibrary, Top 10 New Styles wk 13)

Pintora britânica do início do séc. XX: figuras altamente estilizadas com realismo detalhado, volume de luz e sombra e uma sensação de saudade.

**Paleta de cores** tons sóbrios com luz suave

**Melhores usos:** retratos estilizados, cenas contemplativas, arte clássica moderna

**MidJourney:** `[tema] by Winifred Knights --v 4`

**Prompt universal:** `British early 20th century painting in the style of Winifred Knights, highly stylized figures, detailed realism with volume of light and shadow, sense of longing and quiet drama`

---

### **Bruno Munari**

**Atmosfera e mood**

**Design italiano elegante** — (MidLibrary, Top 10 New Styles wk 13)

Artista e designer italiano ligado ao futurismo: composição forte, jogo de cores e formas geométricas elegantes — experimentação modernista lúdica.

**Paleta de cores** cores puras em geometria limpa

**Melhores usos:** design gráfico, abstração geométrica, pôsteres modernistas

**MidJourney:** `[tema] by Bruno Munari --v 4`

**Prompt universal:** `elegant Italian design in the style of Bruno Munari, strong composition and color play, sleek geometric shapes, playful modernist experimentation`

---

### **Issey Miyake**

**Atmosfera e mood**

**Moda japonesa avant-garde** — (MidLibrary, Top 10 New Styles wk 13)

Estilista japonês: silhuetas futuristas aerodinâmicas, padrões geométricos coloridos e tecidos de alta tecnologia — elegância minimalista plissé.

**Paleta de cores** cores limpas em plissados geométricos

**Melhores usos:** moda futurista, design têxtil, estética minimalista tech

**MidJourney:** `[tema] by Issey Miyake --v 4`

**Prompt universal:** `avant-garde fashion design in the style of Issey Miyake, streamlined futuristic silhouettes, colorful geometric pleated patterns, high-tech fabrics with minimalist elegance`

---

### **Maria Lassnig**

**Atmosfera e mood**

**Expressionismo corporal** — (MidLibrary, Top 10 New Styles wk 13)

Pintora austríaca: pinceladas ousadas e expressivas com cores fortes — retrato introspectivo focado no corpo e nas sensações, presença emocional crua.

**Paleta de cores** tons de pele com acentos fortes

**Melhores usos:** retratos expressivos, arte emocional, figuração contemporânea

**MidJourney:** `[tema] by Maria Lassnig --v 4`

**Prompt universal:** `expressive figurative painting in the style of Maria Lassnig, bold expressive brushstrokes, strong colors, introspective body-focused portraiture, raw emotional presence`

---

### **Tadanori Yokoo**

**Atmosfera e mood**

**Pôster pop japonês** — (MidLibrary, Top 10 New Styles wk 13)

Artista gráfico japonês: pôsteres pop de cores marcantes, colagens lúdicas e motivos tradicionais japoneses com nostalgia psicodélica.

**Paleta de cores** cores marcantes saturadas

**Melhores usos:** pôsteres gráficos, colagem pop, estética retrô japonesa

**MidJourney:** `[tema] by Tadanori Yokoo --v 4`

**Prompt universal:** `Japanese pop art poster in the style of Tadanori Yokoo, striking bold colors, playful collage imagery, traditional Japanese motifs with modern graphics, nostalgic psychedelic energy`

---

### **Iwona Lifsches**

**Atmosfera e mood**

**Arte naïf de conto de fadas** — (MidLibrary, Top 10 New Styles wk 13)

Artista polonesa de Arte Naïf: inocência infantil em forma e cor — cenas brilhantes, simples mas detalhadas, com humor gentil e um toque de melancolia.

**Paleta de cores** cores alegres e acolhedoras

**Melhores usos:** cenas de conto de fadas, ilustração ingênua, charme nostálgico

**MidJourney:** `[tema] by Iwona Lifsches --v 4`

**Prompt universal:** `naive art painting in the style of Iwona Lifsches, childlike innocence in shape and color, bright simple yet detailed scenes, whimsical fairy tale charm with gentle humor`

---

### **Hilma af Klint**

**Atmosfera e mood**

**Abstração espiritual pioneira** — (MidLibrary, Top 10 New Styles wk 13)

Pintora sueca, pioneira da arte abstrata: abstrações geométricas elegantes com cores suaves e brilhantes, linhas finas e simetria simbólica — misticismo teosófico.

**Paleta de cores** pastéis luminosos com dourados

**Melhores usos:** abstração espiritual, diagramas místicos, geometria simbólica

**MidJourney:** `[tema] by Hilma af Klint --v 4`

**Prompt universal:** `spiritual abstract painting in the style of Hilma af Klint, elegant geometric abstractions, soft bright colors and fine lines, symbolic symmetry, theosophical mysticism`

---

### **Beeple**

**Atmosfera e mood**

**Arte digital épica distópica** — (MidLibrary, Top 10 New Styles wk 13)

Artista digital (Mike Winkelmann): cenas sci-fi surreais em escala massiva com cores vibrantes e iluminação cinematográfica — renderização 3D hiperdetalhada.

**Paleta de cores** neônicos vibrantes com sombras profundas

**Melhores usos:** sci-fi épico, distopias monumentais, arte digital 3D

**MidJourney:** `[tema] by Beeple --v 4`

**Prompt universal:** `epic digital art in the style of Beeple, massive-scale surreal sci-fi scene, vibrant colors and cinematic lighting, dystopian otherworldly atmosphere, hyper-detailed 3D render`

---

### **Sergei Parajanov**

**Atmosfera e mood**

**Surrealismo poético armênio** — (MidLibrary, Top 10 Cinematic Styles)

Diretor armênio: imagens vívidas e surreais, identidade cultural e visuais ousados — tableaux simbólicos com figurinos ornamentados.

**Paleta de cores** cores vívidas rituais

**Melhores usos:** cenas simbólicas, poética visual, figurinos culturais

**MidJourney:** `[tema], cinematic shot by Sergei Parajanov --v 5.2`

**Prompt universal:** `cinematic still in the style of Sergei Parajanov, vivid surreal imagery, ornate cultural costumes and symbolic tableaux, bold theatrical composition`

---

### **Mario Bava**

**Atmosfera e mood**

**Horror italiano estilizado** — (MidLibrary, Top 10 Cinematic Styles)

Mestre do horror italiano: cenas surreais com cores intensas e sombras elegantes — atmosfera gótica dos anos 1960.

**Paleta de cores** luzes coloridas saturadas dramáticas

**Melhores usos:** horror gótico, suspense estilizado, iluminação teatral

**MidJourney:** `[tema], cinematic shot by Mario Bava --v 5.2`

**Prompt universal:** `cinematic still in the style of Mario Bava, surreal gothic horror scene, intense saturated color lighting, stylish dramatic shadows, 1960s Italian horror atmosphere`

---

### **Leni Riefenstahl**

**Atmosfera e mood**

**Épico monocromático monumental** — (MidLibrary, Top 10 Cinematic Styles)

Cineasta alemã (figura histórica controversa; a referência aqui é puramente estética): tons monocromáticos/vintage clássicos, forte contraste e composições poderosas em escala épica.

**Paleta de cores** preto e branco de alto contraste

**Melhores usos:** cenas épicas monumentais, fotografia vintage, composição dramática

**MidJourney:** `[tema], cinematic shot by Leni Riefenstahl --v 5.2`

**Prompt universal:** `epic cinematic still, classic 1930s monochrome film aesthetic, strong contrast and powerful monumental composition, vintage film grain, dramatic scale`

---

### **Pedro Almodóvar**

**Atmosfera e mood**

**Melodrama espanhol vibrante** — (MidLibrary, Top 10 Cinematic Styles)

Diretor espanhol: filmes visualmente deslumbrantes e emocionalmente carregados — cores vívidas saturadas com vermelhos marcantes.

**Paleta de cores** vermelhos intensos e cores saturadas

**Melhores usos:** cenas emocionais, interiores estilosos, drama colorido

**MidJourney:** `[tema], cinematic shot by Pedro Almodovar --v 5.2`

**Prompt universal:** `cinematic still in the style of Pedro Almodovar, vivid saturated colors with bold reds, emotionally charged domestic scene, stylish Spanish melodrama aesthetic`

---

### **Roger Deakins**

**Atmosfera e mood**

**Fotografia épica atmosférica** — (MidLibrary, Top 10 Cinematic Styles)

Diretor de fotografia lendário (Blade Runner 2049, 1917): luz enevoada em múltiplas camadas, enquadramentos épicos escuros e dramáticos, sombras e silhuetas magistrais — vasta sensação de solidão.

**Paleta de cores** tons atmosféricos com silhuetas

**Melhores usos:** cinematografia épica, cenas de névoa e silhueta, solidão visual

**MidJourney:** `[tema], cinematic shot by Roger Deakins --v 5.2`

**Prompt universal:** `cinematic still with cinematography in the style of Roger Deakins, misty multilayered light, epic dark dramatic framing, masterful shadows and silhouettes, vast sense of loneliness`

---

### **James Bidgood**

**Atmosfera e mood**

**Neon onírico teatral** — (MidLibrary, Top 10 Cinematic Styles)

Cineasta e fotógrafo americano, pioneiro da arte queer: sets e figurinos elaborados feitos à mão com “febre neon” de cor — brilho romântico sonhador.

**Paleta de cores** neônicos rosados sonhadores

**Melhores usos:** fantasia teatral, retratos românticos, estética kitsch-glam

**MidJourney:** `[tema], cinematic shot by James Bidgood --v 5.2`

**Prompt universal:** `cinematic still in the style of James Bidgood, elaborate fantastical handmade sets, dreamy neon color craze, soft romantic glow, theatrical otherworldly styling`

---

### **Guillermo del Toro**

**Atmosfera e mood**

**Fantasia gótica imersiva** — (MidLibrary, Top 10 Cinematic Styles)

Diretor mexicano (O Labirinto do Fauno, A Forma da Água): cenários góticos, criaturas fantásticas memoráveis e atmosfera dramática onírica.

**Paleta de cores** âmbar e azul-petróleo ricos

**Melhores usos:** criaturas fantásticas, fantasia sombria, cenários góticos

**MidJourney:** `[tema], cinematic shot by Guillermo del Toro --v 5.2`

**Prompt universal:** `cinematic still in the style of Guillermo del Toro, gothic fantasy scenery, memorable fantastical creatures, rich amber and teal palette, immersive dramatic atmosphere`

---

### **Dario Argento**

**Atmosfera e mood**

**Giallo onírico inquietante** — (MidLibrary, Top 10 Cinematic Styles)

Mestre do giallo italiano (Suspiria): cores vivas ousadas, atmosfera onírica de suspense e cenários perturbadores — luz vermelha e azul dramática.

**Paleta de cores** vermelhos e azuis vibrantes teatrais

**Melhores usos:** suspense estilizado, horror artístico, iluminação expressionista

**MidJourney:** `[tema], cinematic shot by Dario Argento --v 5.2`

**Prompt universal:** `cinematic still in the style of Dario Argento, bold vivid giallo colors, dreamlike suspenseful atmosphere, dramatic red and blue lighting, unsettling dark set pieces`

---

### **Takashi Miike**

**Atmosfera e mood**

**Intensidade grotesca surreal** — (MidLibrary, Top 10 Cinematic Styles)

Diretor japonês prolífico: cenas visualmente intensas e provocativas — mistura de grotesco e surreal com composições chocantes.

**Paleta de cores** contrastes intensos viscerais

**Melhores usos:** thriller japonês, cenas intensas, surrealismo provocativo

**MidJourney:** `[tema], cinematic shot by Takashi Miike --v 5.2`

**Prompt universal:** `cinematic still in the style of Takashi Miike, visually intense provocative scene, blend of grotesque and surreal, striking shocking composition, Japanese thriller energy`

---

### **Wes Anderson**

**Atmosfera e mood**

**Simetria pastel nostálgica** — (MidLibrary, Top 10 Cinematic Styles)

Diretor americano (Grande Hotel Budapeste): enquadramento perfeitamente simétrico, paleta dominada por pastéis e detalhe meticuloso caprichoso.

**Paleta de cores** pastéis rosados e amarelados

**Melhores usos:** cenas simétricas, estética retrô charmosa, composições meticulosas

**MidJourney:** `[tema], cinematic shot by Wes Anderson --v 5.2`

**Prompt universal:** `cinematic still in the style of Wes Anderson, perfectly symmetrical composition, pastel-dominated color palette, whimsical meticulous detail, nostalgic elegance`

---

### **Rufino Tamayo**

**Atmosfera e mood**

**Modernismo mexicano vibrante** — (MidLibrary, Top 12 Most Extravagant Artists)

Pintor mexicano: retratos ousados da cultura e mitologia mexicanas — cores ricas e formas abstratas em linguagem visual distinta.

**Paleta de cores** cores ricas terrosas e vibrantes

**Melhores usos:** arte latino-americana, mitologia, abstração figurativa

**MidJourney:** `[tema] by Rufino Tamayo --v 4`

**Prompt universal:** `Mexican modernist painting in the style of Rufino Tamayo, bold vibrant colors and abstract shapes, mythological themes, rich textured surfaces`

---

### **Aries Moross**

**Atmosfera e mood**

**Design gráfico pop ousado** — (MidLibrary, Top 12 Most Extravagant Artists)

Artista de Londres: estilo gráfico colorido inspirado em cultura pop, tipografia e street art — formas geométricas e letras lúdicas.

**Paleta de cores** cores brilhantes energéticas

**Melhores usos:** design gráfico, capas e pôsteres, tipografia criativa

**MidJourney:** `[tema] by Aries Moross --v 4`

**Prompt universal:** `bold graphic design in the style of Aries Moross, bright colors and geometric shapes, playful hand-drawn typography, pop culture energy`

---

### **Guo Pei**

**Atmosfera e mood**

**Alta-costura opulenta** — (MidLibrary, Top 12 Most Extravagant Artists)

Estilista chinesa (do vestido amarelo icônico de Rihanna no Met Gala 2015): bordados intrincados, contas e ornamentação — motivos chineses com silhuetas dramáticas.

**Paleta de cores** dourados opulentos e tons imperiais

**Melhores usos:** moda extravagante, vestidos majestosos, ornamentação luxuosa

**MidJourney:** `[tema] by Guo Pei --v 4`

**Prompt universal:** `extravagant haute couture in the style of Guo Pei, ornate intricate embroidery and beading, opulent gold embellishments, traditional Chinese motifs with dramatic silhouettes`

---

### **David Wiesner**

**Atmosfera e mood**

**Livro infantil surreal** — (MidLibrary, Top 12 Most Extravagant Artists)

Autor e ilustrador americano (múltiplas medalhas Caldecott): livros infantis detalhados e imaginativos que borram realidade e imaginação.

**Paleta de cores** aquarelas realistas suaves

**Melhores usos:** ilustração infantil sofisticada, cenas surreais, narrativa visual

**MidJourney:** `[tema] by David Wiesner --v 4`

**Prompt universal:** `imaginative children's book illustration in the style of David Wiesner, surreal fantastical scenes, detailed realistic watercolor rendering, dreamlike wonder blurring reality and imagination`

---

### **Ivan Marchuk**

**Atmosfera e mood**

**Texturas místicas ucranianas** — (MidLibrary, Top 12 Most Extravagant Artists)

Artista ucraniano: pinturas altamente detalhadas com padrões e texturas como fios entrelaçados — folk ucraniano e mitologia.

**Paleta de cores** cores ricas com texturas filamentosas

**Melhores usos:** arte mística, texturas intrincadas, folclore eslavo

**MidJourney:** `[tema] by Ivan Marchuk --v 4`

**Prompt universal:** `intricate painting in the style of Ivan Marchuk, highly detailed thread-like textures and patterns, Ukrainian folk art and mythology influences, rich colors and mystical atmosphere`

---

### **Iris van Herpen**

**Atmosfera e mood**

**Moda escultural futurista** — (MidLibrary, Top 12 Most Extravagant Artists)

Estilista holandesa: tecnologia e materiais não convencionais em formas esculturais — fusão de moda, arte e ciência.

**Paleta de cores** tons orgânicos etéreos e metálicos

**Melhores usos:** moda futurista, formas orgânicas 3D, design vanguardista

**MidJourney:** `[tema] by Iris van Herpen --v 4`

**Prompt universal:** `futuristic sculptural fashion in the style of Iris van Herpen, organic flowing 3D-printed forms, intricate otherworldly detailing, fusion of technology and nature`

---

### **Benoit B. Mandelbrot**

**Atmosfera e mood**

**Geometria fractal infinita** — (MidLibrary, Top 12 Most Extravagant Artists)

Matemático pioneiro dos fractais: padrões recursivos infinitos e formas espiraladas autossimilares — caos matemático visual.

**Paleta de cores** espectros psicodélicos em espirais

**Melhores usos:** fractais, abstração matemática, padrões infinitos

**MidJourney:** `[tema] by Benoit B. Mandelbrot --v 4`

**Prompt universal:** `fractal geometry art inspired by Benoit Mandelbrot, infinite recursive patterns, spiraling mathematical forms, psychedelic detail and self-similar structures`

---

### **Sandy Skoglund**

**Atmosfera e mood**

**Tableaux surreais encenados** — (MidLibrary, Top 12 Most Extravagant Artists)

Fotógrafa e artista de instalação americana: sets elaborados com objetos repetidos em cores vívidas contrastantes — sonho inquietante e cativante.

**Paleta de cores** monocromáticos vívidos contrastantes

**Melhores usos:** fotografia conceitual, cenas surreais encenadas, arte de instalação

**MidJourney:** `[tema] by Sandy Skoglund --v 4`

**Prompt universal:** `surreal staged photography in the style of Sandy Skoglund, elaborate monochromatic installation sets, repeated objects in vivid contrasting colors, dreamlike unsettling tableau`

---

### **Marcel Wanders**

**Atmosfera e mood**

**Design teatral caprichoso** — (MidLibrary, Top 12 Most Extravagant Artists)

Designer holandês: criações imaginativas com sensibilidade lúdica e teatral — materiais e formas não convencionais, fusão barroco-moderna.

**Paleta de cores** contrastes elegantes com ornamentação

**Melhores usos:** design de interiores, objetos surreais elegantes, decoração teatral

**MidJourney:** `[tema] by Marcel Wanders --v 4`

**Prompt universal:** `whimsical theatrical design in the style of Marcel Wanders, playful ornate forms, unconventional materials, baroque-modern fusion, elegant surreal objects`

---

### **Chris Ofili**

**Atmosfera e mood**

**Mixed media vibrante em camadas** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Artista britânico: superfícies texturizadas em camadas com glitter e resina — imagens gráficas ousadas com mitologia africana e caribenha.

**Paleta de cores** cores vibrantes com brilhos e texturas

**Melhores usos:** arte experimental, colagens vibrantes, temas afro-caribenhos

**MidJourney:** `[tema] by Chris Ofili --niji`

**Prompt universal:** `vibrant mixed media art in the style of Chris Ofili, layered textured surfaces with glitter and resin, bold graphic imagery, African and Caribbean mythology influences, experimental collage`

---

### **Abigail Larson**

**Atmosfera e mood**

**Gótico vitoriano delicado** — (MidLibrary, Top 13 Non-anime Styles in Niji)

Ilustradora americana: estética gótica e vitoriana assombrosamente bela — cenários sombrios atmosféricos, temas macabros e linhas delicadas.

**Paleta de cores** tons apagados sombrios com acentos delicados

**Melhores usos:** contos góticos, personagens sombrios elegantes, ilustração dark

**MidJourney:** `[tema] by Abigail Larson --niji`

**Prompt universal:** `gothic Victorian illustration in the style of Abigail Larson, dark atmospheric settings, macabre whimsy, delicate linework and muted colors, hauntingly beautiful characters`

---

### **Mark Catesby**

**Atmosfera e mood**

**Ilustração naturalista do séc. XVIII** — (MidLibrary, Top 19 Botanical & Floral)

Naturalista inglês: ilustrações altamente detalhadas e realistas de plantas e animais em estilo preciso e científico.

**Paleta de cores** tons naturais sobre papel envelhecido

**Melhores usos:** ilustração botânica, história natural, gravuras científicas

**MidJourney:** `[tema] by Mark Catesby --v 5`

**Prompt universal:** `18th century natural history illustration in the style of Mark Catesby, highly detailed realistic botanical and animal drawing, precise scientific rendering, aged paper tones`

---

### **Mary Blair**

**Atmosfera e mood**

**Modernismo Disney encantado** — (MidLibrary, Top 19 Botanical & Floral)

Artista da Disney (Alice, Cinderela): design modernista com maravilhamento infantil — formas chapadas ousadas e harmonia de cor vibrante.

**Paleta de cores** cores vibrantes em harmonia lúdica

**Melhores usos:** ilustração infantil, concept art retrô, cenas mágicas

**MidJourney:** `[tema] by Mary Blair --v 5`

**Prompt universal:** `mid-century modern illustration in the style of Mary Blair, playful childlike wonder, bold flat shapes and whimsical characters, vibrant color harmony, vintage Disney concept art charm`

---

### **Paul Barson**

**Atmosfera e mood**

**Abstração gestual vibrante** — (MidLibrary, Top 19 Botanical & Floral)

Pintor americano de abstrações coloridas: pinceladas gestuais ousadas, espontaneidade e movimento com cores contrastantes.

**Paleta de cores** cores brilhantes contrastantes

**Melhores usos:** abstração floral, energia e movimento, arte expressiva

**MidJourney:** `[tema] by Paul Barson --v 5`

**Prompt universal:** `vibrant abstract painting in the style of Paul Barson, bold gestural brushstrokes, bright contrasting colors, spontaneous energetic movement`

---

### **Yvonne Coomber**

**Atmosfera e mood**

**Prados floridos mágicos** — (MidLibrary, Top 19 Botanical & Floral)

Artista britânica de obras coloridas e caprichosas: flores silvestres cintilantes em respingos de cor, encantamento e alegria.

**Paleta de cores** respingos vibrantes multicoloridos

**Melhores usos:** campos floridos, atmosferas alegres, arte encantada

**MidJourney:** `[tema] by Yvonne Coomber --v 5`

**Prompt universal:** `whimsical flower meadow painting in the style of Yvonne Coomber, joyful splashes of vibrant color, enchanted glittering wildflowers, dreamy magical atmosphere`

---

### **Eyvind Earle**

**Atmosfera e mood**

**Paisagem estilizada misteriosa** — (MidLibrary, Top 19 Botanical & Floral)

Artista de fundo de A Bela Adormecida (Disney): silhuetas elegantes nítidas, nuances de luz e atmosfera, mistério e magia.

**Paleta de cores** gradientes luminosos com silhuetas escuras

**Melhores usos:** paisagens mágicas, florestas estilizadas, cenários de conto de fadas

**MidJourney:** `[tema] by Eyvind Earle --v 5`

**Prompt universal:** `stylized landscape in the style of Eyvind Earle, sharp elegant silhouettes and intricate detail, luminous gradients of light and atmosphere, magical mysterious mood, mid-century Disney background art`

---

### **Armand Guillaumin**

**Atmosfera e mood**

**Impressionismo vibrante** — (MidLibrary, Top 19 Botanical & Floral)

Impressionista francês: cores vivas e brilhantes, pincelada solta e gestual, efeitos de luz e atmosfera.

**Paleta de cores** cores vivas impressionistas

**Melhores usos:** jardins e paisagens, luz natural, impressionismo floral

**MidJourney:** `[tema] by Armand Guillaumin --v 5`

**Prompt universal:** `French Impressionist painting in the style of Armand Guillaumin, bright vivid colors and loose gestural brushwork, luminous light and atmosphere, landscape charm`

---

### **Alan Kenny**

**Atmosfera e mood**

**Gráfico pop ousado** — (MidLibrary, Top 19 Botanical & Floral)

Pintor e ilustrador: pop art, street art e influência de xilogravura japonesa — elementos gráficos fortes, humor e energia.

**Paleta de cores** cores chamativas e brilhantes

**Melhores usos:** ilustração gráfica, arte pop, composições divertidas

**MidJourney:** `[tema] by Alan Kenny --v 5`

**Prompt universal:** `bold graphic illustration in the style of Alan Kenny, pop art and street art influences, bright eye-catching colors, strong graphic shapes, playful energy`

---

### **A. J. Casson**

**Atmosfera e mood**

**Paisagem canadense serena** — (MidLibrary, Top 19 Botanical & Floral)

Membro do Group of Seven: cidadezinhas e paisagens rurais em estilo preciso, formas simplificadas e composição tranquila.

**Paleta de cores** tons naturais equilibrados

**Melhores usos:** paisagens serenas, natureza canadense, cenas rurais

**MidJourney:** `[tema] by A. J. Casson --v 5`

**Prompt universal:** `Canadian landscape painting in the style of A. J. Casson, Group of Seven aesthetic, crisp simplified forms, quiet rural scenes and skies, precise serene composition`

---

### **Chris Dyer**

**Atmosfera e mood**

**Psicodélico visionário** — (MidLibrary, Top 19 Botanical & Floral)

Artista peruano-canadense: arte psicodélica e visionária com influências indígenas, graffiti e street art — temas espirituais e místicos.

**Paleta de cores** cores ousadas brilhantes com padrões intrincados

**Melhores usos:** arte psicodélica, temas espirituais, padrões visionários

**MidJourney:** `[tema] by Chris Dyer --v 5`

**Prompt universal:** `psychedelic visionary art in the style of Chris Dyer, bold bright colors and intricate patterns, spiritual mystical themes, graffiti and indigenous art influences`

---

### **Zhang Daqian**

**Atmosfera e mood**

**Pintura chinesa clássica** — (MidLibrary, Top 19 Botanical & Floral)

Pintor e calígrafo chinês: domínio das técnicas clássicas com uso inovador de cor e pincelada — lavagens de tinta e cor salpicada.

**Paleta de cores** tintas tradicionais com cor salpicada inovadora

**Melhores usos:** pintura oriental, flores e paisagens clássicas, caligrafia

**MidJourney:** `[tema] by Zhang Daqian --v 5`

**Prompt universal:** `classical Chinese painting in the style of Zhang Daqian, traditional brushwork and calligraphy, innovative splashed color and ink washes, elegant natural subjects`

---

### **Margaret Preston**

**Atmosfera e mood**

**Modernismo botânico australiano** — (MidLibrary, Top 19 Botanical & Floral)

Pintora e gravurista australiana: interpretações modernistas de paisagens e flora nativa — formas geométricas ousadas em cores vívidas.

**Paleta de cores** cores vívidas em formas chapadas

**Melhores usos:** flores estilizadas, gravuras modernistas, arte botânica gráfica

**MidJourney:** `[tema] by Margaret Preston --v 5`

**Prompt universal:** `Australian modernist print in the style of Margaret Preston, bold geometric botanical forms, bright vivid colors, flat woodblock print aesthetic, native flowers`

---

### **Josephine Wall**

**Atmosfera e mood**

**Fantasia caprichosa encantada** — (MidLibrary, Top 19 Botanical & Floral)

Pintora britânica de obras fantásticas: cores brilhantes em redemoinho, detalhes intrincados e elementos místicos — magia e encantamento.

**Paleta de cores** cores brilhantes fluidas em redemoinho

**Melhores usos:** fantasia floral, deusas e fadas, cenas mágicas

**MidJourney:** `[tema] by Josephine Wall --v 5`

**Prompt universal:** `fantastical whimsical painting in the style of Josephine Wall, bright swirling colors and intricate details, mystical mythical elements, dreamy enchanted atmosphere`

---

### **Iznik Tiles**

**Atmosfera e mood**

**Azulejos otomanos ornamentados** — (MidLibrary, Top 19 Botanical & Floral)

Cerâmica turca dos séc. XVI–XVII: padrões florais e geométricos complexos em paleta rica — arte decorativa islâmica de alto artesanato.

**Paleta de cores** azul cobalto, turquesa e vermelho sobre branco

**Melhores usos:** padrões florais, azulejos decorativos, arte islâmica

**MidJourney:** `[tema] as Iznik tiles --v 5`

**Prompt universal:** `Ottoman Iznik ceramic tile design, complex floral and geometric patterns, vivid cobalt blue turquoise and red palette, glazed ceramic texture, Islamic decorative art`

---

### **Henri Rousseau**

**Atmosfera e mood**

**Selvas oníricas naïfs** — (MidLibrary, Top 19 Botanical & Floral)

Pintor francês autônomo: cenas de selva vívidas e oníricas com folhagem exuberante e animais exóticos em estilização plana imaginativa.

**Paleta de cores** verdes ricos e exuberantes

**Melhores usos:** selvas fantásticas, folhagem estilizada, realismo mágico

**MidJourney:** `[tema] by Henri Rousseau --v 5`

**Prompt universal:** `naive jungle painting in the style of Henri Rousseau, lush stylized foliage and exotic animals, flat dreamlike rendering, rich greens, imaginative primitive charm`

---

### **Ambrosius Bosschaert**

**Atmosfera e mood**

**Natureza-morta holandesa dourada** — (MidLibrary, Top 19 Botanical & Floral)

Pintor holandês do séc. XVII: buquês elaborados altamente detalhados e realistas, com jogos de luz e sombra para profundidade e textura.

**Paleta de cores** cores de joia sobre fundo escuro

**Melhores usos:** buquês clássicos, natureza-morta dramática, realismo floral

**MidJourney:** `[tema] by Ambrosius Bosschaert --v 5`

**Prompt universal:** `Dutch Golden Age floral still life in the style of Ambrosius Bosschaert, highly detailed realistic flower bouquet, dramatic light and shadow, dark background, jewel-like precision`

---

### **Rachel Ruysch**

**Atmosfera e mood**

**Natureza-morta barroca com vida** — (MidLibrary, Top 19 Botanical & Floral)

Pintora holandesa dos séc. XVII–XVIII: composições florais elaboradas com insetos e pequenas criaturas — realismo delicado e profundidade.

**Paleta de cores** tons ricos sobre fundos escuros profundos

**Melhores usos:** flores barrocas, detalhes com insetos, elegância clássica

**MidJourney:** `[tema] by Rachel Ruysch --v 5`

**Prompt universal:** `Dutch Baroque floral still life in the style of Rachel Ruysch, elaborate detailed flower composition with insects, rich dark background, delicate realism and depth`

---

### **Marjorie Miller**

**Atmosfera e mood**

**Charme lúdico ilustrado** — (MidLibrary, Top 19 Botanical & Floral)

Ilustradora americana de obras coloridas e caprichosas: humor, personagens animais e charme de livro de histórias.

**Paleta de cores** paleta alegre e brilhante

**Melhores usos:** ilustração infantil, personagens encantadores, cenas divertidas

**MidJourney:** `[tema] by Marjorie Miller --v 5`

**Prompt universal:** `colorful whimsical illustration in the style of Marjorie Miller, playful humor and charming animal characters, bright cheerful palette, lighthearted storybook feel`

---

### **Qi Baishi**

**Atmosfera e mood**

**Precisão e vitalidade chinesas** — (MidLibrary, Top 19 Botanical & Floral)

Pintor chinês: plantas e animais detalhados quase fotográficos com pincelada tradicional, caligrafia e uso inovador de cor e composição.

**Paleta de cores** tintas suaves com acentos vivos

**Melhores usos:** flora e fauna orientais, pintura tradicional, delicadeza natural

**MidJourney:** `[tema] by Qi Baishi --v 5`

**Prompt universal:** `Chinese ink and color painting in the style of Qi Baishi, detailed natural subjects with expressive brushwork, traditional calligraphy elements, delicate precision and vitality`

---

### **Aaron Horkey**

**Atmosfera e mood**

**Nanquim intrincado ornamentado** — (MidLibrary, Top 12 Most Extravagant Artists)

Ilustrador americano: desenhos a nanquim altamente detalhados com natureza, fantasia e tipografia ornamentada — atenção meticulosa ao detalhe.

**Paleta de cores** linhas finas em tons apagados e metálicos

**Melhores usos:** ilustração detalhada, pôsteres ornamentados, natureza fantástica

**MidJourney:** `[tema] by Aaron Horkey --v 4`

**Prompt universal:** `highly detailed pen and ink illustration in the style of Aaron Horkey, intricate ornate linework, nature and fantasy elements, elaborate decorative typography flourishes`

---

### **Choi Jeong-Hwa**

**Atmosfera e mood**

**Instalações kitsch coloridas** — (MidLibrary, Top 12 Most Extravagant Artists)

Artista sul-coreano: instalações lúdicas com objetos cotidianos (tigelas plásticas, guarda-chuvas, balões) — humor e beleza do ordinário.

**Paleta de cores** cores vibrantes saturadas kitsch

**Melhores usos:** instalações artísticas, acumulações coloridas, arte lúdica

**MidJourney:** `[tema] by Choi Jeong-Hwa --v 4`

**Prompt universal:** `colorful playful installation art in the style of Choi Jeong-Hwa, everyday plastic objects assembled into vibrant sculptures, bold kitsch colors, humorous celebration of ordinary things`

---

### **Book of Kells**

**Atmosfera e mood**

**Iluminação celta monumental** — (MidLibrary, Guia Manuscripts & Codices)

Manuscrito iluminado irlandês com entrelaçados e espirais intrincados — pigmentos vívidos com ouro e letras capitulares ornamentadas.

**Paleta de cores** pigmentos vívidos com dourados

**Melhores usos:** arte celta, iluminúra ornamentada, estética monastéria medieval

**MidJourney:** `Book of Kells page depicting [tema] --stylize 65`

**Prompt universal:** `illuminated Celtic manuscript page in Book of Kells style, intricate knotwork and spiral ornamentation, vivid pigments with gold, ornate initial letters, medieval Irish monastic art`

---

### **Codex Mendoza**

**Atmosfera e mood**

**Pictogramas astecas históricos** — (MidLibrary, Guia Manuscripts & Codices)

Um dos códices astecas mais significativos (c. 1541): símbolos pictográficos e figuras em cores planas — iconografia indígena mexicana.

**Paleta de cores** cores planas e fortes sobre papel amate

**Melhores usos:** arte pré-colombiana, iconografia histórica, narrativas visuais ancestrais

**MidJourney:** `page from Codex Mendoza depicting [tema] --stylize 75`

**Prompt universal:** `Aztec codex page in Codex Mendoza style, pictographic symbols and figures, flat bold colors on amate paper, indigenous Mexican iconography, historical tribute records aesthetic`

---

### **Medieval Bestiary**

**Atmosfera e mood**

**Bestiário iluminado do séc. XII** — (MidLibrary, Guia Manuscripts & Codices)

Compendios medievais de criaturas reais e míticas com escrita latina e bordas florais ornamentadas — folha de ouro sobre pergaminho.

**Paleta de cores** pergaminho envelhecido com acentos de folha de ouro

**Melhores usos:** criaturas míticas, enciclopédias fantásticas, estética medieval

**MidJourney:** `full-page scan of Medieval bestiary with drawing of [tema], illuminated manuscript style --stylize 75`

**Prompt universal:** `medieval illuminated bestiary page, mythical creature illustration with Latin script and ornate floral border, aged parchment, gold leaf accents, 12th century manuscript aesthetic`

---

### **Edo Period Codex**

**Atmosfera e mood**

**Bestiário japonês do período Edo** — (MidLibrary, Guia Manuscripts & Codices)

Códices japoneses com tinta e pigmentos minerais, anotações manuscritas, símbolos e molduras florais — perfeito para yokai e espíritos como Kitsune.

**Paleta de cores** tintas e pigmentos minerais sobre papel washi envelhecido

**Melhores usos:** criaturas do folclore japonês, yokai, estética oriental histórica

**MidJourney:** `Edo period codex bestiary page with notes, descriptions, marks, symbols and floral frame depicting [tema]`

**Prompt universal:** `Edo period Japanese codex bestiary page, ink and mineral pigment illustration with handwritten notes and symbols, mythical yokai creature, floral frame, aged washi paper aesthetic`

---

### **Madhubani Painting**

**Atmosfera e mood**

**Arte folk indiana geométrica** — (MidLibrary, Top 20 Fantastic Techniques V5)

Pintura tradicional de Mithila (Bihar, Índia): padrões geométricos intrincados e coloridos com pigmentos naturais, mitologia hindu e vida cotidiana em desenhos simétricos.

**Paleta de cores** cores vibrantes de pigmentos naturais

**Melhores usos:** arte folk, padrões simétricos, cenas mitológicas

**MidJourney:** `[tema] in Madhubani painting style --v 5`

**Prompt universal:** `traditional Indian Madhubani painting, intricate colorful geometric patterns, natural pigments on handmade paper, Hindu mythology motifs, symmetrical folk art design, fine detailed linework`

---

### **Phad Painting**

**Atmosfera e mood**

**Pergaminho narrativo do Rajastão** — (MidLibrary, Top 20 Fantastic Techniques V5)

Pintura em rolos de tecido do Rajastão: cores vibrantes e desenhos intrincados que narram lendas e mitologia hindu, tradicionalmente acompanhados de canções.

**Paleta de cores** vermelhos, ocres e amarelos vibrantes

**Melhores usos:** narrativas visuais, cenas épicas, arte devocional

**MidJourney:** `[tema] in Phad painting style --v 5`

**Prompt universal:** `traditional Rajasthani Phad scroll painting, vibrant colors and intricate designs, Hindu mythology narrative scenes, natural pigments on cloth, Indian folk storytelling art`

---

### **Alebrije**

**Atmosfera e mood**

**Criaturas fantásticas mexicanas** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte popular de Oaxaca: criaturas caprichosas que combinam características de vários animais em cores vivas e ousadas — papel machê ou madeira entalhada.

**Paleta de cores** cores vivas e ousadas em padrões intrincados

**Melhores usos:** criaturas fantásticas, arte mexicana, personagens híbridos

**MidJourney:** `[tema] in Alebrije style --v 5`

**Prompt universal:** `Mexican Alebrije folk art style, brightly colored whimsical fantastical creature, hybrid animal features, bold vivid patterns, Oaxacan carved wood and papier-mache aesthetic`

---

### **Pichwai Painting**

**Atmosfera e mood**

**Miniatura devocional ornamentada** — (MidLibrary, Top 20 Fantastic Techniques V5)

Pintura indiana do Rajastão usada como pano de fundo para divindades hindus: obras grandes e elaboradas com desenhos intrincados e cores ricas.

**Paleta de cores** cores ricas e profundas com detalhes dourados

**Melhores usos:** arte devocional, padrões ornamentados, cenas majestosas

**MidJourney:** `[tema] in Pichwai painting style --v 5`

**Prompt universal:** `Indian Pichwai painting style, large elaborate devotional art, intricate designs and rich colors, ornate detailed patterns, natural pigments on cloth, Hindu temple backdrop aesthetic`

---

### **Patachitra Painting**

**Atmosfera e mood**

**Linhas finas de Odisha** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte folk do leste da Índia: desenhos detalhados em tecido ou folha de palmeira, mitologia hindu em cores vibrantes e linhas finíssimas.

**Paleta de cores** cores vibrantes com contornos precisos

**Melhores usos:** ilustração mitológica, arte detalhada, estética artesanal

**MidJourney:** `[tema] in Patachitra painting style --v 5`

**Prompt universal:** `traditional Patachitra folk painting from Odisha India, intricate detailed designs, natural pigments on cloth or palm leaf, Hindu mythology scenes, vibrant colors and fine lines`

---

### **Warli Painting**

**Atmosfera e mood**

**Minimalismo tribal indiano** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte tribal de Maharashtra: desenhos geométricos simples em pigmento branco sobre fundo vermelho ou marrom, cenas do cotidiano e da natureza.

**Paleta de cores** branco sobre terracota e marrom

**Melhores usos:** arte minimalista, cenas cotidianas estilizadas, padrões tribais

**MidJourney:** `[tema] in Warli painting style --v 5`

**Prompt universal:** `Warli tribal painting style, simple geometric white pigment figures on red-brown earthen background, scenes of daily life and nature, minimalist Indian folk art`

---

### **Gond Painting**

**Atmosfera e mood**

**Linhas e pontos vibrantes** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte tribal de Madhya Pradesh: padrões intrincados e vibrantes criados com técnica única de linhas finas e pontos, retratando animais e pássaros.

**Paleta de cores** cores naturais intensas

**Melhores usos:** animais estilizados, padrões orgânicos, natureza vibrante

**MidJourney:** `[tema] in Gond painting style --v 5`

**Prompt universal:** `Gond tribal painting style, intricate vibrant patterns of fine lines and dots, animals and birds of the natural world, bold natural colors, Indian folk art`

---

### **Palekh**

**Atmosfera e mood**

**Miniatura laqueada russa** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte folk russa dos anos 1920: miniaturas em têmpera sobre laca preta retratando contos de fadas e folclore, com linhas finas e acentos em folha de ouro.

**Paleta de cores** cores vibrantes e ouro sobre laca preta

**Melhores usos:** contos de fadas, cenas folclóricas, arte ornamentada

**MidJourney:** `[tema] in Palekh style --v 5`

**Prompt universal:** `Russian Palekh lacquer miniature painting, Russian fairy tale and folklore scenes, fine lines and vibrant colors on black lacquer, gold leaf accents, intricate tempera craftsmanship`

---

### **Kalighat Painting**

**Atmosfera e mood**

**Folk de Calcutá estilizado** — (MidLibrary, Top 20 Fantastic Techniques V5)

Pintura folk do séc. XIX de Kolkata: linhas ousadas, cores brilhantes e figuras estilizadas com traços exagerados, do cotidiano à mitologia.

**Paleta de cores** cores brilhantes em aquarela

**Melhores usos:** figuras expressivas, arte folk narrativa, retratos estilizados

**MidJourney:** `[tema] in Kalighat painting style --v 5`

**Prompt universal:** `Kalighat folk painting style from 19th century Kolkata, bold lines and bright colors, stylized figures with exaggerated features, watercolor on paper, scenes of daily life and mythology`

---

### **Ebru**

**Atmosfera e mood**

**Marmorização turca fluida** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte tradicional turca de criar padrões coloridos sobre a água com pigmentos e transferi-los para papel ou tecido — fluidez orgânica e intrincada.

**Paleta de cores** redemoinhos multicoloridos fluidos

**Melhores usos:** texturas marmorizadas, abstração fluida, fundos orgânicos

**MidJourney:** `[tema] in Ebru style --v 5`

**Prompt universal:** `traditional Turkish Ebru paper marbling art, swirling colorful pigment patterns on water, fluid organic designs, intricate marbled texture`

---

### **Suminagashi**

**Atmosfera e mood**

**Marmorização zen japonesa** — (MidLibrary, Top 20 Fantastic Techniques V5)

Técnica japonesa de tinta flutuando na água transferida para o papel — padrões espiralados delicados, abstração minimalista e elegância sutil.

**Paleta de cores** monocromática sutil com linhas concêntricas

**Melhores usos:** abstração zen, texturas delicadas, fundos minimalistas

**MidJourney:** `[tema] in Suminagashi style --v 5`

**Prompt universal:** `Japanese Suminagashi ink marbling, floating ink patterns on water, delicate swirling concentric lines, minimalist zen abstract design, subtle monochrome elegance`

---

### **Marquetry**

**Atmosfera e mood**

**Marchetaria de madeira** — (MidLibrary, Top 20 Fantastic Techniques V5)

Técnica decorativa que forma imagens intrincadas encaixando pequenas peças de folheado de madeira — tons quentes naturais e artesanato refinado.

**Paleta de cores** tons quentes naturais de madeira

**Melhores usos:** texturas de madeira, artesanato refinado, arte decorativa

**MidJourney:** `[tema] in Marquetry style --v 5`

**Prompt universal:** `marquetry wood veneer inlay art, intricate picture formed from fitted wood pieces, warm natural wood grain tones, fine decorative craftsmanship`

---

### **Papier-mache**

**Atmosfera e mood**

**Escultura de papel artesanal** — (MidLibrary, Top 20 Fantastic Techniques V5)

Objetos tridimensionais em camadas de papel e cola — charme artesanal folk, textura visível e formas caprichosas pintadas em cores vivas.

**Paleta de cores** cores vivas pintadas sobre textura de papel

**Melhores usos:** esculturas lúdicas, máscaras, arte artesanal

**MidJourney:** `[tema] in Papier-mache style --v 5`

**Prompt universal:** `papier-mache sculpture style, layered paper craft with visible texture, handmade folk art charm, bright painted colors, whimsical three-dimensional forms`

---

### **Aubusson Tapestry**

**Atmosfera e mood**

**Tapeçaria francesa clássica** — (MidLibrary, Top 20 Fantastic Techniques V5)

Tapeçaria tecida à mão da cidade de Aubusson: cenas de mitologia, história e vida cotidiana em lã e seda com bordas ornamentais.

**Paleta de cores** tons ricos e apagados de fios naturais

**Melhores usos:** cenas clássicas, texturas têxteis, decoração histórica

**MidJourney:** `[tema] in Aubusson tapestry style --v 5`

**Prompt universal:** `Aubusson French woven tapestry style, intricate mythological and pastoral scenes, wool and silk texture, muted rich colors, classical ornamental borders`

---

### **Kirigami**

**Atmosfera e mood**

**Corte de papel japonês** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte japonesa de dobrar e cortar papel criando designs intrincados — esculturas de papel em camadas, padrões geométricos precisos e elegância limpa.

**Paleta de cores** papel branco ou tons suaves em camadas

**Melhores usos:** arte em camadas, cartões pop-up, geometria delicada

**MidJourney:** `[tema] in Kirigami style --v 5`

**Prompt universal:** `Japanese kirigami paper cutting art, intricate folded and cut paper design, delicate layered paper sculpture, precise geometric patterns, clean minimal elegance`

---

### **Pyrography**

**Atmosfera e mood**

**Pirogravura em madeira** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte de queimar desenhos na madeira com ferramenta aquecida — tons sépia e marrons quentes sobre o veio natural da madeira, detalhe rústico artesanal.

**Paleta de cores** sépia e marrons queimados sobre madeira clara

**Melhores usos:** arte rústica, retratos em madeira, padrões queimados

**MidJourney:** `[tema] in Pyrography style --v 5`

**Prompt universal:** `pyrography wood burning art, detailed design burned into wood, warm sepia and brown tones, natural wood grain background, handcrafted rustic detail`

---

### **Stained Glass**

**Atmosfera e mood**

**Vitral luminoso** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte de vidro colorido unido por tiras de chumbo — brilho luminoso retroiluminado, desenhos pictóricos intrincados e artesanato estilo catedral.

**Paleta de cores** vidros vibrantes saturados com linhas escuras

**Melhores usos:** janelas de catedral, arte luminosa, cenas sagradas ou fantásticas

**MidJourney:** `[tema] in Stained glass style --v 5`

**Prompt universal:** `stained glass window art, vivid colored glass pieces joined by dark lead lines, luminous backlit glow, intricate pictorial design, cathedral-style craftsmanship`

---

### **Origami**

**Atmosfera e mood**

**Dobradura japonesa** — (MidLibrary, Top 20 Fantastic Techniques V5)

Arte tradicional japonesa de dobrar papel — formas facetadas nítidas, geometria limpa e composição minimalista delicada.

**Paleta de cores** papel em tons puros e suaves

**Melhores usos:** animais geométricos, minimalismo, arte de papel

**MidJourney:** `[tema] in Origami style --v 5`

**Prompt universal:** `origami paper folding art style, crisp folded paper forms, clean geometric facets, minimalist composition, delicate Japanese paper craft`

---

### **Wood Carving**

**Atmosfera e mood**

**Entalhe em madeira** — (MidLibrary, Top 20 Fantastic Techniques V5)

Artesanato tradicional de esculpir madeira — relevos intrincados com detalhes de goiva visíveis, veios naturais e tons quentes de madeira.

**Paleta de cores** tons quentes naturais de madeira

**Melhores usos:** esculturas, relevos ornamentados, arte artesanal

**MidJourney:** `[tema] in Wood carving style --v 5`

**Prompt universal:** `wood carving sculpture style, intricately carved wooden relief, visible chisel detail and natural grain, warm timber tones, artisanal craftsmanship`

---

### **Ivory Carving**

**Atmosfera e mood**

**Entalhe em marfim** — (MidLibrary, Top 20 Fantastic Techniques V5)

Estética de escultura em marfim — peças lisas e pálidas com detalhes em miniatura intrincados e artesanato antigo delicado.

**Paleta de cores** tons creme e marfim suaves

**Melhores usos:** esculturas delicadas, miniaturas, estética antiga

**MidJourney:** `[tema] in Ivory carving style --v 5`

**Prompt universal:** `ivory carving style, finely carved smooth pale sculpture, intricate miniature detail, soft cream tones, delicate antique craftsmanship`

---

### **Sumi-e Drawing**

**Atmosfera e mood**

**Tinta japonesa zen** — (MidLibrary, Top 19 Botanical & Floral)

Pintura monocromática em tinta preta: pincelada expressiva mínima, espaço negativo e equilíbrio zen — fluidez e espontaneidade em temas naturais.

**Paleta de cores** preto e cinzas sobre papel claro

**Melhores usos:** flores e paisagens zen, minimalismo oriental, caligrafia

**MidJourney:** `[tema] as Sumi-e drawing --v 5`

**Prompt universal:** `Japanese Sumi-e ink painting, monochromatic black ink brushwork, expressive minimal strokes, negative space and zen balance, natural subjects with fluid spontaneity`

---

### **Jan Van Eyck**

**Atmosfera e mood**

**Realismo flamengo luminoso** — (MidLibrary, Top 15 Renaissance Styles)

Realismo excepcional e detalhe microscópico com técnicas de óleo revolucionárias — novos padrões de cor e textura que moldaram o Renascimento Nórdico.

**Paleta de cores** cores profundas, luminosas e preciosas

**Melhores usos:** retratos ricos, interiores detalhados, realismo precioso

**MidJourney:** `[tema] by Jan Van Eyck --v 6`

**Prompt universal:** `early Flemish oil painting in the style of Jan Van Eyck, exceptional realism and microscopic detail, luminous jewel-like colors, rich textures of fabric and glass, precise light rendering, Northern Renaissance masterwork`

---

### **Leonardo Da Vinci**

**Atmosfera e mood**

**Gênio renascentista universal** — (MidLibrary, Top 15 Renaissance Styles)

Sfumato suave, anatomia perfeita e profundidade atmosférica — a fusão de precisão científica e genialidade artística do maior polimata da época.

**Paleta de cores** tons terrosos com sfumato atmosférico

**Melhores usos:** retratos clássicos, estudos anatômicos, desenhos técnicos

**MidJourney:** `[tema] by Leonardo Da Vinci --v 6`

**Prompt universal:** `High Renaissance painting in the style of Leonardo Da Vinci, soft sfumato shading, masterful anatomy and proportion, enigmatic expression, earthy tones with atmospheric depth, scientific precision and artistic genius`

---

### **Michelangelo**

**Atmosfera e mood**

**Monumentalidade escultural épica** — (MidLibrary, Top 15 Renaissance Styles)

Corpos poderosos com anatomia escultural em composições épicas e monumentais — a grandiosidade dos afrescos da Capela Sistina.

**Paleta de cores** tons de afresco vibrantes

**Melhores usos:** figuras heroicas, cenas épicas, arte monumental

**MidJourney:** `[tema] by Michelangelo --v 6`

**Prompt universal:** `High Renaissance fresco in the style of Michelangelo, powerful muscular figures with sculptural anatomy, epic monumental composition, dynamic poses, vibrant fresco colors, Sistine Chapel grandeur`

---

### **Raphael**

**Atmosfera e mood**

**Clareza e equilíbrio perfeitos** — (MidLibrary, Top 15 Renaissance Styles)

Composições admiradas pela clareza e equilíbrio, com domínio profundo de perspectiva e geometria — como na célebre “Escola de Atenas”.

**Paleta de cores** cores harmoniosas e luminosas

**Melhores usos:** composições equilibradas, retratos graciosos, cenas clássicas

**MidJourney:** `[tema] by Raphael --v 6`

**Prompt universal:** `High Renaissance painting in the style of Raphael, perfect clarity and balance, harmonious composition with masterful perspective and geometry, graceful idealized figures, luminous harmonious colors`

---

### **Piero della Francesca**

**Atmosfera e mood**

**Harmonia matemática serena** — (MidLibrary, Top 15 Renaissance Styles)

Abordagem matemática da composição com design harmonioso — atenção meticulosa ao detalhe e profundo senso de equilíbrio contemplativo.

**Paleta de cores** tons claros e serenos

**Melhores usos:** cenas serenas, composições geométricas, arte contemplativa

**MidJourney:** `[tema] by Piero della Francesca --v 6`

**Prompt universal:** `early Renaissance painting in the style of Piero della Francesca, mathematical geometric composition, serene balanced harmony, pale luminous colors, still dignified figures, meticulous perspective and calm monumentality`

---

### **Titian**

**Atmosfera e mood**

**Cor veneziana sensual** — (MidLibrary, Top 15 Renaissance Styles)

Revolucionou o uso da cor com tons ricos e sensuais e pinceladas soltas — estilo dinâmico e emocionalmente carregado na transição para o Barroco.

**Paleta de cores** tons ricos e quentes venezianos

**Melhores usos:** retratos dinâmicos, cenas emocionais, cor expressiva

**MidJourney:** `[tema] by Titian --v 6`

**Prompt universal:** `Venetian Renaissance painting in the style of Titian, rich sensuous color palette, loose expressive brushwork, dynamic emotionally charged composition, warm golden flesh tones, dramatic painterly atmosphere`

---

### **Henri-Edmond Cross**

**Atmosfera e mood**

**Pontilhismo luminoso mediterrâneo** — (MidLibrary, Top 20 Overlooked Styles)

Pontos vibrantes de cor pura em mosaico neoimpressionista — luz mediterrânea luminosa e vibração cromática harmoniosa.

**Paleta de cores** cores puras vibrantes em pontos

**Melhores usos:** paisagens luminosas, cenas serenas, texturas pontilhadas

**MidJourney:** `[tema] by Henri-Edmond Cross --v 6`

**Prompt universal:** `neo-impressionist pointillist painting in the style of Henri-Edmond Cross, vibrant mosaic-like dots of pure color, luminous Mediterranean light, harmonious color vibration, serene landscape atmosphere`

---

### **Coles Phillips**

**Atmosfera e mood**

**Elegância gráfica “fadeaway”** — (MidLibrary, Top 20 Overlooked Styles)

Ilustração americana dos anos 1910 com a técnica “fadeaway girl”: a figura se funde com o fundo plano — elegância gráfica refinada.

**Paleta de cores** cores planas com fusão figura-fundo

**Melhores usos:** capas vintage, ilustração elegânte, design gráfico retrô

**MidJourney:** `[tema] by Coles Phillips --v 6`

**Prompt universal:** `elegant 1910s American illustration in the style of Coles Phillips, fadeaway girl technique with figure merging into flat background, clean graphic shapes, refined feminine elegance, vintage magazine cover art`

---

### **Andre Kertesz**

**Atmosfera e mood**

**Fotografia poética do cotidiano** — (MidLibrary, Top 20 Overlooked Styles)

Momentos íntimos e espontâneos em preto e branco com composição geométrica e ângulos inesperados — beleza lírica do dia a dia.

**Paleta de cores** preto e branco com gradações suaves

**Melhores usos:** fotografia poética, cenas urbanas íntimas, P&B artístico

**MidJourney:** `[tema] by Andre Kertesz --v 6`

**Prompt universal:** `poetic black and white photography in the style of Andre Kertesz, intimate candid moments, geometric composition with unexpected angles, soft tonal gradations, lyrical everyday beauty`

---

### **Alessandro Gottardo**

**Atmosfera e mood**

**Metáfora visual minimalista** — (MidLibrary, Top 20 Overlooked Styles)

Ilustração conceitual com metáforas visuais inteligentes — paleta apagada com textura suave e generoso espaço negativo, narrativa poética silenciosa.

**Paleta de cores** tons apagados com grão suave

**Melhores usos:** ilustração editorial, conceitos abstratos, storytelling visual

**MidJourney:** `[tema] by Alessandro Gottardo --v 6`

**Prompt universal:** `minimalist conceptual illustration in the style of Alessandro Gottardo, clever visual metaphor, muted palette with soft grain texture, generous negative space, quiet poetic storytelling`

---

### **Arthur Dove**

**Atmosfera e mood**

**Abstração orgânica da natureza** — (MidLibrary, Top 20 Overlooked Styles)

Formas naturais simplificadas em ritmos abstratos — conexão espiritual com a natureza em abstração fluida e suave.

**Paleta de cores** tons terrosos apagados

**Melhores usos:** abstração orgânica, natureza estilizada, arte contemplativa

**MidJourney:** `[tema] by Arthur Dove --v 6`

**Prompt universal:** `early American abstract painting in the style of Arthur Dove, organic natural forms simplified into rhythmic shapes, earthy muted palette, spiritual connection to nature, soft flowing abstraction`

---

### **Michael Kenna**

**Atmosfera e mood**

**Paisagem minimalista etérea** — (MidLibrary, Top 20 Overlooked Styles)

Fotografia P&B de longa exposição com atmosfera enevoada — composições simples e rígidas de beleza meditativa e solitária.

**Paleta de cores** preto e branco com faixa tonal delicada

**Melhores usos:** paisagens minimalistas, fotografia meditativa, cenas enevoadas

**MidJourney:** `[tema] by Michael Kenna --v 6`

**Prompt universal:** `minimalist black and white landscape photography in the style of Michael Kenna, long exposure with misty ethereal atmosphere, stark simple compositions, delicate tonal range, meditative solitary beauty`

---

### **Paul Corfield**

**Atmosfera e mood**

**Campos idílicos estilizados** — (MidLibrary, Top 20 Overlooked Styles)

Colinas ondulantes suaves com curvas caprichosas e luz sonhadora — charme pacífico do campo em cores harmoniosas.

**Paleta de cores** cores vibrantes e harmoniosas

**Melhores usos:** paisagens idílicas, cenários acolhedores, ilustração de natureza

**MidJourney:** `[tema] by Paul Corfield --v 6`

**Prompt universal:** `stylized idyllic landscape painting in the style of Paul Corfield, smooth rolling hills with whimsical curves, soft dreamy light, vibrant harmonious colors, peaceful countryside charm`

---

### **Hsiao Ron Cheng**

**Atmosfera e mood**

**Retrato pastel etéreo** — (MidLibrary, Top 20 Overlooked Styles)

Ilustração digital delicada com paleta pastel pálida — retratos oníricos surreais de beleza silenciosa e melancólica.

**Paleta de cores** pastéis pálidos e delicados

**Melhores usos:** retratos delicados, beleza etérea, ilustração fashion

**MidJourney:** `[tema] by Hsiao Ron Cheng --v 6`

**Prompt universal:** `ethereal digital illustration in the style of Hsiao Ron Cheng, delicate pale pastel palette, dreamy surreal portrait, soft minimal shading, quiet melancholic beauty`

---

### **Paul Strand**

**Atmosfera e mood**

**Modernismo fotográfico direto** — (MidLibrary, Top 20 Overlooked Styles)

Formas geométricas nítidas e closes ousados com tonalidade P&B rica — realismo digno e beleza abstrata em objetos cotidianos.

**Paleta de cores** preto e branco de tonalidade rica

**Melhores usos:** fotografia modernista, abstração do cotidiano, retratos diretos

**MidJourney:** `[tema] by Paul Strand --v 6`

**Prompt universal:** `modernist straight photography in the style of Paul Strand, sharp geometric forms and bold close-up composition, rich black and white tonality, dignified realism, abstract beauty in everyday objects`

---

### **Bernard Buffet**

**Atmosfera e mood**

**Expressionismo gráfico melancólico** — (MidLibrary, Top 20 Overlooked Styles)

Linhas angulares pretas e rígidas com figuras alongadas e melancólicas — modernismo francês pós-guerra de forte carga gráfica.

**Paleta de cores** cinzas apagados com acentos nítidos

**Melhores usos:** arte expressionista, retratos gráficos, mood melancólico

**MidJourney:** `[tema] by Bernard Buffet --v 6`

**Prompt universal:** `expressionist painting in the style of Bernard Buffet, stark angular black outlines, elongated melancholic figures, muted greys with sharp accents, graphic post-war French modernism`

---

### **Harold Edgerton**

**Atmosfera e mood**

**Movimento congelado estroboscópico** — (MidLibrary, Top 20 Overlooked Styles)

Fotografia de alta velocidade que congela frações de segundo — respingos de leite e impactos em precisão científica com energia dinâmica.

**Paleta de cores** fundos escuros com o sujeito iluminado em flash

**Melhores usos:** movimento congelado, respingos e impactos, fotografia científica

**MidJourney:** `[tema] by Harold Edgerton --v 6`

**Prompt universal:** `high-speed strobe photography in the style of Harold Edgerton, frozen split-second motion, liquid splashes and dynamic impacts, dramatic dark background, scientific precision and dynamic energy`

---

### **Bert Stern**

**Atmosfera e mood**

**Glamour fotográfico anos 60** — (MidLibrary, Top 20 Overlooked Styles)

Retratos glamourosos de celebridades com poses íntimas e brincalhonas — a elegância hollywoodiana da era Marilyn Monroe.

**Paleta de cores** cores saturadas ousadas ou luz high-key

**Melhores usos:** retratos glamourosos, moda icônica, estética anos 60

**MidJourney:** `[tema] by Bert Stern --v 6`

**Prompt universal:** `iconic 1960s fashion photography in the style of Bert Stern, glamorous celebrity portrait, bold saturated colors or high-key lighting, intimate playful poses, Hollywood era elegance`

---

### **Edward Burne-Jones**

**Atmosfera e mood**

**Romantismo pré-rafaelita** — (MidLibrary, Top 20 Overlooked Styles)

Figuras etéreas e andróginas em mitologia medieval romântica — beleza sonhadora e melancólica com drapeados intrincados.

**Paleta de cores** tons de joia apagados

**Melhores usos:** cenas míticas, romance medieval, beleza etérea

**MidJourney:** `[tema] by Edward Burne-Jones --v 6`

**Prompt universal:** `Pre-Raphaelite painting in the style of Edward Burne-Jones, ethereal androgynous figures, medieval romantic mythology, muted jewel tones, dreamlike melancholic beauty, intricate drapery`

---

### **Francois Boucher**

**Atmosfera e mood**

**Rococó francês galânte** — (MidLibrary, Top 20 Overlooked Styles)

Cenas pastorais e mitológicas brincalhonas com elegância decorativa ornamentada — o charme sensual e gracioso do século XVIII.

**Paleta de cores** pastéis rosados e azuis suaves

**Melhores usos:** cenas românticas, decoração clássica, charme histórico

**MidJourney:** `[tema] by Francois Boucher --v 6`

**Prompt universal:** `French Rococo painting in the style of Francois Boucher, playful pastoral and mythological scenes, soft pink and blue pastel palette, ornate decorative elegance, sensuous graceful figures, 18th century charm`

---

### **Aubrey Beardsley**

**Atmosfera e mood**

**Art nouveau decadente P&B** — (MidLibrary, Top 20 Overlooked Styles)

Contraste ousado de preto e branco com linhas sinuosas fluidas — padrões decorativos ornamentados e figuras elegantemente decadentes.

**Paleta de cores** preto e branco de contraste máximo

**Melhores usos:** ilustração art nouveau, line art dramático, estética fin-de-siècle

**MidJourney:** `[tema] by Aubrey Beardsley --v 6`

**Prompt universal:** `Art Nouveau ink illustration in the style of Aubrey Beardsley, bold black and white contrast, sinuous flowing lines, ornate decorative patterns, elegant decadent figures, fin-de-siecle drama`

---

### **Lorna Simpson**

**Atmosfera e mood**

**Arte conceitual fotográfica** — (MidLibrary, Top 20 Overlooked Styles)

Retratos evocativos em P&B com elementos de colagem — camadas de significado sobre identidade e memória em composição minimalista e poética.

**Paleta de cores** preto e branco com fragmentos colados

**Melhores usos:** arte conceitual, retratos com narrativa, colagem poética

**MidJourney:** `[tema] by Lorna Simpson --v 6`

**Prompt universal:** `conceptual photographic art in the style of Lorna Simpson, evocative black and white portraiture with collage elements, layered meaning on identity and memory, minimal elegant composition, poetic fragmentation`

---

### **Christopher Balaskas**

**Atmosfera e mood**

**Concept art sci-fi vibrante** — (MidLibrary, Top 20 Overlooked Styles)

Paisagens sci-fi arrebatadoras com cor saturada ousada e luz dramática — pincelada pictórica em escala épica e atmosférica retrofuturista.

**Paleta de cores** cores saturadas ousadas com luz dramática

**Melhores usos:** concept art, paisagens sci-fi, capas de ficção científica

**MidJourney:** `[tema] by Christopher Balaskas --v 6`

**Prompt universal:** `vibrant digital concept art in the style of Christopher Balaskas, sweeping sci-fi landscapes, bold saturated color and dramatic light, painterly brushwork, epic atmospheric scale, retro-futuristic mood`

---

### **Dan Hillier**

**Atmosfera e mood**

**Colagem vitoriana surreal** — (MidLibrary, Top 20 Overlooked Styles)

Gravuras vitorianas ornamentadas com hibridismos surreais — figuras humano-animais com tentáculos em elegância gótica P&B e simbolismo místico.

**Paleta de cores** preto e branco de gravura

**Melhores usos:** arte gótica surreal, simbolismo oculto, ilustração vitoriana

**MidJourney:** `[tema] by Dan Hillier --v 6`

**Prompt universal:** `surreal Victorian engraving collage in the style of Dan Hillier, ornate etched linework, human-animal hybrid figures, black and white gothic elegance, mystical occult symbolism`

---

### **August Macke**

**Atmosfera e mood**

**Expressionismo alemão luminoso** — (MidLibrary, Top 20 Overlooked Styles)

Harmonia de cor luminosa com figuras simplificadas em cenas urbanas ensolaradas — a paleta alegre e vibrante do movimento Der Blaue Reiter.

**Paleta de cores** cores alegres e vibrantes

**Melhores usos:** cenas urbanas coloridas, expressionismo leve, arte vibrante

**MidJourney:** `[tema] by August Macke --v 6`

**Prompt universal:** `German Expressionist painting in the style of August Macke, luminous color harmony, simplified figures in sunlit urban scenes, soft geometric forms, joyful vibrant palette, Der Blaue Reiter movement`

---

### **Bruce Munro**

**Atmosfera e mood**

**Campos de luz imersivos** — (MidLibrary, Top 20 Overlooked Styles)

Instalações de milhares de esferas de fibra ótica brilhando na paisagem — campos de luz crepusculares com iluminação cambiante e atmosfera mágica.

**Paleta de cores** luzes cambiantes sonhadoras no crepúsculo

**Melhores usos:** instalações de luz, cenários mágicos, arte imersiva

**MidJourney:** `[tema] by Bruce Munro --v 6`

**Prompt universal:** `immersive light installation in the style of Bruce Munro, thousands of glowing fiber optic spheres in landscape, twilight field of light, dreamy color-shifting illumination, magical serene atmosphere`

---

### **Voynich Manuscript**

**Atmosfera e mood**

**Enigma indecifrável do séc. XV** — (MidLibrary, Guia Manuscripts & Codices)

Manuscrito medieval em escrita jamais decifrada com diagramas de botânica, astronomia e anatomia — um dos maiores mistérios da história.

**Paleta de cores** tintas medievais e aquarelas apagadas sobre pergaminho envelhecido

**Melhores usos:** artefatos misteriosos, diagramas arcanos, estética medieval enigmática

**MidJourney:** `Voynich manuscript page depicting [tema] --stylize 75`

**Prompt universal:** `15th century Voynich manuscript page, undeciphered script and mysterious diagrams, botanical astronomical illustrations, aged parchment, medieval ink and muted watercolor, enigmatic scholarly artifact`

---

### **Codex Seraphinianus**

**Atmosfera e mood**

**Enciclopédia surreal inventada** — (MidLibrary, Guia Manuscripts & Codices)

Criado por Luigi Serafini nos anos 1970: escrita assêmica intencional com criaturas bizarras e máquinas perplexas — diagrama científico onírico.

**Paleta de cores** lápis de cor delicados em tons variados

**Melhores usos:** mundos surreais, criaturas imaginárias, diagramas fantásticos

**MidJourney:** `[tema] from Codex Seraphinianus page --stylize 75`

**Prompt universal:** `page from Codex Seraphinianus, surreal invented encyclopedia, asemic script, bizarre imaginative creatures and machines, delicate colored pencil illustration, dreamlike scientific diagram aesthetic`

---

### **Ethereal Minimal Reference**

**Atmosfera e mood**

**Leveza etérea dissolvida** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Luz difusa e suave com formas delicadas quase invisíveis — atmosfera onírica e sem peso, composição ultra limpa.

**Paleta de cores** tons claros, brancos e névoas

**Melhores usos:** bem-estar, spa, visuais oníricos leves

**MidJourney:** `--sref 4135597898 --sw 1000`

**Prompt universal:** `ethereal minimalist scene, soft diffused light, pale airy tones and misty whites, delicate barely-there forms, dreamlike weightless atmosphere, ultra clean serene composition`

---

### **Construct Deviance**

**Atmosfera e mood**

**Construtivismo desviado** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Geometria assimétrica com desequilíbrio deliberado — design flat ousado com toque modernista experimental.

**Paleta de cores** neutros com acentos de cores primárias

**Melhores usos:** design gráfico experimental, capas, arte modernista

**MidJourney:** `--sref 3243143700 --sw 1000`

**Prompt universal:** `constructivist minimalist composition, asymmetrical geometric shapes, deliberate imbalance, neutral palette with primary color accents, bold flat design, experimental modernist edge`

---

### **Vibrant Whimshift Movement**

**Atmosfera e mood**

**Movimento lúdico vibrante** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas fluidas simples com sensação dinâmica de movimento — espírito caprichoso e moderno com espaço negativo limpo.

**Paleta de cores** cores vivas e alegres

**Melhores usos:** animação, conteúdo jovem, gráficos dinâmicos

**MidJourney:** `--sref 270540111 --sw 1000`

**Prompt universal:** `vibrant playful minimalist design, dynamic sense of movement, bright cheerful colors, simple flowing shapes, energetic composition with clean negative space, whimsical modern spirit`

---

### **Luminous Balance Realm**

**Atmosfera e mood**

**Luz e equilíbrio perfeito** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas simples e harmoniosas banhadas em luz suave e brilhante — atmosfera tranquila e radiante de equilíbrio visual.

**Paleta de cores** tons luminosos suaves

**Melhores usos:** meditação, harmonia, branding zen

**MidJourney:** `--sref 3747600 --sw 1000`

**Prompt universal:** `luminous minimalist composition, perfect visual balance, soft glowing light, gentle tonal palette, simple harmonious forms, tranquil radiant atmosphere`

---

### **Tranquil Minimalist Harmony**

**Atmosfera e mood**

**Calma harmônica essencial** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas simples e equilibradas com luz natural suave — quietude meditativa em composições refinadas e discretas.

**Paleta de cores** neutros tranquilos

**Melhores usos:** bem-estar, interiores, mindfulness

**MidJourney:** `--sref 174190711 --sw 1000`

**Prompt universal:** `tranquil minimalist harmony, calm neutral palette, simple balanced forms, soft natural light, meditative stillness, refined understated composition`

---

### **Monochrome Echo Sculpture**

**Atmosfera e mood**

**Escultura monocromática em eco** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas que se repetem como ecos, superfícies foscas e volumes abstratos tridimensionais — quietude de galeria de arte.

**Paleta de cores** escala de cinza escultural com sombras sutis

**Melhores usos:** arte 3D, formas abstratas, design de objeto

**MidJourney:** `--sref 1281045485 --sw 1000`

**Prompt universal:** `monochrome sculptural minimalism, repeating echoing forms, smooth matte surfaces, greyscale palette with subtle shadows, abstract three-dimensional volume, gallery-like stillness`

---

### **Ethereal Minimalist Elegance**

**Atmosfera e mood**

**Elegância etérea refinada** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas delicadas e refinadas com luminosidade pálida — luxo discreto e sofisticado com espaço negativo gracioso.

**Paleta de cores** tons claros sofisticados e luminosos

**Melhores usos:** moda minimalista, luxo discreto, editoriais

**MidJourney:** `--sref 3925914770 --sw 1000`

**Prompt universal:** `ethereal minimalist elegance, refined delicate forms, soft luminous pale palette, sophisticated understated luxury, graceful negative space, serene high-end aesthetic`

---

### **Serene Minimalist Essence**

**Atmosfera e mood**

**Essência pura e serena** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

O mínimo essencial: um elemento focal único em vasto espaço vazio — mood contemplativo e composição imaculada.

**Paleta de cores** tons neutros suaves

**Melhores usos:** branding clean, mindfulness, design essencial

**MidJourney:** `--sref 2961163763 --sw 1000`

**Prompt universal:** `serene minimalist essence, stripped to purest forms, soft neutral tones, single focal element in vast empty space, quiet contemplative mood, pristine clean composition`

---

### **Cubist Neovogue**

**Atmosfera e mood**

**Cubismo contemporâneo fashion** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Figuras fragmentadas em planos geométricos abstratos — blocos de cor modernos com elegância ousada e fashion-forward.

**Paleta de cores** blocos de cor modernos e contrastantes

**Melhores usos:** moda gráfica, retratos estilizados, arte moderna

**MidJourney:** `--sref 2082952891 --sw 1000`

**Prompt universal:** `cubist minimalist neovogue style, fragmented geometric figure, modern color blocking, flat abstract planes, fashion-forward artistic composition, bold contemporary elegance`

---

### **Pop-Art Cadence**

**Atmosfera e mood**

**Ritmo pop-art minimal** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas icônicas simples com repetição gráfica rítmica — design flat limpo com impacto visual marcante e cadência retrô-moderna.

**Paleta de cores** cores pop saturadas

**Melhores usos:** pôsteres, música, gráficos retrô-modernos

**MidJourney:** `--sref 3682160454 --sw 1000`

**Prompt universal:** `minimalist pop-art rhythm, bold saturated colors, simple iconic shapes with graphic repetition, flat clean design, playful retro-modern cadence, striking visual impact`

---

### **Pastel Retrofuturist Vision**

**Atmosfera e mood**

**Retrofuturismo pastel** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas futuristas elegantes e simplificadas em tons de doce — atmosfera sci-fi nostálgica e sonhadora com mood utópico gentil.

**Paleta de cores** pastéis com toque futurista

**Melhores usos:** tech leve, sci-fi soft, visuais nostálgico-futuristas

**MidJourney:** `--sref 2673824429 --sw 1000`

**Prompt universal:** `pastel retrofuturist minimalist vision, soft candy-toned palette, sleek simplified futuristic forms, dreamy nostalgic sci-fi atmosphere, clean uncluttered composition, gentle utopian mood`

---

### **Liquid Whimsy**

**Atmosfera e mood**

**Fluidez lúdica orgânica** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas orgânicas fluidas que parecem derreter, com gradientes suaves — energia leve, sonhadora e divertida.

**Paleta de cores** cores suaves e fluidas

**Melhores usos:** formas orgânicas, arte abstrata leve, branding criativo

**MidJourney:** `--sref 2677418099 --sw 1000`

**Prompt universal:** `liquid whimsical minimalism, fluid organic melting shapes, smooth gradients, soft playful palette, abstract flowing composition, lighthearted dreamy energy`

---

### **Zen Linear Fusion**

**Atmosfera e mood**

**Zen de traço contínuo** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Linhas únicas fluidas e contínuas sobre fundos neutros — simplicidade meditativa com elegância de inspiração oriental.

**Paleta de cores** neutros com traço escuro de tinta

**Melhores usos:** line art, logotipos, arte meditativa

**MidJourney:** `--sref 996905225 --sw 1000`

**Prompt universal:** `zen minimalist line art, continuous flowing single lines, neutral background with dark ink strokes, meditative simplicity, balanced negative space, calm eastern-inspired elegance`

---

### **Pastel Ethereal Dreamfields**

**Atmosfera e mood**

**Campos oníricos em pastel** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Paisagens suaves e enevoadas com céus em gradiente e elementos minúsculos em vastos espaços abertos — serenidade de sonho.

**Paleta de cores** pastéis etéreos e tons de doce apagados

**Melhores usos:** paisagens suaves, visuais de sonho, conteúdo delicado

**MidJourney:** `--sref 3371524171 --sw 1000`

**Prompt universal:** `pastel ethereal dreamfields, soft hazy landscape minimalism, gentle gradient skies, muted candy tones, vast open space with tiny elements, tranquil dreamlike serenity`

---

### **Etheroptic Illumina**

**Atmosfera e mood**

**Luz cinematográfica etérea** — (MidLibrary, Top 10 Cinematic SREF)

Iluminação óptica dramática com raios de luz e brilhos de lente — profundidade atmosférica e mood onírico de fotograma de filme.

**Paleta de cores** tons luminosos com sombras profundas

**Melhores usos:** cenas de filme, atmosferas oníricas, sci-fi surreal

**MidJourney:** `--sref 3769261565 --sw 1000`

**Prompt universal:** `cinematic scene with ethereal optical illumination, dramatic light rays and lens glow, atmospheric depth, film still composition, luminous tones with deep shadows, surreal dreamlike movie mood`

---

### **NeonCortex Architecture**

**Atmosfera e mood**

**Arquitetura neon cyberpunk** — (MidLibrary, Top 10 Cinematic SREF)

Estruturas futuristas com acentos neon brilhantes contra formas urbanas escuras — perspectiva dramática e clima noir de alta tecnologia.

**Paleta de cores** neons vibrantes sobre estruturas escuras

**Melhores usos:** sci-fi urbano, cenários futuristas, thrillers tech

**MidJourney:** `--sref 2854203644 --sw 1000`

**Prompt universal:** `cinematic neon-lit architectural scene, futuristic cyberpunk structures, glowing neon accents against dark urban forms, dramatic perspective, moody atmospheric film still, high-tech noir ambiance`

---

### **Sepia Enchantment**

**Atmosfera e mood**

**Encanto sépia de cinema mudo** — (MidLibrary, Top 10 Cinematic SREF)

Estética de filme do início dos anos 1900 com grão suave e vinheta — atmosfera nostálgica encantada da era do cinema mudo.

**Paleta de cores** sépia e dourados envelhecidos

**Melhores usos:** cenas de época, nostalgia 1900s, estética de filme mudo

**MidJourney:** `--sref 69666734 --sw 1000`

**Prompt universal:** `cinematic sepia-toned scene, vintage early 1900s film aesthetic, aged golden-brown palette, soft grain and vignette, enchanted nostalgic atmosphere, silent movie era storytelling`

---

### **Neonstructural Dynamics**

**Atmosfera e mood**

**Dinâmica estrutural neon** — (MidLibrary, Top 10 Cinematic SREF)

Energia geométrica ousada com linhas brilhantes contra fundos escuros — composição de ação com movimento dramático futurista.

**Paleta de cores** neons vibrantes, linhas estruturais luminosas

**Melhores usos:** cenas de ação, sci-fi dinâmico, visuais energéticos

**MidJourney:** `--sref 2190592951 --sw 1000`

**Prompt universal:** `cinematic dynamic scene with neon structural elements, bold geometric energy, vibrant glowing lines against dark backdrop, action-packed composition, futuristic film still with dramatic motion`

---

### **Retro-Futuristic Machinescape**

**Atmosfera e mood**

**Paisagem de máquinas retrofuturista** — (MidLibrary, Top 10 Cinematic SREF)

Maquinário vintage intrincado e estruturas industriais em escala épica — influências steampunk e dieselpunk em fotogramas atmosféricos.

**Paleta de cores** metálicos e tons industriais quentes

**Melhores usos:** sci-fi retrô, mundos mecânicos, concept art

**MidJourney:** `--sref 3094236681 --sw 1000`

**Prompt universal:** `cinematic retro-futuristic machinescape, intricate vintage machinery and industrial structures, steampunk dieselpunk influences, warm metallic tones, epic scale composition, atmospheric sci-fi film still`

---

### **Chromatic Fantasia**

**Atmosfera e mood**

**Fantasia cromática teatral** — (MidLibrary, Top 10 Cinematic SREF)

Cenas fantásticas e oníricas com espectro de cores vívido e iluminação teatral rica — construção de mundos imersiva e colorida.

**Paleta de cores** espectro vívido e saturado

**Melhores usos:** fantasia, musicais, mundos vibrantes

**MidJourney:** `--sref 2662058036 --sw 1000`

**Prompt universal:** `cinematic chromatic fantasia, vivid saturated color spectrum, fantastical dreamlike scenes, rich theatrical lighting, whimsical surreal film still, immersive colorful world-building`

---

### **Surlayer Narrative**

**Atmosfera e mood**

**Narrativa surreal em camadas** — (MidLibrary, Top 10 Cinematic SREF)

Simbolismo onírico e misterioso com personagens e cenários enigmáticos — atmosfera inspirada em David Lynch, cinema autoral.

**Paleta de cores** tons enigmáticos e contrastantes

**Melhores usos:** narrativas surreais, mistério, cinema autoral

**MidJourney:** `--sref 1474328911 --sw 1000`

**Prompt universal:** `cinematic surreal layered narrative scene, mysterious dreamlike symbolism, enigmatic characters and settings, David Lynch inspired atmosphere, contrasting moody tones, arthouse film still`

---

### **Monochrome Arcana Pavilion**

**Atmosfera e mood**

**Arcana neo-expressionista P&B** — (MidLibrary, Top 10 Cinematic SREF)

Contrastes rígidos de preto e branco com sombras dramáticas e composição angular — estética de filme mudo neo-expressionista alemão.

**Paleta de cores** preto e branco expressionista de alto contraste

**Melhores usos:** estética de filme mudo alemão, mistério gótico, P&B dramático

**MidJourney:** `--sref 2476944343 --sw 1000`

**Prompt universal:** `cinematic monochrome scene, German neo-expressionist silent film aesthetic, stark black and white contrasts, arcane mysterious pavilion setting, dramatic shadows and angular composition, haunting vintage atmosphere`

---

### **Radionic Harmony**

**Atmosfera e mood**

**Harmonia retro-tech serena** — (MidLibrary, Top 10 Cinematic SREF)

Estética de retro-tecnologia com ondas de energia suaves e brilhantes — composição equilibrada e atmosfera futurista serena.

**Paleta de cores** tons equilibrados com brilhos tecnológicos

**Melhores usos:** sci-fi elegante, retro-tech, cenas harmônicas

**MidJourney:** `--sref 2376998380 --sw 1000`

**Prompt universal:** `cinematic radionic harmony scene, retro-technology aesthetic, balanced harmonious composition, soft glowing energy waves, elegant sci-fi film still, serene futuristic atmosphere`

---

### **Vivid Fractal Joyride**

**Atmosfera e mood**

**Passeio fractal vívido** — (MidLibrary, Top 10 Cinematic SREF)

Padrões coloridos explosivos com movimento enérgico e detalhes caleidoscópicos — fotograma de ação divertido e eletrizante.

**Paleta de cores** cores vívidas fractais e caleidoscópicas

**Melhores usos:** cenas psicodélicas, ação divertida, visuais explosivos

**MidJourney:** `--sref 877133173 --sw 1000`

**Prompt universal:** `cinematic vivid fractal joyride, explosive colorful patterns, dynamic energetic motion, psychedelic kaleidoscopic detail, playful action-packed film still, exhilarating vibrant atmosphere`

---

### **Masaccio**

**Atmosfera e mood**

**Realismo pioneiro do início do Renascimento** — (MidLibrary, Top 15 Renaissance Styles)

Figuras realistas com perspectiva pioneira e emoção em cenas religiosas — a transição do gótico para o Renascimento.

**Paleta de cores** tons de afresco terrosos

**Melhores usos:** cenas sacras, retratos solenes, releituras clássicas

**MidJourney:** `[tema] depicted by Masaccio --v 6`

**Prompt universal:** `early Renaissance fresco painting style of Masaccio, realistic figures with pioneering linear perspective, solemn religious atmosphere, earthy fresco tones, soft volumetric shading, quattrocento Italian art`

---

### **El Greco**

**Atmosfera e mood**

**Misticismo maneirista intenso** — (MidLibrary, Top 15 Renaissance Styles)

Figuras alongadas e expressivas com cores vibrantes e intensidade espiritual — composições dramáticas e místicas com luz sobrenatural.

**Paleta de cores** azuis e vermelhos dramáticos com luz sobrenatural

**Melhores usos:** cenas místicas, retratos dramáticos, releituras espirituais

**MidJourney:** `[tema] by El Greco --v 6`

**Prompt universal:** `dramatic Mannerist painting in the style of El Greco, elongated expressive figures, vibrant otherworldly colors, spiritual intensity, swirling composition, stormy skies and supernatural light, Spanish Renaissance`

---

### **Ambrosius Benson**

**Atmosfera e mood**

**Elegância flamenga refinada** — (MidLibrary, Top 15 Renaissance Styles)

Cores ricas, detalhe meticuloso e execução elegante — do religioso e mitológico a retratos graciosos.

**Paleta de cores** tons ricos e profundos

**Melhores usos:** retratos renascentistas, cenas elegantes, releituras clássicas

**MidJourney:** `[tema] by Ambrosius Benson --v 6`

**Prompt universal:** `Flemish Renaissance painting in the style of Ambrosius Benson, rich deep colors, meticulous detail, elegant graceful figures, soft sfumato lighting, refined portrait composition`

---

### **Hieronymus Bosch**

**Atmosfera e mood**

**Surrealismo medieval fantástico** — (MidLibrary, Top 15 Renaissance Styles)

Composições complexas e surreais repletas de criaturas bizarras e temas morais profundos — o mestre de “O Jardim das Delícias Terrenas”.

**Paleta de cores** tons medievais com acentos fantásticos

**Melhores usos:** cenas fantásticas, alegorias, mundos surreais povoados

**MidJourney:** `[tema] painted by Hieronymus Bosch --v 6`

**Prompt universal:** `surreal medieval painting in the style of Hieronymus Bosch, bizarre hybrid creatures, intricate crowded composition, moral allegory, fantastical landscapes, detailed Northern Renaissance oil painting`

---

### **Sandro Botticelli**

**Atmosfera e mood**

**Graça linear italiana** — (MidLibrary, Top 15 Renaissance Styles)

Elegância e graça da figura humana com linhas fluidas e mitologia poética — um dos pilares do Renascimento italiano.

**Paleta de cores** tons suaves e delicados

**Melhores usos:** figuras graciosas, mitologia, beleza clássica idealizada

**MidJourney:** `[tema] by Sandro Botticelli --v 6`

**Prompt universal:** `Italian Renaissance painting in the style of Sandro Botticelli, graceful linear figures, flowing drapery and hair, poetic mythological scenes, delicate pastel tones, elegant idealized beauty`

---

### **Caravaggio**

**Atmosfera e mood**

**Drama de luz e sombra** — (MidLibrary, Top 15 Renaissance Styles)

Chiaroscuro intenso com contraste ousado entre luz e sombra — realismo cru e teatral em cenas de intensidade emocional.

**Paleta de cores** sombras profundas com luz dramática focal

**Melhores usos:** cenas dramáticas, retratos intensos, realismo teatral

**MidJourney:** `[tema] by Caravaggio --v 6`

**Prompt universal:** `dramatic Baroque painting in the style of Caravaggio, intense chiaroscuro with bold light and shadow contrast, raw realism, theatrical composition, dark background with spotlight illumination`

---

### **Antonello da Messina**

**Atmosfera e mood**

**Realismo a óleo siciliano** — (MidLibrary, Top 15 Renaissance Styles)

Realismo meticuloso com atenção extrema ao detalhe — retratos com arquitetura clássica e paisagens naturais da Sicília ao fundo.

**Paleta de cores** tons naturais luminosos

**Melhores usos:** retratos realistas, cenas mediterrâneas, detalhe fino

**MidJourney:** `[tema] by Antonello da Messina --v 6`

**Prompt universal:** `15th century oil painting in the style of Antonello da Messina, meticulous realism and fine detail, luminous natural tones, classical architecture backdrop, serene Sicilian landscape, Renaissance portrait mastery`

---

### **Carlo Crivelli**

**Atmosfera e mood**

**Ornamentação escultural dourada** — (MidLibrary, Top 15 Renaissance Styles)

Devoção ao detalhe ornamentado: folha de ouro, drapeados elaborados, joias e elementos arquitetônicos como pano de fundo espiritual.

**Paleta de cores** dourados ricos e cores intensas

**Melhores usos:** cenas ornamentadas, iconografia rica, decoração dramática

**MidJourney:** `[tema] by Carlo Crivelli --v 6`

**Prompt universal:** `ornate 15th century Italian painting in the style of Carlo Crivelli, gold leaf and elaborate decoration, sculptural detail in drapery and jewelry, rich intense colors, dramatic spiritual scenes with architectural framing`

---

### **Albrecht Durer**

**Atmosfera e mood**

**Precisão gráfica alemã** — (MidLibrary, Top 15 Renaissance Styles)

Precisão técnica e detalhes intrincados com domínio de anatomia, perspectiva e luz — fusão dos Renascimentos alemão e italiano, rica em simbolismo e alegoria.

**Paleta de cores** tons de gravura detalhados

**Melhores usos:** gravuras, ilustração simbólica, estudos detalhados

**MidJourney:** `[tema] by Albrecht Durer --v 6`

**Prompt universal:** `Northern Renaissance artwork in the style of Albrecht Durer, technical precision and intricate engraved detail, masterful anatomy and perspective, symbolic allegorical elements, fine linework, German Renaissance craftsmanship`

---

### **1960s fashion**

**Atmosfera e mood**

**Mod e pop art** — (MidLibrary, Genres + Art Movements)

Composições simétricas com enquadramento fechado, linhas limpas e estética mod — energia jovem e otimista da revolução cultural dos anos 1960.

**Paleta de cores** cores brilhantes e saturadas, padrões geométricos

**Melhores usos:** campanhas vibrantes, moda retrô, artes com padrões gráficos

**MidJourney:** `[tema] in 1960s fashion style --v 6.1`

**Prompt universal:** `1960s mod fashion photography, bold geometric patterns, playful vibrant design, symmetrical centered composition, tight framing, bright saturated colors, youthful energetic pop art mood`

---

### **1950s fashion**

**Atmosfera e mood**

**Glamour pós-guerra** — (MidLibrary, Genres + Art Movements)

Retratos posados e simétricos com silhueta ampulheta, saias rodadas, luvas e pérolas — sofisticação realista com toque de nostalgia hollywoodiana.

**Paleta de cores** tons pastel com acentos vívidos, alto contraste e foco suave

**Melhores usos:** editoriais clássicos, retratos elegantes, estética pin-up refinada

**MidJourney:** `[tema] in 1950s fashion style --v 6.1`

**Prompt universal:** `1950s fashion photography, hourglass silhouette with full skirt and fitted bodice, gloves hat and pearls, pastel tones with vivid accents, high contrast soft focus, posed symmetrical composition, nostalgic post-war glamour`

---

### **Rave fashion**

**Atmosfera e mood**

**Energia neon futurista** — (MidLibrary, Genres + Art Movements)

Estética sci-fi surreal com render digital 3D, materiais refletivos e texturas holográficas — a energia vibrante e misteriosa da cultura rave e da vida noturna futurista.

**Paleta de cores** neon e iridescente, materiais holográficos

**Melhores usos:** música eletrônica, festas e eventos, visuais futuristas de alto impacto

**MidJourney:** `[tema] in rave fashion style --v 6.1`

**Prompt universal:** `rave fashion, futuristic sci-fi surreal aesthetic, neon and iridescent color palette, holographic reflective materials, dynamic centered composition with layered textures, 3D digital rendering, energetic nightlife atmosphere`

---

### **2010s fashion**

**Atmosfera e mood**

**Streetwear eclético** — (MidLibrary, Genres + Art Movements)

Colagem digital vívida com silhuetas dinâmicas, elementos oversized e combinações inesperadas — atmosfera lúdica e experimental entre athleisure, normcore e revival dos anos 90/2000.

**Paleta de cores** cores vívidas, padrões intricados

**Melhores usos:** moda urbana contemporânea, conteúdo jovem, visuais experimentais

**MidJourney:** `[tema] in 2010s fashion style --v 6.1`

**Prompt universal:** `2010s fashion, vibrant eclectic streetwear, digital collage with bold surreal elements, vivid colors and intricate patterns, dynamic silhouettes with oversized layered pieces, playful whimsical experimental mood`

---

### **Goth fashion**

**Atmosfera e mood**

**Elegância sombria** — (MidLibrary, Genres + Art Movements)

Retratos detalhados e expressivos com peças de cabeça ornamentadas e rendas intrincadas — melancolia romântica com inspiração vitoriana e literatura gótica.

**Paleta de cores** monocromático, pretos e cinzas profundos

**Melhores usos:** estética dark romântica, editoriais alternativos, Halloween sofisticado

**MidJourney:** `[tema] in goth fashion style --v 6.1`

**Prompt universal:** `goth fashion portrait, dark romantic aesthetic, black clothing with intricate lace and ornate headpieces, Victorian inspiration, monochrome palette of deep blacks and greys, mysterious melancholic mood, detailed digital illustration`

---

### **Scene fashion**

**Atmosfera e mood**

**Explosão colorida anos 2000** — (MidLibrary, Genres + Art Movements)

Retratos próximos vívidos e expressivos com acessórios ecléticos em camadas e adereços florais — espírito jovem, rebelde e imaginativo entre punk, emo e indie.

**Paleta de cores** cores brilhantes e contrastantes

**Melhores usos:** conteúdo jovem e ousado, nostalgia Y2K, retratos criativos

**MidJourney:** `[tema] in scene fashion style --v 6.1`

**Prompt universal:** `scene fashion portrait, early 2000s youth subculture, bright contrasting colors, bold hairstyle with floral headpiece, layered eclectic accessories, textured fabrics, close-up expressive composition, whimsical rebellious energy`

---

### **2020s fashion**

**Atmosfera e mood**

**Vanguarda contemporânea** — (MidLibrary, Genres + Art Movements)

Silhuetas oversized e designs assimétricos com tecidos texturizados e materiais mistos — estética avant-garde que mistura pop art, futurismo e cultura urbana.

**Paleta de cores** neon vívido, padrões geométricos

**Melhores usos:** moda conceitual, campanhas modernas, visuais urbanos experimentais

**MidJourney:** `[tema] in 2020s fashion style --v 6.1`

**Prompt universal:** `2020s fashion, avant-garde experimental aesthetic, vivid neon colors and geometric patterns, oversized asymmetrical silhouettes, textured mixed materials, dynamic composition with movement and energy, futuristic pop art urban culture`

---

### **Baggy fashion**

**Atmosfera e mood**

**Volume dark fantasy** — (MidLibrary, Genres + Art Movements)

Silhuetas volumosas e tecidos em camadas com assimetria e linhas fluidas — atmosfera misteriosa e etérea com referências góticas e trajes históricos.

**Paleta de cores** monocromático, vermelhos profundos e verdes suaves

**Melhores usos:** moda conceitual dramática, editoriais dark, visuais de fantasia

**MidJourney:** `[tema] in baggy fashion style --v 6.1`

**Prompt universal:** `baggy fashion, dark fantasy aesthetic, voluminous oversized silhouettes with layered flowing fabrics, asymmetrical composition emphasizing silhouette and texture, monochrome palette with deep reds and muted greens, mysterious ethereal gothic mood`

---

### **Animalier fashion**

**Atmosfera e mood**

**Luxo selvagem** — (MidLibrary, Genres + Art Movements)

Figuras centrais com peças de cabeça elaboradas e motivos animais com joias — opulência dramática, simétrica e misteriosa com influências barrocas, góticas e vitorianas.

**Paleta de cores** tons escuros e terrosos, detalhes ricos

**Melhores usos:** alta-costura, branding de luxo, visuais dramáticos e exóticos

**MidJourney:** `[tema] in animalier fashion style --v 6.1`

**Prompt universal:** `animalier high fashion, surreal fantasy aesthetic, bold animal prints and motifs, elaborate jeweled headpiece, dark earthy color palette, balanced symmetrical composition, dramatic opulent atmosphere, baroque gothic Victorian influences`

---

### **Cybergoth fashion**

**Atmosfera e mood**

**Futurismo industrial** — (MidLibrary, Genres + Art Movements)

Retratos em close com ângulos dinâmicos, adereços mecânicos e cibernéticos, óculos e respiradores — fusão enigmática de goth com cyberpunk.

**Paleta de cores** monocromático com acentos metálicos e neon

**Melhores usos:** visuais sci-fi, música eletrônica dark, personagens futuristas

**MidJourney:** `[tema] in cybergoth fashion style --v 6.1`

**Prompt universal:** `cybergoth fashion, dark sci-fi aesthetic, mechanical cybernetic enhancements with goggles and intricate headgear, monochrome palette with metallic and neon accents, close-up portrait with dynamic angle, futuristic enigmatic industrial mood`

---

### **Dashiki fashion**

**Atmosfera e mood**

**Orgulho e cor da África Ocidental** — (MidLibrary, Genres + Art Movements)

Figuras centrais em equilíbrio simétrico com penteados tradicionais e joias ornamentadas contra fundos urbanos — fusão vibrante de moda contemporânea com raízes étnicas.

**Paleta de cores** multicolorida vívida, motivos geométricos marcantes

**Melhores usos:** celebração cultural, moda étnica, retratos vibrantes e expressivos

**MidJourney:** `[tema] in dashiki fashion style --v 6.1`

**Prompt universal:** `dashiki fashion portrait, vibrant West African garment with bold geometric embroidered patterns, multicolored vivid palette, traditional hairstyle and ornate jewelry, urban background, dynamic symmetrical composition, cultural pride and identity`

---

### **Rocker fashion**

**Atmosfera e mood**

**Atitude punk rock** — (MidLibrary, Genres + Art Movements)

Retratos em close com jaquetas de couro cravejadas e cabelos espetados, contra fundos urbanos com grafite — estética rebelde e crua dos anos 1970.

**Paleta de cores** monocromático com contrastes de preto e vermelho, acentos metálicos

**Melhores usos:** música e bandas, visuais rebeldes, editoriais urbanos

**MidJourney:** `[tema] in rocker fashion style --v 6.1`

**Prompt universal:** `rocker punk fashion portrait, studded leather jacket and spiked hair, gritty urban graffiti background, monochrome palette with striking black and red contrasts, metallic accents, close-up dynamic pose, rebellious 1970s punk attitude`

---

### **Psychobilly fashion**

**Atmosfera e mood**

**Punk rockabilly de terror** — (MidLibrary, Genres + Art Movements)

Ilustrações digitais de alto contraste com personagens dramáticos em poses dinâmicas — tatuagens, acessórios vintage e maquiagem marcante entre pin-up e gótico.

**Paleta de cores** monocromático, vermelhos vibrantes e pretos profundos

**Melhores usos:** estética alternativa retrô, pôsteres de banda, personagens marcantes

**MidJourney:** `[tema] in psychobilly fashion style --v 6.1`

**Prompt universal:** `psychobilly fashion, punk rockabilly fusion, pompadour hairstyle and leather jacket, tattoos vintage accessories and bold makeup, high contrast vivid imagery, monochrome with vibrant reds and deep blacks, gothic pin-up style, rebellious nostalgic mood`

---

### **1940s fashion**

**Atmosfera e mood**

**Elegância prática de guerra** — (MidLibrary, Genres + Art Movements)

Retratos em grupo posados e simétricos com ternos alinhados, ombreiras, chapéus e luvas — charme nostálgico realista da América pós-guerra.

**Paleta de cores** pastéis e tons terrosos, elementos monocromáticos e sépia

**Melhores usos:** editoriais vintage, projetos históricos, retratos clássicos

**MidJourney:** `[tema] in 1940s fashion style --v 6.1`

**Prompt universal:** `1940s fashion, tailored suit with padded shoulders and knee-length skirt, hats and gloves, pastel and earth tones with sepia accents, posed symmetrical group portrait, elegant sophisticated nostalgic mood, detailed realistic rendering`

---

### **Grunge fashion**

**Atmosfera e mood**

**Rebeldia Seattle anos 90** — (MidLibrary, Genres + Art Movements)

Visual documental realista com camisas de flanela, jeans rasgados e texturas desgastadas em ambientes urbanos — individualismo cru e não conformista da cena grunge.

**Paleta de cores** tons terrosos apagados e preto

**Melhores usos:** moda urbana autêntica, estética anos 90, retratos despojados

**MidJourney:** `[tema] in grunge fashion style --v 6.1`

**Prompt universal:** `grunge fashion, 1990s Seattle aesthetic, flannel shirt ripped jeans and combat boots, layered clothing with distressed textures, muted earthy tones and black, gritty urban environment, realistic documentary style, moody rebellious nonconformist attitude`

---

### **Emo fashion**

**Atmosfera e mood**

**Introspecção anos 2000** — (MidLibrary, Genres + Art Movements)

Retratos em close com expressões intensas e melancólicas, maquiagem pesada, piercings e franjas marcantes — individualidade e expressão emocional em composições assimétricas.

**Paleta de cores** monocromático preto e cinza com acentos rosa

**Melhores usos:** estética alternativa jovem, nostalgia 2000s, retratos expressivos

**MidJourney:** `[tema] in emo fashion style --v 6.1`

**Prompt universal:** `emo fashion portrait, early 2000s subculture, dark expressive aesthetic, heavy eyeliner piercings and bold dyed hairstyle, tight jeans band t-shirt and studded belt, monochrome black and grey with pink accents, moody introspective urban atmosphere`

---

### **Beachwear fashion**

**Atmosfera e mood**

**Verão tropical onírico** — (MidLibrary, Genres + Art Movements)

Técnicas pictóricas vívidas destacam padrões florais e tecidos esvoaçantes contra cenários naturais — atmosfera despreocupada e ensolarada com toque de fantasia.

**Paleta de cores** brilhante e tropical, contrastes quentes com brilhos de sol

**Melhores usos:** moda praia e resort, conteúdo de verão, visuais tropicais leves

**MidJourney:** `[tema] in beachwear fashion style --v 6.1`

**Prompt universal:** `beachwear fashion, dreamy painterly style, flowing fabrics with floral patterns, natural beach backdrop, bright tropical color palette with warm contrasts and sunlit highlights, elegant dynamic poses, carefree tropical atmosphere`

---

### **Cosplay fashion**

**Atmosfera e mood**

**Fantasia hiper-realista** — (MidLibrary, Genres + Art Movements)

Renders digitais de alta resolução com mapeamento de textura intrincado e modelagem 3D — retratos imersivos de personagens com trajes elaborados e expressões marcantes.

**Paleta de cores** matizes ricos e tons contrastantes

**Melhores usos:** personagens de games e anime, eventos geek, arte de fantasia

**MidJourney:** `[tema] in cosplay fashion style --v 6.1`

**Prompt universal:** `cosplay fashion, hyper-realistic fantasy character portrait, elaborate detailed costume, high-resolution digital rendering with intricate textures, close-up with expressive facial features, rich hues and contrasting tones, dramatic adventurous atmosphere`

---

### **1920s fashion**

**Atmosfera e mood**

**Espírito flapper art déco** — (MidLibrary, Genres + Art Movements)

Trajes detalhados com rendas intrincadas, plissados e bordados, chapéus e luvas em arranjos de grupo — o chique libertário e vibrante dos Loucos Anos 20.

**Paleta de cores** tons suaves, sépia e pastéis

**Melhores usos:** festas Gatsby, editoriais retrô, projetos art déco

**MidJourney:** `[tema] in 1920s fashion style --v 6.1`

**Prompt universal:** `1920s flapper fashion, art deco elegance, intricate lace pleating and embroidery, hats gloves and floral embellishments, sepia tones and soft pastels, posed group arrangement, chic sophisticated Roaring Twenties atmosphere`

---

### **Rapture Pop Fusion**

**Atmosfera e mood**

**Minimalismo pop vibrante** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas geométricas simples com energia pop — acentos de cor vibrantes sobre fundos limpos, design flat e generoso espaço negativo.

**Paleta de cores** cores pop vibrantes sobre fundos neutros limpos

**Melhores usos:** gráficos ousados, capas, branding jovem e moderno

**MidJourney:** `--sref 2372558512 --sw 1000`

**Prompt universal:** `ultra minimalist graphic composition, bold pop art influence, simple geometric shapes, vibrant accent colors on clean background, flat design, generous negative space, playful modern energy`

---

### **Minimalist Monochrome Architecture**

**Atmosfera e mood**

**Arquitetura monocromática pura** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Linhas geométricas limpas e jogo dramático de luz e sombra — elegância estrutural serena em escala de cinza.

**Paleta de cores** escala de cinza, alto contraste de luz e sombra

**Melhores usos:** arquitetura, editoriais sóbrios, fotografia estrutural

**MidJourney:** `--sref 1677920710 --sw 1000`

**Prompt universal:** `minimalist monochrome architectural composition, clean geometric lines, dramatic light and shadow interplay, greyscale palette, vast negative space, serene structural elegance`

---

### **Serene Pastrosa Microtopia**

**Atmosfera e mood**

**Micromundos serenos em pastel** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Pequenas formas simplificadas flutuando em vastos espaços vazios — gradientes suaves e atmosfera calma e onírica.

**Paleta de cores** pastéis suaves e delicados

**Melhores usos:** ilustração leve, bem-estar, cenários delicados

**MidJourney:** `--sref 3150216390 --sw 1000`

**Prompt universal:** `serene minimalist micro-world scene, soft pastel palette, tiny simplified forms in vast empty space, gentle gradients, calm dreamy atmosphere, ultra clean composition`

---

### **Gentlesoft Geometric Ethos**

**Atmosfera e mood**

**Geometria suave e acolhedora** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas arredondadas e gentis com texturas foscas — elegância moderna discreta em composições equilibradas e calmas.

**Paleta de cores** tons neutros quentes e suaves

**Melhores usos:** branding acolhedor, design de produto, interiores

**MidJourney:** `--sref 2826667815 --sw 1000`

**Prompt universal:** `soft geometric minimalist design, rounded gentle shapes, warm neutral muted tones, smooth matte textures, balanced calm composition, understated modern elegance`

---

### **Monochrome Chronique**

**Atmosfera e mood**

**Narrativa gráfica em P&B** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas simples e ousadas em preto e branco de alto contraste — estilo editorial gráfico com mood narrativo atemporal.

**Paleta de cores** preto e branco de alto contraste

**Melhores usos:** editoriais, ilustração de imprensa, pôsteres

**MidJourney:** `--sref 3059491453 --sw 1000`

**Prompt universal:** `monochrome minimalist illustration, high contrast black and white, bold simple shapes, graphic editorial style, generous white space, timeless narrative mood`

---

### **Crimson Contrast Union**

**Atmosfera e mood**

**Vermelho como único acento** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Base monocromática neutra com blocos de vermelho carmim marcante — impacto gráfico poderoso com espaço negativo dramático.

**Paleta de cores** neutros com vermelho carmim vibrante

**Melhores usos:** identidade visual marcante, pôsteres, destaques gráficos

**MidJourney:** `--sref 2833029185 --sw 1000`

**Prompt universal:** `minimalist composition with striking crimson red accent, neutral monochrome base, bold color blocking, clean geometric forms, dramatic negative space, powerful graphic impact`

---

### **Monochrome Visionary**

**Atmosfera e mood**

**Visão monocromática futurista** — (MidLibrary, Top 21 Ultra-Minimalist SREF)

Formas abstratas simplificadas com gradientes tonais sutis — estética futurista discreta e atmosfera contemplativa.

**Paleta de cores** monocromático com gradientes sutis

**Melhores usos:** arte conceitual sóbria, sci-fi minimalista, visuais abstratos

**MidJourney:** `--sref 395151849 --sw 1000`

**Prompt universal:** `visionary monochrome minimalist art, abstract simplified forms, subtle tonal gradients, futuristic understated aesthetic, expansive negative space, contemplative atmosphere`

---

### **Pastel Fantasies**

**Atmosfera e mood**

**Fantasias pastel** — por Melis (Lummi, categoria Illustration)

Cenas mágicas e lúdicas com clima de livro de histórias

**Paleta de cores** Pastéis sonhadores, luz aérea e delicada

**Melhores usos:** storytelling lúdico, conteúdo acolhedor, visualizações e imaginação guiada

**MidJourney:** `--sref 118073848 --sw 1000`

**Prompt universal:** `Pastel fantasy illustration, dreamy soft colors, whimsical magical scenes, gentle airy light, fairytale imagination, tender storybook aesthetic`

---

### **Pop Surrealism**

**Atmosfera e mood**

**Surrealismo pop** — por Gizem Akdag (Lummi, categoria Illustration)

Justaposições imaginativas com acabamento de ilustração contemporânea polida

**Paleta de cores** Cores contemporâneas ousadas

**Melhores usos:** metáforas visuais criativas, conteúdo que surpreende, ilustrações editoriais

**MidJourney:** `--sref 3895563330 --sw 1000`

**Prompt universal:** `Pop surrealism illustration, playful surreal imagery with bold contemporary colors, imaginative juxtapositions, lowbrow art influence, polished modern illustration`

---

### **Nature Frames**

**Atmosfera e mood**

**Molduras naturais** — por Gizem Akdag (Lummi, categoria Editorial)

Sujeito enquadrado por folhas, flores e galhos — natureza integrada à composição

**Paleta de cores** Paleta orgânica e fresca

**Melhores usos:** retratos com natureza, conteúdo corpo-mente-natureza, editoriais elegantes

**MidJourney:** `--sref 3131880576 --sw 1000`

**Prompt universal:** `Editorial composition framed by natural elements, subject seen through leaves flowers or branches, fresh organic palette, elegant nature-integrated photography style`

---

### **Octopus Zen**

**Atmosfera e mood**

**Zen fluido** — por Dogan Ural (Lummi, categoria Editorial)

Composições calmas e meditativas com formas orgânicas e curvas fluidas

**Paleta de cores** Tons oceânicos suaves

**Melhores usos:** conteúdo de calma e meditação, visuais minimalistas sofisticados, equilíbrio

**MidJourney:** `--sref 1056112643 --sw 1000`

**Prompt universal:** `Zen editorial aesthetic with fluid organic forms, calm meditative composition, soft oceanic tones, minimal elegant scene with flowing curves, serene sophisticated mood`

---

### **Ethereal**

**Atmosfera e mood**

**Etéreo** — por Alie Jules (Lummi, categoria Surreal)

Luz translúcida e brilhante, elementos flutuantes, leveza de outro mundo

**Paleta de cores** Paleta pálida e luminosa

**Melhores usos:** espiritualidade com sobriedade, temas de alma e sutileza, visuais contemplativos

**MidJourney:** `--sref 2930026128 --sw 1000`

**Prompt universal:** `Ethereal surreal artwork, translucent glowing light, soft floating elements, delicate otherworldly atmosphere, luminous pale palette, dreamlike weightless mood`

---

### **Super Photorealism**

**Atmosfera e mood**

**Fotorrealismo extremo** — por Tatiana Tsiguleva (Lummi, categoria Editorial)

Detalhe ultra nítido, luz natural realista, qualidade de revista profissional

**Paleta de cores** Tons fiéis à realidade, texturas e pele naturais

**Melhores usos:** retratos profissionais, fotos de produto realistas, conteúdo de credibilidade

**MidJourney:** `--sref 3117130089 --sw 1000`

**Prompt universal:** `Hyper photorealistic editorial photography, ultra sharp detail, natural realistic lighting, true-to-life textures and skin tones, professional magazine quality realism`

---

### **Sun Demon**

**Atmosfera e mood**

**Energia solar mítica** — por kattlatte (Lummi, categoria Illustration)

Motivos de sol flamejante com imagens míticas e energia gráfica marcante

**Paleta de cores** Vermelhos, laranjas e dourados incandescentes

**Melhores usos:** temas de força e vitalidade, arte simbólica, composições radiantes

**MidJourney:** `--sref 3250200374 --sw 1000`

**Prompt universal:** `Bold illustration with blazing sun motifs, fiery warm palette of reds oranges and golds, mythic solar imagery, striking graphic energy, dramatic radiant composition`

---

### **Radiant Dystopia**

**Atmosfera e mood**

**Distopia radiante** — por Dogan Ural (Lummi, categoria Surreal)

Cenários futuristas decadentes banhados em luz intensa — beleza no colapso

**Paleta de cores** Brilhos luminosos contrastando com tons distópicos

**Melhores usos:** arte conceitual, temas de transformação e contraste, visuais impactantes

**MidJourney:** `--sref 875931069 --sw 1000`

**Prompt universal:** `Radiant dystopian scene, decaying futuristic world bathed in intense glowing light, surreal beauty in collapse, dramatic luminous atmosphere, cinematic sci-fi mood with striking contrast`

---

### **Cosmic Cowboy**

**Atmosfera e mood**

**Faroeste cósmico** — por Ellenor Argyropoulos (Lummi, categoria Surreal)

Estética western encontrando o espaço: deserto, poeira e céu estrelado surreal

**Paleta de cores** Tons desertos quentes com azuis cósmicos profundos

**Melhores usos:** narrativas de jornada e fronteira, visuais poéticos inusitados, capas conceituais

**MidJourney:** `--sref 3342128517 --sw 1000`

**Prompt universal:** `Cosmic cowboy aesthetic, western desert scenes merging with starry cosmic skies, surreal frontier imagery, warm dusty tones against deep space blues, dreamlike mythic atmosphere`

---

### **French Movie**

**Atmosfera e mood**

**Cinema francês** — por Hugo Ventura (Lummi, categoria Cinematic)

Stills de nouvelle vague: naturalidade, charme parisiense e melancolia elegante

**Paleta de cores** Tons de filme analógico, luz natural suave

**Melhores usos:** retratos com alma, lifestyle sofisticado, storytelling intimista

**MidJourney:** `--sref 4029852131 --sw 1000`

**Prompt universal:** `French cinema still aesthetic, nouvelle vague film mood, natural candid moments, soft analog film tones, Parisian elegance with subtle melancholy, intimate cinematic framing`

---

### **Golden Hour**

**Atmosfera e mood**

**Hora dourada** — por Hugo Ventura (Lummi, categoria Editorial)

Luz de fim de tarde envolvendo tudo em calor e nostalgia

**Paleta de cores** Dourados, âmbar e tons de pôr do sol

**Melhores usos:** retratos acolhedores, temas de gratidão e presença, conteúdo inspiracional

**MidJourney:** `--sref 3260390197 --sw 1000`

**Prompt universal:** `Golden hour editorial photography, warm low sunlight, amber and honey tones, soft glowing backlight, nostalgic serene atmosphere, elegant natural warmth`

---

### **Hyperpink Vision**

**Atmosfera e mood**

**Visão hiper-rosa** — por Craftian (Lummi, categoria Artsy)

Rosa levado ao máximo: monocromia intensa e ousada

**Paleta de cores** Rosas saturados dominando toda a cena

**Melhores usos:** branding feminino de alto impacto, posts que param o scroll, editoriais ousados

**MidJourney:** `--sref 20240916 --sw 1000`

**Prompt universal:** `Hyper pink monochromatic artwork, intense saturated pink dominating the entire scene, bold artistic vision, striking high-impact composition, modern maximalist pink aesthetic`

---

### **Maximalism**

**Atmosfera e mood**

**Maximalismo** — por Salma (Lummi, categoria Editorial)

Abundância visual: padrões, texturas e cores em camadas ricas

**Paleta de cores** Paleta rica e exuberante, sem medo do excesso

**Melhores usos:** editoriais de personalidade forte, cenários exuberantes, conteúdo de abundância

**MidJourney:** `--sref 2143186076 --sw 1000`

**Prompt universal:** `Maximalist editorial aesthetic, rich layered patterns and textures, abundant vibrant colors, opulent decorated scenes, bold more-is-more composition, luxurious visual abundance`

---

### **Neo-Pharaonic**

**Atmosfera e mood**

**Neo-faraônico** — por Sofia (Lummi, categoria Illustration)

Iconografia egípcia antiga reinterpretada com linguagem contemporânea

**Paleta de cores** Dourados, lápis-lazúli e tons de areia

**Melhores usos:** simbolismo e arquétipos, arte mística sofisticada, narrativas ancestrais

**MidJourney:** `--sref 1042837376 --sw 1000`

**Prompt universal:** `Neo-pharaonic illustration, ancient Egyptian iconography reimagined in contemporary style, gold lapis blue and sand tones, elegant mythic symbolism, refined modern take on ancient art`

---

### **Refined Botanica**

**Atmosfera e mood**

**Botânica refinada** — por kattlatte (Lummi, categoria Editorial)

Plantas e flores com tratamento editorial elegante e sofisticado

**Paleta de cores** Verdes profundos e tons naturais polidos

**Melhores usos:** fitoterapia com sofisticação, branding natural premium, editoriais botânicos

**MidJourney:** `--sref 3199369175 --sw 1000`

**Prompt universal:** `Refined botanical editorial photography, elegant plants and flowers with sophisticated styling, deep greens and polished natural tones, premium organic aesthetic, clean luxurious composition`

---

### **Kineticism**

**Atmosfera e mood**

**Cinetismo** — por Morph (Lummi, categoria Artsy)

Movimento capturado: dinamismo, borrões e energia em fluxo

**Paleta de cores** Contrastes dinâmicos que reforçam a sensação de movimento

**Melhores usos:** temas de mudança e ação, visuais energéticos, metáforas de progresso

**MidJourney:** `--sref 3074265609 --sw 1000`

**Prompt universal:** `Kinetic art aesthetic, captured motion and dynamic energy, flowing blurs and movement trails, rhythmic abstract composition, vibrant sense of speed and transformation`

---

### **Bold Pop**

**Atmosfera e mood**

**Pop ousado** — por Marco (Lummi, categoria Artsy)

Gráfico, direto e vibrante — pop art com máximo impacto

**Paleta de cores** Cores puras e saturadas com contornos fortes

**Melhores usos:** posts de impacto, capas vibrantes, comunicação visual direta

**MidJourney:** `--sref 3976506151 --sw 1000`

**Prompt universal:** `Bold pop art style, pure saturated colors with strong graphic shapes, high impact minimal composition, punchy modern pop aesthetic, confident vibrant design`

---

### **Pastel Mint**

**Atmosfera e mood**

**Menta pastel** — por Hugo Ventura (Lummi, categoria Summer)

Frescor de verão em tons de menta suaves e arejados

**Paleta de cores** Verde-menta, pastéis frescos e luz clara

**Melhores usos:** conteúdo de leveza e frescor, bem-estar, branding clean de verão

**MidJourney:** `--sref 1619212211 --sw 1000`

**Prompt universal:** `Pastel mint summer aesthetic, fresh soft mint green palette, airy light scenes, clean breezy composition, gentle summery freshness, calm modern elegance`

---

### **Preppy Fashion**

**Atmosfera e mood**

**Moda preppy universitária** — MidLibrary (Genres + Art Movements)

Visual limpo, clássico e sofisticado com raízes na cultura Ivy League americana: blazers, camisas sociais e loafers — elegância juvenil, tradição e atemporalidade

**Luz e textura**

Mistura de realismo com ilustração digital; tecidos texturizados e roupas em camadas, retratos com composição centrada

**Paleta de cores** Tons quentes com acentos pastel — clima claro, vívido e luminoso

**Melhores usos:** retratos elegantes e jovens, branding clássico-sofisticado, editoriais de moda tradicional

**MidJourney:** `[assunto] preppy fashion --v 6.1`

**Prompt universal:** `Preppy Ivy League fashion editorial, clean classic collegiate style, blazers button-down shirts and loafers, layered textured fabrics, warm tones with pastel accents, youthful elegant portrait, blend of realism and digital illustration, sophisticated timeless mood`

---

### **Normcore Fashion**

**Atmosfera e mood**

**Moda despretensiosa** — MidLibrary (Genres + Art Movements)

Roupas comuns e funcionais (jeans, camiseta, tênis) — conforto e praticidade acima do estilo; a proposta é se misturar, não se destacar

**Luz e textura**

Minimalista e fotorrealista; cenários urbanos do dia a dia, sujeito centrado contra fundos simples

**Paleta de cores** Tons sóbrios: terrosos, cinzas e beges

**Melhores usos:** conteúdo autêntico e acessível, lifestyle cotidiano, visuais "gente como a gente"

**MidJourney:** `[assunto] normcore fashion --v 6.1`

**Prompt universal:** `Normcore fashion photography, unpretentious everyday clothing, plain jeans t-shirts and sneakers, minimalist realistic style, subdued earth tones greys and beiges, urban everyday setting, centered subject against plain background, casual relaxed contemporary mood, photorealistic quality`

---

### **Tailored Fashion**

**Atmosfera e mood**

**Alfaiataria moderna** — MidLibrary (Genres + Art Movements)

Roupas sob medida com acabamento impecável — elegância sartorial de Milão e Londres, atenção meticulosa a corte, tecido e construção

**Luz e textura**

Render digital detalhado e realista com ênfase em textura de tecido; composições equilibradas e simétricas destacando detalhes de alfaiataria (lapelas, botões)

**Paleta de cores** Sóbria: tons terrosos, verdes ricos e vermelhos profundos

**Melhores usos:** branding executivo e premium, retratos profissionais sofisticados, editoriais de alfaiataria

**MidJourney:** `[assunto] tailored fashion --v 6.1`

**Prompt universal:** `Modern tailored fashion editorial, bespoke high-end suit with meticulous craftsmanship, detailed fabric texture and refined lapel design, balanced symmetrical composition, subdued palette of earth tones rich greens and deep reds, sartorial elegance, contemporary fashion photography`

---

### **2000s Fashion**

**Atmosfera e mood**

**Moda anos 2000 (Y2K)** — MidLibrary (Genres + Art Movements)

Experimentação ousada da década: calças de cintura baixa, cargo pants e camisetas gráficas — influências de hip-hop, pop e clipes musicais

**Luz e textura**

Vívido e ousado com elementos surreais; texturas metálicas, silhuetas marcantes em camadas, acessórios oversized e estampas gráficas

**Paleta de cores** Cores brilhantes e neon com toques metálicos e futuristas

**Melhores usos:** conteúdo nostálgico Y2K, visuais energéticos de streetwear, editoriais pop

**MidJourney:** `[assunto] in 2000s fashion style --v 6.1`

**Prompt universal:** `2000s fashion style, eclectic Y2K look with low-rise jeans cargo pants and graphic tees, bright neon colors and metallic textures, bold silhouettes with layered clothing and oversized accessories, pop art influence with futuristic touches, energetic music-video atmosphere, streetwear meets high fashion`

---

### **Harajuku Fashion**

**Atmosfera e mood**

**Moda de rua japonesa** — MidLibrary (Genres + Art Movements)

Estilo vibrante e eclético do distrito de Harajuku (Tóquio): mistura de punk, gótico e kawaii — individualidade e criatividade máximas

**Luz e textura**

Ilustração digital com render fotorrealista; personagens expressivos e lúdicos em cenários de rua, roupas em camadas e acessórios oversized

**Paleta de cores** Dominada por neon e pastéis — jovem e whimsical, com influência de anime e pop japonês

**Melhores usos:** conteúdo criativo e ousado, personagens expressivos, visuais de individualidade e autoexpressão

**MidJourney:** `[assunto] harajuku fashion --v 6.1`

**Prompt universal:** `Harajuku Japanese street fashion, bold colorful eclectic outfit mixing punk gothic and kawaii elements, layered clothing with oversized accessories and colorful patterns, neon and pastel palette, playful expressive character in Tokyo street setting, anime and Japanese pop culture influence, vivid photorealistic illustration`

---

### **1990s Fashion**

**Atmosfera e mood**

**Moda anos 90** — MidLibrary (Genres + Art Movements)

Década eclética: grunge, minimalismo e ascensão do streetwear — mistura de vintage com estética futurista, influência de música e TV

**Luz e textura**

Texturas em camadas com equilíbrio assimétrico; penteados e acessórios marcantes da época, influência de pop art

**Paleta de cores** Cores vivas e ousadas com padrões ecléticos e formas geométricas

**Melhores usos:** conteúdo nostálgico 90s, editoriais retrô divertidos, visuais de personalidade

**MidJourney:** `[assunto] in 1990s fashion style --v 6.1`

**Prompt universal:** `1990s fashion style, grunge minimalism and early streetwear mix, bold vivid colors and eclectic geometric patterns, layered textures with asymmetrical balance, retro hairstyles and accessories, pop art influenced lively playful composition, vintage 90s editorial mood`

---

### **Vintage fashion**

**Atmosfera e mood**

**Elegância nostálgica de meados do século XX** — (MidLibrary, Genres + Art Movements)

Foco suave e pincelada delicada criam clima romântico e nostálgico, com acessórios ornamentados e penteados vintage, evocando o glamour de Hollywood dos anos 1950 e revistas de moda antigas.

**Paleta de cores** tons pastel, rosas suaves e verdes desbotados

**Melhores usos:** retratos elegantes, editoriais nostálgicos, branding romântico e feminino

**MidJourney:** `[tema] in vintage fashion style --v 6.1`

**Prompt universal:** `elegant mid-20th century vintage fashion portrait, soft focus, delicate painterly brushwork, ornate accessories and vintage hairstyle, pastel tones with soft pinks and muted greens, romantic nostalgic atmosphere, 1950s Hollywood glamour`

---

### **Boho fashion**

**Atmosfera e mood**

**Espírito livre boêmio** — (MidLibrary, Genres + Art Movements)

Ilustração digital vívida e detalhada com figuras centrais adornadas de joias ornamentadas e chapéus de aba larga, contra fundos naturais — atmosfera caprichosa e romântica com texturas em camadas.

**Paleta de cores** tons terrosos, vermelhos profundos e acentos turquesa

**Melhores usos:** moda festival, marcas artesanais, conteúdo de bem-estar e natureza

**MidJourney:** `[tema] in boho fashion style --v 6.1`

**Prompt universal:** `bohemian fashion illustration, free-spirited figure with ornate jewelry and wide-brimmed hat, natural backdrop, earthy tones with deep reds and turquoise accents, layered textures, whimsical romantic atmosphere, photorealistic detailed rendering`

---

### **Greaser fashion**

**Atmosfera e mood**

**Rebeldia anos 1950** — (MidLibrary, Genres + Art Movements)

Retratos cinematográficos em close com topetes engomados e jaquetas de couro, iluminação dramática e expressões intensas — a juventude rebelde americana dos anos 1950.

**Paleta de cores** do monocromático a vermelhos e azuis vibrantes

**Melhores usos:** retratos marcantes, estética retrô rock'n'roll, pôsteres

**MidJourney:** `[tema] in greaser fashion style --v 6.1`

**Prompt universal:** `1950s greaser fashion portrait, slicked-back hair and leather jacket, dramatic cinematic lighting, close-up with intense expression, monochrome with vibrant red and blue accents, rebellious nostalgic mood, American youth culture`

---

### **Soft Pink**

**Atmosfera e mood**

**Minimalismo extremo** em rosa — estilo apelidado de "Powderism" (estética empoada/pastel)

Visual **limpo de banco de imagens premium** — a comunidade diz que dá para criar um portfólio de stock inteiro com ele

**Luz e textura**

Luz de estúdio suave e uniforme, fundos limpos

Textura **empoada/matte**, sem ruído visual

**Paleta de cores** Rosa-pó e pastéis delicados — paleta **mínima e consistente**

**Melhores usos:** branding minimalista, fotos de produto, retratos clean, conteúdo feminino sofisticado

**MidJourney:** `--sref 577817196 --sw 1000`

**Prompt universal:** `Extreme minimalist photography in soft powder pink tones, clean pastel background, elegant simplicity, soft even studio lighting, powdery matte texture, high-end stock image aesthetic, delicate feminine minimalism`

---

### **Ocean Blue**

**Atmosfera e mood**

Identidade visual dominada pelo **azul-oceânico** — sereno e ao mesmo tempo impactante

Muito popular na biblioteca (1.400+ curtidas)

**Luz e textura**

Color grading cinematográfico em azul

**Paleta de cores** Azuis profundos, do marinho ao azul-celeste — paleta **fria e imersiva**

**Melhores usos:** conteúdo sobre calma/profundidade, visuais aquáticos, capas serenas, identidade visual azul

**MidJourney:** `--sref 1982648737 --sw 1000`

**Prompt universal:** `Striking artwork dominated by a deep ocean blue palette, rich blue tones from navy to azure, serene yet powerful oceanic mood, cinematic blue color grading, clean composition with strong color identity, immersive tranquil atmosphere`

---

### **Vibrant Ethereal Vibes**

**Atmosfera e mood**

Mistura de **cores vibrantes com atmosfera etérea** — luminoso e sonhador ao mesmo tempo

Funciona para retratos e paisagens (exemplos da comunidade incluem ambos)

**Luz e textura**

Luz **radiante e brilhante**, transições suaves entre cores

**Paleta de cores** Saturada e luminosa, mas com suavidade onírica — não é neon agressivo

**Melhores usos:** retratos expressivos, paisagens mágicas, conteúdo inspiracional vibrante

**MidJourney:** `--sref 4111512992 --sw 1000`

**Prompt universal:** `Vibrant ethereal artwork, luminous saturated colors with dreamy soft atmosphere, glowing light and gentle color transitions, expressive vivid palette, otherworldly radiant mood, fine art quality`

---

### **Vibrant Craft Fantasy**

**Atmosfera e mood**

Mundo de **artesanato colorido e fantasia** — a comunidade o descreve como "mundo de tricô" (knitted world)

Cenas lúdicas feitas de **materiais táteis**: lã, tricô, tecido, fios

**Luz e textura**

Texturas de **tricô e artesanato em close** — tudo parece feito à mão

**Paleta de cores** Saturada e alegre — cores vivas de lãs e fios

**Melhores usos:** mockups coloridos de produto (dica da comunidade), conteúdo acolhedor e artesanal, cenas lúdicas

**Dica da comunidade:** ótimo em blends com outros códigos para cenas de mockup

**MidJourney:** `--sref 484604415 --sw 1000`

**Prompt universal:** `Vibrant craft fantasy world, knitted and handmade textures, colorful yarn and fabric materials, playful whimsical scene made entirely of textile crafts, saturated cheerful palette, cozy tactile handmade aesthetic, detailed miniature craft world`

---

### **Playful 3D Pastel Workspace**

**Atmosfera e mood**

**Ilustrações 3D lúdicas** — a comunidade recomenda para designers: "3D isolated illustrations"

Visual **amigável e minimalista**, estilo ícones e cenas 3D modernas de UI/branding

**Luz e textura**

Render 3D suave com **materiais matte arredondados**

Objetos isolados em fundos limpos

**Paleta de cores** Pastéis suaves — paleta **leve e amistosa**

**Melhores usos:** ícones e ilustrações para sites/apps, apresentações, branding moderno, infográficos

**MidJourney:** `--sref 1923246294 --sw 1000`

**Prompt universal:** `Playful 3D rendered illustration, isolated object on a clean pastel background, soft rounded shapes, smooth matte 3D materials, gentle pastel color palette, friendly minimal design aesthetic, high quality studio render for UI and branding`

---

### **Pastel Dreams**

**Atmosfera e mood**

Ilustração **pastel e sonhadora** — curadoria da Lummi (por Muriel Lherm, categoria Illustration)

Clima **calmo, delicado e acolhedor**

**Luz e textura**

Luz suave e difusa, estilo pictórico gentil com texturas sutis

**Paleta de cores** Pastéis delicados e dessaturados

**Melhores usos:** conteúdo calmo e acolhedor, ilustrações poéticas, visuais de bem-estar

**MidJourney:** `--sref 648319572 --sw 1000`

**Prompt universal:** `Dreamy pastel illustration, soft delicate colors, gentle painterly style with subtle textures, tender diffuse light, soothing calm atmosphere, poetic artistic mood`

---

### **Côte d'Azur**

**Atmosfera e mood**

Verão na **Riviera Francesa** — curadoria da Lummi (por Gizem Akdag, categoria Summer)

Descrito como **"cool e contemporâneo"** — moderno e sofisticado

**Luz e textura**

Luz solar mediterrânea, clima arejado e luxuoso

**Paleta de cores** Azul-celeste do mar, brancos e tons costeiros elegantes

**Melhores usos:** lifestyle aspiracional, verão e viagens, branding sofisticado e leve

**MidJourney:** `--sref 1654219691 --sw 1000`

**Prompt universal:** `French Riviera summer aesthetic, Côte d'Azur inspired scene, sunny Mediterranean light, cool contemporary sophistication, azure sea with elegant coastal colors, modern editorial style, breezy luxurious summer mood`

---

### **Space Odyssey**

**Atmosfera e mood**

**Odisseia espacial surreal** — curadoria da Lummi (por Kiri, categoria Surreal)

Paisagens cósmicas vastas com clima cinematográfico de ficção científica

**Luz e textura**

Luz de espaço profundo com brilhos pontuais — atmosfera imersiva

**Paleta de cores** Tons cósmicos escuros com acentos luminosos

**Melhores usos:** visuais de expansão/imensidão, metáforas de jornada, capas conceituais, sci-fi

**MidJourney:** `--sref 1475660433 --sw 1000`

**Prompt universal:** `Surreal space odyssey aesthetic, cosmic retro-futuristic scenery, vast otherworldly landscapes, cinematic sci-fi atmosphere, deep space palette with glowing accents, dreamlike interstellar mood`

---

### **Dreamworld**

**Atmosfera e mood**

**Mundo dos sonhos surreal** — curadoria da Lummi (por Ege, categoria Surreal; mesmo criador do Indigo Gothic Enchantment)

Cenários fantasiosos e poéticos, imagens do subconsciente

**Luz e textura**

Luz suave e sobrenatural, elementos flutuantes e composições imaginativas

**Paleta de cores** Tons etéreos e oníricos

**Melhores usos:** storytelling onírico, metáforas de sonho/inconsciente, arte conceitual poética

**MidJourney:** `--sref 4085362821 --sw 1000`

**Prompt universal:** `Surreal dreamworld aesthetic, fantastical dreamlike scenery, soft otherworldly light, imaginative surreal composition, ethereal floating elements, poetic subconscious imagery`

---

### **Surreal Pink**

**Atmosfera e mood**

**Surrealismo em rosa** — por Gizem Akdag (Lummi, categoria Surreal)

Cenas oníricas e inesperadas dominadas por tons de rosa

**Paleta de cores** Rosas suaves a intensos com toques surreais

**Melhores usos:** conteúdo feminino com toque artístico, metáforas de sonho, visuais inesperados de marca

**MidJourney:** `--sref 2740450718 --sw 1000`

**Prompt universal:** `Surreal artwork dominated by pink tones, dreamlike unexpected compositions, soft to vivid pink palette, imaginative surrealist imagery, elegant modern surrealism, otherworldly playful mood`

---

### **Trippy**

**Atmosfera e mood**

**Psicodelia surreal** — por Alie Jules (Lummi, categoria Surreal)

Formas distorcidas e realidade fluida, clima hipnótico

**Paleta de cores** Cores iridescentes e cambiantes

**Melhores usos:** visuais de estados alterados de consciência, arte conceitual, conteúdo ousado

**MidJourney:** `--sref 2602 --sw 1000`

**Prompt universal:** `Trippy surreal artwork, warped psychedelic forms, iridescent shifting colors, hallucinatory dreamlike imagery, fluid distorted reality, hypnotic surreal mood`

---

### **Time Travel**

**Atmosfera e mood**

**Viagem no tempo** — por Tom Blake (Lummi, categoria Editorial)

Mistura de elementos vintage e futuristas em clima cinematográfico

**Paleta de cores** Tons de filme nostálgico com detalhes sci-fi

**Melhores usos:** narrativas de transformação (antes/depois), editoriais conceituais, capas

**MidJourney:** `--sref 3514740034 --sw 1000`

**Prompt universal:** `Time travel editorial aesthetic, blending vintage and futuristic elements, retro decades meeting sci-fi details, nostalgic film tones, cinematic timeless atmosphere`

---

### **Dramatic Fog**

**Atmosfera e mood**

**Névoa dramática** — por Hugo Ventura (Lummi, categoria Editorial)

Silhuetas emergindo da bruma, clima misterioso e elegante

**Paleta de cores** Tons frios e dessaturados

**Melhores usos:** capas dramáticas, metáforas de incerteza/clareza, visuais introspectivos

**MidJourney:** `--sref 2560033873 --sw 1000`

**Prompt universal:** `Editorial photography with dramatic dense fog, atmospheric misty scene, soft diffused light through haze, moody desaturated tones, cinematic silhouettes emerging from mist, mysterious elegant mood`

---

### **Noir Lines**

**Atmosfera e mood**

**Noir gráfico** — por Morph (Lummi, categoria Editorial)

Linhas fortes, sombras profundas e feixes de luz, estética film noir

**Paleta de cores** Alto contraste, preto e branco dominante

**Melhores usos:** visuais de mistério e profundidade, composições minimalistas impactantes

**MidJourney:** `--sref 1550254738 --sw 1000`

**Prompt universal:** `Noir editorial aesthetic with strong graphic lines, high contrast black and white, dramatic shadows and light beams, film noir mood, bold minimal composition, elegant mystery`

---

### **Psychedelic 70s**

**Atmosfera e mood**

**Psicodelia anos 70** — por Marco (Lummi, categoria Artsy)

Formas fluidas em espiral, estética de pôster vintage groovy

**Paleta de cores** Laranjas, roxos e amarelos retrô vibrantes

**Melhores usos:** conteúdo retrô e criativo, pôsteres, visuais de expansão de consciência

**MidJourney:** `--sref 468793 --sw 1000`

**Prompt universal:** `1970s psychedelic art style, swirling fluid shapes, vibrant retro palette of oranges purples and yellows, groovy vintage poster aesthetic, bold trippy patterns, warm analog feel`

---

### **Retro Futurism**

**Atmosfera e mood**

**Retrofuturismo** — por Felix Koutchinski (Lummi, categoria Surreal)

A visão vintage do futuro: sci-fi dos anos 60-70, nostálgico e limpo

**Paleta de cores** Cromados e pastéis futuristas

**Melhores usos:** visão de futuro/metas, conteúdo aspiracional, design conceitual

**MidJourney:** `--sref 1091950851 --sw 1000`

**Prompt universal:** `Retro futurism aesthetic, vintage vision of the future, sleek chrome and pastel machines, 60s-70s sci-fi design language, nostalgic futuristic scenes, clean surreal composition`

---

### **Saturated Cityscape**

**Atmosfera e mood**

**Paisagem urbana saturada** — por Ege (Lummi, categoria Artsy)

Cenas urbanas vívidas com energia metropolitana

**Paleta de cores** Saturação intensa, céus dramáticos sobre arquitetura

**Melhores usos:** conteúdo urbano e dinâmico, cenários de cidade, energia e movimento

**MidJourney:** `--sref 3141514601 --sw 1000`

**Prompt universal:** `Highly saturated cityscape art, vivid urban scenes with intense color grading, bold artistic city views, dramatic skies over architecture, energetic metropolitan mood`

---

### **Pop Comic**

**Atmosfera e mood**

**Quadrinhos pop art** — por OscarAI (Lummi, categoria Illustration)

Contornos fortes de nanquim, retículas de meio-tom, painéis retrô

**Paleta de cores** Cores primárias vibrantes

**Melhores usos:** conteúdo divertido e expressivo, storytelling em quadrinhos, posts chamativos

**MidJourney:** `--sref 1791691478 --sw 1000`

**Prompt universal:** `Pop art comic book illustration, bold ink outlines, halftone dots, vibrant primary colors, retro comic panel aesthetic, expressive graphic style`

---

### **Futuristic Pink**

**Atmosfera e mood**

**Futurismo em rosa** — por Ege (Lummi, categoria Surreal)

Formas sci-fi elegantes envoltas em atmosfera rosa sonhadora

**Paleta de cores** Rosas suaves com acentos neon

**Melhores usos:** branding feminino moderno, visuais de inovação, estética tech delicada

**MidJourney:** `--sref 3989595870 --sw 1000`

**Prompt universal:** `Futuristic surreal scene in pink tones, sleek sci-fi shapes with soft pink palette, glowing neon pink accents, dreamy high-tech atmosphere, elegant otherworldly design`

---

### **80s Movie**

**Atmosfera e mood**

**Filme dos anos 80** — por fofr (Lummi, categoria Cinematic)

Stills de cinema com grão de filme e clima de era VHS

**Paleta de cores** Neon e tungstênio, color grading retrô

**Melhores usos:** conteúdo nostálgico, storytelling cinematográfico, retratos com personalidade

**MidJourney:** `--sref 2158083008 --sw 1000`

**Prompt universal:** `1980s movie still aesthetic, cinematic film grain, neon and tungsten lighting, retro wardrobe and set design, VHS-era color grading, nostalgic cinematic atmosphere`

---

### **Fallen**

**Atmosfera e mood**

**Beleza melancólica** — por Julie W. Design (Lummi, categoria Cinematic)

Cenas sombrias e poéticas, composição de still de filme

**Paleta de cores** Sombras profundas com luz pontual dramática

**Melhores usos:** temas de queda e recomeço, conteúdo introspectivo, drama visual

**MidJourney:** `--sref 3879150397 --sw 1000`

**Prompt universal:** `Dark cinematic scene with melancholic dramatic mood, moody lighting and deep shadows, poetic somber beauty, film still composition, elegant emotional atmosphere`

---

### **Minivista**

**Atmosfera e mood**

**Mundos em miniatura** — por Dogan Ural (Lummi, categoria Editorial)

Efeito tilt-shift: cenários detalhados que parecem dioramas minúsculos

**Paleta de cores** Luz limpa e suave, cores nítidas

**Melhores usos:** visão panorâmica de processos/jornadas, cenários encantadores, metáforas de perspectiva

**MidJourney:** `--sref 2907424065 --sw 1000`

**Prompt universal:** `Miniature diorama look, tilt-shift photography effect, tiny detailed world seen from above, clean editorial composition, charming small-scale scenery, crisp soft light`

---

### **Summer in Sicily**

**Atmosfera e mood**

**Verão siciliano** — por ArtiMindArt (Lummi, categoria Editorial)

Charme costeiro italiano, clima de Riviera vintage ensolarada

**Paleta de cores** Terracota quente e azul mediterrâneo

**Melhores usos:** lifestyle aspiracional, temas de leveza e prazer, conteúdo de verão

**MidJourney:** `--sref 56753421 --sw 1000`

**Prompt universal:** `Sicilian summer editorial aesthetic, Mediterranean sunlight, warm terracotta and azure palette, Italian coastal charm, vintage Riviera mood, sun-drenched relaxed scenes`

---

### **Polygonal Expressionism**

**Atmosfera e mood**

**Expressionismo poligonal** — por MiraiMosaic (Lummi, categoria Illustration)

Formas geométricas facetadas com cor expressiva, estilo low-poly artístico

**Paleta de cores** Cores expressivas em composição angular abstrata

**Melhores usos:** visuais modernos e conceituais, metáforas de construção/estrutura, arte digital

**MidJourney:** `--sref 376735 --sw 1000`

**Prompt universal:** `Polygonal expressionist illustration, faceted geometric shapes, low-poly inspired art with expressive bold color, angular abstract composition, modern digital art style`

---

### **Idyllic Flora**

**Atmosfera e mood**

**Flora idílica** — por Sofia (Lummi, categoria Illustration)

Arte botânica romântica e serena, jardins em plena floração

**Paleta de cores** Pastéis suaves e verdes frescos

**Melhores usos:** temas de natureza e florescimento, fitoterapia, conteúdo de bem-estar

**MidJourney:** `--sref 1032733850 --sw 1000`

**Prompt universal:** `Idyllic floral illustration, lush blooming flowers, soft romantic botanical art, gentle pastel and fresh green palette, serene garden atmosphere, delicate painterly detail`

---

### **Earth's Essence**

**Atmosfera e mood**

**Essência da terra** — por Underwood (Lummi, categoria Illustration; destaque da semana no catálogo)

Motivos botânicos e minerais texturizados, clima orgânico e artesanal

**Paleta de cores** Tons terrosos: argila, musgo e areia

**Melhores usos:** conteúdo de aterramento/enraizamento, naturais e fitoterapia, branding orgânico

**MidJourney:** `--sref 534505 --sw 1000`

**Prompt universal:** `Organic earthy illustration, natural tones of clay moss and sand, textured botanical and mineral motifs, warm grounded atmosphere, artisanal hand-crafted feel`

---

### **Floral Pop Art**

**Atmosfera e mood**

**Pop art floral** — por Sofia (Lummi, categoria Artsy)

Flores gráficas e ousadas com contornos fortes, energia decorativa

**Paleta de cores** Cores saturadas e vivas

**Melhores usos:** posts vibrantes de redes sociais, capas alegres, conteúdo floral com impacto

**MidJourney:** `--sref 2009687028 --sw 1000`

**Prompt universal:** `Floral pop art style, bold graphic flowers, vivid saturated colors with strong outlines, playful modern botanical design, high-energy decorative composition`

---

### **Italian Summer**

**Atmosfera e mood**

**Verão italiano** — por Gizem Akdag (Lummi, categoria Summer)

Dolce vita costeira: luz dourada mediterrânea e nostalgia leve

**Paleta de cores** Tons quentes vintage e azuis de costa

**Melhores usos:** lifestyle, temas de prazer e presença, conteúdo ensolarado

**MidJourney:** `--sref 3721090848 --sw 1000`

**Prompt universal:** `Italian summer aesthetic, golden Mediterranean light, coastal dolce vita mood, warm vintage tones, sun-soaked editorial scenes, breezy nostalgic charm`

---

### **Ethereal Dreamscape with Surrealist Overtones**

**Atmosfera e mood**

Clima **etéreo e onírico** (dream-like) — imagens que parecem cenas de sonho

Elementos **surrealistas** que misturam fantasia com realidade

Influências: **Surrealismo e Realismo Mágico**

**Luz e textura**

Iluminação **suave e difusa** (sem sombras duras ou contrastes dramáticos)

Textura **fosca/matte** (nada de brilhos ou acabamento polido)

Harmonia tonal unificada com **contraste gentil**

**Paleta de cores** Tons terrosos, escuros e dessaturados: verde-acinzentado (rgb 81,95,82), marrom quase preto (rgb 18,11,8), marrom-oliva (rgb 36,32,25), cáqui escuro (rgb 57,51,34) e verde-oliva (rgb 73,71,36)

Paleta **sóbria, orgânica e melancólica** — nada de cores vibrantes

**Melhores usos:** expressão artística, storytelling ilustrativo, arte conceitual e metáforas visuais

`--sref 2696696027 --sw 1000` Ethereal dreamscape, surrealist overtones blending fantasy and reality, magical realism, soft diffuse lighting, matte texture, muted earthy palette of dark olive greens and deep browns, unified tonal harmony, gentle contrast, melancholic dreamlike atmosphere, conceptual fine art

---

### **Indigo Gothic Enchantment |** Neon Noir

**Atmosfera e mood**

Clima **gótico e encantado** — atmosfera noturna, misteriosa e mágica

Tom **surreal**, com pegada de *neon noir* (noite urbana/fantástica com brilhos pontuais)

Forte presença de **silhuetas** escuras contra fundos luminosos

Cenários recorrentes: **castelos, arquitetura gótica e paisagens de fantasia**

**Luz e textura**

Iluminação noturna dramática, com **brilhos e luzes pontuais** emergindo da escuridão

Alto contraste entre silhuetas escuras e áreas iluminadas

**Paleta de cores** Dominada por **índigo e azuis profundos**, com violetas escuros e acentos luminosos (rosa/neon)

Paleta **fria, noturna e enigmática** — o oposto da paleta terrosa do código anterior

**Melhores usos:** fantasia sombria, cenas noturnas, storytelling místico, capas e artes conceituais de atmosfera mágica

`--sref 2380670247 --sw 1000` Indigo gothic enchantment, dark fantasy night scene, deep indigo and violet palette, dramatic silhouettes against glowing light, neon noir accents, gothic castles and mystical architecture, enchanted nocturnal atmosphere, surreal magical mood, high contrast conceptual art

---

### **Surreal Fragmented Elegance**

**Atmosfera e mood**

Clima **surreal e sofisticado** — composições que parecem arte contemporânea de galeria

Elementos **fragmentados** — figuras e formas quebradas, deslocadas ou recompostas, como colagem artística

Elegância **editorial/fashion** — refinamento visual mesmo na desconstrução

**Luz e textura**

Estética limpa e controlada, com fragmentação intencional (não caótica)

Contraste entre áreas íntegras e áreas quebradas/deslocadas da imagem

**Paleta de cores** Tons **frios** (catalogado na categoria "Cool" da biblioteca) — azuis, cinzas e neutros elegantes

Paleta **sofisticada e contida** — sem saturação excessiva

**Melhores usos:** arte conceitual, metáforas visuais de transformação e identidade, capas editoriais, conteúdo sobre mente/percepção

`--sref 1641924896 --sw 1000` Surreal fragmented elegance, contemporary fine art collage, broken and displaced figure fragments elegantly recomposed, editorial fashion sophistication, cool muted palette of blues and refined neutrals, clean controlled aesthetic, conceptual surrealism, visual metaphor of identity and transformation

---

### **Oceanic Opulence**

**Atmosfera e mood**

Estética de **fotografia hiper-realista** — imagens com acabamento de foto profissional, não ilustração

Clima de **luxo e opulência** com tema **oceânico/aquático** — elegância dramática e sofisticada

Catalogado nas categorias: *Photography, Hyperrealistic, Luxury*

**Luz e textura**

Luz cinematográfica e realista, com texturas ricas (água, tecidos, superfícies reflexivas)

Acabamento polido de editorial de alto padrão

**Paleta de cores** Azuis profundos e turquesas oceânicos com acentos dourados/luxuosos

Paleta **rica, fria e opulenta**

**Melhores usos:** retratos e cenas fotorrealistas de luxo, editoriais, capas premium, conteúdo aspiracional

**Dica do criador (AlexandrIA):** usar sem `--p` e sem Upscale, com `--s 200`

`--sref 1257717666 --sw 1000` Oceanic opulence, hyperrealistic luxury photography, deep ocean blues and teals with golden opulent accents, cinematic realistic lighting, rich textures of water and fabric, high-end editorial polish, dramatic aquatic elegance, lavish sophisticated mood

---

### **Gothic Elegance Flow**

**Atmosfera e mood**

Elegância **gótica com fluidez** — silhuetas e tecidos que fluem, drama romântico refinado

Estética de **ilustração de moda haute couture** — traço de sketch de estilista, estilo capa de revista de moda

Toque **whimsical** (lúdico/fantasioso) equilibrado com sofisticação editorial

**Luz e textura**

Acabamento de **ilustração/desenho elegante**, não fotografia

Traços fluidos e leves, com aparência de croqui de moda profissional

**Paleta de cores** Paleta **suave** (soft color palette) com contrastes góticos — tons escuros equilibrados por cores delicadas

**Melhores usos:** ilustração de moda, capas e editoriais, fashion sketches, conteúdo feminino elegante

**Prompt de exemplo do criador (chiyoneei):** Beautiful and whimsical haute couture fashion, illustration for popular fashion magazine cover, elegant design sketches, soft color palette, fashion editorial style

`--sref 2738987908 --sw 1000` Gothic elegance flow, whimsical haute couture fashion illustration, elegant designer sketches, flowing fabrics and silhouettes, fashion magazine editorial style, soft color palette with gothic contrast, refined romantic drama

---

### **Vintage Gentleman Portrait**

**Atmosfera e mood**

Estética de **retrato vintage e refinado** — elegância clássica, ar de época com sofisticação atemporal

Especialidade: **retratos de figuras elegantes** ("gentleman portraits"), mas funciona bem também para interiores, street style e fotografia de produto/joias

Um dos códigos **mais populares** da biblioteca (2.500+ curtidas)

**Luz e textura**

Acabamento **fotográfico clássico**, com textura rica de materiais nobres (couro, tecidos, madeira)

Luz quente e controlada, com clima de estúdio ou ambiente vintage

**Paleta de cores** Tons **quentes e vintage** — destaque para **bordô/burgundy**, marrons e neutros clássicos

Paleta **elegante e nostálgica**

**Melhores usos:** retratos elegantes, branding sofisticado, moda clássica, interiores, produtos premium

**Dica da comunidade:** costuma ser combinado com outros códigos no mesmo prompt (ex.: `--sref 1851881805 1597909873 3592395100`) para blends de estilo

`--sref 1851881805 --sw 1000` Vintage gentleman portrait, classic refined photography, timeless old-world elegance, warm burgundy and brown palette, rich leather and fabric textures, controlled studio lighting, nostalgic sophisticated mood, premium editorial quality

---

### **Icelandic Fairytale Fashion**

**Atmosfera e mood**

Clima de **conto de fadas nórdico/islandês** — como "viver dentro de um conto de fadas fashion islandês" (descrição da comunidade)

Mistura de **moda editorial com fantasia** — figurinos elaborados em cenários naturais dramáticos

Sensação **etérea, fria e mágica** — natureza selvagem nórdica encantada

**Luz e textura**

Luz natural difusa de latitudes altas — suave, fria e nevoenta

Texturas ricas: lã, tecidos volumosos, musgo, gelo, pedra

**Paleta de cores** Tons **frios e nórdicos** — brancos gelados, azuis suaves, cinzas e verdes-musgo dessaturados

Paleta **etérea e natural**, sem cores saturadas

**Melhores usos:** editoriais de moda fantasiosos, storytelling mágico, conteúdo sobre natureza e encantamento, visuais aspiracionais de inverno

`--sref 2579904580 --sw 1000` Icelandic fairytale fashion, nordic fantasy editorial, elaborate couture in dramatic natural landscapes, ethereal cold magical atmosphere, soft diffuse northern light, icy whites and muted nordic blues with mossy greens, rich wool and fabric textures, enchanted wilderness storytelling

---

### **Indigenous Fashion Elegance**

**Atmosfera e mood**

Elegância de **moda inspirada em culturas indígenas** — alta-costura que honra artesanato e vestimentas tradicionais

Retratos editoriais com **dignidade e força** — figurinos elaborados, adornos e texturas artesanais

**Luz e textura**

Acabamento fotográfico editorial, com riqueza de detalhes em texturas artesanais: tecidos tramados, bordados, miçangas, plumas

**Paleta de cores** Tons **terrosos e naturais** — ocres, marrons, vermelhos profundos — com acentos vibrantes de adornos

**Melhores usos:** editoriais de moda, retratos culturais, storytelling ancestral, conteúdo sobre raízes e identidade

**MidJourney:** `--sref 749698835 --sw 1000`

**Prompt universal:** `High-fashion editorial portrait inspired by indigenous couture, elaborate traditional garments reimagined as haute couture, intricate handwoven textiles, beadwork and feather adornments, earthy palette of ochres, deep reds and browns with vibrant accents, dignified powerful pose, professional fashion photography, rich artisanal textures, dramatic natural lighting`

---

### **Elegant Urban Glamour**

**Atmosfera e mood**

Glamour **urbano e sofisticado** — moda chique em cenários de cidade

Elegância contemporânea com atitude — estética de editorial de moda metropolitano

**Luz e textura**

Luz urbana cinematográfica — mistura de luz natural de cidade com brilhos de vitrine/noite

Acabamento polido de fotografia de moda

**Paleta de cores** Neutros elegantes (preto, cinza, nude) com acentos glamourosos

**Melhores usos:** moda urbana, lifestyle sofisticado, branding pessoal elegante, editoriais de cidade

**MidJourney:** `--sref 251 --sw 1000`

**Prompt universal:** `Elegant urban glamour fashion editorial, chic sophisticated outfit in a metropolitan setting, cinematic city lighting mixing natural light and glowing storefronts, polished high-fashion photography, refined neutral palette of black, grey and nude with glamorous accents, confident contemporary attitude, editorial magazine quality`

---

### **Iridescent Futurism**

**Atmosfera e mood**

Fusão de **sci-fi com retrô** — futurismo nostalgico, muito usado por artistas de arte conceitual

Um dos códigos **mais populares** da biblioteca (1.350+ curtidas)

**Luz e textura**

Superfícies **iridescentes e holográficas** — reflexos metálicos que mudam de cor

Brilhos futuristas sobre formas retrô

**Paleta de cores** Iridescente: rosas, roxos, turquesas e azuis metálicos com reflexos holográficos

**Melhores usos:** arte conceitual, sci-fi, retratos futuristas, capas e visuais de tecnologia/inovação

**MidJourney:** `--sref 2453165002 --sw 1000`

**Prompt universal:** `Iridescent retro-futurism concept art, sci-fi meets vintage aesthetics, holographic and iridescent surfaces with color-shifting metallic reflections, palette of iridescent pinks, purples, teals and metallic blues, nostalgic futuristic mood, polished concept artist quality, dramatic glowing highlights on retro shapes`

---

### **Ethereal Abstract Fashion**

**Atmosfera e mood**

Moda **abstrata e etérea** — tecidos e materiais que parecem esculturas impossíveis ("preciso que esse material seja real", nas palavras da comunidade)

Fronteira entre **moda, arte e sonho**

**Luz e textura**

Materiais **fluidos e esculturais** — tecidos que flutuam, dobram e se transformam em formas abstratas

Luz suave que realça transparências e volumes

**Paleta de cores** Tons suaves e etéreos, com ênfase na forma e no material mais que na cor

**Melhores usos:** editoriais artísticos, conceitos de design, visuais oníricos de moda, metáforas de transformação

**MidJourney:** `--sref 2216250964 --sw 1000`

**Prompt universal:** `Ethereal abstract fashion editorial, sculptural impossible fabrics floating and folding into abstract forms, dreamlike couture between fashion and art, soft diffuse lighting revealing translucency and volume, delicate ethereal palette, surreal material design, high-end artistic fashion photography`

---

### **Futuristic Retro Fashion Collage**

**Atmosfera e mood**

Colagem de **moda retrô-futurista** — mistura de estética vintage com elementos futuristas em composição de colagem

Visual **gráfico e editorial**, com sobreposições e recortes

**Luz e textura**

Texturas de colagem: recortes, sobreposições, mistura de fotografia e elementos gráficos

**Paleta de cores** Contraste entre tons retrô (desbotados/vintage) e acentos futuristas

**Melhores usos:** capas criativas, conteúdo editorial ousado, moodboards, visuais de moda alternativos

**Dica do criador (NeuroAutomata):** usar com `--sw 1000` para efeito máximo

**MidJourney:** `--sref 19787 --sw 1000`

**Prompt universal:** `Futuristic retro fashion collage, graphic editorial composition with cutouts and layered overlays, vintage aesthetics fused with futuristic elements, mixed-media collage of photography and graphic shapes, faded retro tones contrasted with bold futuristic accents, avant-garde fashion magazine style, high resolution detailed artwork`

---

### **Embroidered Nature**

**Atmosfera e mood**

Natureza (**flora e fauna**) retratada como **bordado artesanal** — arte tátil e delicada

Homenagem ao **artesanato tradicional** — cada imagem parece uma peça bordada à mão, com pontos e fios visíveis

**Luz e textura**

Textura de **fios, pontos e relevo de bordado** — acabamento tátil, artesanal

Sem profundidade fotográfica: a beleza está na trama e no detalhe do ponto

**Paleta de cores** Cores de linhas de bordado — vivas mas orgânicas, sobre fundo de tecido

**Melhores usos:** conteúdo sobre natureza e fitoterapia, artes decorativas, visuais acolhedores e artesanais, capas delicadas

**Prompt original (Olga Volosin):** `--chaos 10 --ar 2:3 --sref 1911829838`

**MidJourney:** `--sref 1911829838 --sw 1000`

**Prompt universal:** `Intricate hand-embroidered artwork of flora and fauna, detailed embroidery with visible threads, stitches and raised texture, traditional textile craft aesthetic, vibrant organic thread colors on fabric background, tactile artisanal beauty, delicate botanical needlework, folk art embroidery style`

---

### **Dreamy Blurred Scenes**

**Atmosfera e mood**

Cenas **etéreas com desfoque de movimento** (motion blur artístico) — exemplos catalogados: dançarina, ciclista, pessoa com papagaio

Clima **onírico e abstrato** — o movimento vira poesia visual

**Luz e textura**

Desfoque intencional de longa exposição — figuras que se dissolvem em rastros de movimento

Luz suave e difusa, atmosfera de sonho

**Paleta de cores** Tons suaves e etéreos, diluídos pelo desfoque

**Melhores usos:** fotografia abstrata, moodboards, conteúdo sobre movimento/corpo/dança, metáforas de fluidez e transformação

**Prompt original (Olga Volosin):** `Illustration [sujeito] --ar 3:4 --exp 30 --sref 3422126476 --sv 4 --sw 1000 --stylize 1000 --v 7`

**MidJourney:** `--sref 3422126476 --sw 1000`

**Prompt universal:** `Ethereal dreamy scene with artistic motion blur, figure dissolving into long-exposure movement trails, soft diffuse light, abstract impressionistic photography, delicate muted palette softened by blur, poetic sense of motion and fluidity, dreamlike atmosphere, fine art mood board aesthetic`

---

### **Redish Dreams**

**Atmosfera e mood**

Sonho **romântico em tons de rosa e vermelho** — a comunidade o chama de "aggressive pink"

Efeito marcante: **traços de sketch sobrepostos à imagem** (desenho multiplicado sobre a foto), com toques surreais

Um dos códigos **mais populares** da biblioteca (2.790+ curtidas) — tudo fica romântico com ele

**Luz e textura**

Luz suave e onírica; mistura de fotografia com linhas de desenho à mão

**Paleta de cores** Rosas intensos, vermelhos e tons rosados — paleta **quente e apaixonada**

**Melhores usos:** conteúdo romântico e feminino, retratos oníricos, branding delicado, editoriais poéticos

**MidJourney:** `--sref 4270736322 --sw 1000`

**Prompt universal:** `Dreamy romantic artwork in reddish pink tones, delicate hand-drawn sketch lines layered over a soft photographic image, abstract surreal romantic atmosphere, blush pinks and deep reds, tender dreamlike mood, mixed media of drawing and photography, elegant feminine aesthetic`

---

### **Gastronomic Tarot Whimsy**

**Atmosfera e mood**

Estética de **cartas de tarô ilustradas com humor** — exemplo clássico da comunidade: carta de tarô de cheeseburger

Visual **simbólico e ornamental** com leveza lúdica

**Luz e textura**

Ilustração com **molduras decorativas e símbolos** — acabamento de carta vintage/esotérica

**Paleta de cores** Tons quentes e envelhecidos de baralho antigo, com acentos vivos

**Melhores usos:** baralhos e cartas simbólicas, conteúdo místico-lúdico, infográficos criativos, artes com arquétipos

**Dica da comunidade:** `--c 20 --ar 2:3 --s 250` (formato de carta)

**MidJourney:** `--sref 57040263 --sw 1000`

**Prompt universal:** `Whimsical illustrated tarot card design, ornate decorative borders and mystical symbols framing a central figure, vintage esoteric card aesthetic with playful humor, rich hand-drawn illustration, warm aged palette with vivid accents, elegant symbolic composition`