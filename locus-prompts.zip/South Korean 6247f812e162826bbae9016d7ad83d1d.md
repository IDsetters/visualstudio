# South Korean

Eixo (verbatim): SYNERGY ↑ → EMANATIO ↑
Eixo secundário: EMANATION
Epíteto: Hanbok Lines Under Seoul Neon
Ideograma primário: SYNERGY
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 833