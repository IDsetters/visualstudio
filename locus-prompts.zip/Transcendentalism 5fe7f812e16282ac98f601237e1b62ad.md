# Transcendentalism

Eixo (verbatim): EMANATIO ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Truth Found Beyond the Built World
Ideograma primário: EMANATION
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 905