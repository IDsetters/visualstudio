# Illustrationcore

Eixo (verbatim): NARRATIVE ↑ → MATTER ↑
Eixo secundário: MATTER
Epíteto: Ink Margins Open a Door to a Drawn World
Ideograma primário: NARRATIVE
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 458