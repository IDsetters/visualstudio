# Memento Mori

Eixo (verbatim): ETERNITY ↑ → DENSITY ↓
Eixo secundário: DENSITY
Epíteto: Skull Keeping Time on the Table
Ideograma primário: ETERNITY
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 561