# Eco Algorithmic

Eixo (verbatim): SYNTHESIS ↑ → DOMAIN ↑
Eixo secundário: DOMAIN
Epíteto: Beauty Proved in Carbon, Watts, and Species
Ideograma primário: SYNTHESIS
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 264