# Romantic Revival

Eixo (verbatim): RESONANCE ↑ (presença) → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Nostalgia's Embrace
Ideograma primário: RESONANCE
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 771