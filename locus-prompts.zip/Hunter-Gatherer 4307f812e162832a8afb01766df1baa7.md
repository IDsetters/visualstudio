# Hunter-Gatherer

Eixo (verbatim): ETERNITY ↑ → SAGA ↑
Eixo secundário: SAGA
Epíteto: Fire Ring Holds Knowledge Within a Day's Walk
Ideograma primário: ETERNITY
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 443