# Hermitcore

Eixo (verbatim): EXPRESSION ↓ → INTENTIONALITY ↑
Eixo secundário: INTENTIONALITY
Epíteto: Thoreau's Ten-by-Fifteen Cabin Holds One Life
Ideograma primário: EXPRESSION
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↓ ausência
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 428