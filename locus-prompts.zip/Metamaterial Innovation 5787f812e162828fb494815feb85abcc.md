# Metamaterial Innovation

Eixo (verbatim): MATTER ↑ → SYNTHESIS ↑
Eixo secundário: SYNTHESIS
Epíteto: Matter Engineered to Disobey Nature
Ideograma primário: MATTER
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 565