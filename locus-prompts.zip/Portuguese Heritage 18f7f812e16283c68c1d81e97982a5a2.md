# Portuguese Heritage

Eixo (verbatim): SAGA ↑ (presença) → EDITING ↓
Eixo secundário: EDITING
Epíteto: Empire Returns as Ornament
Ideograma primário: SAGA
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 703