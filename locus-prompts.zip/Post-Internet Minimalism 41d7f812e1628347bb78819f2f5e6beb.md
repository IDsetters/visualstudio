# Post-Internet Minimalism

Eixo (verbatim): EDITING ↑ → MATTER ↑
Eixo secundário: MATTER
Epíteto: Digital Detox Through Design
Ideograma primário: EDITING
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 705