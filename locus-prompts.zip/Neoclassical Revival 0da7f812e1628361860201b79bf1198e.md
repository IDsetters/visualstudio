# Neoclassical Revival

Eixo (verbatim): COHERENCE ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Antiquity Recast for Modern Longing
Ideograma primário: COHERENCE
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 605