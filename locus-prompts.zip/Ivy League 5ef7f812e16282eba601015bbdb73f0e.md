# Ivy League

Eixo (verbatim): SEMIOTICS ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Shetland Sweater Crosses Harvard Yard
Ideograma primário: SEMIOTICS
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 483