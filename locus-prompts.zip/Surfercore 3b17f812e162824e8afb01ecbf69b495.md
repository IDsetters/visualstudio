# Surfercore

Eixo (verbatim): EMANATIO ↑ → RESONANCE ↑
Eixo secundário: RESONANCE
Epíteto: Salt, swell, and a schedule set by tides
Ideograma primário: EMANATION
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 871