# Liminal Space

Eixo (verbatim): EFFECT ↑ (presença) → COHERENCE ↓
Eixo secundário: COHERENCE
Epíteto: Fluorescent hallways after closing
Ideograma primário: EFFECT
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 524