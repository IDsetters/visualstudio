# Primitivism

Eixo (verbatim): SEMIOTICS ↑ → SYNTHESIS ↑
Eixo secundário: SYNTHESIS
Epíteto: Paris Raids the World for Modernity
Ideograma primário: SEMIOTICS
Nível: 🟣 Secundária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 720