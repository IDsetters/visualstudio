# Silent Generation

Eixo (verbatim): EDITING ↑ → EXPRESSION ↓
Eixo secundário: EXPRESSION
Epíteto: Quiet Achievers
Ideograma primário: EDITING
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 806