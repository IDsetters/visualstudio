# Eclectic

Eixo (verbatim): SYNTHESIS ↑ → SEMIOTICS ↑
Eixo secundário: SEMIOTICS
Epíteto: Seven Dialects, One Sentence That Parses
Ideograma primário: SYNTHESIS
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 262