# Imaginative Realism

Eixo (verbatim): EXPRESSION ↑ → INTEGRITY ↑
Eixo secundário: INTEGRITY
Epíteto: Frazetta's Dragon Carries Anatomical Weight
Ideograma primário: EXPRESSION
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 459