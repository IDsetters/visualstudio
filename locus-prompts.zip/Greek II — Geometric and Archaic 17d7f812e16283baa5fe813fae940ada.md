# Greek II — Geometric and Archaic

Eixo (verbatim): INTEGRITY ↑ → ETERNITY ↓
Eixo secundário: ETERNITY
Epíteto: Dipylon Meander Teaches the Kouros to Stand
Ideograma primário: INTEGRITY
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 401