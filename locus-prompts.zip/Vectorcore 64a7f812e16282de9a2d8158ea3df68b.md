# Vectorcore

Eixo (verbatim): ILLUMINATION ↑ → MATTER ↓
Eixo secundário: MATTER
Epíteto: Digital Precision With No Grain to Hide
Ideograma primário: ILLUMINATION
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 942