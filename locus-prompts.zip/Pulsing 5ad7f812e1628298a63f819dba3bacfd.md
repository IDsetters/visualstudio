# Pulsing

Eixo (verbatim): RESONANCE ↑ (presença) → SYNERGY ↑
Eixo secundário: SYNERGY
Epíteto: Beat Made Visible Between Frames
Ideograma primário: RESONANCE
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 732