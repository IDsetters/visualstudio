# Serpentcore

Eixo (verbatim): SEMIOTICS ↑ → EMANATIO ↑
Eixo secundário: EMANATION
Epíteto: Reptilian Grace
Ideograma primário: SEMIOTICS
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 798