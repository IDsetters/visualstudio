# Japanese (Experimental)

Eixo (verbatim): SYNTHESIS ↑ → TECHNIQUE ↑
Eixo secundário: TECHNIQUE
Epíteto: Gutai Tears the Paper Screen and Calls It Form
Ideograma primário: SYNTHESIS
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 486