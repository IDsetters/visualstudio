# Gothic II Romantic Gothic

Eixo (verbatim): THEME ↑ (presença) → ILLUMINATION ↓
Eixo secundário: ILLUMINATION
Epíteto: Walpole's Ruin Lit by One Candle
Ideograma primário: THEME
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 390