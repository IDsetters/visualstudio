# Extravagance

Eixo (verbatim): EMANATIO ↑ → DENSITY ↑
Eixo secundário: DENSITY
Epíteto: Gilding Applied Until the Surface Disappears
Ideograma primário: EMANATION
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 314