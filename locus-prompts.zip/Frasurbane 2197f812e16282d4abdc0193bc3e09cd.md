# Frasurbane

Eixo (verbatim): NARRATIVE ↑ → MATTER ↑
Eixo secundário: MATTER
Epíteto: 'Frasier' Apartment: Jazz, Wine, and Eames
Ideograma primário: NARRATIVE
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 347