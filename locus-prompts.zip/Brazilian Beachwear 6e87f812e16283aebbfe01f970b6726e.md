# Brazilian Beachwear

Eixo (verbatim): EXPRESSION ↑ → EDITING ↑
Eixo secundário: EDITING
Epíteto: Tan line drawn by electrical tape
Ideograma primário: EXPRESSION
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 119

## Prompt de locus duplo — EXPRESSION ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação → veredito **RA** *(escolha interna — site publicado só até o № 054)* · **Epíteto:** *Tan line drawn by electrical tape*

`A rooftop tanning deck at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the strip of black electrical tape drawing the tan line's future edge at the hip, one kept imperfection: last summer's line a centimetre off beneath the new one, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the deck culled to three objects — the roll of tape, a bottle of oil, a folded canga — the cull's trace in the swept concrete's broom lines, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**Linha negativa:** `no softbox flattery, no retouched skin, no tripod-locked symmetry, no second focal point, no more than three objects, no swimwear-catalogue posing, no vulgarity, no digital smoothing`

## Prompts por substyle

Cada prompt herda a arquitetura do locus EXPRESSION ↑ → EDITING ↑ e o veredito RA (rearticulação); parear sempre com a linha negativa da estética acima.

**👙 CLASSIC BRAZILIAN BIKINI** — `a sand strip at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the hand-tied side knot repeated at hip and neck, one kept imperfection: one loop pulled a centimetre longer than the other, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the towel culled to three objects — a comb, a bottle of oil, a folded canga — the cull's trace in the raked sand's drag lines, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**💎 LUXURY BEACHWEAR** — `a private terrace above the water at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the hand-finished gold ring joining the straps, repeated once at the hip, one kept imperfection: a thread end left uncut at the seam, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the terrace culled to three objects — a linen wrap, a glass of water, one sandal — the cull's trace in the swept stone's broom lines, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🏄 ATHLETIC BEACHWEAR** — `a surf break shoreline at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the flat-locked seam running hip to shoulder, repeated once on the leash cuff, one kept imperfection: a wax smear dried on the ribs, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the sand culled to three objects — a board, a bar of wax, a folded rash top — the cull's trace in the drag mark where the board was hauled up, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**👗 FASHION BEACHWEAR** — `a boardwalk wall at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the asymmetric single strap repeated once as a wrist tie, one kept imperfection: the strap sitting a centimetre off the shoulder bone, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the wall culled to three objects — a sample tag, a bottle of oil, a folded sarong — the cull's trace in the cleared ledge where the rail was moved, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**♻️ SUSTAINABLE BEACHWEAR** — `a tidal rock shelf at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the undyed regenerated-fibre binding repeated at hip and neck, one kept imperfection: a slight colour drift between the two panels, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the rock culled to three objects — a mesh bag, a bar of solid sunscreen, a folded cotton wrap — the cull's trace in the cleared shelf where collected plastic was carried off, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**📷 VINTAGE BEACHWEAR** — `a 1970s poolside deck at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the high-cut leg line repeated once in the belt of the cover-up, one kept imperfection: the elastic gone slightly slack at one hip, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the deck culled to three objects — a tanning mirror, a bottle of oil, a folded terry robe — the cull's trace in the pale rectangles where loungers were dragged away, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**✨ BIKINI WORLD EXPORT** — `a shipping-crate loading bay open to the beach at noon, one internal state carried in jaw, shoulder and hand — unhurried certainty — exactly one recurring sigil: the same tie-knot printed on the export carton and worn on the body, one kept imperfection: the printed knot slightly out of register, direct unblinking gaze down the lens, hard undiffused noon light, handheld-feel framing with the crop slightly wrong and grain kept, the bay culled to three objects — one carton, a bottle of oil, a folded canga — the cull's trace in the swept concrete's broom lines where the pallet stood, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`