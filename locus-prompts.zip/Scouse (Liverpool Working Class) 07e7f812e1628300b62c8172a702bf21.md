# Scouse (Liverpool Working Class)

Eixo (verbatim): RESONANCE ↑ (presença) → SYNERGY ↑
Eixo secundário: SYNERGY
Epíteto: Style With a Mersey Beat
Ideograma primário: RESONANCE
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 789