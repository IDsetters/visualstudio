# Indigenous Futurisms

Eixo (verbatim): SAGA ↑ (presença) → SYNTHESIS ↑
Eixo secundário: SYNTHESIS
Epíteto: Skawennati Sends the Longhouse Into Cyberspace
Ideograma primário: SAGA
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 467