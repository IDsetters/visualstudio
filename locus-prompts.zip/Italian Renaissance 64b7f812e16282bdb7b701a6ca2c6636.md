# Italian Renaissance

Eixo (verbatim): SYNTHESIS ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Brunelleschi's Dome Makes Florence Measure the World
Ideograma primário: SYNTHESIS
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 482