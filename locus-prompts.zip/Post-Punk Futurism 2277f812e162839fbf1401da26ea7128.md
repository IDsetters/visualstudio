# Post-Punk Futurism

Eixo (verbatim): EXPRESSION ↑ → SYNTHESIS ↑
Eixo secundário: SYNTHESIS
Epíteto: Rebellion Evolved Into Tomorrow
Ideograma primário: EXPRESSION
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 709