# Tinycore

Eixo (verbatim): DENSITY ↑ → RESONANCE ↑
Eixo secundário: RESONANCE
Epíteto: Wonder Reduced to Dollhouse Scale
Ideograma primário: DENSITY
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 901