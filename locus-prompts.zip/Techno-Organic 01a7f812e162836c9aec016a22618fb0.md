# Techno-Organic

Eixo (verbatim): SYNTHESIS ↑ → MATTER ↑
Eixo secundário: MATTER
Epíteto: Biology Wired Into Digital Growth
Ideograma primário: SYNTHESIS
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 894