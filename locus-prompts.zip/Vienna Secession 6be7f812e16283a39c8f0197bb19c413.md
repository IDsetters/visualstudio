# Vienna Secession

Eixo (verbatim): SYNTHESIS ↑ → EMANATIO ↑
Eixo secundário: EMANATION
Epíteto: Laurel Dome Breaks Academic Rank
Ideograma primário: SYNTHESIS
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 950