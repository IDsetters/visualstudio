# Hudson River School

Eixo (verbatim): NARRATIVE ↑ → MATTER ↓
Eixo secundário: MATTER
Epíteto: Cole's Catskill Light Edits the Railroad Out
Ideograma primário: NARRATIVE
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 442