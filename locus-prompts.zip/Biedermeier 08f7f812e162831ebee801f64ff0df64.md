# Biedermeier

Eixo (verbatim): COHERENCE ↑ → EXPRESSION ↓
Eixo secundário: EXPRESSION
Epíteto: Chair sized for the hand that dusts it
Ideograma primário: COHERENCE
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 87

## Prompt de locus duplo — COHERENCE ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por transmissão → veredito **TR** *(escolha interna — site publicado só até o № 054)* · **Epíteto:** *Chair sized for the hand that dusts it*

*Nota de arquitetura:* EXPRESSION entra em registro suprimido (↓) — sinal retido: tom sobre tom silenciado, silhueta fechada e autossuficiente, luz plana sem fonte com nada mais iluminado que o resto, figura empurrada à borda do quadro, rosto sem nada a declarar, ofício que só aparece no olhar lento, nenhum objeto disposto a ser a primeira coisa vista.

`A modest parlour where one construction logic reads at every scale — the cherry-wood chair's clean curve repeated in the sewing box's lid, the porcelain cup's handle, the picture frame's profile — a matched pair of readings in one image: the full room legible as an 85mm view and the dovetail detail as a 100mm view under identical window light, the whole recoverable from any fragment, the chair sized for the hand that dusts it, and the expressive signal deliberately withheld: muted tone-on-tone honey browns and greys, a closed self-contained silhouette in a high-collared house dress, flat sourceless daylight with nothing lit more than anything else, the figure pushed to the frame's edge with the face turned to the needlework and given nothing to declare, craft that surfaces only under slow looking, no object in frame willing to be the first thing seen, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**Linha negativa:** `no drama, no gesture demanding attention, no single lit hero object, no theatrical shadow, no palace scale, no gilt excess, no stylistic drift between scales, no mixed lighting logics, no modern object`

## Prompts por substyle

Cada prompt herda a arquitetura do locus COHERENCE ↑ → EXPRESSION ↓ e o veredito TR (transmissão); parear sempre com a linha negativa da estética acima. Todos os substyles vivem em 1815–1848.

**🏡 GERMAN DOMESTIC CULTURE** — `A Wohnzimmer where one household logic reads from the room's width to the darning egg's grain, wide view and close detail legible under the same flat window light, tone-on-tone browns, the family at quiet tasks pushed toward the frame's edges with faces given nothing to declare, the clock's tick implied rather than staged, craft surfacing only under slow looking, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🪑 FURNITURE CRAFTSMANSHIP** — `A joiner's showroom corner where the cherry veneer's logic repeats from the secretary desk's full height down to one drawer's keyhole escutcheon, an 85mm room reading and a 100mm dovetail reading under identical light, the whole piece recoverable from the fragment, the craftsman at the frame's edge with a polishing cloth and a face turned to the grain, muted tone-on-tone finish, flat even daylight, no piece lit more than another, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🎨 INTIMATE PORTRAITURE** — `A sitter posed small within the room rather than filling it, the portrait's construction logic — clean oval face, closed silhouette, tidy interior — repeated identically in the miniature on the table beside, full scene and locket detail legible under one flat window light, tone-on-tone dress against tone-on-tone wall, the face composed and given nothing to declare, craft in the lace collar surfacing only under slow looking, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**📚 LITERARY SALON** — `A reading circle where one binding logic reads from the bookcase's full wall to a single gilt-tooled spine, the room at 85mm and the endpaper's marbling at 100mm under the same lamp-warm evenness, readers pushed to the frame's edges with faces bent to their pages declaring nothing, muted wool and paper tones joined, the reading aloud implied only by one turned head, craft surfacing under slow looking, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🌸 DECORATIVE ARTS PORCELAIN** — `A cabinet where one painting logic reads from the full service to a single cup's flower sprig, shelf view and rim detail legible under identical flat light, the whole pattern recoverable from any fragment, the collector's hand at the frame's edge dusting with a face given nothing to declare, tone-on-tone whites and blossom pinks muted to the room's register, no piece lit as hero, craft surfacing only under slow looking, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**☕ CAFÉ CULTURE** — `A Konditorei corner where one turned-wood logic repeats from the chair backs to the pastry stand's spindle, the café's width and the cup handle's curve legible under the same flat afternoon light, patrons at quiet conversation pushed to the frame's edges with faces declaring nothing, tone-on-tone creams and walnut browns, the newspaper rack orderly and unlit as everything else, craft in the strudel's laminations surfacing only under slow looking, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🎵 DOMESTIC MUSIC MAKING** — `A parlour fortepiano whose case logic repeats from the full instrument to one ivory key's edge, room view and hinge detail legible under identical evening evenness, the player and the page-turner pushed toward the frame's edge with faces bent to the score declaring nothing, tone-on-tone muslin and mahogany, the music implied by hands mid-phrase rather than performed at the camera, craft in the fretwork stand surfacing under slow looking, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`