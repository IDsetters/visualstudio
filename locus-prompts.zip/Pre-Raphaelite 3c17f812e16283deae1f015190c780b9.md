# Pre-Raphaelite

Eixo (verbatim): NARRATIVE ↑ → DENSITY ↑
Eixo secundário: DENSITY
Epíteto: Victorian England Dreams in Medieval Color
Ideograma primário: NARRATIVE
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 718