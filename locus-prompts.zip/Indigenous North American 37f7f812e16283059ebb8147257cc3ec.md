# Indigenous North American

Eixo (verbatim): SAGA ↑ (presença) → COHERENCE ↑
Eixo secundário: COHERENCE
Epíteto: Haudenosaunee Wampum Holds Law in Beadwork
Ideograma primário: SAGA
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 468