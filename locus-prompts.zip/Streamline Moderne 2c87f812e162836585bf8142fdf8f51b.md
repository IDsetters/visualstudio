# Streamline Moderne

Eixo (verbatim): ESTHETICS ↑ → EFFECT ↑
Eixo secundário: EFFECT
Epíteto: Aerodynamic Dreams Take Flight
Ideograma primário: ESTHETICS
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 854