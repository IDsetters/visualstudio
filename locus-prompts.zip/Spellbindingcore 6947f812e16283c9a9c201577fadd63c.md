# Spellbindingcore

Eixo (verbatim): SEMIOTICS ↑ → RESONANCE ↑
Eixo secundário: RESONANCE
Epíteto: Enchantment worn as everyday armor
Ideograma primário: SEMIOTICS
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 839