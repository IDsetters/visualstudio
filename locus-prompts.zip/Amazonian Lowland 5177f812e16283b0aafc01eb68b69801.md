# Amazonian Lowland

Eixo (verbatim): COHERENCE ↑ → MATTER ↑
Eixo secundário: MATTER
Epíteto: Cosmology built from vines and mud
Ideograma primário: COHERENCE
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 43

## Prompt de locus duplo — COHERENCE ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão → veredito **TR** · **Epíteto:** *Cosmology built from vines and mud*

`Photographed as a matched pair under one identical light — a tight 100mm detail at f/8 beside an 85mm full-length at f/8 with matching exposure — a figure inside the concentric plan of a shabono whose kené weave grammar is legible at every scale of the same look: the serpentine river line repeated in the painted line on the cheek, in the woven cuff, in the vine lashing of the roof ring, the fingers crossing in the weave's own over-under rhythm, the same even temperature of expression held identically in close detail and at full length, the widened grounded stance braced against the mass of wet clay and rolled palm fibre, hands reading the weave with tendons visible, mud and plant dye kept on the forearm, hard raking light through the roof opening skimming every fibre ridge so the weave survives at print scale, the surrounding structure obeying the same construction grammar without literalizing it, any crop of the frame keeping the logic, the pattern of the whole recoverable from the fragment alone, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**Linha negativa:** `No stylistic drift between scales, no detail that contradicts the silhouette, no mixed lighting logics, no off-programme accessory, no reading that changes with distance, no crop that breaks the pattern, no gloss, no synthetic sheen, no weightless floating fabric, no digital smoothing, no printed patina, no set that hides its own formation.`

## Prompts por substyle

Cada prompt herda a arquitetura do locus COHERENCE ↑ → MATTER ↑ e o veredito TR (transmissão); parear sempre com a linha negativa da estética acima.

**🌿 INDIGENOUS** — `Matched pair at f/8 under one light, an elder's hands and full figure carrying the same ancestral construction logic from fingertip to roofline, a woven basket whose over-under rhythm repeats in the house lashing and the painted arm line, clay dust and annatto kept on the skin, raking light holding fibre ridges at print scale, the fragment predicting the whole from any crop, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🛶 RIVERINE** — `Matched pair at f/8 under one river light, a dugout canoe's adze-cut grain repeating the same line as the paddler's woven arm band and the current's serpentine track, the body braced against the paddle's real load, wet wood and mud legible at print scale, the water-highway grammar surviving every crop from bow detail to full bend of the river, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🌺 BOTANICAL** — `Matched pair at f/8 under one canopy light, a healer's bench of pressed leaves and bark scrapings where the leaf's vein logic repeats in the woven mat and the sorted rows, hands crushing fresh plant matter with sap kept on the fingers, every vein and fibre held at print scale, the same classifying grammar legible from a single leaf to the whole bench, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🔮 SHAMANIC** — `Matched pair at f/8 under one low fire light, a maloca interior where the kené vision pattern painted on the post repeats in the cup's incised rim and the singer's painted jaw, the vine brew's clay pot braced in both hands with real weight, smoke and pigment texture surviving at print scale, one continuous cosmological line recoverable from any fragment of the frame, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**♻️ SUSTAINABLE** — `Matched pair at f/8 under one worked light, a permaculture terrace whose planting rows repeat the same interval as the woven fence and the gardener's braided cord belt, hands pressed into wet earth with tendons visible, mulch and clay legible at print scale, the growing system's single logic surviving from one seedling to the whole slope, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🏙️ URBAN** — `Matched pair at f/8 under one humid city light, a city-forest street where the vine climbing the concrete pillar repeats the painted serpentine on the wall and the woven bag on the shoulder, the figure braced against a sack of market produce with real weight, moss on masonry held at print scale, the same green grammar legible from a single tendril to the whole block, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**💻 DIGITAL** — `Matched pair at f/8 under one screen-and-fire light, a cyber-shamanic workspace where the kené lattice on the monitor repeats the beaded wristband and the woven chair back at exact interval, hands resting on clay-dusted keys with tendons visible, pixel grid and plant fibre both surviving at print scale, one continuous pattern recoverable from screen fragment or woven fragment alike, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`