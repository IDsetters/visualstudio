# Deconstructed Glamour

Eixo (verbatim): EXPRESSION ↑ → INTEGRITY ↓
Eixo secundário: INTEGRITY
Epíteto: Autopsy of luxury
Ideograma primário: EXPRESSION
Nível: 🟣 Secundária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 212

## Prompt de locus duplo — EXPRESSION ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por ruptura → veredito **RP** *(escolha interna — site publicado só até o № 054)* · **Epíteto:** *Autopsy of luxury*

*Nota de arquitetura:* o polo secundário está em registro suprimido — INTEGRITY ↓ significa sistemas construtivos misturados no mesmo objeto, postura assimétrica e duas luzes desiguais que não combinam. Nada de prumo, nada de lógica única, nada de luz única: a incoerência construtiva é a matéria da imagem.

`figure standing in a bare atelier wearing a couture garment opened to its own construction, ONE internal state held throughout — composed refusal — a recurring sigil in the exposed basting thread appearing three times on the body, one kept imperfection left uncorrected in a puckered shoulder seam, hard undiffused light with two unmatched sources, one cold from a high window and one warm from a work lamp, shadows crossing and disagreeing, mixed construction systems in the same piece — hand-padded canvas beside raw serged edge beside bonded seam — asymmetric stance with the hips off any plumb line, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event — the garment's finished face is turned inward and the interior is worn outward, 85mm at f/5.6, 8k`

**Linha negativa:** `no soft diffused light, no single matched light source, no symmetrical plumb stance, no clean finished hems, no polished styling, no HDR, no glossy skin, no runway crowd, no pristine tailoring, no colour harmony, no text, no watermark, no signature`

## Prompts por substyle

Cada prompt herda a arquitetura do locus EXPRESSION ↑ → INTEGRITY ↓ e o veredito RP (disrupção por ruptura); parear sempre com a linha negativa da estética acima. Em todas as imagens: um único estado interno sustentado, um sigilo recorrente em três aparições, uma imperfeição preservada e luz dura sem difusão (EXPRESSION ↑). No registro suprimido de INTEGRITY ↓: sistemas construtivos misturados, postura assimétrica e duas luzes desiguais. Uma regra da gramática herdada aparece rompida como evento central.

**🎭 AVANT-GARDE EXPERIMENTAL FASHION** — `figure standing in an empty white studio in a sculptural garment that denies the body's line, ONE internal state of composed refusal, a recurring sigil in a chalk pattern mark repeated three times on the cloth, one kept imperfection in an unclipped thread at the neck, hard undiffused light from two unmatched sources with disagreeing shadows, mixed construction systems in the same piece with moulded felt beside raw cut edge, asymmetric stance off any plumb line, one rule of the inherited grammar visibly broken inside the frame — the garment has no front and no back, both faces reading as interior — 85mm at f/5.6, 8k`

**👗 FASHION WEARABLE DECONSTRUCTION** — `figure standing in a workroom in a tailored jacket with its lining and canvas exposed, ONE internal state of composed refusal, a recurring sigil in white basting stitch appearing three times, one kept imperfection in a shoulder that sits deliberately high, hard undiffused light from two unmatched sources, mixed construction systems with hand-padded canvas beside serged edge beside bonded seam, asymmetric stance with hips off plumb, one rule of the inherited grammar visibly broken inside the frame — the sleeve is attached but unfinished at the head and the armhole stays visible — 85mm at f/5.6, 8k`

**💔 FRAGILE BEAUTY IMPERFECTION** — `figure standing against a stained plaster wall in a worn silk dress with visible mends, ONE internal state of composed refusal, a recurring sigil in a small darned square repeated three times, one kept imperfection in a tea-coloured stain left unremoved, hard undiffused light from two unmatched sources with crossing shadows, mixed construction systems with hand-darning beside machine overlock, asymmetric stance off plumb, one rule of the inherited grammar visibly broken inside the frame — the damage is placed at the focal point where the ornament should be — 85mm at f/5.6, 8k`

**✂️ TEXTILE MANIPULATION** — `figure standing beside a cutting table wearing a garment of shredded and re-fused cloth, ONE internal state of composed refusal, a recurring sigil in a scorched edge motif appearing three times, one kept imperfection in a fray left growing, hard undiffused light from two unmatched sources, mixed construction systems with heat-bonded panel beside hand-stitched patch beside raw slash, asymmetric stance with weight thrown to one side, one rule of the inherited grammar visibly broken inside the frame — the cloth is cut across the grain everywhere and refuses to hang — 75mm at f/5.6, 8k`

**✨ RECONSTRUCTED ELEGANCE** — `figure standing in a mirrored fitting room in a gown assembled from parts of three different garments, ONE internal state of composed refusal, a recurring sigil in a repeated original label sewn three times on the outside, one kept imperfection in a mismatched hem length, hard undiffused light from two unmatched sources, mixed construction systems with couture seam beside utility zip beside knotted tie, asymmetric stance off any plumb line, one rule of the inherited grammar visibly broken inside the frame — the silhouette is elegant and every joint that produced it is left on show — 85mm at f/5.6, 8k`

**🖤 DARK ROMANTIC DECONSTRUCTION** — `figure standing in a shuttered room in a black lace and jersey construction pulled apart at the seams, ONE internal state of composed refusal, a recurring sigil in a torn rosette repeated three times, one kept imperfection in a ladder run down the sleeve, hard undiffused light from two unmatched sources with governed dark between them, mixed construction systems with corsetry boning beside raw jersey edge, asymmetric stance with the shoulders counter to the hips, one rule of the inherited grammar visibly broken inside the frame — the mourning silhouette is opened at the chest where it should be most closed — 85mm at f/5.6, 8k`

**🔄 CIRCULAR FASHION PHILOSOPHY** — `figure standing among sorted textile bales wearing a piece built entirely from reclaimed panels, ONE internal state of composed refusal, a recurring sigil in a stamped batch number appearing three times on the outside, one kept imperfection in a faded patch of the previous garment's colour, hard undiffused light from two unmatched sources, mixed construction systems with industrial overlock beside hand mend beside grommet lacing, asymmetric stance off plumb, one rule of the inherited grammar visibly broken inside the frame — the garment openly declares its previous life instead of erasing it — 50mm at f/5.6, 8k`