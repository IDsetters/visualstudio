# Harvest Festivalcore

Eixo (verbatim): SAGA ↑ (presença) → COHERENCE ↓
Eixo secundário: COHERENCE
Epíteto: Seren Taun Rice Procession Returns to Cigugur
Ideograma primário: SAGA
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 419