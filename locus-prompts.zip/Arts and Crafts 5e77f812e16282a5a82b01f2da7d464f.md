# Arts and Crafts

Eixo (verbatim): MATTER ↑ → INTEGRITY ↑
Eixo secundário: INTEGRITY
Epíteto: Oak that admits it's oak
Ideograma primário: MATTER
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 64

## Prompt de locus duplo — MATTER ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por ruptura → veredito **RP** *(escolha interna — site publicado só até o № 054)* · **Epíteto:** *Oak that admits it's oak*

`A joiner in a hand-loomed linen work smock braced at a quarter-sawn oak bench, widened grounded stance taking the plank's full weight, knuckles deep in the open grain and tendons visible, gaze steady under the load, matte mineral skin with oak dust settled on the collarbone, every construction in frame exposed — through-tenons, pegged joints, plane marks legible in the wood, the smock finished inside as out with one exposed seam standing for the whole system — one continuous structural logic running from floor joist to rafter, feet hips shoulders stacked on the same plumb vertical as the roof posts, a single north window the only light, one temperature one direction near to far, camera tripod-still at eye level with zero tilt, raking three-quarter light so the grain survives at print scale, the ground showing its own formation in shavings and mid-use tools, and at the centre the frame's one event: a Victorian parlor panel half stripped, its false rosewood veneer peeled back to expose the honest oak beneath, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**Linha negativa:** `no gloss, no laminate, no intact veneer, no second light of a different temperature, no leaning vertical, no mixed construction systems, no machine-stamped ornament, no weightless fabric, no decorative hands, no beauty-dish softness, no digital smoothing, no set hiding its own formation`

## Prompts por substyle

Cada prompt herda a arquitetura do locus MATTER ↑ → INTEGRITY ↑ e o veredito RP (ruptura); parear sempre com a linha negativa da estética acima.

**🏡 WILLIAM MORRIS GUILD CRAFT** — `A guild weaver at a wooden hand-loom in a Merton Abbey workshop, 1890s, braced low against the beater's weight, indigo-stained fingers deep in the warp, a willow-pattern wool tapestry growing one thrown shuttle at a time, every joint of the loom pegged and legible, one north window lighting warp and rafter alike, feet stacked plumb with the loom's posts, and centre frame a roll of machine-printed wallpaper torn across to show the hand-blocked cloth behind it, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🔨 AMERICAN MISSION / PRAIRIE** — `A furniture maker in a Stickley-era workshop, 1900s, bracing a fumed quarter-sawn oak settle whose every mortise-and-tenon is exposed and pegged, hands gripping the rail with tendons visible, ammonia-fumed grain glowing under a single clerestory light, plumb verticals from settle post to roof beam, and centre frame a gilded rococo side chair set out on the scrap pile with its ornament facing the honest frame that replaces it, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🌿 HONEST MATERIALS ETHIC** — `A workbench still life at working height: hammered copper with every hammer blow left legible, unglazed terracotta tile, raw wool yarn, hands mid-task with oak dust on the wrists, one raking window light so each material's formation survives at print scale, and centre frame a painted pine board half sanded back to bare grain, the paint skin curling away, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🎨 INTEGRATED TOTAL DESIGN** — `A sitting room where textile, tile, lamp and bound book all carry one drawn line — the same stem curve in the curtain block print, the fireplace tile, the copper lamp arm and the tooled leather spine — a figure grounded at its centre with a hand resting on the oak mantel's exposed joint, one hearth-side light one temperature, and centre frame the pale silhouette on the wallpaper where a mass-produced ornament has just been taken down, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**♻️ SUSTAINABLE** — `A 1970s back-to-the-land workshop, a builder braced against a beam of reclaimed barn oak, nail holes and old mortises left visible as its history, hand tools mid-use, ground littered with its own shavings, single window light raking the salvaged grain, and centre frame a sheet of plastic laminate leaning abandoned against the wall while the reclaimed oak takes its place on the bench, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**👥 WORKSHOP SKILL SHARING** — `Two pairs of hands on one dovetail joint — the apprentice's holding the board, the master's guiding the saw — both braced at the same bench, matte skin dusted with oak, every stage of a single chair present in the frame from raw board to finished seat, one north light over both heads, the factory's division of labour visibly refused at one bench as the frame's central event, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🌟 MODERN ARTISAN REVIVAL** — `A contemporary maker's studio, 1990s onward, a woodworker braced over a bench with a spokeshave mid-stroke, shavings curling live, exposed joinery and one visible seam in the canvas apron, single daylight source with zero tilt on a tripod-still frame, and centre frame the CNC router standing unplugged in the corner while the hand tool crosses in front of it, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`