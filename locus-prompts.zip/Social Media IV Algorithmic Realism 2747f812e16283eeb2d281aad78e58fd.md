# Social Media IV Algorithmic Realism

Eixo (verbatim): EMANATIO ↑ → EDITING ↑
Eixo secundário: EDITING
Epíteto: Your feed, trained to mirror you
Ideograma primário: EMANATION
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 820