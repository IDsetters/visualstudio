# Mesopotamian

Eixo (verbatim): SEMIOTICS ↑ → MATTER ↑
Eixo secundário: MATTER
Epíteto: Clay Tablets Under a Stepped Sky
Ideograma primário: SEMIOTICS
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 563