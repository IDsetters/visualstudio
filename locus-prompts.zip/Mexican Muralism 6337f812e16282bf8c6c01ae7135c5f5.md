# Mexican Muralism

Eixo (verbatim): NARRATIVE ↑ → DOMAIN ↑
Eixo secundário: DOMAIN
Epíteto: Revolution Painted at Building Scale
Ideograma primário: NARRATIVE
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 567