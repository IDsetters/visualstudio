# Elemental Earth

Eixo (verbatim): MATTER ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Thumbprint Still Pressed in Clay
Ideograma primário: MATTER
Nível: 🟤 Terciária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 275