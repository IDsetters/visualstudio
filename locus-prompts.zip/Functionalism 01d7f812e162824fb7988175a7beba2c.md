# Functionalism

Eixo (verbatim): INTEGRITY ↑ → EDITING ↑
Eixo secundário: EDITING
Epíteto: Sullivan's 1896 Rule: Form Follows Function
Ideograma primário: INTEGRITY
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 353