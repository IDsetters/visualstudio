# Pittura Metafisica

Eixo (verbatim): SEMIOTICS ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Architecture Waiting for a Dream to Return
Ideograma primário: SEMIOTICS
Nível: 🟣 Secundária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 687