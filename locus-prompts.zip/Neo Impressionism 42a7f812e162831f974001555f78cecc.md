# Neo Impressionism

Eixo (verbatim): TECHNIQUE ↑ (presença) → ILLUMINATION ↑
Eixo secundário: ILLUMINATION
Epíteto: Optical Color Carrying Modern Emotion
Ideograma primário: TECHNIQUE
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 596