# Factory Pomo

Eixo (verbatim): SEMIOTICS ↑ → ETERNITY ↓
Eixo secundário: ETERNITY
Epíteto: Exposed Ductwork Worn as Ornament
Ideograma primário: SEMIOTICS
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 316