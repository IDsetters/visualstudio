# Early Christian

Eixo (verbatim): ETERNITY ↑ → SEMIOTICS ↑
Eixo secundário: SEMIOTICS
Epíteto: Gold Ground That Refuses Depth
Ideograma primário: ETERNITY
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 254