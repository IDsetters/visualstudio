# Bohemian Vintage

Eixo (verbatim): RESONANCE ↑ (presença) → MATTER ↑
Eixo secundário: MATTER
Epíteto: Rose a week past bloom
Ideograma primário: RESONANCE
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 105

## Prompt de locus duplo — RESONANCE ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação → veredito **RA** *(escolha interna — site publicado só até o № 054)* · **Epíteto:** *Rose a week past bloom*

`A figure caught mid-departure at the threshold of an attic dress shop, one foot already on the stair, head counter-rotated back toward the racks being left, a carried object in hand — a 1920s beaded dress folded over the arm with a rose a week past bloom pressed against it, the dress's real weight dragging the shoulder line — dusk's magenta half-light meeting the shop's warm tungsten, one strange device at the frame's edge: a wind-up gramophone mid-turn, hands engaged with the beadwork, tendons visible, matte skin with attic dust traced on the collarbone, construction exposed — the beads' knotted threads, the hem's hand-stitching surviving at print scale — 75mm at f/11 raking light, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**Linha negativa:** `no costume-party styling, no fresh showroom rose, no gloss, no weightless fabric, no backlit halo, no decorative hands, no digital smoothing, no sterile boutique emptiness, no era-mixed props contradicting the garments`

## Prompts por substyle

Cada prompt herda a arquitetura do locus RESONANCE ↑ → MATTER ↑ e o veredito RA (rearticulação); parear sempre com a linha negativa da estética acima.

**💕 ROMANTIC BOHEMIAN VINTAGE** — `a woman halted in a doorway mid-departure, head counter-rotated back into the room, a folded lace shawl carried against her chest, magenta half-light falling from the hallway, one strange device on the sill — a brass hygrometer — and the whole thing grounded in matter: her stance widened on the threshold, hands gripping the velvet with tendons visible, matte skin, dust on the collarbone, the shawl's darned repairs and the door's stripped hinge left exposed, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**👗 FASHION BOHEMIAN VINTAGE** — `a figure stopped in a thrift-shop doorway mid-exit, head turned back over the shoulder, a 1970s crushed-velvet coat carried folded over the forearm, magenta half-light from the shop's window sign, one strange device hanging by the frame — a hand-cranked garment steamer — and matter holding the frame: feet planted wide, hands closed on the fabric with tendons showing, matte skin, lint dust on the collarbone, the coat's re-set buttons and open lining seam left visible, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🏠 DOMESTIC BOHEMIAN VINTAGE** — `a person paused in the threshold between two rooms mid-move, head counter-rotated toward the one being left, a rattan side table carried in both arms, magenta half-light from a fringed lamp behind, one strange device on the floor — a wooden carpet beater — and matter dominant: grounded widened stance, tendons raised in the carrying hands, matte skin, house dust on the collarbone, the table's re-caned seat and exposed joinery pegs in plain view, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🎵 VINTAGE FOLK REVIVAL** — `a musician stopped in a hall doorway mid-departure, head turned back to the room, a 1960s parlour guitar carried by the neck, magenta half-light from the stairwell, one strange device on the shelf — a reel-to-reel field recorder — and matter carrying the image: stance widened at the sill, calloused hand closed on the neck with tendons visible, matte skin, rosin dust on the collarbone, the guitar's replaced bridge, worn frets and open case construction left exposed, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**📷 PHOTOGRAPHIC BOHEMIAN VINTAGE** — `a photographer halted in a darkroom doorway mid-exit, head counter-rotated to the trays behind, a stack of still-damp prints carried flat in both hands, magenta half-light from the safelight, one strange device on the bench — a selenium meter on a cord — and matter first: feet planted wide, tendons visible in the carrying hands, matte skin, fixer haze on the collarbone, the enlarger's exposed column and the film cassette's peeled label in plain sight, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🌸 FLORAL BOHEMIAN VINTAGE** — `a woman stopped in a garden doorway mid-departure, head turned back toward the beds, a heavy pressing book carried against the hip with a fern edge protruding, magenta half-light from the late sky, one strange device hooked on the frame — a japanned plant vasculum — and matter grounding it: widened stance on the step, soil under the nails and tendons raised, matte skin, pollen dust on the collarbone, the book's split spine and exposed sewn signatures showing, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🕯️ RETRO OCCULT CHARM** — `a figure paused in a curtained doorway mid-exit, head counter-rotated to the table behind, a wrapped 1970s tarot deck carried in one hand, magenta half-light from a beaded lamp, one strange device on the cloth — a brass planetary volvelle — and matter dominant: stance widened at the threshold, tendons visible in the closed hand, matte skin, candle soot on the collarbone, the deck's foxed edges and the table's exposed trestle joints left in view, raking three-quarter light, 75mm macro at f/11, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`