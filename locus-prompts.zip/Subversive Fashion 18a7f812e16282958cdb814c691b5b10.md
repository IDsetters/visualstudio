# Subversive Fashion

Eixo (verbatim): INTENTIONALITY ↑ → SEMIOTICS ↑
Eixo secundário: SEMIOTICS
Epíteto: Clothing Cut to Question the Rules
Ideograma primário: INTENTIONALITY
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 860