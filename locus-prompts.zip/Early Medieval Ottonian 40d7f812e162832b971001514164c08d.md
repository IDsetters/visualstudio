# Early Medieval Ottonian

Eixo (verbatim): SYNERGY ↑ → INTENTIONALITY ↑
Eixo secundário: INTENTIONALITY
Epíteto: Saxon Court That Calls Itself Rome
Ideograma primário: SYNERGY
Nível: 🟣 Secundária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 258