# Sensational

Eixo (verbatim): EXPRESSION ↑ → EDITING ↓
Eixo secundário: EDITING
Epíteto: More Is More
Ideograma primário: EXPRESSION
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 795