# Optical Illusion

Eixo (verbatim): EFFECT ↑ (presença) → TECHNIQUE ↑
Eixo secundário: TECHNIQUE
Epíteto: Reality Loses the Vote
Ideograma primário: EFFECT
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 650