# Neoclassical

Eixo (verbatim): INTEGRITY ↑ → COHERENCE ↑
Eixo secundário: COHERENCE
Epíteto: Reason Cut Into Marble Proportion
Ideograma primário: INTEGRITY
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 604