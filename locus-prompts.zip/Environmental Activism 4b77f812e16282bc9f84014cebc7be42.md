# Environmental Activism

Eixo (verbatim): INTENTIONALITY ↑ → EFFECT ↑
Eixo secundário: EFFECT
Epíteto: Leaf Stuck in the Wet Paint
Ideograma primário: INTENTIONALITY
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 293