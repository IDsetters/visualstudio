# Abstract Expressionism

Eixo (verbatim): TECHNIQUE ↑ (presença) → RESONANCE ↑
Eixo secundário: RESONANCE
Epíteto: Painting at the size of feeling
Ideograma primário: TECHNIQUE
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 13

## Prompt de locus duplo — TECHNIQUE ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção → veredito **RP** · **Epíteto:** *Painting at the size of feeling*

`a paint-crusted New York loft at the exact working point, an artist's hand mid-gesture over a floor-spread canvas the size of a wall, hard verification light raking the wet surface so every ridge of pigment can be checked, one discarded rolled study leaning by the door, the artist caught at a threshold mid-departure with head counter-rotated toward the unfinished field, a magenta-bias half-light bleeding from the far window, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**Linha negativa:** `tidy easel painting, small decorative canvas, recognizable figures, prettiness, text, watermark, clean clothes, sterile gallery walls`

## Prompts por substyle

Cada prompt herda a arquitetura do locus TECHNIQUE ↑ → RESONANCE ↑ e o veredito RP; parear sempre com a linha negativa da estética acima.

**💥 ACTION PAINTING** — `Pollock's drip revolution caught at the working point, a paint-spattered figure moving across a floor canvas with a stick trailing liquid enamel, 1947–1956 studio performance of physical gesture, hard raking light verifying every flung filament of black and silver, a rejected drip study crumpled at the canvas edge, the body mid-stride as if leaving the frame with head turned back to the wet field, magenta-tinged dusk in the loft window, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🎭 COLOR FIELD EXPRESSIONISM** — `Rothko's spiritual meditation at the working point, a hand steadying a wide brush over a floating rectangle of maroon dissolving into black beside a single vertical Newman zip of white fire, 1947–1970 transcendent minimalism, low verification light grazing the canvas so the feathered edges can be checked, one abandoned darker study turned to the wall, the painter pausing at the threshold mid-departure with head counter-rotated, magenta-bias half-light pooling in the corners, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🏙️ NEW YORK SCHOOL** — `a Cedar Tavern back room turned studio at the working point, brushes in coffee cans, a canvas of muscular strokes under a bare bulb's verification light, 1940s–1960s downtown brotherhood of American art independence and Greenberg criticism, typed pages and a discarded draft canvas stacked by the door, one painter mid-departure in an overcoat with head counter-rotated toward the wet work, a strange chrome siphon bottle on the table, magenta neon bleeding through the blinds, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**✋ GESTURAL ABSTRACTION** — `de Kooning's and Kline's grammar at the working point, an arm sweeping a house-painter's brush of black calligraphy across white primed canvas, emotional brushwork of the 1940s–1960s, hard side light verifying the drag and skip of every bristle, a slashed rejected Women-series study leaning face-out by the wall, the painter half-turned at the doorway mid-departure carrying a single egg-smooth jar of pigment, magenta half-light on wet enamel, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🖌️ PAINTERLY ABSTRACTION** — `paint-as-paint at the working point, a palette knife pressing ridges of unmixed cadmium and zinc into a thick impasto field, anti-illustration material texture of the 1950s–1960s, harsh verification light skimming the surface so each furrow reads like topography, a scraped-down failed panel drying against the radiator, the artist pausing mid-departure with head turned back, one strange dental mirror used to inspect the crust, magenta-bias dusk, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**💧 DRIP PAINTING** — `the all-over composition at the working point, ropes and pools of enamel falling from a pierced can onto raw canvas covering the entire floor, unconscious automatism of 1947–1950, painting redefined with no centre and no edge privileged, verification light raking low so every layered skein can be traced, one rolled rejected canvas at the margin, the painter's shadow mid-stride across the field with head counter-rotated, magenta-tinted evening in the skylight, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**⛰️ ABSTRACT SUBLIME** — `transcendent scale at the working point, a tiny figure on a ladder before a canvas rising past the frame like a chasm of deep ultramarine and burnt darkness, overwhelming spiritual abstraction of the 1940s–1960s, a single work-lamp's verification light picking out the wet seam being finished, one small discarded study pinned like a postage stamp beside the void, the figure caught mid-descent as if departing with head turned back to the immensity, magenta half-light along the floor, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`