# Romanticism

Eixo (verbatim): EXPRESSION ↑ → EDITING ↓
Eixo secundário: EDITING
Epíteto: Feeling's Triumph
Ideograma primário: EXPRESSION
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: IDSETTERS
№: 772