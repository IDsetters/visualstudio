# Baroque

Eixo (verbatim): EMANATIO ↑ → DENSITY ↑
Eixo secundário: DENSITY
Epíteto: Ornament staged until it becomes proof
Ideograma primário: EMANATION
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 80

## Prompt de locus duplo — EMANATION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação → veredito **RA** *(escolha interna — site publicado só até o № 054)* · **Epíteto:** *Ornament staged until it becomes proof*

`A chapel interior organized around one gravitational centre — a gilded altar figure from which every tone in the packed frame grades at three depths, no dedicated key light, only candle banks and a hidden clerestory the scene itself motivates — the frame filled to its edges with disciplined abundance: marble, ormolu, brocade, carved putti, every ornament staged until it becomes proof, one still anchor holding the noise — a kneeling figure as a slow dark column at the centre of the abundance — hands compressed near the torso on a rosary's stacked inventory, steady gaze through the splendour, dark lip and kohl anchoring the face, pattern-on-pattern disciplined by the one dark garment, the gilt motif repeated at three depths in three materials — carved wood, woven thread, painted ceiling — deep focus at f/11 so texture holds at every depth with no empty stretch anywhere, light radiating from the centre until the stone itself appears to generate radiance, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**Linha negativa:** `no minimal backgrounds, no negative space, no shallow depth of field, no chaos without anchor, no frantic gesture, no dedicated studio key, no sourceless glow, no figure faster than the room`

## Prompts por substyle

Cada prompt herda a arquitetura do locus EMANATION ↑ → DENSITY ↑ e o veredito RA (rearticulação); parear sempre com a linha negativa da estética acima. Todos os substyles vivem em 1600s–1750s.

**👑 ABSOLUTIST COURT VERSAILLES** — `A mirrored gallery graded at three depths from one gravitational centre — the king's chair — candle banks and their doubled reflections the only motivated light, the frame packed with brocade, crystal, parquet and courtiers with no empty stretch, one still anchor: a figure in a dark court coat as slow column amid the gold, hands compressed on a stacked order of medals, the sun motif at three depths in three materials — gilt bronze, woven silk, painted ceiling — deep focus holding texture everywhere, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**⛪ COUNTER-REFORMATION SPIRITUALITY** — `A side chapel where the reliquary is the gravitational centre and every tone grades at three depths toward the dark aisles, votive banks the only motivated light, the frame dense with ex-votos, silver hearts and carved saints, one still anchor — a pilgrim as dark column among the offerings — hands compressed on a rosary's inventory, steady gaze through the blaze, the flame motif at three depths in wax, silver and fresco, deep focus with no empty stretch, ornament staged until it becomes proof of the doctrine, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**✨ THEATRICAL ILLUSIONISM** — `A painted ceiling opening into a false heaven, the vanishing burst its gravitational centre with tone graded at three depths down the real architecture, hidden cornice light the only motivated source, the frame packed where fresco figures hand objects across the painted-real seam, one still anchor — a viewer as dark column beneath the trompe-l'oeil — hands compressed on a folded libretto, the cloud motif at three depths in paint, stucco and marble inlay, deep focus so the illusion's edge stays legible everywhere, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🎵 MUSICAL COMPLEXITY** — `An organ loft where the gilded pipe façade is the gravitational centre, tone graded at three depths into the nave below, candle desk lamps the only motivated light, the frame dense with scores, stops, carved music stands and choir robes, one still anchor — the organist as slow dark column amid the ornament — hands compressed above the stacked manuals a breath before the fugue, the scroll motif at three depths in carved oak, printed staff and wrought railing, deep focus with no empty stretch, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🏛️ ARCHITECTURAL BERNINI / BORROMINI** — `An oval nave whose twisted columns spiral toward the lantern as the gravitational centre, daylight from the hidden drum the only motivated source graded at three depths down the travertine, the frame packed with fluting, coffers and sculpted drapery with no empty stretch, one still anchor — a figure in dark pilgrim wool as slow column on the axis — hands compressed on a folded plan of the church itself, the volute motif at three depths in stone, stucco and bronze, deep focus at f/11, stone appearing to generate its own radiance, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**💎 DECORATIVE ARTS LUXURY** — `A cabinet room graded at three depths from one gravitational centre — an ormolu-mounted ebony cabinet blazing under its own candle sconces — the frame packed with porcelain, gilt bronze, tortoiseshell and silk with no empty stretch, one still anchor: a connoisseur as dark column among the objects, hands compressed on a stacked inventory ledger of the collection, the acanthus motif at three depths in bronze, marquetry and woven damask, deep focus holding every texture, ornament staged until it becomes proof of rank, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`

**🌍 GLOBAL SPREAD COLONIAL** — `A colonial mission church where the gilded retable is the gravitational centre, tone graded at three depths toward the adobe walls, candle banks the only motivated light, the frame dense with local silverwork, feathered ornament and carved maize motifs woven into the European grammar with no empty stretch, one still anchor — a figure in dark wool as slow column before the altar — hands compressed on a carved rosary, the sun motif at three depths in gold leaf, hammered silver and painted wood, deep focus everywhere, two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject, 8k`