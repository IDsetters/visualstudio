# Sculptural

Eixo (verbatim): MATTER ↑ → EMANATIO ↑
Eixo secundário: EMANATION
Epíteto: Form's Eloquence
Ideograma primário: MATTER
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 790