# Understimulation

Eixo (verbatim): EDITING ↑ → DENSITY ↓
Eixo secundário: DENSITY
Epíteto: Calm Designed Below the Noise Floor
Ideograma primário: EDITING
Nível: 🟤 Terciária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↓ ausência
Página de origem: ID-MISE-EN-SCENE
№: 925