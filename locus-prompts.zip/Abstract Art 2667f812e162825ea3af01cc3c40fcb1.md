# Abstract Art

Eixo (verbatim): EDITING ↑ → THEME ↑
Eixo secundário: THEME
Epíteto: Painting that stopped pretending
Ideograma primário: EDITING
Nível: 🔴 Primária
Polaridade: XY — disrupção
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 12

## Prompt de locus duplo — EDITING ↑ → THEME ↑

**Polaridade:** XY — disrupção → veredito **RP** · **Epíteto:** *Painting that stopped pretending*

`a painter's studio stripped to exactly three surviving objects, one vast canvas of pure non-representational colour, one loaded brush resting on a rail, one turpentine rag, every figurative study torn from the wall leaving pale ghost rectangles as the visible trace of the purge, the canvas's single chromatic motif recurring at three scales, in the wet paint field, in a small study dropped on the floor, in a smear across the window glass, only the canvas plane critically sharp while the room dissolves into luminous bokeh, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**Linha negativa:** `recognizable figures, portrait likeness, landscape horizon, storytelling scene, text, watermark, signature, clutter, more than three foreground objects, muddy blended colors`

## Prompts por substyle

Cada prompt herda a arquitetura do locus EDITING ↑ → THEME ↑ e o veredito RP; parear sempre com a linha negativa da estética acima.

**🎨 CUBIST GEOMETRIC DECONSTRUCTION** — `a café still life pared down to guitar, bottle and folded newspaper, the three objects fractured into simultaneous incompatible viewpoints fused on one shallow plane of ochre, umber and slate, 1907–1912 Paris atelier grammar of the Picasso-Braque revolution, the guitar motif recurring at three scales across the shattered facets while only the central facet holds focus and the rest blurs into dusty bokeh, torn naturalistic sketches ghosting at the edge as the trace of what was excluded, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🌊 LYRICAL ABSTRACTION** — `a bare white studio holding only a suspended canvas of gestural stains, a spent brush and an overturned jar, European Informel freedom of the 1950s–1960s, emotion loosed in translucent washes of rose, indigo and gold, the same sweeping stroke recurring at three scales from canvas to floor-splash to droplet on glass, only the stained canvas sharp against a softly glowing blur, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🌈 COLOR FIELD PAINTING** — `a silent gallery reduced to one immense floating veil of saturated crimson bleeding into violet, Newman-Rothko school of chromatic immersion and spiritual minimalism of the 1940s–1970s, a single bench and a lone standing viewer as the only other presences, the colour field's hue recurring at three scales in canvas, reflection on the polished floor and glow on the viewer's skin, only the canvas edge razor sharp, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🔧 CONSTRUCTIVIST ABSTRACTION** — `a workshop table cleared to a red diagonal beam, a black circle of sheet metal and a spool of wire, Tatlin-Rodchenko revolutionary geometry of the Soviet avant-garde 1915–1930s, engineering drawings swept to the floor as the visible trace of the cull, the red diagonal recurring at three scales in maquette, wall poster and cast shadow, only the maquette plane sharp under factory light, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**⬜ SUPREMATIST ABSTRACTION** — `a whitewashed room emptied to one canvas where a black square and two tilted quadrilaterals float on white, Malevich's non-objective pure feeling of 1913–1920s revolutionary Russia, every icon and frame removed from the walls leaving pale nails and halos as the trace of the purge, the tilted square recurring at three scales in canvas, window shadow and floor tile, only the black square critically sharp, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**🌿 BIOMORPHIC ABSTRACTION** — `a sunlit studio pared to a canvas of drifting organic forms, one smooth river stone and one sprouting bulb, Arp-Miró organicism of surrealist biology 1920s–1940s, curved amoebic shapes in coral, black and cobalt, the same soft biomorph recurring at three scales in painting, stone silhouette and shadow on the wall, only the canvas plane sharp inside a warm botanical blur, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`

**✂️ HARD-EDGE PAINTING** — `a pristine white studio reduced to one canvas of immaculate flat bands in cadmium, turquoise and black meeting at razor edges, post-painterly abstraction and American minimalism of the 1950s–1970s, masking tape peeled and coiled on the floor as the visible trace of each subtractive decision, the striped motif recurring at three scales in canvas, tape roll and window blind, only the painted edge critically sharp, one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event, 8k`