# Afrocentricity

Eixo (verbatim): SAGA ↑ (presença) → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Design language older than empire
Ideograma primário: SAGA
Nível: 🔴 Primária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: IDSETTERS
№: 31

## Prompt de locus duplo — SAGA ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão → veredito **TR** · **Epíteto:** *Design language older than empire*

`an artisan at the gravitational centre of a courtyard workshop, a design grammar older than empire ringed around in three ages, fresh kente rising warp by warp on the loom in the inner ring, adinkra cloth stamped by an earlier hand in the middle ring, a bronze relief fragment worn smooth at the outer ring, a hand-carved rope-tuned djembe braced like a relic to be guarded, one carved stool removed leaving its scar in the swept earth, the light aging from centre to edge across carved wood and woven fibre, geometry with no dateable marker, craft sovereignty composed to hang in a museum archive print and on next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**Linha negativa:** `safari costume clichés, colonial exotica framing, generic mixed tribal props, studio gloss, text, watermark`

## Prompts por substyle

Cada prompt herda a arquitetura do locus SAGA ↑ → ETERNITY ↑ e o veredito TR (transmissão); parear sempre com a linha negativa da estética acima.

**👑 ASANTE ACADEMIC FRAMEWORK** — `a theorist at the gravitational centre of a seminar room, the framework ringed in three ages, fresh manuscript pages in the inner ring, annotated foundational volumes of the eighties in the middle ring, a kente-wrapped first edition at the outer ring, a carved Akan stool miniature held like a relic to be guarded, one desk removed leaving its scar on the tiles, no dateable marker beyond the argument's own lineage, afternoon light aging from lectern to shelves, agency written from the centre outward, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**📚 ACADEMIC AFROCENTRICITY** — `a teacher at the gravitational centre of a classroom re-centred on Africa, learning ringed in three ages, today's redrawn map and fresh workbooks in the inner ring, a shelf of sixties liberation curricula in the middle ring, a colonial-era textbook retired under glass at the outer ring, a wooden pointer held like a relic to be guarded, one desk row turned leaving its scuff-scar on the floor, no dateable marker beyond the knowledge reclaimed, window light aging from blackboard to archive corner, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🎨 AFRICAN AESTHETIC LIBERATION** — `a muralist at the gravitational centre of a community wall, liberation ringed in three ages, wet paint on today's panel in the inner ring, a faded seventies mural band in the middle ring, a preserved fragment of the first wall at the outer ring, a calabash of pigment held like a relic to be guarded, one scaffold moved leaving its post-scar in the grass verge, no dateable marker beyond the palette's own inheritance, late sun aging from panel centre to street, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**👘 FASHION AFROCENTRICITY** — `a designer at the gravitational centre of an atelier of reclaimed dress, the revival ringed in three ages, fresh-cut kente and ankara on the table in the inner ring, a rack of first-generation dashikis in the middle ring, an heirloom indigo wrapper at the outer ring, a carved comb held like a relic to be guarded, one dress form removed leaving its castor-scar on the boards, no dateable marker beyond the textile's own lineage, daylight aging from cutting table to storage dark, identity tailored as continuity, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🕯️ ANCESTRAL RELIGION REVIVAL** — `a priestess at the gravitational centre of a household shrine room, reconnection ringed in three ages, fresh libation and kola set out in the inner ring, a parent's consecrated vessels in the middle ring, an ancestor's staff kept wrapped at the outer ring, a white cowrie strand held like a relic to be guarded, one altar table moved leaving its scar on the swept floor, no dateable marker beyond the rite's own calendar, candlelight aging from shrine to doorway dark, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**✊ POLITICAL AFROCENTRICITY** — `an organizer at the gravitational centre of a movement office, consciousness ringed in three ages, tonight's fresh placards in the inner ring, sixties liberation posters archived on the wall in the middle ring, a first-march banner folded under glass at the outer ring, a raised-fist medallion held like a relic to be guarded, one table cleared for the march leaving its scar on the linoleum, no dateable marker beyond the struggle's own continuity, desk lamps aging from centre to filing dark, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`

**🌍 PAN-AFRICAN GLOBAL WAVE** — `a curator at the gravitational centre of a diaspora cultural centre, the wave ringed in three ages, a fresh exhibition of continental designers in the inner ring, festival posters of past decades in the middle ring, an independence-era flag preserved at the outer ring, a beaded pendant of the continent held like a relic to be guarded, one crate shipped onward leaving its scar of clean floor, no dateable marker beyond the movement's own reach, gallery light aging from centre plinth to archive, a frame composed for a museum archive print and next month's cover at once, the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary, 8k`