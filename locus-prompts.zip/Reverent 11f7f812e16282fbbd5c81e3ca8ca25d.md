# Reverent

Eixo (verbatim): ILLUMINATION ↑ → ETERNITY ↑
Eixo secundário: ETERNITY
Epíteto: Design That Kneels Before the Sacred
Ideograma primário: ILLUMINATION
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 758