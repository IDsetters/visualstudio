# Nouveau Réalisme

Eixo (verbatim): MATTER ↑ → DENSITY ↑
Eixo secundário: DENSITY
Epíteto: Street Walks Into the Gallery
Ideograma primário: MATTER
Nível: 🟣 Secundária
Polaridade: XX — continuidade
Polo primário: ↑ presença
Polo secundário: ↑ presença
Página de origem: ID-MISE-EN-SCENE
№: 636