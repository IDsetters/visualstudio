# Instruções para um agente de bloco (5 estéticas)

Você produz os prompts de arte de camiseta do projeto "1001 Aesthetics" para UM bloco de estéticas (A–B), e nada mais. O kit fica em `/tmp/claude-0/tee/kit` e é compartilhado com outros agentes. Nunca mexa em arquivos de números fora do seu bloco.

## Passo 0 — Ler as regras

1. Leia `/tmp/claude-0/tee/kit/GUIA_CRIATIVO.md` inteiro. As regras são obrigatórias.
2. Leia 3 briefs de exemplo em `/tmp/claude-0/tee/kit/exemplos/briefs/`:
   - `016.json` (cultural)
   - `007.json` (conceitual)
   - mais um parecido com a categoria das suas estéticas: `017` digital/subcultura, `012` movimento artístico, `023` esporte/emoção, `025` comercial, `021` lugar/estilo de vida, `020` herança cultural.

## Passo 1 — Dados atuais do Notion (fonte da verdade)

**Estrutura já pronta e oficial:** `/tmp/claude-0/tee/kit/data/notion/NNN.json` já existe para cada estética e vem da taxonomia limpa da autora, tirada das páginas do Notion. Traz:
- `archetype`
- as 3 `personas`
- todos os `substyles`, com `substyle_tags`
- `palette`
- `category`
- `locus`

Arquétipo, personas e substyles vêm SEMPRE desse arquivo. **Não altere** esses campos.

**Do navegador vem só o material criativo:** `axiom`, a descrição de cada persona e os `codes` da comunidade. Quando conseguir o `axiom`, acrescente-o ao `data/notion/NNN.json` (campo `axiom`) com Python, sem mexer no resto.

Se depois de esperar o `__DATA[n]` não vier, siga sem ele, usando a taxonomia e o seu conhecimento da comunidade. Nesse caso o Signature parte de uma tensão de pertencimento escrita por você ("ser incompreendido → ser vindicado"), e isso entra no relatório.

Carregue a ferramenta: `ToolSearch` com `select:mcp__remote-devices__Claude_Browser__javascript_tool` (max_results 1).

Para cada `n` do bloco, chame `javascript_exec` com `tabId "seed"` e o texto:
`JSON.stringify(window.__DATA[n] || null)`
(troque `n` pelo número).

- **Se vier `null`:** a página ainda está sendo extraída em segundo plano. Espere e tente de novo com:
  `await new Promise(r=>setTimeout(r,30000)); JSON.stringify(window.__DATA[n]||null)`
  Repita até 30 vezes.
- **Se `window.__EXT.stopped` for true:** pare e relate.
- **Proibido** navegar, recarregar, abrir abas ou rodar qualquer outro código nessa aba. Ela está extraindo os dados para todos os agentes.

**Campos que chegam:** `title`, `id`, `archetype`, `personas[{name, desc}]`, `substyles[{name, tags}]`, `axiom`, `emoji`, `voice`, `category`, `codes{imagery, motifs, symbols, fashion, identity, subculture}`, `archetype_raw`, `personas_raw`, `check`.

**Uso do `__DATA[n]`:**
- Aproveite `axiom`, `personas[].desc`, `codes` e `emoji`.
- Arquétipo, personas e substyles continuam vindo do `data/notion/NNN.json`. Se o navegador mostrar algo diferente, siga o arquivo e cite a diferença no relatório.
- Acrescente o `axiom` ao `data/notion/NNN.json` com Python (`json.load`, define `["axiom"]`, `json.dump(..., ensure_ascii=False, indent=1)`).

**Paleta:** está em `/tmp/claude-0/tee/kit/data/taxonomia_1001.json`, chave `palette` do registro `n`. Use só esses HEX.

## Passo 2 — Briefs

Para cada estética, grave `/tmp/claude-0/tee/kit/briefs/NNN.json` no mesmo formato dos exemplos. Escreva com um script Python (`json.dump`, `ensure_ascii=False`) para não errar o escape das aspas.

**Campos do brief:**
- `n`, `name`: o nome curto da estética, antes do "|" no título.
- `NAME`: o nome em MAIÚSCULAS.
- `arch`: o arquétipo em MAIÚSCULAS, sem "THE".
- `L` e `D`: a cor mais clara e a mais escura da paleta, cada uma como `[nome descritivo em minúsculas, "#HEX"]`.

**Itens:**
- **1 item `sub` por substyle**, todos e na ordem do Notion.
  - `title` = nome do substyle em Title Case.
  - O texto diegético entre aspas no `body` = o nome do substyle em MAIÚSCULAS, exatamente.
  - Se o nome contiver uma pessoa real ou uma marca, adapte só o texto impresso, como em "DANTESQUE COSMOS AXIOM", e avise no relatório.
- **3 itens `cast`**, uma por persona.
  - `title` = "The <Persona>".
  - `credit` = "THE <PERSONA EM MAIÚSCULAS>".
  - A cena mostra a persona em ação, a partir da `desc`. O nome da estética aparece grande, entre aspas, dentro da cena.
- **1 item `stmt`**, com `width` "about three-quarters of its width".
  - Arch typography só com o nome.
  - Letras construídas com os materiais e objetos da estética.
  - Nenhum outro texto entre aspas.
- **1 item `sig`**: o Signature Piece.
  - Transforme o `axiom` numa cena-metáfora.
  - O nome da estética, entre aspas, fica dentro da cena.
  - Feche o `body` com: `The poetry: <axiom sem "Feeling X is">.`

**Formato dos substyles:** varie entre Still Life, Muse, Relic, Place, Poster, Mixed Media, Specimen Plate, Close-up, Portrait, Diagram, Studio, Street etc. Escolha o que mais combina com cada substyle.

**Tamanho do `body`:** 650 a 1.300 caracteres, só a cena. O build acrescenta tela, hierarquia, N°, regras de impressão e exclusões; não repita nada disso. Um único texto entre aspas por `body`.

## O nível que se espera (o mais importante)

- **Público:** senso estético apurado, alta moda, peças hype e colecionáveis. A arte precisa dar **orgulho de vestir**, não parecer brinde.
- **Narrativa e poesia visual em toda arte:** um momento, um gesto, um paradoxo visual. Uma lista de objetos não basta.
- **Códigos da comunidade:** 2 a 4 objetos, rituais ou gestos que só quem é de dentro reconhece. Tire-os de `codes` e do seu conhecimento. Nada de clichê de turista.
- **Três vertentes distribuídas nos prompts de cada estética:**
  - **hype:** pôster, bootleg, grafite, cor saturada;
  - **high-end:** ilustração editorial, gravura, guache;
  - **collector:** prancha de museu, relíquia, espécime.
- **Técnica sempre de traço grosso:** "bold engraving-style line work with gouache", "bold ink with flat gouache", "screenprint in flat inks", "woodcut".
- **Cores:** 4 a 7 HEX da paleta por `body`, cada uma com seu papel ("barn red #992A25 apron"). Use nomes descritivos; nunca escreva nomes de pessoas reais, mesmo que estejam no nome da cor na paleta.

## Regras de impressão

- **Nada que vire retângulo na barriga:** parede, painel, quadro grande, janela, céu ou billboard de frente. Escreva "only objects, no walls drawn" e descreva a silhueta irregular.
- **Nada de** glow, translúcido, transparente, névoa suave, linha fina ou hachura fina.
- **Luz e neon** = cor chapada e opaca. Degradê só com halftone grosso.

## Proibido

Pessoas reais, marcas, logotipos, obras famosas, personagens conhecidos, ícone 🃏, banners e faixas, "SOCIAL CLUB/EST./MEMBERS ONLY", HEX como texto impresso e sexualização.

Símbolos culturais e sagrados devem ser descritos com precisão e dignidade.

## Passo 3 — Montar e auditar

Rode `cd /tmp/claude-0/tee/kit && python3 scripts/build.py A-B`, com A e B do seu bloco.

- Repita até ter **0 ERROS**.
- Leia cada AVISO e corrija os reais: parede ou billboard que vira retângulo, cena curta.

## Passo 4 — Relatório final (curto)

Para cada estética, informe:
- `n`, nome, arquétipo, as 3 personas, nº de substyles, nº de prompts;
- qualquer dúvida ou adaptação feita.

**Não cole os prompts no relatório.**
