# Kit Camisetas 1001 Aesthetics

Este projeto gera os prompts de arte de camiseta das 1001 estéticas do livro **Moda Extraordinária / 1001 Aesthetics**.

**Leia `GUIA_CRIATIVO.md` inteiro antes de escrever qualquer brief.**

## Estrutura

| Pasta / arquivo | O que tem |
|---|---|
| `data/taxonomia_1001.json` | Número, título, link do Notion e paleta oficial das 1001 estéticas. |
| `data/notion/NNN.json` | Dados atuais do Notion: arquétipo, personas, substyles, axiom e códigos. Fonte da verdade. |
| `exemplos/briefs/001–025.json` | Os 25 briefs aprovados como padrão de qualidade. Leia antes de escrever. |
| `exemplos/1001_prompts_v5_01-25_completo.txt` | Os 313 prompts prontos das estéticas 1–25. |
| `briefs/` | Onde você escreve os briefs novos (`026.json`, `027.json`…). |
| `saida/` | Onde o `build.py` grava os .txt finais. |
| `scripts/build.py` | Monta e audita: `python scripts/build.py 26-30`. |
| `scripts/extract_notion.js` | Extração das páginas do Notion. |
| `scripts/merge_notion.py` | Junta as extrações em `data/notion/`. |
| `scripts/lista_links.py` | Gera a lista de links para a extração. |

## Pedido típico

"Faça as estéticas 26 a 50":

1. Garanta os dados em `data/notion/` (veja o GUIA, seção 3).
2. Divida em blocos de 5 e use subagentes em paralelo. Cada subagente lê o GUIA e os exemplos e escreve os briefs do seu bloco.
3. Rode `python scripts/build.py 26-50` até ter 0 ERROS.
4. Entregue `saida/1001_prompts_026-050.txt`.

## Regras da dona do projeto

- Nunca grave arquivos no Google Drive.
- Qualidade acima de velocidade. O público é exigente, hype e colecionador.
