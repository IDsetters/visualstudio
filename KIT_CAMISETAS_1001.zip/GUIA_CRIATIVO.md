# Camisetas 1001 Aesthetics — guia de produção (v5)

Prompts de **arte para camiseta** (só a arte, sem mockup), para Seedream 5.0 ou similar. Uma estética por vez, sempre a partir dos dados atuais do Notion.

## 1. O que entregar por estética

| Tipo (`kind`) | Quantos | O que é |
|---|---|---|
| `sub` | 1 por substyle (lista do Notion) | Uma arte por substyle, no formato que fizer mais sentido: Still Life, Muse, Relic, Place, Poster/Bootleg, Mixed Media, Specimen Plate, Close-up, Portrait, Diagram… |
| `cast` | 3 | Hero Scene: cada persona do Notion como protagonista de uma cena. |
| `stmt` | 1 | Statement / arch typography: **só o nome da estética**, muito elaborado. |
| `sig` | 1 | Signature Piece: a obra-prima da estética, com o arquétipo embaixo. |

Exemplo: 7 substyles → 12 prompts.

**Formato do arquivo final:** um prompt por parágrafo, uma linha em branco entre eles, em inglês, com no máximo 3.000 caracteres e começando pelo nome da estética. O `scripts/build.py` monta e audita tudo isso.

## 2. Fonte da verdade

- **Arquétipo, personas e substyles vêm sempre de `data/notion/NNN.json`**, extraído do link do Notion de cada estética. A taxonomia antiga está desatualizada; muitos arquétipos e personas mudaram.
- **Paleta:** `data/taxonomia_1001.json`, que é igual à do Notion. Use só os HEX da paleta.
- **Matéria-prima criativa (`data/notion/NNN.json`):**
  - `axiom`: a frase de pertencimento. É o motor do Signature.
  - `personas_full[].desc`: o que cada persona faz, para criar a Hero Scene.
  - `codes.*` (imagery, motifs, symbols, fashion, identity, subculture): os códigos da comunidade.
  - `emoji_rationale`: o símbolo central da estética.

## 3. Fluxo de trabalho (Claude Code)

1. **Dados.**
   - Se faltar `data/notion/NNN.json`, gere com `python scripts/lista_links.py A B` e rode `scripts/extract_notion.js` no Chrome logado no Notion (veja o cabeçalho do arquivo).
   - Depois rode `python scripts/merge_notion.py <pasta Downloads>`.
   - Corrija à mão os casos marcados "PRECISAM DE CONFERÊNCIA", olhando `archetype_raw` e `personas_raw`.
2. **Briefs.** Para cada estética do bloco:
   - Leia o `data/notion/NNN.json`.
   - Abra 2 ou 3 exemplos em `exemplos/briefs/` da mesma família (filosófica, cultural, digital, emocional, movimento artístico).
   - Pesquise rapidamente os códigos da comunidade quando os dados forem rasos.
   - Escreva `briefs/NNN.json`.
3. **Montagem e auditoria.** Rode `python scripts/build.py A-B`. Corrija todo ERRO e releia cada AVISO. O arquivo sai em `saida/1001_prompts_AAA-BBB.txt`.
4. **Escala.** Trabalhe em blocos de 5 estéticas por subagente, em paralelo. Cada subagente roda o `build.py` no seu bloco. No fim, rode o bloco inteiro de novo.
5. **Antes de escalar** para centenas, gere as imagens de 2 ou 3 estéticas e ajuste o guia se algo falhar. Corrigir uma vez é melhor que corrigir 1001 vezes.

## 4. Formato do brief (`briefs/NNN.json`)

```json
{
 "n": 26, "name": "Aeropunk", "NAME": "AEROPUNK", "arch": "ARCHETYPE NAME IN CAPS",
 "L": ["nome da cor clara", "#XXXXXX"], "D": ["nome da cor escura", "#XXXXXX"],
 "items": [
  {"kind": "sub",  "fmt": "Still Life", "title": "Nome do Substyle", "bg": "L", "body": "..."},
  {"kind": "cast", "fmt": "Hero Scene", "title": "The Persona", "credit": "THE PERSONA", "bg": "D", "body": "..."},
  {"kind": "stmt", "fmt": "Statement", "title": "Arch Typography", "bg": "D", "width": "about three-quarters of its width", "body": "..."},
  {"kind": "sig",  "fmt": "Signature Piece", "title": "Título poético", "bg": "L", "body": "..."}
 ]
}
```

**`name`, `NAME` e `arch`:**
- `name` é o nome da estética como começa o prompt.
- `NAME` é o nome em maiúsculas, que aparece na arte.
- `arch` é o arquétipo do Notion em maiúsculas, sem "THE".

**`L`, `D` e `bg`:**
- `L` e `D` são a cor clara e a cor escura da paleta, ou seja, a cor da camiseta.
- `bg` escolhe entre elas.
- Varie o fundo dentro da estética. Use `D` quando a estética vive no escuro (UV, neon, noite).

**`body`** é só a cena. O `build.py` acrescenta sozinho:
- a tela 4500×5400 com fundo liso;
- a silhueta orgânica;
- o crédito e o arquétipo com a hierarquia de tamanho;
- o "N° XXX · 1001 AESTHETICS";
- as regras de impressão e as exclusões.

**Não repita nada disso no `body`.**

## 5. Guia criativo — o que faz a pessoa sentir orgulho de vestir

**Público:** pessoas com senso estético apurado, que consomem alta moda e gostam de peças hype e colecionáveis. A camiseta precisa parecer obra, não brinde. Trabalhe as três vertentes:

- **Hype:** energia de streetwear, bootleg, pôster de show, grafite, cor saturada.
- **High-end:** ilustração editorial refinada, gravura, guache, composição de revista de moda.
- **Collector:** prancha de museu, espécime, relíquia, série numerada que dá vontade de completar.

Distribua as três vertentes entre os prompts de cada estética.

**Cada arte é uma micro-história com poesia visual.** Pergunte sempre: *qual é o momento? qual é o gesto? qual é o paradoxo visual?* Exemplos que funcionaram:
- **Acadian:** o tapete de lã cujo fio vira a estrada de volta para casa.
- **Zenith:** os seis falsos cumes antes do verdadeiro.
- **Acidgoth:** a roupa "só preta" que revela o verde tóxico sob a luz negra.
- **Adrenaline:** o paraquedas aberto no céu, com as linhas descendo até a mesma pessoa dobrando o paraquedas no chão.
- **Nexus:** o cama-de-gato em que o X é o ponto onde todos os fios se cruzam.

**Regras por tipo:**

- **Signature Piece.**
  - Transforme o `axiom` numa cena. O axiom tem a estrutura "ser incompreendido → ser vindicado", e é isso que dá pertencimento.
  - Feche o `body` com `The poetry: <axiom sem "Feeling X is">.`
  - O nome da estética fica grande e dentro da cena.
- **Hero Scene (personas).**
  - A persona em ação, tirada da descrição do Notion: um gesto concreto, ferramentas reais do ofício, um cenário.
  - O nome da estética aparece grande, dentro da cena.
  - O crédito "THE PERSONA" é colocado pelo build.
- **Substyle.**
  - Escolha o formato que mais combina e varie os formatos dentro da estética.
  - O nome do substyle é diegético: pintado no barco, gravado no pedestal, carimbado no tecido, escrito no tape, bordado, estampado no anel do sino…
  - Entre aspas e em maiúsculas.
- **Statement.**
  - Só o nome, em arco, com letras construídas com os materiais e objetos da estética: corda, twig, cristal, tubo de neon sem halo, carimbo de cabaça, pincelada…
  - Ornamentos e objetos da comunidade logo abaixo.
  - Nenhum outro texto.

**Códigos da comunidade:**
- Use 2 a 4 objetos, gestos ou rituais que só quem é de dentro reconhece. Exemplos: os nomes de rota escritos com giz pelos escaladores, o cofre de geocache, o pino de spike tape no palco, o nome do fabricante fundido na porta do fogão, a marca de laminação no aço.
- Tire-os de `codes.identity`, `codes.subculture` e `codes.motifs`, e de pesquisa.
- Fuja do clichê genérico.

**Texto diegético:**
- O nome vive dentro do mundo da imagem.
- Escreva o texto entre aspas duplas, EXATAMENTE como deve sair.
- Um único texto entre aspas por `body`: o nome da estética, ou o nome do substyle.

**Hierarquia:** nome da estética (grande) > arquétipo ou persona (cerca de 1/3) > N° (o menor, na borda). O build aplica isso.

**Técnica:**
- Sempre algo como "bold engraving-style line work with gouache", "bold ink with flat gouache", "screenprint in flat inks", "woodcut" etc., adaptado à estética.
- Nunca hachura fina.

**Cores:**
- Use 4 a 7 HEX da paleta por prompt, dizendo o papel de cada cor ("barn red #992A25 apron").
- Escreva nomes descritivos. Não use nomes de pessoas reais dentro do nome da cor (por exemplo: "Rothko Maroon" vira "chapel maroon #5C1F2A").

## 6. Regras de impressão (POD) — o auditor bloqueia ou avisa

- **Nada que vire retângulo na barriga.** Evite parede, painel, quadro grande, janela, céu e billboard de frente.
  - Use "only objects, no walls drawn" e silhueta irregular: bordas quebradas, rasgadas, que se dissolvem em halftone grosso.
  - Um objeto retangular pequeno dentro da cena (uma etiqueta, um livro) tudo bem.
- **Nada de glow, brilho difuso, translúcido, transparência ou névoa suave.** No DTG isso cria halo ou caixa. Luz e neon viram cor chapada e opaca, com borda nítida. Degradê é feito com halftone grosso.
- **Nada de linha fina, hairline ou hachura fina.** A linha mínima é de 12 px, ou 1 mm na impressão.
- **Fundo = cor da camiseta.** Ele aparece como espaço negativo dentro da arte, o que deixa a estampa mais leve.

## 7. Proibido

- Ícone 🃏 de arquétipo, faixas e banners vintage, "SOCIAL CLUB / EST. / MEMBERS ONLY".
- HEX impresso na arte, layout de carta/card, estilo dicionário, mockup, modelo vestindo.
- Nomes de pessoas reais, marcas, logotipos, obras famosas reproduzidas, personagens conhecidos.
  - Quando o nome do substyle contém pessoa real, adapte: "Dante's Cosmos" vira "DANTESQUE COSMOS".
- Símbolos culturais e sagrados sem respeito: descreva-os com precisão e dignidade.
- Sexualização, e qualquer pessoa que pareça menor de idade em contexto inadequado.

## 8. Checklist antes de entregar

- [ ] Arquétipo, personas e substyles batem com o Notion (o `build.py` confere).
- [ ] Cada prompt tem momento, gesto e paradoxo, e não só uma lista de objetos.
- [ ] Os códigos são de quem é da comunidade, não de turista.
- [ ] As três vertentes (hype, high-end, collector) estão distribuídas.
- [ ] Nada vira caixa, nada brilha, nenhuma linha é fina.
- [ ] `python scripts/build.py A-B` passa com 0 ERROS.

## 9. Modelo de imagem

- **Seedream (raster) na maior resolução:** para as cenas com luz e cor (Signature, Hero Scene, Still Life).
- **Recraft Vector (SVG real, gerado direto no recraft.ai):** funciona bem para Statement e Bootleg. Confira a grafia, porque o texto vira contorno.
- **Recraft V4.1 Flash:** só 1K, serve para rascunho.
