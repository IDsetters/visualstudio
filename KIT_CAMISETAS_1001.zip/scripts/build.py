#!/usr/bin/env python3
"""
build.py — monta e audita os prompts de camiseta 1001 Aesthetics (v5).

Uso:
  python scripts/build.py 26-30            # monta briefs/026.json ... briefs/030.json
  python scripts/build.py 26-30 --check    # só audita, não grava
  python scripts/build.py exemplos         # remonta os 25 exemplos (teste do kit)

Entrada:  briefs/NNN.json   (escrito pelo Claude: só a parte criativa)
Dados:    data/taxonomia_1001.json (paleta oficial, links)
          data/notion/NNN.json     (arquétipo, personas e substyles atuais, extraídos do Notion)
Saída:    saida/1001_prompts_NNN-MMM.txt  (um prompt por parágrafo, linha em branco entre eles)

Tudo o que é fixo (tela, fundo, regras de impressão, hierarquia de texto, exclusões)
vem deste script. O brief traz apenas a cena.
"""
import json, re, sys, os, glob, unicodedata

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TAX = {r['n']: r for r in json.load(open(os.path.join(ROOT, 'data', 'taxonomia_1001.json'), encoding='utf-8'))}

# ───────────── partes fixas do prompt ─────────────
def canvas(bg, width="about two-thirds of its width"):
    n, h = bg
    return (f"Print-ready t-shirt art, vertical 4500 × 5400 px, on a perfectly flat, plain {n} {h} background "
            f"with nothing else on it — no frame, no panel, no box, no sky, no gradient and no shadow behind the art — "
            f"so it removes cleanly. One free-standing image with an irregular, organic outer silhouette, centered, "
            f"filling the canvas height from near the top to near the bottom and {width}. ")

def printsafe(bg):
    n, h = bg
    return (f"Print-safe drawing: bold, confident lines, none thinner than 12 px, no hairline hatching, no tiny specks; "
            f"every edge crisp and fully opaque, with no glow, haze or soft transparent fade (any fade is built from coarse "
            f"halftone dots); the {n} ground shows through as negative space inside the art. ")

NO = ("All text spelled exactly as written; no other text anywhere. "
      "No logos, no brand names, no watermark, no signature, no mockup, no garment, no border.")

def num(n):
    return f"At the bottom edge, centered, the smallest text of all, in small spaced capitals: \"N° {n:03d} · 1001 AESTHETICS\". "

def build(A, it):
    bg = A[it.get('bg', 'L')]
    head = f"{A['name']} aesthetic — {it['fmt']}: {it['title']}. "
    p = head + canvas(bg, it.get('width', "about two-thirds of its width")) + it['body'].strip() + " "
    k = it['kind']
    if k == 'sub':
        p += num(A['n'])
    elif k == 'cast':
        p += (f"\"{A['NAME']}\" is by far the largest text. Beneath the scene, centered, like a film credit in refined spaced "
              f"capitals with letters about one third the height of the name's letters: \"{it['credit']}\". ") + num(A['n'])
    elif k == 'sig':
        p += (f"\"{A['NAME']}\" is by far the largest text. Beneath the art, centered, with breathing space, the archetype in "
              f"refined spaced capitals with letters about one third the height of the name's letters: \"{A['arch']}\". ") + num(A['n'])
    elif k == 'stmt':
        p += f"The only text in the whole design is \"{A['NAME']}\"; nothing else is written anywhere. "
    p += printsafe(bg) + NO
    return p

# ───────────── auditoria ─────────────
BANNED_BODY = [
    (r'\bglow', "efeito de brilho/glow (DTG cria halo) — descreva luz como cor chapada"),
    (r'translucent|transparen|semi-transparent|see-through', "transparência (DTG cria halo)"),
    (r'hairline|fine line|thin line|fine cross-hatching|delicate line', "linha fina (problema de impressão)"),
    (r'🃏', "ícone de arquétipo proibido"),
    (r'SOCIAL CLUB|MEMBERS ONLY|\bEST\. ', "texto de clube proibido"),
    (r'ribbon banner|scroll banner|\bbanner\b', "faixa/banner vintage proibido"),
    (r'\bwall\b(?![- ]?(?:less|s are not))', "parede pode virar retângulo — diga 'no walls drawn' ou use objeto solto"),
    (r'billboard|poster frame|framed|rectangle|square panel|box behind', "forma retangular — confirme que não vira caixa na barriga"),
]
REAL_NAMES = ['Pollock','Rothko','Malevich','Mondrian','Picasso','Braque','Magritte','Dalí','Dali','Beckett','Kafka','Camus',
              'Godot','Ogilvy','Kline','de Kooning','Lissitzky','Miró','Bouguereau','Ingres','Delacroix','Gérôme','Polykleitos',
              'Pythagoras','Euclid','Dante','Vanderbilt','Monty Python','Ionesco','Tzara','Rodchenko','Tatlin','Greenberg',
              'Nike','Apple','iPhone','Instagram','TikTok','GoPro','Arc\'teryx','Pendleton','Hudson','Kevlar','Gore-Tex',
              'Marvel','Disney','Pokémon','Hello Kitty','Chanel','Dior','Gucci','Prada','Louis Vuitton','Supreme']

def norm(s):
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode()
    return re.sub(r'[^A-Z0-9]', '', s.upper())

def load_notion(n):
    f = os.path.join(ROOT, 'data', 'notion', f'{n:03d}.json')
    return json.load(open(f, encoding='utf-8')) if os.path.exists(f) else None

def audit(A, items, prompts):
    errs, warns = [], []
    n = A['n']; T = TAX[n]
    pal = {p['hex'].upper() for p in T['palette']}
    N = load_notion(n)
    tag0 = f"#{n:03d} {A['name']}"
    # contagem de formatos
    kinds = [it['kind'] for it in items]
    nsub = kinds.count('sub')
    exp_subs = (N or {}).get('substyles') or T['substyles_tax']
    if nsub != len(exp_subs):
        errs.append(f"{tag0}: {nsub} substyles no brief, esperado {len(exp_subs)} ({'Notion' if N else 'taxonomia'})")
    if kinds.count('cast') != 3: errs.append(f"{tag0}: precisa de 3 Hero Scene (personas)")
    if kinds.count('stmt') != 1: errs.append(f"{tag0}: precisa de 1 Statement")
    if kinds.count('sig') != 1: errs.append(f"{tag0}: precisa de 1 Signature Piece")
    # arquétipo e personas do Notion
    if N:
        if N.get('archetype') and norm(N['archetype']) != norm(A['arch']):
            errs.append(f"{tag0}: arquétipo '{A['arch']}' difere do Notion '{N['archetype']}'")
        pn = [norm(p) for p in N.get('personas', [])]
        for it in items:
            if it['kind'] == 'cast':
                c = norm(re.sub(r'^THE ', '', it['credit']))
                if pn and not any(c == p or c in p or p in c for p in pn):
                    errs.append(f"{tag0}: persona '{it['credit']}' não bate com o Notion {N.get('personas')}")
        sn = [norm(s) for s in exp_subs]
        for it in items:
            if it['kind'] == 'sub':
                t = norm(it['title'])
                if not any(t == s or t in s or s in t for s in sn):
                    warns.append(f"{tag0}: substyle '{it['title']}' não encontrado na lista {exp_subs}")
    else:
        warns.append(f"{tag0}: sem data/notion/{n:03d}.json — arquétipo/personas não verificados contra o Notion")
    for it, p in zip(items, prompts):
        tag = f"{tag0} · {it['title'][:42]}"
        b = it['body']
        if len(p) > 3000: errs.append(f"{tag}: {len(p)} caracteres (máx 3000)")
        if not p.startswith(A['name']): errs.append(f"{tag}: não começa com o nome da estética")
        if '\n' in p: errs.append(f"{tag}: quebra de linha dentro do prompt")
        hx = {h.upper() for h in re.findall(r'#[0-9A-Fa-f]{6}', p)}
        if hx - pal: errs.append(f"{tag}: HEX fora da paleta {sorted(hx - pal)}")
        for rx, why in BANNED_BODY:
            m = re.search(rx, b, re.I)
            if m:
                (warns if 'wall' in rx or 'billboard' in rx else errs).append(f"{tag}: '{m.group(0)}' → {why}")
        for nm in REAL_NAMES:
            if re.search(r'\b' + re.escape(nm) + r'\b', b):
                errs.append(f"{tag}: nome real/marca '{nm}' no texto")
        k = it['kind']
        quoted = re.findall(r'"([^"]+)"', b)
        if k in ('sig', 'cast', 'stmt') and A['NAME'] not in quoted:
            errs.append(f"{tag}: o nome \"{A['NAME']}\" precisa aparecer entre aspas, dentro da cena (diegético)")
        if k == 'sub' and not quoted:
            errs.append(f"{tag}: o nome do substyle precisa aparecer entre aspas, dentro da cena")
        if k == 'stmt' and len(set(quoted)) > 1:
            errs.append(f"{tag}: statement só pode ter o nome da estética como texto")
        if k == 'sub' and len(set(quoted)) > 1:
            errs.append(f"{tag}: substyle com mais de um texto entre aspas")
        if k in ('sig', 'cast') and len(set(quoted)) > 1:
            errs.append(f"{tag}: além do nome, não coloque outros textos na cena")
        if len(b) < 420: warns.append(f"{tag}: cena curta ({len(b)} caracteres) — risco de arte pobre")
    return errs, warns

def parse_range(arg):
    if arg == 'exemplos':
        return sorted(glob.glob(os.path.join(ROOT, 'exemplos', 'briefs', '*.json'))), 'exemplos'
    a, b = (arg.split('-') + [arg])[:2]
    a, b = int(a), int(b)
    files = [os.path.join(ROOT, 'briefs', f'{i:03d}.json') for i in range(a, b + 1)]
    return files, f'{a:03d}-{b:03d}'

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    files, label = parse_range(sys.argv[1])
    check = '--check' in sys.argv
    allp, E, W, missing = [], [], [], []
    for f in files:
        if not os.path.exists(f):
            missing.append(os.path.basename(f)); continue
        A = json.load(open(f, encoding='utf-8'))
        A['L'] = tuple(A['L']); A['D'] = tuple(A['D'])
        items = A['items']
        ps = [build(A, it) for it in items]
        e, w = audit(A, items, ps)
        E += e; W += w; allp += ps
        print(f"#{A['n']:03d} {A['name']}: {len(ps)} prompts ({min(map(len, ps))}–{max(map(len, ps))} caracteres)")
    if missing: print('FALTANDO:', ', '.join(missing))
    print(f"\nTOTAL {len(allp)} prompts · ERROS {len(E)} · AVISOS {len(W)}")
    for e in E: print('  ERRO ', e)
    for w in W: print('  aviso', w)
    if E:
        print('\nCorrija os erros no brief e rode de novo. Nada foi gravado.'); sys.exit(2)
    if not check and allp:
        os.makedirs(os.path.join(ROOT, 'saida'), exist_ok=True)
        out = os.path.join(ROOT, 'saida', f'1001_prompts_{label}.txt')
        open(out, 'w', encoding='utf-8').write('\n\n'.join(allp) + '\n')
        print('\nGravado:', out)

if __name__ == '__main__':
    main()
