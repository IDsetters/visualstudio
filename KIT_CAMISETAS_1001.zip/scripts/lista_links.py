#!/usr/bin/env python3
"""lista_links.py 26 100  → imprime a lista JS [{n, link}, ...] para colar em NOTION1001.run(...)"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
a, b = int(sys.argv[1]), int(sys.argv[2])
T = json.load(open(os.path.join(ROOT, 'data', 'taxonomia_1001.json'), encoding='utf-8'))
print(json.dumps([{'n': r['n'], 'link': r['link']} for r in T if a <= r['n'] <= b]))
