// extract_notion.js — extrai das páginas do Notion (1001 Aesthetics) os dados atuais de cada estética.
// Como usar (Claude Code + Claude in Chrome, ou à mão no console do navegador):
//   1. Abra qualquer página do workspace no Chrome já logado no Notion (app.notion.com).
//   2. Cole/execute este arquivo inteiro no console da página.
//   3. Execute:  await NOTION1001.run(LISTA)  onde LISTA = [{n:26, link:"https://app.notion.com/p/..."}, ...]
//      (a lista sai de data/taxonomia_1001.json; o script scripts/lista_links.py imprime pronta)
//   4. O navegador baixa notion_026-050.json na pasta Downloads. Rode scripts/merge_notion.py.
// Não grava nada no Notion: só lê.
(() => {
  const fmt = id => id.replace(/[^0-9a-f]/gi, '').replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
  const idFromLink = l => (l.match(/[0-9a-f]{32}/i) || [''])[0];
  const V = b => b && b.value && (b.value.value || b.value);
  const T = v => v && v.properties && v.properties.title ? v.properties.title.map(x => x[0]).join('') : '';
  let SPACE = null;
  async function post(path, body) {
    const r = await fetch('/api/v3/' + path, {method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify(body)});
    return r.json();
  }
  async function getRec(table, ids) {
    const j = await post('syncRecordValuesMain', {requests: ids.map(id => ({pointer: {table, id, spaceId: SPACE}, version: -1}))});
    return j.recordMap || {};
  }
  async function loadAll(pageId) {
    let cursor = {stack: []}, chunk = 0, blocks = {};
    for (let i = 0; i < 80; i++) {
      const j = await post('loadPageChunk', {pageId, limit: 100, cursor, chunkNumber: chunk, verticalColumns: false});
      Object.assign(blocks, (j.recordMap || {}).block || {});
      if (!SPACE) { const v = V(blocks[pageId]); if (v) SPACE = v.space_id; }
      if (!j.cursor || !j.cursor.stack || !j.cursor.stack.length) break;
      cursor = j.cursor; chunk++;
    }
    for (let pass = 0; pass < 4; pass++) {
      const miss = [];
      for (const b of Object.values(blocks)) { const v = V(b); if (v && (v.type !== 'page' || v.id === pageId)) for (const c of (v.content || [])) if (!blocks[c]) miss.push(c); }
      if (!miss.length) break;
      for (let k = 0; k < miss.length; k += 100) Object.assign(blocks, (await getRec('block', miss.slice(k, k + 100))).block || {});
    }
    return blocks;
  }
  const isH = l => /header/.test(l.t);
  const EMO = /\p{Extended_Pictographic}/u;
  function cleanName(s) {
    return s.replace(/^[^A-Za-zÀ-ÿφ]+/u, '').replace(/^(Main\s+)?Archetype\s*[:—-]\s*/i, '').replace(/^The\s+/i, '')
            .split(/\s+[—–]\s+|\s*:\s+/)[0].replace(/[—–:\-\s]+$/, '').trim();
  }
  const isTitle = t => /^(?:[A-ZÀ-Ý][\w'’-]*|of|the|and|de)(?:\s+(?:[A-ZÀ-Ý][\w'’-]*|of|the|and|de)){0,6}$/.test(t.trim());
  function parsePersonaLine(x) {
    const s = x.trim();
    const marked = EMO.test(s.slice(0, 4)) || /^[^A-Za-z]/.test(s);
    if (!marked && !/^[A-Z][\w'’-]+(?:\s+(?:of|the|[A-Z][\w'’-]+)){0,4}\s*[—–:]/.test(s)) return null;
    const body = s.replace(/^[^A-Za-zÀ-ÿ]+/u, '').trim();
    if (isTitle(body)) return {name: body.replace(/^The\s+/i, ''), desc: ''};
    let m = body.match(/^(.{2,60}?)\s*[—–:]\s*(.*)$/);
    if (m && isTitle(m[1])) return {name: m[1].replace(/^The\s+/i, '').trim(), desc: m[2].slice(0, 280)};
    m = body.match(/^((?:[A-Z][\w'’-]+|of|the|and)(?:\s+(?:[A-Z][\w'’-]+|of|the|and)){0,5})\s+(.*)$/);
    if (m) return {name: m[1].replace(/\s+(of|the|and)$/, '').replace(/^The\s+/i, '').trim(), desc: m[2].slice(0, 280)};
    return null;
  }
  async function extractOne(rec) {
    const pid = fmt(idFromLink(rec.link));
    const blocks = await loadAll(pid);
    const root = V(blocks[pid]);
    if (!root) return {n: rec.n, link: rec.link, error: 'sem acesso à página'};
    const lines = [];
    const walk = id => { const v = V(blocks[id]); if (!v) return; const t = T(v); if (t && id !== pid) lines.push({t: v.type, x: t}); if (id === pid || (v.content && v.type !== 'page')) (v.content || []).forEach(walk); };
    walk(pid);
    const cm = await getRec('collection', [root.parent_id]);
    const col = V((cm.collection || {})[root.parent_id]) || {schema: {}};
    const P = {};
    for (const [k, v] of Object.entries(root.properties || {})) { const s = col.schema[k]; if (s) P[s.name] = v.map(x => x[0]).join(''); }
    const sec = (re, n) => { const i = lines.findIndex(l => isH(l) && re.test(l.x)); if (i < 0) return ''; let s = ''; for (let j = i + 1; j < lines.length && !isH(lines[j]); j++) { s += lines[j].x + ' '; if (s.length > n) break; } return s.slice(0, n).trim(); };
    // arquétipo
    const ai = lines.findIndex(l => isH(l) && /Archetype/i.test(l.x) && !/Family|Cognitive/i.test(l.x));
    const archRaw = [];
    let archetype = '';
    if (ai >= 0) {
      archRaw.push(lines[ai].x);
      for (let j = ai + 1; j < lines.length && j < ai + 8 && !isH(lines[j]); j++) archRaw.push(lines[j].x.slice(0, 300));
      const hm = lines[ai].x.match(/Archetype\s*:\s*(.+)$/i);
      if (hm) archetype = cleanName(hm[1]);
      if (!archetype) { const mm = archRaw.join('\n').match(/Main Archetype\s*:\s*([^\n]+)/i); if (mm) archetype = cleanName(mm[1]); }
      if (!archetype && archRaw[1] && archRaw[1].length < 70) archetype = cleanName(archRaw[1]);
    }
    // personas
    let pi = lines.findIndex(l => /Creative Personas/i.test(l.x));
    const persRaw = [], personas = [];
    if (pi >= 0) {
      for (let j = pi + 1; j < lines.length && persRaw.length < 16; j++) {
        if (isH(lines[j]) && !/Personas/i.test(lines[j].x)) {
          // persona como cabeçalho curto (algumas páginas)
          if (lines[j].x.length < 50 && personas.length < 3 && lines[j].t === 'header_4' && !/Beauty|Cognitive|Signature|Family|Auditory|Thinking/i.test(lines[j].x)) { persRaw.push('[H] ' + lines[j].x); personas.push({name: cleanName(lines[j].x), desc: ((lines[j + 1] || {}).x || '').slice(0, 280)}); continue; }
          break;
        }
        const x = lines[j].x; persRaw.push(x.slice(0, 300));
        const p = parsePersonaLine(x);
        if (p && !p.desc) p.desc = ((lines[j + 1] || {}).x || '').slice(0, 280);
        if (p && personas.length < 3 && !personas.some(q => q.name === p.name)) personas.push(p);
        else if (!p && x.length < 45 && personas.length < 3 && /^[A-Z]/.test(x)) personas.push({name: cleanName(x), desc: ((lines[j + 1] || {}).x || '').slice(0, 280)});
      }
    }
    // substyles (propriedade)
    const subsProp = P['Substyles'] || '';
    const substyles = [...subsProp.matchAll(/([^\[\]|·]+?)\s*\[([^\]]*)\]/g)].map(m => ({name: m[1].replace(/^[^A-Za-zÀ-ÿ0-9]+/u, '').trim(), tags: m[2].trim()})).filter(s => s.name);
    const palKey = Object.keys(P).find(k => /#[0-9A-Fa-f]{6}\s*\|\s*oklch/.test(P[k]));
    const palette = palKey ? P[palKey].split('\n').map(s => { const m = s.match(/^(.*?)\s*(#[0-9A-Fa-f]{6}).*?(?:IDcolor)?[^—]*—\s*(.*)$/); return m ? {name: m[1].trim(), hex: m[2].toUpperCase(), note: m[3].slice(0, 140)} : null; }).filter(Boolean) : [];
    return {
      n: rec.n, link: rec.link, title: P['Aesthetic Title'] || T(root), number: P['Number'] || '',
      archetype, personas, substyles, axiom: P['Card Axiom (EN)'] || '', emoji_rationale: (P['Emoji Rationale'] || '').slice(0, 300),
      locus: P['📍 Locus'] || '', voice: P['🗣 Voice Style'] || '', category: P['📁 Category:'] || '', type: P['◉ Type'] || '',
      palette,
      codes: {
        imagery: sec(/Imagery/, 600), signaling: sec(/Visual Signaling/, 400), motifs: sec(/Patterns & Motifs/, 600),
        symbols: sec(/Symbolic Language/, 600), fashion: sec(/Fashion, Styling/, 600), identity: sec(/Identity Signaling/, 700),
        subculture: sec(/^🔦 Subculture/, 500), emotional: sec(/Emotional Landscape/, 400)
      },
      archetype_raw: archRaw, personas_raw: persRaw,
      check: (archetype ? '' : 'ARQUETIPO? ') + (personas.length === 3 ? '' : `PERSONAS=${personas.length}? `) + (substyles.length ? '' : 'SUBSTYLES? ')
    };
  }
  function download(name, data) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 1)], {type: 'application/json'}));
    a.download = name; document.body.appendChild(a); a.click(); a.remove();
  }
  window.NOTION1001 = {
    extractOne,
    status: {done: 0, total: 0, errors: []},
    async run(list, chunk = 25) {
      this.status = {done: 0, total: list.length, errors: []};
      for (let i = 0; i < list.length; i += chunk) {
        const part = list.slice(i, i + chunk), out = [];
        for (const rec of part) {
          try { out.push(await extractOne(rec)); } catch (e) { out.push({n: rec.n, link: rec.link, error: String(e)}); this.status.errors.push(rec.n); }
          this.status.done++;
        }
        const a = String(part[0].n).padStart(3, '0'), b = String(part[part.length - 1].n).padStart(3, '0');
        download(`notion_${a}-${b}.json`, out);
      }
      return this.status;
    }
  };
  return 'NOTION1001 pronto';
})();
