#!/usr/bin/env python3
"""
merge_notion.py — pega os arquivos notion_NNN-MMM.json baixados pelo extract_notion.js
e grava um arquivo por estética em data/notion/NNN.json. Lista as estéticas que precisam
de conferência manual (arquétipo ou personas que o extrator não conseguiu ler com certeza).

Uso:
  python scripts/merge_notion.py "C:/Users/<você>/Downloads"      # procura notion_*.json nessa pasta
  python scripts/merge_notion.py arquivo1.json arquivo2.json
"""
import json, os, sys, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'data', 'notion')
os.makedirs(OUT, exist_ok=True)

def main():
    args = sys.argv[1:] or [os.path.expanduser('~/Downloads')]
    files = []
    for a in args:
        files += sorted(glob.glob(os.path.join(a, 'notion_*.json'))) if os.path.isdir(a) else [a]
    tax = {r['n']: r for r in json.load(open(os.path.join(ROOT, 'data', 'taxonomia_1001.json'), encoding='utf-8'))}
    ok, check, err = 0, [], []
    for f in files:
        for rec in json.load(open(f, encoding='utf-8')):
            n = rec['n']
            if rec.get('error'):
                err.append(f"#{n:03d}: {rec['error']}"); continue
            # nomes de substyles só como texto, em maiúsculas
            rec['substyles'] = [s['name'].upper() if isinstance(s, dict) else str(s).upper() for s in rec.get('substyles', [])]
            rec['personas_full'] = rec.get('personas', [])
            rec['personas'] = [p['name'] if isinstance(p, dict) else p for p in rec.get('personas', [])]
            if not rec.get('palette'):
                rec['palette'] = tax[n]['palette']
            json.dump(rec, open(os.path.join(OUT, f'{n:03d}.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            ok += 1
            if rec.get('check'):
                check.append(f"#{n:03d} {rec.get('title','')}: {rec['check']}→ conferir archetype_raw/personas_raw no JSON")
    print(f"{ok} estéticas gravadas em data/notion/")
    if check:
        print("\nPRECISAM DE CONFERÊNCIA (abra o JSON e corrija 'archetype' / 'personas' à mão, olhando os campos *_raw):")
        for c in check: print('  ', c)
    if err:
        print("\nERROS (página sem acesso ou falha de leitura):")
        for e in err: print('  ', e)

if __name__ == '__main__':
    main()
