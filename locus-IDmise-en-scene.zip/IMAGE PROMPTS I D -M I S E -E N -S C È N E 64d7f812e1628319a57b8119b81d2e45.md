# IMAGE PROMPTS  I.D.-M.I.S.E.-E.N.-S.C.È.N.E

<aside>
🎬

**Como ler este glossário.** São quatorze entradas, uma para cada Ação de Direção de I.D.-M.I.S.E.-E.N.-S.C.È.N.E.: um ideograma ancestral sustenta a identidade da ação; em seguida, aparecem seus dois polos — **↑ presença amplificada** e **↓ presença suprimida** —, cada qual acompanhado de repertório e prompt montado. DIRECTION, representada pelo ideograma 23 e pelos quatro modos TR · RV · RP · RA, nunca ocupa o lugar do sujeito: ela encerra o prompt com **uma cláusula e uma evidência visível no quadro**. A montagem obedece a cinco leis: nunca colar notação — sem setas, nomes de ideogramas ou vocabulário do sistema no prompt final, salvo a exceção licenciada em SEMIOTICS; fundir campos em frases únicas, nunca em listas de etiquetas separadas por vírgulas; emitir um único veredito por imagem; orientar a luz ao bem-estar, salvo quando a assinatura exigir sombra; e aplicar por último o filtro Vale — um padrão repetido sem sua vibração viva é areia morta. Páginas complementares: o glossário das 9 Posições [Locus → Visual Translation Glossary **9 Posições** I.D.S.E.T.T.E.R.S.](https://app.notion.com/p/Locus-Visual-Translation-Glossary-9-Posi-es-I-D-S-E-T-T-E-R-S-af107dcdad434011a32e0977d58f9dab?pvs=21) e a decodificação integral de produção em [Visual Production Codex — The 14 Direction Actions × 4 Polarities (Image Identity Master Reference)](https://app.notion.com/p/Visual-Production-Codex-The-14-Direction-Actions-4-Polarities-Image-Identity-Master-Reference-635c03b20b334a9b976d377aabe61079?pvs=21).

</aside>

# INTENTIONALITY — o Vajra

<aside>
⚡

**Essência.** INTENTIONALITY é a legibilidade de uma decisão orientada: toda força converge antes da liberação, e nada aponta para fora por acaso. Seu ideograma é o Vajra — diamante, aquilo que nada corta; raio, aquilo que corta tudo — duas coroas de pontas reunidas em uma esfera. Na imagem, o elemento se prova quando cada colocação remete a uma decisão anterior à câmera; no registro ↓, o acidente só vale quando foi claramente visto e mantido.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para INTENTIONALITY, no mesmo formato dos prompts universais do glossário 9 Posições: os colchetes recebem o vocabulário material de cada estética, enquanto a arquitetura preserva a lógica do Vajra — toda força convergida antes da liberação, nada apontando para fora por acaso.

> **↑ INTENTIONALITY — universal prompt.** A figure planted on an exact mark that reads as older than the pose — [the aesthetic's own geometric anchor: a floor seam, a grid line, a chalk mark, a module of its own architecture] — spine stacked on one plumb line, weight even on both feet, stillness held one second longer than comfortable; exactly one gesture, arrested at its most legible point, every finger individually placed, no transitional movement and no anxious self-touch anywhere in the body; the gaze locked on a decided coordinate — dead into the lens or at one fixed off-frame point — lids low, blink suppressed, the face of a verdict already delivered; hair resolved into a single decision and one precise graphic line on matte even skin, nothing tentative on the head; [the aesthetic's own signature garment] worn as a signed contract, closures fully closed, the hem weighted to fall in one decided line; one prop maximum — [the aesthetic's own instrument or emblem] — placed at a measured angle like a signature; camera tripod-locked at eye level on a 90mm at f/8, horizon perfectly level, the angle itself legible as chosen; orthogonal composition with the figure at the exact intersection of two architectural seams and the crop confident to the millimetre; hard directional light accepted and used, its shadow edge ruling the composition like a drawn line, no apologetic fill; a ground where geometry testifies to prior decision — [the aesthetic's own decided setting: gridded pavement, ruled page, drill yard, workshop bench] — and one visible proof that the decision preceded the camera: a chalk mark still on the floor, a measured interval repeated, or an accident clearly seen and deliberately kept.
> 

**Universal INTENTIONALITY ↓ negative line (always pair with the ↑ prompt):**

> No motion blur, no mid-gesture or candid energy, no tilted horizon, no handheld shake, no flyaway hair, no smudged makeup, no half-open closures, no cluttered set, no competing light sources, no apologetic fill, no prop that arrived by accident, no transitional movement, no anxious grounding gesture, no crop that hedges, no expression still deciding.
> 

**Como usar para as 19 estéticas da lista.** Troque só os colchetes pelo vocabulário material da estética — nada na arquitetura do prompt nomeia lugar, tribo ou estilo, só os mecanismos que a página define como INTENTIONALITY (a marca anterior à pose, o gesto único detido, a luz dura aceita, a prova da decisão em quadro). Exemplos: para **Graphic**, âncora geométrica = a grade de doze colunas, emblema = a única régua vermelha; para **Military**, o pátio de formatura e a patente costurada na manga; para **Utilitarian**, a bancada de trabalho e a ferramenta sem um único elemento decorativo; para **CONCRETE ART**, o plano geométrico tratado como fato concreto, não como referência; para **Social Realism / Progressive / Radical**, o cartaz ou mural com a posição política legível como evidência física; para **Conscious Curation Mastery**, a prateleira com o vazio deixado pela última remoção como prova. Para **Indie**, inverta para o registro ↓ — o demo de quatro pistas, o acidente mantido de propósito.

## Fundamentos do elemento

### Identidade e lei da decisão anterior

**Identity.** Legibility of oriented decision. Its ideogram is the Tibetan diamond-thunderbolt, two incompatible things at once — diamond, what nothing cuts; thunderbolt, what cuts everything: two crowns of prongs converging on one sphere, all force gathered before release, nothing pointing outward by accident. The decided intention is both at once, uncuttable before consequence and cutting in release. In an image this element is proven when every placement reads as a decision, or when the accident is visibly kept.

**The mark precedes the model.** The frame's deepest proof is temporal: the geometry must read as if it existed before the body arrived — a floor seam the heel finds, a chalk line still visible, a chair already at its measured angle. When the placement reads as chosen *for* the picture, this instrument has failed; when it reads as the picture merely documenting a prior decision, it has landed. Perceived effect: gravity — the figure reads as inevitable.

**The kept accident is a decision.** The suppressed register is not sloppiness. An accident enters the frame only when it is visibly *seen and kept* — the wrong crop preserved, the flash bounce left uncorrected on purpose. The difference is legible: sloppiness hides at the edges; the kept accident sits exactly where the author's eye obviously passed. One kept accident maximum per frame — two reads as negligence.

## Corpo — postura, gesto e olhar

**Model posture & structure.** Full vertical stack — head, sternum, pelvis, heels on one plumb line; weight even on both feet; stillness held one second longer than comfortable; the body planted on an exact mark as if the mark existed first. In the caught register: weight mid-transfer, torso twisted toward something off-frame, one shoulder out of the jacket — the body between decisions, kept honest.

**Gesture.** One gesture only, arrested at its most legible point — a hand flat on a table, a hem held in one decided line, every finger individually placed. No transitional movement, no self-touch, no anxious grounding (no collar-fix, no hair-tuck). The suppressed register inverts the law: the gesture nobody finished — mid-laugh, a strap being adjusted, an assistant's hand entering frame left.

**The look — how the eyes behave.** Eyes locked on a decided point — dead into the lens or at a fixed off-frame coordinate; lids low and steady, blink suppressed; the mouth closed and level. The face of someone who finished deciding before the shutter. Banned: the darting check, the expression still weighing options, the smile assembled after the eyes.

## Regras de imagem — do figurino à prova de decisão

**Look & styling continuity.** Sharp tailoring or a weighted hem that falls in one decided line; closures fully closed; the garment worn as a signed contract, not an outfit being tried on. One graphic decision maximum in the accessory plan, placed like a signature. In the caught register: coat half on, one shoe held, a pin between the teeth — dress caught mid-sentence and kept.

**Camera.** 85–105mm portrait lens, tripod-locked, perfectly level horizon; eye level or two degrees below; f/8 so the whole decision stays sharp; frontal or exact three-quarter — the angle itself legible as chosen. The caught register flips every setting: 35mm handheld, slight tilt, f/2.8 with the focus landing a little wrong and kept.

**Composition.** The figure at the exact intersection of two architectural seams; orthogonal alignments throughout; props at measured angles — a chair at precisely forty-five degrees; symmetry used as proof of will; the crop confident to the millimetre. Nothing enters the frame that was not chosen, and the frame shows it.

**Lighting.** Hard directional light accepted and used — noon sun or one focused source; the shadow edge treated as a drawn line the composition obeys; no apologetic fill; every shadow lands where it was told to. Suppressed: uneven flash bounce, mixed temperatures nobody corrected, left in.

**Beauty detail.** Hair resolved into a single decision — a sealed centre part, a lacquered sweep, or one architectural knot with zero flyaways; makeup built on one precise graphic line (a drawn liner edge, a sharply mapped brow) on matte, even skin; nails short, one opaque colour. Nothing tentative anywhere on the head. Caught register: one eye lined and one bare, hair mid-fix, a lipstick print on a coffee cup in frame.

**Cenography.** Marble floor seams, gridded pavement, drawn chalk marks still visible — a set where geometry testifies to prior decision; one prop maximum, placed like a signature. Suppressed: backstage truth — garment rail, gaffer tape, an open makeup kit, the room mid-use.

**Colour.** One palette decided once and held: a restricted field with a single accent that reads as underlined rather than decorative. No drifting temperature across the frame — a colour that wanders is a decision that wasn't made. The kept-accident register admits one colour clash, visibly noticed and retained.

**Decision proof.** Wherever the composition allows it, plant one device proving the decision preceded the camera: the chalk mark still on the floor, the measured interval repeated across three props, the folding chair at exactly forty-five degrees — or, in the caught register, the wrong crop kept with such confidence that the keeping itself reads as authorship. A frame that cannot show *when* it was decided has only asserted decision, which is this instrument's most legible failure.

**Practitioner lines (from the codices).** Irving Penn — the large-format ground glass disciplining the composition before the shutter, the frame decided before the model enters. Hiro — every millimetre of specular highlight planned before the first exposure and corrected between frames. For the caught register: Frank Horvat — candid 35mm documentary framing, real passersby admitted to the frame; Michel Comte — a fast, almost careless-looking exchange, the frame kept being the one where the mask slipped; Clara Balzary — the editorial built entirely from glimpses between takes.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Everything staged and legible as staged: the figure at an exact geometric intersection, hem weighted to fall in one decided line, props at measured angles, hard light accepted and used, no chance left in frame.

> **↑ Prompt.** A figure positioned at the exact intersection of two marble floor seams, hem weighted to fall in one decided line, every finger placed, a folding chair angled precisely forty-five degrees to the wall, hard noon light accepted and used, the whole frame reading as a sequence of decisions with nothing left to chance.
> 

> **↑ Negative line.** No motion blur, no mid-gesture, no candid energy, no tilted horizon, no handheld shake, no flyaway hair, no smudged makeup, no cluttered set, no competing light sources, no apologetic fill light.
> 

**↓ Suppressed — repertory.** The caught moment: mid-gesture, half-dressed, an assistant's hand in frame, uneven flash bounce, a crop slightly wrong and kept.

> **↓ Prompt.** Caught between poses, the model mid-laugh adjusting a strap, coat half on, an assistant's hand entering frame left, flash bounce uneven across the wall, the crop slightly wrong and kept, the image alive precisely because nobody arranged it.
> 

> **↓ Negative line.** No symmetry, no locked tripod stillness, no lacquered hair, no posed hands, no architectural set, no single controlled light source, no verdict expression.
> 

## Estéticas relacionadas a INTENTIONALITY (A–Z)

As 19 estéticas classificadas sob INTENTIONALITY, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **CONCRETE ART**

**№ 171 / 1001** — *Form as Concrete Fact, Not Reference*

**Nível:** 🟤 Tertiary

**Eixo:** INTENTIONALITY ↑ → SEMIOTICS ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** geometria neoplástica, método construtivista e teoria matemática do design convergem. Sem a matemática, a forma perde sua prova; sem a linhagem geométrica, o plano perde o vocabulário. É fusão de linhagens distintas, não revisão de um único pai.

**Atmosfera e mood**

**Forma como fato concreto, não referência** — (1001 Aesthetics, interpretação)

Arte concreta: geometria pura sem representação — planos, ritmos matemáticos e cor exata (Max Bill, Waldemar Cordeiro).

**Paleta de cores** primárias exatas, branco, preto

**Melhores usos:** design, arte, padronagem

**MidJourney:** `[tema], concrete art, pure geometric abstraction, Max Bill style --v 6`

**Prompt universal (Seedream):** `Ultra-crisp composition at 8k, concrete art of pure non-representational geometry, mathematically rhythmic planes in exact primary colors on white, form as fact not reference, Brazilian concretism precision of Waldemar Cordeiro and Geraldo de Barros, flat immaculate surfaces with razor edges, museum-print quality`

### **Conscious Curation Mastery**

**№ 172 / 1001** — *Removal, Not Addition*

**Nível:** ⚫ Quaternary

**Eixo:** INTENTIONALITY ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** redução minimalista, método curatorial e práticas contemporâneas de desapego convergem várias gerações depois. Cada linhagem permanece rastreável, mas nenhuma transforma sozinha a remoção em disciplina.

**Atmosfera e mood**

**Remoção, não adição** — (1001 Aesthetics, interpretação)

Curadoria consciente: poucos objetos escolhidos com rigor, espaço negativo como afirmação, cada item justificado.

**Paleta de cores** neutros quentes, um acento único

**Melhores usos:** interiores, branding, editorial

**MidJourney:** `[tema], consciously curated minimal interior, negative space --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a consciously curated interior, very few rigorously chosen objects breathing in generous negative space, warm neutrals with one single sculptural accent, soft directional daylight grazing plaster walls, mastery through removal not addition, Axel Vervoordt restraint, serene gallery-grade clarity, 8k`

### **Environmental Activism**

**№ 293 / 1001** — *Leaf Stuck in the Wet Paint*

**Nível:** 🟤 Tertiary

**Eixo:** INTENTIONALITY ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a decisão ecológica deixa de ser tema ilustrado e passa a organizar materiais, gesto e consequência; a folha presa na tinta funciona como prova física da posição assumida.

**Atmosfera e mood**

**A folha grudada na tinta fresca** — (1001 Aesthetics, interpretação)

Ativismo ambiental: cartaz pintado à mão, verde de urgência, natureza e protesto na mesma imagem.

**Paleta de cores** verde vivo, terra, tinta de protesto

**Melhores usos:** campanhas, editorial, social

**MidJourney:** `[tema], environmental activism poster, hand-painted protest art, a real leaf stuck in wet paint --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Tri-X film with 24mm lens, an environmental activism image, hand-painted protest banner with a real leaf stuck in the wet paint, urgent green and earth tones in overcast daylight, weathered hands gripping the pole, Dorothea Lange documentary honesty, nature and protest in one frame, 8k`

### **Existentialism**

**№ 310 / 1001** — *Bare Stage and the Manuscript*

**Nível:** 🔴 Primary

**Eixo:** INTENTIONALITY ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota:** a decisão individual é afirmada sem garantia de permanência. O palco nu e o manuscrito sustentam uma gramática de escolha presente que rompe com qualquer promessa herdada de monumento ou duração.

**Atmosfera e mood**

**O palco nu e o manuscrito** — (1001 Aesthetics, interpretação)

Existencialista: café parisiense em preto e fumaça, figura solitária diante da página, liberdade como peso.

**Paleta de cores** preto, cinza de fumaça, luz de abajur fria

**Melhores usos:** editorial, retratos, narrativa

**MidJourney:** `[tema], existentialist mood, bare stage, lone figure with manuscript, Parisian café smoke --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Tri-X with 50mm lens, an existentialist scene, bare stage and a manuscript under cold lamp light, lone figure in smoke-grey Parisian café mood, cigarette smoke curling through the beam, black and grey, freedom carried as weight, heavy film grain, nouvelle vague still`

### **Graphic**

**№ 398 / 1001** — *Twelve-Column Grid and Its Single Red Rule*

**Nível:** 🔴 Primary

**Eixo:** INTENTIONALITY ↑ → DENSITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota:** a grade e a única regra vermelha tornam visível uma decisão anterior à forma; tudo o que não serve ao sistema é excluído, e a baixa densidade confirma o corte.

**Atmosfera e mood**

**A grade de doze colunas e sua única linha vermelha** — (1001 Aesthetics; código: Lummi, match aproximado)

Gráfico: layout suíço e tipografia disciplinada, grid visível na precisão, um só acento de cor como argumento.

**Paleta de cores** preto e branco de grid, vermelho único de destaque

**Melhores usos:** design gráfico, editorial, pôsteres

**MidJourney:** `--sref 1239879655 --sw 1000` (Graphic Dreamscape — match aproximado)

**Prompt universal (Seedream):** `Ultra-crisp graphic composition, a Swiss design layout, twelve-column grid with disciplined typography and one single red rule, black and white precision in the school of Josef Müller-Brockmann, the grid visible in every alignment, 8k`

### **Health Goth**

**№ 423 / 1001** — *280 GSM Compression Knit Under Fluorescent Light*

**Nível:** 🟤 Tertiary

**Eixo:** INTENTIONALITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** vestuário técnico, disciplina atlética e código gótico são rearticulados numa matéria deliberadamente especificada; peso, compressão e fluorescência funcionam como evidência da decisão.

**Atmosfera e mood**

**Malha de compressão 280 GSM sob luz fluorescente** — (1001 Aesthetics, interpretação)

Health goth: academia monocromática e técnica, preto esportivo total, o corpo otimizado com estética sombria.

**Paleta de cores** preto técnico, branco clínico, cinza de máquina

**Melhores usos:** fitness, moda esportiva, editorial

**MidJourney:** `[tema], health goth aesthetic, black compression knit under fluorescent gym light, monochrome technical sportswear --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 35mm lens, a health goth image, 280 GSM black compression knit under clinical fluorescent light, monochrome gym machinery, the optimized body dressed in darkness, 8k`

### **Indie**

**№ 465 / 1001** — *Four-Track Demo Refuses the Major Label*

**Nível:** 🟤 Tertiary

**Eixo:** INTENTIONALITY ↑ → EDITING ↓

**Polaridade:** XX — continuidade por transmissão

**Nota:** a recusa do acabamento corporativo é transmitida como escolha autoral: o acidente mantido, o ruído e a gravação de quatro pistas não são falta de decisão, mas a decisão de não corrigir.

**Atmosfera e mood**

**A demo de quatro canais recusa a gravadora major** — (1001 Aesthetics, interpretação)

Indie: DIY e imperfeição querida, fotografia de filme e show de porão, o pequeno como escolha estética.

**Paleta de cores** filme desbotado, mostarda e vinho, luz de porão

**Melhores usos:** música, editorial, branding autêntico

**MidJourney:** `[tema], indie aesthetic, four-track demo basement show, faded film photography, DIY charm --v 6`

**Prompt universal (Seedream):** `Shot on Pentax K1000 with 50mm lens on expired film, an indie image, a four-track demo refusing the major label, basement show on faded film stock, mustard and wine tones, the small as aesthetic choice, 8k`

### **Kindnesscore**

**№ 502 / 1001** — *Mutual Aid as Soft Dress Code*

**Nível:** ⚫ Quaternary

**Eixo:** INTENTIONALITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** códigos de cuidado e ajuda mútua são reinstrumentados como linguagem visual suave; a intenção ética permanece legível e continua vibrando depois da primeira leitura.

**Atmosfera e mood**

**Ajuda mútua como dress code suave** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Kindnesscore: gentileza como prática estética, tricôs pastéis, pão compartilhado e jardim comunitário.

**Paleta de cores** pastéis suaves, creme, verde de horta

**Melhores usos:** conteúdo comunitário, branding acolhedor, ilustração

**MidJourney:** `[tema], kindnesscore aesthetic, mutual aid, soft pastel knits, community garden warmth --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 160 with 35mm lens, a kindnesscore image, neighbors passing warm bread over a shared fence, soft pastel knits and community garden light, mutual aid worn as a soft dress code, gentleness as practice, 8k`

### **Military**

**№ 573 / 1001** — *Rank Sewn Into Every Seam*

**Nível:** 🔴 Primary

**Eixo:** INTENTIONALITY ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por transmissão

**Nota:** hierarquia, função e disciplina são transmitidas intactas por corte, insígnia e posição. A expressão individual é rebaixada para que a decisão institucional permaneça soberana.

**Atmosfera e mood**

**Patente costurada em cada costura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Militar: ordem tornada vestuário, oliva e caqui sob disciplina de vinco.

**Paleta de cores** verde-oliva, caqui, latão de insígnia

**Melhores usos:** moda utilitária, editorial, retrato

**MidJourney:** `[tema], military aesthetic, olive drab and khaki pressed to regulation, brass insignia, rank in every seam --v 6`

**Prompt universal (Seedream):** `Shot on Leica M10 Monochrom with 50mm lens, a military image, olive drab and khaki pressed to razor regulation under hard side light, brass insignia and boot polish answering inspection, creases running as true as drawn lines, Don McCullin gravity held in a quiet frame, discipline and rank sewn into every seam, 8k`

### **Neo-Luddism**

**№ 609 / 1001** — *Offline Switch as Design Position*

**Nível:** 🟣 Secondary

**Eixo:** INTENTIONALITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a crítica luddista à tecnologia é revisada como código contemporâneo de recusa; o interruptor offline deixa de ser mera função e passa a declarar uma posição.

**Atmosfera e mood**

**O botão offline como posição de design** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neoludismo: smartphone na gaveta, máquina de escrever e mapa de papel escolhidos de propósito.

**Paleta de cores** papel, madeira, cinza analógico

**Melhores usos:** editorial, lifestyle, conceito

**MidJourney:** `[tema], neo-luddism aesthetic, smartphone in a drawer, typewriter and paper maps by choice --v 6`

**Prompt universal (Seedream):** `Shot on Ilford HP5 with 50mm lens, a neo-luddite still life, smartphone face-down in a closing drawer beside a working typewriter and unfolded paper map, honest analog grain and window light, the offline switch chosen as a design position, quiet defiance, 8k scan`

### **New Sincerity**

**№ 623 / 1001** — *Irony Runs Out of Oxygen*

**Nível:** 🟤 Tertiary

**Eixo:** INTENTIONALITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** códigos pós-irônicos, confissão direta e recusa do distanciamento são recombinados numa gramática em que a sinceridade precisa aparecer como decisão consciente, não como ingenuidade.

**Atmosfera e mood**

**Dizer o que se sente sem aspas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nova sinceridade: cartaz feito à mão, abraço sem ironia, o afeto declarado depois do cinismo.

**Paleta de cores** dourado de fim de tarde, mostarda, vermelho de feltro

**Melhores usos:** lifestyle, campanhas, editorial afetivo

**MidJourney:** `[tema], new sincerity aesthetic, handmade banner unironic warmth, feeling said without quotes --v 6`

**Prompt universal (Seedream):** `Shot on Fuji Superia 400 with 35mm lens, a new sincerity scene, a handmade felt banner reading its feeling without quotation marks, golden late-afternoon warmth on mustard and red, earnest faces after the age of irony, tender honest film color, 8k`

### **Noucentisme**

**№ 634 / 1001** — *Catalonia Measures Itself Against the Mediterranean*

**Nível:** 🟣 Secondary

**Eixo:** INTENTIONALITY ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** medida mediterrânea, ordem cívica e disciplina clássica são assumidas como decisão fundadora; a coerência do conjunto prova que a orientação precede cada forma.

**Atmosfera e mood**

**Classicismo mediterrâneo em medida catalã** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Noucentisme: ordem serena depois do modernisme, arcadas caiadas, ciprestes e civilidade ensolarada.

**Paleta de cores** cal branca, terracota, azul mediterrâneo

**Melhores usos:** arquitetura, editorial, cultura

**MidJourney:** `[tema], noucentisme aesthetic, Catalan Mediterranean classicism, whitewashed arcades cypress order --v 6`

**Prompt universal (Seedream):** `Shot on Bronica SQ-A with 80mm lens, a noucentista courtyard, whitewashed arcades and cypress rows in serene Catalan measure, terracotta and Mediterranean blue after the fever of modernisme, sunlit civility and classical calm, 8k`

### **Progressive**

**№ 724 / 1001** — *Design Takes a Political Position*

**Nível:** 🔴 Primary

**Eixo:** INTENTIONALITY ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a consciência social de Morris, a provocação situacionista e o mandato ecológico de Papanek são recombinados numa gramática em que fazer já é reivindicar; nenhuma fonte isolada contém essa fusão.

**Atmosfera e mood**

**O design tomando posição política** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Progressista: setas para frente, tipografia de campanha e cores primárias marchando juntas.

**Paleta de cores** vermelho de causa, azul de fé cívica, branco de cartaz

**Melhores usos:** campanhas, editorial, design

**MidJourney:** `[tema], progressive aesthetic, bold forward arrows campaign typography, design taking a position --v 6`

**Prompt universal (Seedream):** `Bold graphic poster design, a progressive composition of forward-marching arrows and confident campaign typography, cause red and civic blue on poster white, design openly taking a political position instead of decorating one, flat print-perfect edges, 8k`

### **Radical**

**№ 739 / 1001** — *Art Moves From Studio to Struggle*

**Nível:** 🔴 Primary

**Eixo:** INTENTIONALITY ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** parte de uma premissa sem gramática-mãe: produção estética é ação revolucionária. A formulação rompe a separação burguesa entre arte e política, tornando a consequência pública parte da própria forma.

**Atmosfera e mood**

**Do ateliê para a barricada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Radical: serigrafia de maio de 1968, punho e slogan em uma cor só — a urgência impressa às pressas.

**Paleta de cores** vermelho único, preto de traço, papel barato

**Melhores usos:** editorial, histórico, design

**MidJourney:** `[tema], radical 1968 aesthetic, one-color silkscreen fist and slogan, printed in a hurry --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a 1968 Atelier Populaire silkscreen poster, a raised fist and hurried slogan in one urgent red on cheap paper, rough registration and ink bleed from the occupied print shop, art moved from studio to barricade overnight, raw graphic urgency, 8k`

### **Second Wave Feminism**

**№ 793 / 1001** — *Personal Life Declared Political Ground*

**Nível:** 🟣 Secondary

**Eixo:** INTENTIONALITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** faixa violeta e cartaz manuscrito da cultura sufragista são reinstrumentados para o corpo e a vida doméstica. Uma linhagem de direitos é redirecionada a um território que a primeira onda não havia ocupado.

**Atmosfera e mood**

**O pessoal declarado terreno político** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Segunda onda: marchas de 1970, cartazes à mão e cozinhas transformadas em assembleia — a vida privada levada à praça.

**Paleta de cores** preto e branco de jornal, roxo de movimento, cartolina

**Melhores usos:** histórico, documental, editorial

**MidJourney:** `[tema], second wave feminism 1970 aesthetic, hand-lettered march placards, the personal declared political --v 6`

**Prompt universal (Seedream):** `Shot on Nikkormat FTn with Ilford FP4, a 1970 women's march, hand-lettered placards raised over linked arms on a city avenue, newspaper black-and-white with the grain of history being made, private life carried into the public square and declared political ground, documentary conviction, 8k scan`

### **Social Realism**

**№ 821 / 1001** — *Art for the People*

**Nível:** 🟣 Secondary

**Eixo:** INTENTIONALITY ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por revisão

**Nota:** o Realismo europeu do século XIX fornece o pai único, revisado por uma exigência transformadora: a imagem deve servir à luta de classes. O retrato cotidiano torna-se composição construída de trás para frente a partir da mensagem coletiva.

**Atmosfera e mood**

**A arte feita para o povo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Realismo social: murais de operários em escala heroica, mãos calejadas e a dignidade do trabalho pintada em parede pública.

**Paleta de cores** ocre de mural, vermelho de bandeira, azul de macacão

**Melhores usos:** histórico, arte, editorial

**MidJourney:** `[tema], social realism aesthetic, heroic-scale worker mural calloused hands, art for the people --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of a social realist mural, workers at heroic scale with calloused hands turning wheels of industry in the Diego Rivera and WPA manner, mural ochre and flag red over overall blue, the dignity of labor painted on a public wall for everyone, 8k documentation`

### **Space Age**

**№ 836 / 1001** — *Atomic Dreams Launch Retro-Future*

**Nível:** 🟤 Tertiary

**Eixo:** INTENTIONALITY ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** curva aerodinâmica do Streamline Moderne, funcionalismo moderno e imaginação espacial pulp são soldados numa forma que nenhum ancestral produziria sozinho; a luz torna o futuro decidido visível.

**Atmosfera e mood**

**Sonhos atômicos lançando o retrofuturo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Era espacial: interiores de cápsula em plástico moldado, luminárias Sputnik e o design doméstico de 1968 pronto para órbita.

**Paleta de cores** branco de cápsula, laranja de 1968, cromo de satélite

**Melhores usos:** design, interiores, editorial

**MidJourney:** `[tema], space age aesthetic, molded plastic capsule interior sputnik lamps 1968, atomic dreams in orbit --v 6`

**Prompt universal (Seedream):** `Ultra-clean photograph of a Space Age interior, a 1968 living pod of white molded plastic with a sunken conversation pit and a chrome Sputnik lamp, capsule white sparked by atomic orange upholstery, domestic design ready for orbit in the Colombo and Panton spirit, glossy period perfection, 8k`

### **Subversive Fashion**

**№ 860 / 1001** — *Clothing Cut to Question the Rules*

**Nível:** 🟣 Secondary

**Eixo:** INTENTIONALITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a tradição de recusa da antimoda, do dandismo ao détournement situacionista, é reinstrumentada diretamente no corpo; a costura rasgada ocupa o lugar do manifesto sem introduzir uma segunda linhagem estrutural.

**Atmosfera e mood**

**A roupa cortada para questionar as regras** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Moda subversiva: costuras expostas, proporções erradas de propósito e o desfile como argumento — Margiela e Westwood como gramática.

**Paleta de cores** cru de entretela, preto desconstruído, vermelho de protesto

**Melhores usos:** moda, editorial, conceito

**MidJourney:** `[tema], subversive fashion aesthetic, exposed seams deliberately wrong proportions, clothing cut to question the rules --v 6`

**Prompt universal (Seedream):** `Ultra-sharp runway photograph, subversive fashion mid-stride, a deconstructed garment with exposed interfacing and deliberately wrong proportions in the Margiela and Westwood grammar, raw canvas and unraveling black slashed with protest red, clothing built as an argument against its own rules, 8k`

### **Utilitarian**

**№ 934 / 1001** — *Function Leaves the Decoration Unemployed*

**Nível:** 🔴 Primary

**Eixo:** INTENTIONALITY ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** a função como origem da forma sobrevive à remoção de qualquer dialeto — Arts and Crafts, Bauhaus ou Modernismo Escandinavo — e gera esses dialetos em vez de descender deles. É um nó fundador, não uma reinterpretação.

**Atmosfera e mood**

**A função deixando a decoração desempregada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Utilitário: a ferramenta pendurada no seu contorno pintado, a bancada sem um objeto supérfluo e a beleza que sobra quando só o necessário fica.

**Paleta de cores** cinza de ferramenta, verde de bancada industrial, madeira de cabo

**Melhores usos:** design, produto, interiores

**MidJourney:** `[tema], utilitarian aesthetic, tools hung on painted outlines nothing superfluous, function leaves decoration unemployed --v 6`

**Prompt universal (Seedream):** `Shot on Toyo 4x5 with 210mm lens, a utilitarian workshop wall, every tool hung precisely inside its painted outline above a workbench holding nothing superfluous, tool gray and industrial green with worn wooden handles, the beauty that remains when only the necessary stays, exacting functional order, 8k`

## Leitura do padrão — o que as 19 estéticas confirmam

A lista inteira confirma um sistema visual comum: **toda estética de INTENTIONALITY é organizada por uma decisão anterior à forma, e a forma existe para provar que essa decisão aconteceu.**

### Um instrumento quase totalmente unidirecional

As 19 entradas são INTENTIONALITY ↑. O registro ↓ — o acidente visto e mantido — aparece no corpus apenas como eixo secundário de outras ações. A não decisão não sustenta uma identidade sozinha; ela apenas modula outra força.

### Quatro famílias recorrentes

1. **Decisão política declarada:** Progressive, Radical, Environmental Activism, Social Realism, Second Wave Feminism, Subversive Fashion e Neo-Luddism. A decisão converte-se em efeito ou código.
2. **Função como origem da forma:** Utilitarian, Graphic, CONCRETE ART e Military. Decidir é cortar; nenhum elemento permanece sem justificativa anterior.
3. **Curadoria e recusa:** Conscious Curation Mastery, Indie, New Sincerity e Neo-Luddism. A decisão é não fazer, e a recusa precisa permanecer visível para contar.
4. **Projeção decidida:** Space Age, Health Goth, Kindnesscore, Existentialism e Noucentisme. A intenção é aplicada a um futuro, uma ética ou uma ordem coletiva.

### O teste operacional

INTENTIONALITY não significa apenas “design com propósito”. A pergunta é mais rigorosa: **cada colocação no quadro remete a uma decisão anterior à câmera?** Se a decisão for removida e a estética desaparecer, o Vajra está operando. Se restar apenas matéria bem arranjada, a intenção foi afirmada, mas não provada.

# DENSITY — o Omphalos

<aside>
🜃

**Essência.** DENSITY mede a concentração de relações visuais, materiais e referenciais: quanto mundo cabe no quadro sem transbordar. Seu ideograma é o Omphalos — a pedra-umbigo de Delfos, ponto onde o mundo inteiro se comprime. No registro ↑, a abundância permanece legível porque uma âncora imóvel governa o conjunto; no registro ↓, a rarefação é deliberada e uma única presença sustenta o espaço.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para DENSITY, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem o inventário material da estética, enquanto a arquitetura preserva a lógica do Omphalos — o mundo inteiro comprimido num só lugar, sem transbordar, mantido em ordem por uma única âncora imóvel.

> **↑ DENSITY — universal prompt.** A packed frame governed by one still anchor — a figure seated or standing as a slow dark column at the centre of visual abundance, shoulders dropped, the body deliberately slower than everything around it, immobility the loudest element in a loud room; hands compressed close to the torso and layered with material evidence, holding folds of [the aesthetic's own layered materials] at once, fingers resting on [the aesthetic's own stacked inventory: bolts, books, frames, tins, instruments]; a steady unhurried gaze straight through the visual noise, the one point of stillness the eye returns to, contained knowledge around the mouth, nothing startled; layered accumulated beauty held in strict order — [the aesthetic's own adornment logic] stacked so it reads as archive rather than clutter, a deep-toned lip or kohl-weighted eyes giving the face its own dark anchor, skin with dimensional lived texture; pattern on pattern disciplined by one dark column — [the aesthetic's own anchoring garment: a long coat, a black robe, one unbroken dark plane] — with visible weight in the cloth; photographed static at chest height on a 50mm at f/11 so information stays legible at every distance, the frame wide enough to admit the abundance and tight enough to keep the figure sovereign; texture at every depth of field, [the aesthetic's own shelving world] rising out of focus behind, every object obeying one logic of accumulation with no empty stretch anywhere; an even generous key with enough fill that no information dies in shadow and a half-step warmer pool on the figure so the anchor reads brighter than the world; the whole image built so the eye circles the inventory and lands, involuntarily, back on the still centre.
> 

**Universal DENSITY ↓ negative line (always pair with the ↑ prompt):**

> No empty minimal backgrounds, no negative space doing the work, no shallow depth of field washing out the inventory, no chaos without a governing anchor, no frantic gesture, no startled expression, no information dying in shadow, no clutter that obeys no logic, no figure moving faster than the room, no single-tone sparse field.
> 

**Como usar para as 30 estéticas da lista.** Troque os colchetes pelo inventário próprio da estética: para **Maximalism / Opulence / Embellished / DECOPLEX**, o cômodo que recusa um objeto final, disciplinado pela coluna escura; para **Victorian / Gilded Age**, a sala coalhada de evidência — molduras, veludo, porcelana — com o império como lógica de acúmulo; para **Persian / Moorish / Indian**, geometria, caligrafia e têxtil em camadas: a densidade como arquivo de civilização; para **Petitecore / Tinycore / MicroPrecision / Flemish Primitive**, inverta a escala sem inverter a lei — o mundo inteiro comprimido em miniatura, macro na lente, informação em toda profundidade (o espelho convexo de Arnolfini é o Omphalos literal); para **Visual Pollution / Overstimulation / Overloaded**, mantenha a abundância e remova deliberadamente a âncora — DENSITY ↑ com EDITING ↓, a saturação sem curadoria como o próprio argumento; para **Slowcore**, use o registro ↓ integral — o campo esparso, a respiração como matéria.

## Fundamentos do elemento

### Identidade e lei da âncora

**Identity.** Concentration of visual, material, and referential relations. Its ideogram is the navel-stone of Delphi, where two eagles released from opposite ends of the world met: the whole world compressed into one place without overflowing. In an image this element is proven by information at every depth of field, or by a frame emptied to one gesture.

**The anchor law.** Abundance is admissible only under government: one still, dark vertical — a figure, a column, a coat — that outranks everything surrounding it. Remove the anchor and density collapses into noise; that collapse, deliberately staged, is the saturation register (DENSITY ↑ with EDITING ↓), and it must read as a decision about the world, never as a failure of the set.

**Compression without overflow.** The Omphalos measures information per depth, not clutter per surface. A dense frame earns its density by staying legible at every distance — deep focus, ordered layers, an accumulation with a logic. The failure states are two: emptiness pretending to be restraint, and clutter pretending to be wealth.

**The eye's return.** The composition's test is circulatory: the eye tours the inventory and lands back on the still centre without being told. If the gaze exits the frame or settles on a shelf, the anchor was too weak — brighten its pool a half-step or darken its column; never thin the inventory first.

## Corpo — postura, gesto e olhar

**Model posture & structure.** A still, grounded column at the centre of visual abundance — seated or standing with slow, low-slung weight, shoulders dropped, the body deliberately slower than everything around it. Immobility as the loudest element in a loud room. Suppressed register: one quiet vertical in a vast plane, arms at rest, stillness without rigidity.

**Gesture.** Hands layered with material evidence — holding folds of three fabrics at once, fingers resting on stacked books or bolts; gestures compressed and close to the torso, never flung outward. Suppressed: a single minimal gesture — one hand lifted a few centimetres, or none at all.

**The look — how the eyes behave.** A steady, unhurried gaze straight through the visual noise — the one point of stillness the eye returns to; contained knowledge, faint gravity around the mouth, nothing startled. Suppressed: a soft level gaze into middle distance, a face emptied of urgency — presence without pressure.

## Regras de imagem — do styling à prova de compressão

**Look & styling continuity.** Brocade over printed silk over knitted mesh — pattern on pattern disciplined by one dark column (a long coat, a black robe) that anchors the entire stack; visible weight in the cloth; jewelry stacked so it reads as archive rather than clutter. Suppressed: one linen shift, one tone, no layering, no accessory.

**Camera.** 50mm at f/11 — deep focus so information stays legible at every distance; camera static at chest height; the frame wide enough to admit the abundance, tight enough to keep the figure sovereign. Suppressed: 90mm at f/5.6 on tripod, generous headroom, a perfectly quiet horizon.

**Composition.** Texture at every depth of field, shelves and objects rising out of focus behind, all of it orbiting the single dark vertical of the figure; density with hierarchy, never spill. Suppressed: vast negative space doing the work, the figure placed by one clean proportional decision, nothing else admitted.

**Lighting.** A generous even key with enough fill that no information dies in shadow — the packed frame must stay readable — and a slightly warmer pool on the figure so the anchor reads a half-step brighter than the world. Suppressed: one shaft of window light, soft edges, air visible in the emptiness.

**Beauty detail.** Layered, accumulated beauty held in strict order — braids threaded with cord or metal, stacked earrings and rings reading as archive; deep-toned lip or kohl-weighted eyes giving the face its own dark anchor; skin with dimensional, lived texture. Suppressed: bare breathing skin, loose untreated hair, no jewelry, balm-only lips.

**Cenography.** A costume archive, a study, a workshop in full inventory — hats, lasts, fabric bolts, paper, instruments; layered but ordered, an accumulation with a logic; the room of someone who has metabolized everything in it. Suppressed: an emptied room, a plaster wall, a swept concrete floor — space as the co-star.

**Colour.** Deep saturated families permitted in numbers no other instrument allows — but ranked, with one dark constant running through every layer so the palette reads as collection, not spill. The suppressed register collapses to a single pale tone and lets air carry the colour.

**Compression proof.** Wherever the frame allows it, plant one device proving the abundance is governed: the same motif recurring at three depths in three materials, a shelf whose grading is legible at a glance, or the figure's dark column visibly repeated in the room's one structural vertical. A packed frame in which no object can name its neighbour is inventory without an owner — this instrument's most legible failure.

**Practitioner lines (from the codices).** Ruth Ossai — printed studio backdrop, pattern-on-pattern styling held in order by frontal casting and communal dignity. For the sparse register: Lillian Bassman — the frame bleached toward white, one gesture held in a narrow band of near-black.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** The packed frame: layered garments, pattern on pattern held in order by one dark anchor, shelves and objects rising out of focus behind, texture at every distance, not one empty inch.

> **↑ Prompt.** A costume archive exploding around a still centre, the model laced into embroidered brocade over printed silk over knitted mesh, shelves of hats and lasts and fabric bolts rising out of focus behind, pattern on pattern held in order by the single dark column of a coat, visual information at every depth of field and not one empty inch.
> 

> **↑ Negative line.** No empty minimal backgrounds, no negative space, no shallow depth of field blur washing out the inventory, no chaos without order, no frantic gesture, no startled expression.
> 

**↓ Suppressed — repertory.** The sparse frame: one garment, one gesture, generous negative space carrying more weight than the cloth.

> **↓ Prompt.** One linen shift, one standing figure, one shaft of window light, a floor that runs empty to the walls, the negative space carrying more weight than the cloth, nothing else admitted to the frame.
> 

> **↓ Negative line.** No layering, no pattern, no props, no shelves or inventory, no stacked jewelry, no deep packed backgrounds, no heavy makeup.
> 

## Estéticas relacionadas a DENSITY (A–Z)

As 30 estéticas classificadas sob DENSITY, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Art Deco**

**№ 058 / 1001** — *Light Cut Until It Reads as Class*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** várias linhagens convergem e nenhuma é opcional. Sem a herança artesanal da Art Nouveau, desaparece a mão luxuosa; sem a geometria da era da máquina, o raio solar não se resolve em grade; sem os empréstimos exotistas, o ornamento perde o vocabulário. É fusão, não revisão de um único pai.

**Atmosfera e mood**

**Luz lapidada até virar classe** — (1001 Aesthetics, interpretação)

Déco 1925: geometria de leques e raios, dourado sobre preto, glamour Gatsby.

**Paleta de cores** dourado, preto, verde-esmeralda, marfim

**Melhores usos:** pôsteres, branding, interiores

**MidJourney:** `[tema], art deco 1925 style, geometric gold --v 6`

**Prompt universal (Seedream):** `Glamour photograph shot on Hasselblad with 80mm lens, an art deco composition of geometric sunburst and fan motifs, gold and black lacquer with emerald accents, 1925 Gatsby ballroom light throwing long elegant shadows, polished chrome and marble reflections, symmetric poster-perfect framing, 8k luxury`

### **Boho Chic**

**№ 106 / 1001** — *Caravan That Unpacked*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** bricolagem boêmia, apropriação de têxteis globais e edição da moda comercial convergem. Sem o aparato da moda, a caravana não se converte em silhueta de varejo; sem os têxteis, a densidade perde o que sobrepor.

**Atmosfera e mood**

**A caravana que desempacotou** — (1001 Aesthetics, interpretação)

Boho chic: franjas, estampas em camadas curadas, festival com acabamento polido.

**Paleta de cores** terrosos, turquesa, dourado

**Melhores usos:** moda, decoração, lifestyle

**MidJourney:** `[tema], boho chic fashion, fringe and layered prints --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.4, a boho chic fashion editorial at golden hour, model in layered ethnic prints fringe suede and stacked turquoise jewelry walking through tall dry grass, backlit hair haze and gentle lens flare, earthy terracotta and cream palette, Free People campaign polish, warm cinematic grading, 8k`

### **DECOPLEX**

**№ 214 / 1001** — *Baroque Density Governed by Proportion*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; o epíteto define uma densidade barroca cuja abundância permanece governada pela proporção.

**Atmosfera e mood**

**Densidade barroca governada pela proporção** — (1001 Aesthetics, interpretação)

Decoplex: ornamento máximo sob grade rigorosa — camadas art déco empilhadas com precisão matemática.

**Paleta de cores** dourado, jade, preto laqueado

**Melhores usos:** design, capas, interiores

**MidJourney:** `[tema], ornate art deco maximalism with strict geometric order --v 6`

**Prompt universal (Seedream):** `Ultra-detailed render at 8k, a decoplex composition, maximal baroque ornament governed by a strict proportional grid, stacked art deco layers in gold jade and lacquered black, dense yet mathematically precise, jewel-like specular highlights, museum-grade digital finish`

### **Downtown**

**№ 241 / 1001** — *Wall Keeps the Score*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a lista de origem não traz nota genealógica expandida; a parede registra camadas de uso, presença e expressão urbana.

**Atmosfera e mood**

**A parede guarda o placar** — (1001 Aesthetics; código: match aproximado)

Centro urbano: paredes com camadas de grafite e cartazes, neon de loja, história acumulada em cada esquina.

**Paleta de cores** concreto, grafite colorido, neon urbano

**Melhores usos:** street, moda urbana, editorial

**MidJourney:** `--sref 1266007468 --sw 1000` (Vibrant Street Art — match aproximado)

**Prompt universal (Seedream):** `Shot on Kodak Portra 800 with 35mm lens, a downtown street scene, walls layered with graffiti and torn posters keeping the score, shop neon reflecting on wet concrete, accumulated urban history on every corner, documentary street grading, gritty texture detail, 8k`

### **Embellished**

**№ 278 / 1001** — *Every Square Inch Carries a Decision*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; cada polegada ornamentada transmite um código reconhecível e deliberado.

**Atmosfera e mood**

**Cada centímetro quadrado carrega uma decisão** — (1001 Aesthetics; código: Lummi, match aproximado)

Ornamentado: bordado, aplicação e pérola, superfície trabalhada até o limite, horror ao vazio.

**Paleta de cores** dourado, joias, tecidos ricos

**Melhores usos:** moda, decorativo, editorial

**MidJourney:** `--sref 2920189809 --sw 1000` (Ornate Elegance — match aproximado)

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 110mm macro lens, an embellished couture surface, embroidery beads and pearls covering every square inch, each centimeter carrying a decision, rich gold and jewel tones under jeweler's light, ornament without emptiness, haute-couture atelier detail, 8k`

### **Flemish Primitive**

**№ 337 / 1001** — *Van Eyck's Oil Glazes and the Arnolfini Mirror*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** a lista de origem não traz nota genealógica expandida; veladuras a óleo e o espelho de Arnolfini comprimem ambiente, símbolo e profundidade em escala mínima.

**Atmosfera e mood**

**Os vernizes a óleo de Van Eyck e o espelho Arnolfini** — (1001 Aesthetics, interpretação)

Primitivos flamengos: detalhe microscópico em camadas de óleo, luz de joia do século XV, realismo devocional absoluto.

**Paleta de cores** vermelho de manto, verde profundo, luz de vitral

**Melhores usos:** retratos, histórico, fine art

**MidJourney:** `[tema], Flemish Primitive painting, Van Eyck oil glazes, Arnolfini mirror detail --v 6`

**LoRA (Civitai):** "Jan van Eyck Style" (Flux) — civitai.com/models/99433

**Prompt universal (Seedream):** `Museum-grade reproduction of a Flemish Primitive painting, Jan van Eyck microscopic detail in layered oil glazes, 15th century jewel light with mantle red and deep green, a convex mirror reflecting the room in impossible clarity, absolute devotional realism, 8k archival scan`

### **Gilded Age**

**№ 377 / 1001** — *Breakers, 1895: Railroad Capital Wearing a Palazzo*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; o capital ferroviário revisa o palazzo como cenário de acumulação e prestígio.

**Atmosfera e mood**

**The Breakers, 1895: capital ferroviário vestindo um palazzo** — (1001 Aesthetics, interpretação)

Era Dourada: mansões americanas imitando palácios europeus, mármore e ouro novo, riqueza industrial em traje renascentista.

**Paleta de cores** dourado, mármore branco, veludo bordô

**Melhores usos:** histórico, luxo, editorial

**MidJourney:** `[tema], Gilded Age mansion interior, 1895 Breakers-style marble and gold opulence --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 24mm lens, a Gilded Age interior, 1895 American mansion wearing an Italian palazzo, new railroad money in marble and gold with burgundy velvet, chandelier glow on polished stone, industrial wealth dressed in Renaissance costume, 8k`

### **Hedonism**

**№ 425 / 1001** — *Decanted Pour Held Before the Swallow*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → EDITING ↓

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; a abundância sensorial é transmitida sem o corte corretivo, concentrada no instante anterior ao consumo.

**Atmosfera e mood**

**O vinho decantado suspenso antes do gole** — (1001 Aesthetics, interpretação)

Hedonismo: prazer em câmera lenta, veludo e taça na luz de vela, o instante antes da satisfação esticado ao máximo.

**Paleta de cores** vinho profundo, veludo bordô, dourado de vela, pele quente

**Melhores usos:** gastronomia, editorial sensorial, branding premium

**MidJourney:** `[tema], hedonist aesthetic, decanted wine held before the swallow, velvet and candlelight indulgence --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 85mm lens by candlelight only, a hedonism image, a decanted pour held before the swallow, deep wine and burgundy velvet, John Alcott candlelit exposure, pleasure stretched in slow motion just before satisfaction, 8k`

### **Indian**

**№ 464 / 1001** — *Marigold and Indigo Crowd the Festival Street*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; calêndula, índigo, multidão e ritual são articulados como camadas interdependentes.

**Atmosfera e mood**

**Calêndula e índigo lotam a rua do festival** — (1001 Aesthetics, interpretação)

Indiano: saturação máxima de festival, guirlandas e pó de holi, cor como abundância e devoção.

**Paleta de cores** laranja de calêndula, índigo, rosa de holi, dourado de sári

**Melhores usos:** cultural, festival, editorial vibrante

**MidJourney:** `[tema], Indian festival aesthetic, marigold garlands and indigo crowding the street, holi color abundance --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7 IV with 24mm lens, an Indian festival image, marigold orange and indigo crowding the street, holi powder and sari gold in maximum saturation, Raghubir Singh street color mastery, color as abundance and devotion, 8k`

### **Japanese (Urban)**

**№ 490 / 1001** — *Shibuya Crossing Refreshes in Neon and Rain*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a lista de origem não traz nota genealógica expandida; neon, chuva, sinalização e fluxo urbano são recombinados numa superfície continuamente atualizada.

**Atmosfera e mood**

**O cruzamento de Shibuya se atualiza em neon e chuva** — (1001 Aesthetics; código: Kinomoto, match aproximado)

Japonês urbano: Tóquio noturna, neon refletido no asfalto molhado, multidão e sinalização em camadas infinitas.

**Paleta de cores** neon multicolorido, asfalto molhado, azul de noite urbana

**Melhores usos:** fotografia urbana, cyber, editorial

**MidJourney:** `--sref 974325905 --sw 1000` (cyberpunk urban — match aproximado)

**Prompt universal (Seedream):** `Shot on Sony A7 III with 35mm lens at night, a Japanese urban image, Shibuya crossing refreshing in neon and rain, multicolored signs reflected on wet asphalt, Liam Wong neon palette, layered crowds and signage in the Tokyo night, 8k`

### **Lush**

**№ 540 / 1001** — *Overgrown Greenhouse, Dripping Ferns*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; a proliferação vegetal é transmitida como abundância orgânica, enquanto a intenção centralizada cede lugar ao crescimento.

**Atmosfera e mood**

**Estufa tomada, samambaias gotejando** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lush: o crescimento além de toda borda, camadas esmeralda saturadas sob vidro embactado.

**Paleta de cores** esmeralda em camadas, vidro embactado, condensação

**Melhores usos:** botânica, editorial, interiores

**MidJourney:** `[tema], lush aesthetic, overgrown greenhouse with dripping ferns, saturated emerald, misted glass light --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya RB67 with 90mm lens, a lush image, an overgrown Victorian greenhouse with ferns dripping condensation down misted panes, saturated emerald layered on emerald under diffuse skylight, monstera pressing against the glass from inside, Henri Rousseau jungle density grown domestic, growth permitted past every border it was given, 8k`

### **Maximalism**

**№ 554 / 1001** — *Room That Refuses a Final Object*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a lista de origem não traz nota genealógica expandida; a sala recusa o objeto final e rearticula a abundância no limite da coerência.

**Atmosfera e mood**

**A sala que recusa um objeto final** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Maximalismo: a abundância como composição, padrão sobre padrão em joia sobre esmeralda e fuchsia.

**Paleta de cores** esmeralda, fuchsia, dourado saturado

**Melhores usos:** interiores, editorial, branding ousado

**MidJourney:** `[tema], maximalism aesthetic, a room that refuses a final object, pattern on pattern, jewel saturation --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100RF with 28mm lens, a maximalism image, a salon-hung room that refuses to nominate a final object, pattern stacked on pattern in emerald fuchsia and saturated gold, Kelly Wearstler confidence over Tony Duquette abundance, lacquer animal-print and malachite negotiating loudly, more proven gloriously to be more, 8k`

### **MicroPrecision**

**№ 569 / 1001** — *Tolerance Where Dust Becomes Huge*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a lista de origem não traz nota genealógica expandida; a escala microscópica comprime informação até que luz, tolerância e poeira se tornem monumentais.

**Atmosfera e mood**

**Tolerância onde a poeira vira gigante** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

MicroPrecision: engrenagens de relógio e trilhas de silício, a perfeição medida em mícrons.

**Paleta de cores** aço polido, dourado de latão, azul técnico

**Melhores usos:** relojoaria, tech, produto

**MidJourney:** `[tema], microprecision aesthetic, watch gears and silicon traces where dust becomes huge, micron tolerance --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D850 with 105mm macro lens, a microprecision image, watch gears meshing beside silicon wafer traces at a tolerance where a dust mote becomes a boulder, polished steel and brass gold under shadowless technical light, jeweled bearings glinting like small planets, Swiss horology discipline applied to the visible world, perfection measured in microns, 8k`

### **Migration Period**

**№ 571 / 1001** — *Portable Prestige in an Age Without Walls*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; o prestígio é condensado em objetos portáteis capazes de atravessar território e tempo.

**Atmosfera e mood**

**Prestígio portátil numa era sem muralhas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Período das Migrações: riqueza que viaja no corpo, granada cloisonné e ouro entrelaçado.

**Paleta de cores** granada, ouro entrelaçado, bronze antigo

**Melhores usos:** histórico, joalheria, museu

**MidJourney:** `[tema], Migration Period aesthetic, garnet cloisonne brooch and interlaced gold, portable treasure --v 6`

**Prompt universal (Seedream):** `Shot on Leica S3 with 120mm macro lens in a museum vitrine, a Migration Period image, a garnet cloisonne brooch and interlaced gold catching case light, portable prestige from an age without walls, wealth made to travel on the body, 8k`

### **Moorish**

**№ 581 / 1001** — *Geometry Cooling the Courtyard*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; geometria, sombra e repetição transmitem um código espacial que organiza o pátio.

**Atmosfera e mood**

**Geometria esfriando o pátio** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mourisco: arcos de ferradura e muqarnas sobre água parada, sombra desenhada em estrela.

**Paleta de cores** estuque, azul de azulejo, sombra de arcada

**Melhores usos:** arquitetura, viagem, editorial

**MidJourney:** `[tema], Moorish aesthetic, horseshoe arches and muqarnas over a still courtyard pool, star-cut shadow --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q3 43 with 43mm lens, a Moorish image, horseshoe arches and muqarnas honeycombs reflected in a still courtyard pool, stucco lacework and tile blue under star-cut shadow, Alhambra water channels whispering through the geometry, carved cedar cooling the light itself, mathematics doing the quiet work of paradise, 8k`

### **Old-Fashioned**

**№ 645 / 1001** — *Worn Outranks the New*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; o usado supera o novo porque cada camada de desgaste acrescenta memória e ressonância.

**Atmosfera e mood**

**O gasto vale mais que o novo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Antiquado: armazém de interior, balança de latão e caderno de fiado — o tempo como selo de confiança.

**Paleta de cores** madeira gasta, latão, papel amarelado

**Melhores usos:** nostalgia, branding, editorial

**MidJourney:** `[tema], old-fashioned aesthetic, worn general store brass scale, time as a seal of trust --v 6`

**Prompt universal (Seedream):** `Shot on a 1950s Kodak Retina with 50mm lens, an old-fashioned general store interior, brass scale and yellowed ledger on a counter worn smooth by decades of hands, warm wood patina where worn outranks new, honest vintage color and gentle grain, 8k scan`

### **Opulence**

**№ 652 / 1001** — *Excess Treated as Sacred Duty*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a lista de origem não traz nota genealógica expandida; o excesso é rearticulado como dever, e a materialidade sustenta sua autoridade.

**Atmosfera e mood**

**Excesso tratado como dever sagrado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Opulência: ouro sobre veludo sobre mármore, a abundância encenada sem pedir desculpas.

**Paleta de cores** ouro profundo, veludo rubi, mármore negro

**Melhores usos:** luxo, interiores, capas

**MidJourney:** `[tema], opulence aesthetic, gold over velvet over marble, excess as sacred duty --v 6`

**Prompt universal (Seedream):** `Shot on an 8x10 Sinar Norma with 300mm lens, an opulent still life, gold vessels over ruby velvet over black marble under candlelit glow, abundance staged without apology, every reflection and thread rendered in large-format detail, excess performed as sacred duty, 8k`

### **Orientalism**

**№ 654 / 1001** — *East Invented for a Western Room*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; códigos atribuídos ao “Oriente” são revisados e acumulados para fabricar um interior ocidental imaginado.

**Atmosfera e mood**

**O Oriente inventado para uma sala ocidental** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Orientalismo: sedas, arcos e vapor pintados por quem olhava de fora — fantasia do século XIX mais que documento.

**Paleta de cores** açafrão, turquesa, sombra de tapete

**Melhores usos:** arte, histórico, editorial crítico

**MidJourney:** `[tema], 19th century orientalist painting aesthetic, silks arches and steam, the East invented for a Western room --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a 19th-century orientalist painting, silks arches and hammam steam composed as the East invented for a Western salon, Jean-Léon Gérôme polished detail in saffron and turquoise, seductive fantasy acknowledged as fantasy, 8k archival scan`

### **Overloaded**

**№ 658 / 1001** — *Information Until the Image Breaks*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a lista de origem não traz nota genealógica expandida; a informação é acumulada até que a imagem rompa sua própria coerência.

**Atmosfera e mood**

**Informação até a imagem quebrar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sobrecarregado: camadas de janelas, adesivos e notificações até a composição saturar de propósito.

**Paleta de cores** tudo ao mesmo tempo, vermelho de alerta

**Melhores usos:** arte digital, conceito, capas

**MidJourney:** `[tema], overloaded aesthetic, layered windows stickers notifications until the image breaks --v 6`

**Prompt universal (Seedream):** `Ultra-dense digital collage, an overloaded composition layering pop-up windows stickers and notification badges until the image deliberately breaks, alert red pulsing through visual static, information volume as the subject itself, obsessive maximal detail, 8k`

### **Overstimulation**

**№ 659 / 1001** — *Every Sense Kept Above Threshold*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → EDITING ↓

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; todos os sentidos permanecem acima do limiar porque o corte é deliberadamente recusado.

**Atmosfera e mood**

**Todos os sentidos acima do limite** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Superestimulação: Times Square dentro da cabeça, estrobo, tela e ruído simultâneos congelados num quadro.

**Paleta de cores** neon simultâneo, branco de estrobo

**Melhores usos:** conceito, editorial, arte

**MidJourney:** `[tema], overstimulation aesthetic, every sense above threshold, strobe screens and noise at once --v 6`

**Prompt universal (Seedream):** `Cinematic freeze-frame shot on RED V-Raptor, an overstimulation tableau, a figure standing still while Times Square screens strobe and crowds blur past, every neon channel firing simultaneously against strobe white, sensory overload composed with surgical clarity, 8k`

### **Palimpsest**

**№ 662 / 1001** — *History Refuses a Clean Erasure*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; a história revisa a superfície sem apagar completamente as inscrições anteriores.

**Atmosfera e mood**

**Texto fantasma sob a escrita nova** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Palimpsesto: pergaminho raspado e reescrito, camadas de séculos transparecendo umas nas outras.

**Paleta de cores** pergaminho, tinta ferrogalálica, sombra de letra

**Melhores usos:** editorial, conceito, arte

**MidJourney:** `[tema], palimpsest aesthetic, scraped vellum ghost text under new script, layered centuries --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a scraped vellum palimpsest, ghost text shimmering beneath newer script in iron-gall ink, centuries of writing showing through one another like sediment, parchment cream and faded umber, raking light revealing erased letters, archival detail, 8k`

### **Persian**

**№ 679 / 1001** — *Garden Geometry Carrying Empire and Verse*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; geometria de jardim, império e verso são transmitidos como uma ordem densa e coerente.

**Atmosfera e mood**

**Jardim, verso e império na mesma moldura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Persa: miniaturas de jardim chahar bagh, caligrafia e turquesa — o paraíso planejado em quatro canteiros.

**Paleta de cores** turquesa, lapis, ouro de iluminúra

**Melhores usos:** arte, cultura, editorial

**MidJourney:** `[tema], Persian miniature aesthetic, chahar bagh garden geometry, verse and empire in one frame --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Persian miniature, a chahar bagh garden divided into four flowering quarters around a turquoise channel, courtiers and calligraphy borders in lapis and illumination gold, paradise planned as geometry with poetry in the margins, jewel-precise detail, 8k`

### **Petitecore**

**№ 680 / 1001** — *Small Scale, Full Sovereignty*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → DOMAIN ↓

**Polaridade:** XX — continuidade por revisão

**Nota:** a lista de origem não traz nota genealógica expandida; a escala reduzida não reduz a soberania do mundo comprimido dentro dela.

**Atmosfera e mood**

**Escala pequena, soberania completa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Petitecore: mundos em miniatura levados a sério — cada objeto minúsculo com dignidade de monumento.

**Paleta de cores** tons de casinha de boneca, madeira mini, pó de açúcar

**Melhores usos:** produto, arte, editorial

**MidJourney:** `[tema], petitecore aesthetic, miniature world taken seriously, tiny objects with monument dignity --v 6`

**Prompt universal (Seedream):** `Shot on OM System OM-5 with 60mm macro lens, a petitecore tableau, a hand-built miniature room where every tiny chair and teacup carries the dignity of a monument, dollhouse tones and powdered-sugar light, small scale ruled with complete sovereignty, exquisite macro focus, 8k`

### **Pop**

**№ 698 / 1001** — *Everything Enters the Feed*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota:** a lista de origem não traz nota genealógica expandida; mercadoria, celebridade e repetição entram no fluxo como emissão contínua.

**Atmosfera e mood**

**Tudo vira adesivo brilhante** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pop: saturação total, contorno grosso e a cultura de massa celebrada em volume máximo.

**Paleta de cores** primárias saturadas, rosa chiclete, contorno preto

**Melhores usos:** campanhas, capas, branding

**MidJourney:** `[tema], pop aesthetic, full saturation thick outlines, mass culture at maximum volume --v 6`

**Prompt universal (Seedream):** `Ultra-vivid pop composition, the subject rendered as a glossy sticker with thick black outlines and full-saturation primaries, bubblegum pink and electric blue celebrating mass culture at maximum volume, flat punchy color with sticker-sheen highlights, billboard-crisp finish, 8k`

### **Slowcore**

**№ 815 / 1001** — *Music That Breathes*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↓ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a lógica de repetição e redução do minimalismo musical, flexibilizada pelo pós-minimalismo, é redirecionada do processo ao sentimento. Um padrão antes afastado da emoção torna-se silêncio sustentado que carrega todo o peso da dor.

**Atmosfera e mood**

**Música que respira devagar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Slowcore: quarto em meia-luz, amplificador em volume mínimo e acordes espaçados como respiração — Low e Duster como clima.

**Paleta de cores** azul de abajur, cinza de tarde, madeira escura

**Melhores usos:** música, editorial, capas

**MidJourney:** `[tema], slowcore aesthetic, dim bedroom amp at minimum spaced chords, music that breathes --v 6`

**Prompt universal (Seedream):** `Shot on Pentax LX with 50mm lens, a slowcore afternoon, a guitar leaning on a barely humming amp in a dim bedroom, lamp blue and overcast gray settling over dark wood floors in the Low and Duster register, chords spaced like slow breathing, patient melancholic grain, 8k`

### **Superflat Pop**

**№ 866 / 1001** — *Japanese Commercial Art Across a Global Feed*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** três linhagens equivalentes se entrelaçam: Superflat de origem galerística, lógica de reprodução industrial da Pop ocidental e merchandising comercial kawaii. A estética existe apenas pela recombinação genuína das três.

**Atmosfera e mood**

**A arte comercial japonesa atravessando o feed global** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Superflat pop: o personagem fofo em colab de luxo, escultura de vinil sob vitrine espelhada e a fronteira arte-produto dissolvida de vez.

**Paleta de cores** rosa de vinil, dourado de colab, branco de vitrine

**Melhores usos:** branding, produto, editorial

**MidJourney:** `[tema], superflat pop aesthetic, cute character luxury collab vinyl sculpture, art and product dissolved --v 6`

**Prompt universal (Seedream):** `Ultra-glossy product photograph, superflat pop, a cute wide-eyed vinyl character sculpture posed on a mirrored luxury vitrine beside its designer collab handbag, vinyl pink and collab gold under boutique spotlights, the border between artwork and product dissolved for a global feed, flawless commercial sheen, 8k`

### **Thorncore**

**№ 899 / 1001** — *Beauty Defended by the Barb*

**Nível:** 🟤 Terciária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Romantismo Gótico, Pré-Rafaelismo e Pastoral Sombrio convergem, cada qual fornecendo um componente estrutural insubstituível. O resultado é um híbrido multigeracional da era da internet.

**Atmosfera e mood**

**A beleza defendida pelo espinho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Thorncore: a rosa cercada da própria guarda, espinhos em contraluz e o aviso de que todo encanto cobra passagem.

**Paleta de cores** vermelho de rosa, verde escuro de haste, prata de espinho

**Melhores usos:** arte, editorial, capas

**MidJourney:** `[tema], thorncore aesthetic, rose ringed by its own guard backlit thorns, beauty defended by the barb --v 6`

**Prompt universal (Seedream):** `Shot on OM System OM-1 with 90mm macro lens, a thorncore study, a deep red rose ringed by its own curved thorns catching silver rim light along every barb, dark stem green receding into shadow, beauty posting its own armed guard and charging admission, razor-sharp macro menace, 8k`

### **Tinycore**

**№ 901 / 1001** — *Wonder Reduced to Dollhouse Scale*

**Nível:** 🟣 Secundária

**Eixo:** DENSITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a tradição miniaturista da casa de bonecas fornece o pai único; Tinycore reinstrumenta essa herança ao aquecer a gramática da casa-gabinete com um registro doméstico de Cottagecore.

**Atmosfera e mood**

**O deslumbre reduzido à escala de casa de boneca** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tinycore: a cozinha inteira cabendo na palma, pãezinhos de um centímetro e a paciência de pinça que constrói mundos minúsculos.

**Paleta de cores** pastel de miniatura, madeira de palito, branco de louça mínima

**Melhores usos:** craft, produto, conteúdo

**MidJourney:** `[tema], tinycore aesthetic, whole kitchen in a palm one-centimeter bread loaves, wonder at dollhouse scale --v 6`

**Prompt universal (Seedream):** `Shot with a Laowa 24mm probe macro lens, a tinycore diorama, a complete dollhouse kitchen with one-centimeter bread loaves and thimble-sized copper pots beside the human fingertip that built them, miniature pastels under soft craft-table light, wonder engineered with tweezer patience, astonishing small-scale detail, 8k`

### **Victorian**

**№ 948 / 1001** — *Empire Crowds the Room With Evidence*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** Neoclassicismo, Romantismo e Revival Gótico funcionam como influências contextuais, não como pais constitutivos. A gramática da acumulação é irredutível e gera Arts and Crafts, o Movimento Estético e a Art Nouveau como descendentes.

**Atmosfera e mood**

**O império lotando a sala de evidências** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vitoriano: samambaias sob redoma, porcelana de três continentes e nenhuma superfície sem objeto — a prosperidade provada por acúmulo.

**Paleta de cores** mogno escuro, verde de papel de parede, dourado de moldura

**Melhores usos:** interiores, histórico, editorial

**MidJourney:** `[tema], victorian aesthetic, ferns under glass domes porcelain from three continents no empty surface, prosperity proven by accumulation --v 6`

**Prompt universal (Seedream):** `Wet plate photograph on a brass Petzval lens, a Victorian parlor, ferns under glass domes crowding porcelain from three continents across every mahogany surface, wallpaper green and frame gold pressing in from all sides, the empire submitting its evidence room by room, dense period opulence, 8k scan`

### **Visual Pollution**

**№ 956 / 1001** — *City Exceeds the Eye's Bandwidth*

**Nível:** 🔴 Primária

**Eixo:** DENSITY ↑ → EDITING ↓

**Polaridade:** XY — disrupção por ruptura

**Nota:** nenhum movimento isolado gera a condição: publicidade, sinalização, construção e resíduos se sobrepõem sem coordenação. O acúmulo é irredutível; remova qualquer contribuinte e a saturação visual continua.

**Atmosfera e mood**

**A cidade excedendo a banda do olho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Poluição visual: cada fachada gritando sobre a outra, fios cruzando entre letreiros luminosos e o olhar sem um centímetro de descanso — o excesso como documento.

**Paleta de cores** neon competindo, amarelo de placa, cinza de fiação

**Melhores usos:** documental, conceito, editorial

**MidJourney:** `[tema], visual pollution aesthetic, every facade shouting over the next crossed wires, the eye's bandwidth exceeded --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-Pro3 with 23mm lens, a visual pollution document, a commercial street where competing neon signs stacked billboards and crossed wiring leave the eye not one centimeter of rest, sign yellow and rival neon tangled in cable gray, the city broadcasting past its own bandwidth, overwhelming saturated density, 8k`

## Leitura do padrão — o que as 30 estéticas confirmam

A lista confirma que DENSITY mede **compressão governada**, não simples volume. O Omphalos opera quando muita informação cabe no quadro e permanece legível por causa de uma âncora; quando a âncora é negada deliberadamente, a saturação vira o próprio argumento.

### Uma exceção suprimida que confirma a regra

Slowcore é a única entrada DENSITY ↓. Sua rarefação não é vazio casual: é disciplina temporal. O pareamento com ETERNITY ↑ mostra que aquilo que respira devagar pode sustentar maior duração.

### Cinco famílias recorrentes

1. **Acúmulo governado pela âncora:** Maximalism, Opulence, Embellished, DECOPLEX, Gilded Age, Victorian e Boho Chic. O quadro está cheio, mas um centro imóvel mantém a hierarquia.
2. **Saturação além do limiar:** Visual Pollution, Overstimulation, Overloaded e Hedonism. O corte é recusado; em Visual Pollution, a própria ausência de coordenação funda a gramática.
3. **Compressão em escala mínima:** Petitecore, Tinycore, MicroPrecision e Flemish Primitive. A densidade é informação por profundidade, não tamanho do inventário.
4. **Camadas de tempo e referência:** Persian, Palimpsest, Migration Period, Moorish, Orientalism, Old-Fashioned, Indian, Superflat Pop e Thorncore. A densidade acumulada converte-se em memória e código.
5. **Densidade urbana e comercial:** Pop, Downtown, Japanese (Urban) e Art Deco. A iluminação organiza o fluxo e impede que a cidade se torne ruído indiferenciado.

### O teste operacional

DENSITY não é sinônimo de maximalismo. A pergunta é mais precisa: **quanto mundo cabe no quadro sem transbordar — e existe um centro imóvel para onde o olho retorna?** Persian, Tinycore e Visual Pollution respondem ao mesmo teste por meios opostos: ordem imperial, miniatura soberana e saturação sem âncora.

# MATTER — o Círculo Quadrado alquímico

<aside>
◉

**Essência.** MATTER mede o papel do substrato, do trabalho e da transformação física. Seu ideograma é a instrução alquímica do Círculo Quadrado: o espírito entra no mundo uma geometria por vez. No registro ↑, peso, trama, gravidade e resistência permanecem visíveis; no registro ↓, a matéria se dissolve deliberadamente em luz, transparência ou sinal.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para MATTER, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem o substrato próprio de cada estética, enquanto a arquitetura preserva a lei do Círculo Quadrado — a resistência do material precisa ficar visível.

> **↑ MATTER — universal prompt.** A figure whose widened, grounded stance visibly braces against the mass of [the aesthetic's own heaviest material], the hem's weight dragging the shoulder line and the spine working rather than decorating; hands engaged with substance — knuckles pressed into a fold, a thumb tracing an edge, tendons visible, nothing decorative in the fingers; a gaze held steady under load, jaw set with quiet labor, the face in negotiation with the material and the material answering; matte mineral skin with lived texture, hair coarse and honestly set with fibres visible, unmanicured hands, a trace of [the aesthetic's own dust or residue] kept on the collarbone; [the aesthetic's own signature garment or substrate] with its construction exposed — seams, weave ridges, tool marks — and its origin legible in the surface; photographed on a macro-capable 75mm at f/11 on tripod, a raking three-quarter angle chosen for texture rather than flattery, focus held on the surface of the material so the weave survives at print scale; the material occupying the frame like a landform, folds reading as strata, figure and substance fused into one mass; hard raking side light skimming across the surface so every ridge catches, shadow carving relief and never hiding, warmth in the key so labor reads noble; a ground that shows its own formation — [the aesthetic's own site of making or wear: workshop, quarry, field, shoreline] — with tools resting mid-use and dust hanging in the beam, one visible proof that the material resisted and the maker answered.
> 

**Universal MATTER ↓ negative line (always pair with the ↑ prompt):**

> No gloss, no synthetic sheen, no laminated surfaces, no weightless floating fabric, no edges dissolving into glare, no backlit halo, no decorative hand poses, no manicure, no beauty-dish softness erasing texture, no digital smoothing, no set that hides its own formation.
> 

**Como usar para as 99 estéticas da lista.** Troque os colchetes pelo substrato próprio da estética — esta é a maior lista do glossário, e a arquitetura do prompt só nomeia mecanismos (o corpo firmado contra a massa, a trama que sobrevive na escala de impressão, a luz rasante que esculpe, a prova da resistência em quadro). Exemplos: para **Raw / Unpolished / Wild**, o acabamento interrompido no estágio de evidência — a marca da ferramenta mantida; para **Romanesque / Imperial Roman / Greek Aegean**, a pedra cortada como oração e o mármore ao meio-dia; para **Wabi-Sabi**, a rachadura que supera a superfície perfeita — a emenda mantida como assinatura; para **Luxury / Dutch Golden Age**, o grão do couro e o vidrado a óleo lidos como o argumento máximo; para **Workwear / INDUSTRIAL**, o denim escrito pelo trabalho e o rebite com a carga exposta; para **Weirdcore / Web 1.0**, a matéria estendida ao pixel — compressão e perda de sinal tratadas como substrato. Para **Neo Surrealism**, inverta para o registro ↓ — o sonho renderizado em resolução de tela, a matéria dissolvida para o signo flutuar.

## Fundamentos do elemento

### Identidade, resistência e disciplina material

**Identity.** Role of substrate, labor, and physical transformation. Its ideogram is the alchemist's impossible instruction of 1617, circle to square to triangle to circle: spirit entering the world only through discipline of form, one geometry at a time. Matter is the world's first word back; the material's resistance must be visible. In an image this element is proven by weight, weave, and gravity, or by the garment dissolved into light.

**The resistance law.** Matter is proven only where the material pushes back and the frame keeps the evidence — the hem that drags the shoulder, the weave that refuses the light, the tool mark left in the surface. A garment that hangs without weight has not been photographed; it has been illustrated. The suppressed register does not break this law — it inverts the substrate: when the cloth dissolves into light, the light itself must carry the material duty, and the dissolution must read as chosen, never as underexposed fabric.

**One geometry at a time.** The Squared Circle's instruction is sequential — circle to square to triangle to circle: spirit enters the world through one discipline of form per frame. Practically: one material argument per image. A frame that testifies to wool and chrome and clay at equal volume has refused the alchemist's order and reads as a materials library, not an aesthetic.

## Corpo — postura, gesto e olhar

**Model posture & structure.** Stance widened and grounded to carry real weight; the shoulder line visibly dragged by the hem's mass; spine working, not decorating — the honest micro-lean of a body bearing material. Suppressed register: upright and weightless, a slow drifting turn, arms lifted by air rather than effort.

**Gesture.** Hands engaged with substance — gripping a fold, knuckles pressed into weave, a thumb tracing a bevel; working hands with tendons visible; no floating decorative gestures. Suppressed: fingertips open, releasing — fabric allowed to float off the hand, gestures that never grip.

**The look — how the eyes behave.** Grounded, effortful presence — gaze steady under load, jaw set with quiet labor; the face of someone in negotiation with the material, and the material answering. Suppressed: a softened backlit profile, features simplified toward outline, expression serene and dissolved.

## Regras de imagem — do substrato à prova de resistência

**Look & styling continuity.** Hand-loomed, felted, or raw-fibred cloth with the ridge of the weave visible, fibres lifting at the collar, seams and construction exposed; the material's origin legible — fleece, bark, ore. Suppressed: layered organza, tulle, or chiffon in pale tones, edges indistinguishable from glare, no visible seams.

**Camera.** 65–80mm macro-capable lens at f/11 on tripod; a raking three-quarter angle chosen for texture, not flattery; focus priority on the surface of the cloth — the texture must survive at print scale. Suppressed: 85–135mm at f/2, exposure lifted toward the highlights, a gentle bloom permitted, focus allowed to melt at the edges.

**Composition.** The material occupying the frame like a landform — folds reading as strata, the garment a horizon, figure and material fused into one mass; tight enough that weave becomes topography. Suppressed: the figure a silhouette inside a luminous volume, the frame dominated by gradient fields, minimal ground contact shown.

**Lighting.** Hard raking side light skimming across the weave so every ridge catches; low sun angle or a single side source; shadow used to carve relief, never to hide; warmth in the key so labor reads noble, not grim. Suppressed: bright scrims and backlight, glare embraced, no shadow structure, light wrapping until the edges disappear.

**Beauty detail.** Mineral matte finish — skin with clay-and-stone texture, no gloss; hair coarse and raw, a rough braid or wind-set mass with fibres visible; brows brushed but unfilled; unmanicured honest nails; a trace of dust on the collarbone kept. Suppressed: luminous translucent prep, glassy highlight, hair backlit into a halo — the face reading as light, not matter.

**Cenography.** Workshop or quarry register — raw timber, stone block, a loom mid-warp, tools resting mid-use, dust hanging in the beam; surfaces that show their formation process; nothing laminated, nothing synthetic. Suppressed: white cyclorama, backlit scrim walls, haze — a set that is atmosphere rather than architecture.

**Colour.** Undyed, mineral, and earth families — the palette the substrate arrives in, held rather than corrected; colour earned from material, never applied over it. The suppressed register inverts: pale tones dissolved into gradients, colour present only as light.

**Resistance proof.** Wherever the frame allows it, plant one device proving the material answered back: the hem's drag legible in the shoulder line, the tool mark left in the surface, the weave's ridge catching the raking light at print scale — or, in the dissolved register, the garment's edge lost in glare so deliberately that the dissolution reads as authored. A frame where the material neither resists nor visibly surrenders is this instrument's most legible failure.

**Practitioner lines (from the codices).** Dana Scruggs — hard sculptural key on glistening skin, sweat and muscle kept as monumental material fact. Sam Rock — overcast elemental daylight on wet wool and rain-dark fields, texture photographed as weather. Paul Outerbridge — tri-colour carbro saturation on ordinary objects arranged with a still-life painter's geometric precision. For the dissolved register: Baron Adolf de Meyer — backlit gauze and halation, the shoulder's edge melting into the ground as an act of choice; Pierre Debusschere — bodies dissolving into coloured light washes in black voids.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Substance foregrounded: hand-loomed and felted surfaces, fibres lifting at the collar, the hem's weight visibly pulling the shoulder line, the body braced against the garment's mass, cloth photographed the way geology is photographed.

> **↑ Prompt.** A hand-loomed greatcoat in undyed horsehair and wool, every ridge of the weave catching side light, the hem's weight visibly dragging the shoulder line, fibres lifting at the collar, the model's stance braced against the garment's mass, fabric photographed the way geology is photographed.
> 

> **↑ Negative line.** No gloss, no synthetic sheen, no laminate surfaces, no floating weightless fabric, no decorative hand poses, no manicure, no beauty-dish softness erasing texture, no digital smoothing.
> 

**↓ Suppressed — repertory.** Dematerialization: layered translucency against bright scrims, edges lost in glare, the body a silhouette inside a luminous volume, fabric present only as colour in the air.

> **↓ Prompt.** A figure in layered organza standing against a bright scrim so the garment dissolves into gradients of light, edges indistinguishable from glare, the body a dark silhouette inside a luminous volume, fabric present only as colour suspended in the air.
> 

> **↓ Negative line.** No visible weave texture, no heavy wool or raw fibre, no raking hard light, no dust or workshop props, no gripping hands, no matte mineral skin.
> 

## Estéticas relacionadas a MATTER (A–Z)

As 99 estéticas classificadas sob MATTER, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Alpine**

**№ 042 / 1001** — *Larch, granite, and a carved rosette*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Lariço, granito e uma roseta entalhada** — (1001 Aesthetics, interpretação)

Chalés alpinos: madeira entalhada com rosetas folk, granito, edelvais, neve e conforto rústico.

**Paleta de cores** madeira cor de mel, branco-neve, verde-pinho, vermelho folk

**Melhores usos:** inverno, interiores, turismo

**MidJourney:** `[tema], Alpine chalet style, carved wood and edelweiss --v 6`

**Prompt universal (Seedream):** `Interior-lifestyle photograph shot on 35mm lens with warm tungsten balance, an Alpine chalet of carved larch and granite, folk rosette details and edelweiss on the table, snow peaks framed by small windows, firelight against honey-toned wood, cozy mountain warmth with cinematic amber grading, 8k`

### **Arts and Crafts**

**№ 064 / 1001** — *Oak that admits it's oak*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Nothing earlier produces this — the demand that material declare itself and that making and design be one act is stated as a root principle against industrial production, and removing honest material collapses the entire system rather than one of its branches.

**Atmosfera e mood**

**Carvalho que admite ser carvalho** — (1001 Aesthetics, interpretação)

Movimento Arts and Crafts: William Morris, artesanato honesto, padrões vegetais entrelaçados.

**Paleta de cores** verde-musgo, terracota, madeira

**Melhores usos:** padronagem, interiores, papelaria

**MidJourney:** `[tema], arts and crafts movement, William Morris pattern --v 6`

**Prompt universal (Seedream):** `Interior photograph shot on medium format with 50mm lens, an Arts and Crafts room with William Morris botanical wallpaper, honest oak joinery and hammered copper, moss green and terracotta harmony, low afternoon sun through leaded glass, handcrafted integrity in every visible tool mark, 8k`

### **Atlantic Forest Indigenous**

**№ 070 / 1001** — *Calendar you can eat*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** There is no earlier aesthetic to descend from — the forms come directly from the forest's own cycles of planting, harvest and renewal, predating any documented style, and removing the ecological calendar collapses the whole system rather than one branch.

**Atmosfera e mood**

**Calendário que se come** — (1001 Aesthetics, interpretação)

Povos da Mata Atlântica (Guarani, Tupinambá): cestaria, grafismos, plumária, saber sazonal da floresta.

**Paleta de cores** verdes de mata, urucum, palha

**Melhores usos:** cultura, padronagem, ilustração

**MidJourney:** `[tema], Brazilian Atlantic Forest indigenous art, Guarani basketry --v 6`

**Prompt universal (Seedream):** `Documentary art photograph shot on 50mm lens, Guarani woven basketry patterns and feather adornments of the Atlantic Forest, urucum red against deep forest greens, dappled light filtering through bromeliads, seasonal forest knowledge made visible in tactile craft detail, respectful editorial realism, 8k`

### **Australian**

**№ 074 / 1001** — *Ochre before iron, country before scenery*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No prior aesthetic supplies this — ochre, country and the relation to land arrive as first principles from the continent's own oldest continuous practice rather than from an inherited style, and removing that ground leaves nothing behind.

**Atmosfera e mood**

**Ocre antes do ferro, país antes de paisagem** — (1001 Aesthetics, interpretação)

Arte aborígene australiana: pontilhismo, songlines do tempo do sonho, ocres ancestrais.

**Paleta de cores** ocres, terracota, preto, branco

**Melhores usos:** padronagem, cultura, arte

**MidJourney:** `[tema], Australian Aboriginal dot painting style --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of an Australian Aboriginal dot painting, dreamtime songlines in ochre terracotta black and white, concentric circles and journey paths in meticulous hand-placed dots, natural earth pigments on linen with visible texture, raking gallery light, country as a living map, 8k`

### **Barbizon School**

**№ 079 / 1001** — *Tree a painter saved by returning to it*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Its founding law — that the painter works before the motif itself, returning to the same tree until it is known — has no precedent to descend from, and removing direct observation dissolves the practice entirely rather than pruning a branch.

**Atmosfera e mood**

**Árvore que um pintor salvou voltando até ela** — (1001 Aesthetics, interpretação)

Escola de Barbizon: paisagem plein-air na floresta de Fontainebleau, realismo rural humilde.

**Paleta de cores** verdes, terrosos, céus prateados

**Melhores usos:** paisagens, fine art

**MidJourney:** `[tema], Barbizon School plein air landscape painting --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Barbizon School oil painting, an ancient gnarled oak in Fontainebleau forest under silvery overcast light, humble shepherd and flock in earthy greens and umber, visible plein air brushwork and layered glazes in the manner of Théodore Rousseau and Corot, fine craquelure texture, 8k archival scan`

### **Berry**

**№ 086 / 1001** — *Blue that only shows up at the right pH*

**Nível:** ⚫ Quaternária

**Eixo:** MATTER ↑ → NUANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Several generations of colour practice converge — botanical pigment, food-culture imagery, and digital palette culture — and the pH-dependent hue only reads as a system when all three are present, confirming recombination rather than single-parent reinterpretation.

**Atmosfera e mood**

**Azul que só aparece no pH certo** — (1001 Aesthetics, interpretação)

Paleta berry: frutas vermelhas e roxas, saturação suculenta e comestível.

**Paleta de cores** framboesa, amora, vinho, rosa-morango

**Melhores usos:** food, branding, beleza

**MidJourney:** `[tema], berry tones palette, juicy deep reds and purples --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a sumptuous berry still life of raspberries blackberries and black cherries tumbling across dark slate, juice beads and sugar-frost bloom in raking window light, saturated raspberry-to-violet gradient, Dutch-master darkness with modern editorial gloss, mouthwatering specular highlights, 8k food-photography perfection`

### **Bio**

**№ 088 / 1001** — *Material that composts instead of getting thrown out*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** A single materials lineage is carried forward and re-specified at its end point — the same objects and forms persist while the substrate is required to return to the soil, so the tradition is redirected rather than rebuilt from several sources.

**Atmosfera e mood**

**Material que composta em vez de ir para o lixo** — (1001 Aesthetics, interpretação)

Design bio: micélio, fibras naturais, embalagens compostáveis, minimalismo ecológico.

**Paleta de cores** cru, bege, verdes suaves

**Melhores usos:** produto, embalagens, sustentabilidade

**MidJourney:** `[tema], biodegradable material design, mycelium --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.4, a sustainable bio-design product study, mycelium packaging and natural fiber textures arranged on raw linen, soft diffuse north light, compostable beige and sage green palette, water droplets on unbleached surfaces, Kinfolk-magazine minimal styling, tactile organic detail, clean eco-editorial grading, 8k`

### **BioCyber**

**№ 089 / 1001** — *Genome that compiles like code*

**Nível:** ⚫ Quaternária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Genetic science, cybernetic systems theory, and software's authoring metaphors converge generations downstream; strip the code metaphor and the genome stops reading as editable text, strip the biology and only interface remains — a weld of distinct lineages.

**Atmosfera e mood**

**Genoma que compila como código** — (1001 Aesthetics, interpretação)

Biocyber: hélice de DNA fundida a circuitos, o corpo digitalizado.

**Paleta de cores** verde-código, azul elétrico, preto

**Melhores usos:** sci-fi, tech, capas

**MidJourney:** `[tema], biocyber DNA circuitry fusion --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork rendered at 8k, a DNA double helix dissolving into glowing circuit boards, genome code compiling in cascading matrix green and electric blue on pure black, microscopic solder traces fusing with cell membranes, volumetric data light, Beeple-grade sci-fi polish, razor-sharp macro depth`

### **Biofluidism**

**№ 090 / 1001** — *Current that draws its own shape first*

**Nível:** ⚫ Quaternária

**Eixo:** MATTER ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Fluid-dynamics simulation, organic morphology, and parametric design practice fuse here; remove the simulation and the curve loses its authority, remove the biological reference and it reads as pure abstraction — recombination across several lines, not the revision of one.

**Atmosfera e mood**

**Corrente que desenha a própria forma primeiro** — (1001 Aesthetics, interpretação)

Biofluidismo: fluidos orgânicos vivos, correntes líquidas congeladas em movimento.

**Paleta de cores** gradientes aquosos perolados

**Melhores usos:** abstrato, capas, texturas

**MidJourney:** `[tema], biofluid organic flowing forms --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, an abstract biofluid composition of living liquid currents frozen mid-motion, pearlescent aqueous gradients swirling in teal ivory and rose gold, microscopic bubbles catching studio strobe light, high-speed fluid dynamics photography, glassy surface tension detail, gallery-print luminosity, 8k`

### **Biolumina**

**№ 091 / 1001** — *Jellyfish that taught the sea to glow*

**Nível:** ⚫ Quaternária

**Eixo:** MATTER ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Deep-sea natural history, luminous material engineering, and dark-environment display design converge; strip the biology and the glow has no origin story, strip the engineering and it cannot leave the ocean — fusion of several traditions rather than single-parent reinterpretation.

**Atmosfera e mood**

**Água-viva que ensinou o mar a brilhar** — (1001 Aesthetics, interpretação)

Bioluminescência: organismos que brilham na escuridão do oceano profundo.

**Paleta de cores** azul-elétrico, ciano, violeta sobre preto-oceano

**Melhores usos:** fantasia, cenários, capas

**MidJourney:** `[tema], bioluminescent deep sea glow --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7S with 24mm f/1.4 in underwater housing, a bioluminescent deep-sea dreamscape, glowing jellyfish trailing electric blue filaments through ink-black water, plankton constellations sparking violet around a drifting silhouette, long-exposure light trails, National Geographic depth and clarity, luminous cyan grading, 8k`

### **Biopunk**

**№ 097 / 1001** — *Lab That Left the Institution*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Cyberpunk's anti-institutional stance, laboratory biotechnology, and DIY maker culture converge; strip the lab and the politics have no instrument, strip the DIY strand and the work returns to the institution it defines itself against — fusion, not revision of one parent.

**Atmosfera e mood**

**Laboratório que saiu da instituição** — (1001 Aesthetics, interpretação)

Biopunk: bioengenharia de garagem, tanques brilhando, mutações de beco.

**Paleta de cores** verde tóxico, rosa-carne, branco de laboratório sujo

**Melhores usos:** sci-fi, worldbuilding, capas

**MidJourney:** `[tema], biopunk street lab, genetic hacking --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with harsh direct flash, a biopunk back-alley gene lab, glowing vats of toxic green culture fluid and mutated specimens in cracked jars, flesh-pink tubing stapled to rusted equipment, condensation and grime in every crevice, grimy body-modification dread in the vein of Cronenberg, gritty cinematic grain, 8k detail`

### **Biosynth**

**№ 098 / 1001** — *Life that remembers neither mother nor machine*

**Nível:** ⚫ Quaternária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Synthetic biology, industrial fabrication, and speculative-design imagery braid several generations down; each donor stays traceable and none alone yields a form that recalls neither organism nor machine — recombination rather than single-parent reinterpretation.

**Atmosfera e mood**

**Vida que não lembra nem da mãe nem da máquina** — (1001 Aesthetics, interpretação)

Biosynth: vida sintética perfeita, pele de polímero translúcido, beleza ambígua.

**Paleta de cores** perolado, translúcido, tons de pele sintética

**Melhores usos:** sci-fi, beleza futurista, 3D

**MidJourney:** `[tema], synthetic lifeform, polymer skin --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, a biosynthetic being with flawless translucent polymer skin over faintly visible organic structure, neither born nor built, pearlescent lilac subsurface glow under soft clinical light, dewy ambiguous beauty in a sterile white studio, hyperreal skin microtexture, futuristic beauty-campaign polish, 8k`

### **Black Modernism**

**№ 101 / 1001** — *Fist and the crown, same gesture at different scales*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No prior aesthetic can be named as its maker — it sets its own terms for representing Black modern life rather than inheriting them, and every element bears load, so removing that founding claim collapses the whole rather than pruning a branch.

**Atmosfera e mood**

**Punho e coroa, mesmo gesto em escalas diferentes** — (1001 Aesthetics, interpretação)

Modernismo negro: abstração e identidade, do Harlem Renaissance ao contemporâneo.

**Paleta de cores** contrastes fortes, dourado, tons de pele profundos

**Melhores usos:** arte, editorial, cultura

**MidJourney:** `[tema], Black modernism art, Harlem Renaissance to contemporary --v 6`

**Prompt universal (Seedream):** `Museum-grade contemporary artwork at 8k, bold abstracted Black figures with crown and raised-fist motifs in flattened geometric planes, Harlem Renaissance heritage reimagined through Jacob Lawrence and Kerry James Marshall, rich deep skin tones against gold leaf and cobalt, confident matte paint texture, dignified monumental power`

### **Botanical**

**№ 110 / 1001** — *Bloom that stops the eye mid-page*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** One lineage — scientific botanical illustration — is carried forward with its precision intact and redirected toward decoration, so the same drawing conventions are re-read for pattern rather than fused with other traditions.

**Atmosfera e mood**

**Flor que para o olho no meio da página** — (1001 Aesthetics, interpretação)

Ilustração botânica: precisão científica de prancha do século XIX com beleza delicada.

**Paleta de cores** verdes naturais, aquarela precisa, fundo creme

**Melhores usos:** ilustração, papelaria, decoração

**MidJourney:** `[tema], botanical illustration plate --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a 19th century botanical illustration plate, scientifically precise watercolor study of an orchid with dissected labeled details, delicate graphite underdrawing visible beneath translucent washes, cream laid paper with subtle foxing, Pierre-Joseph Redouté mastery, archival natural-history beauty, 8k museum digitization`

### **Brasília**

**№ 117 / 1001** — *City drawn in the shape of a plane*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTENTIONALITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** One modernist urban lineage is inherited whole and pushed to its conclusion at national scale — the same plan logic and concrete vocabulary persist while only ambition and completeness change, a reinterpretation within a single line.

**Atmosfera e mood**

**Cidade desenhada em forma de avião** — (1001 Aesthetics, interpretação)

Brasília de Niemeyer e Lucio Costa: curvas de concreto branco contra um céu enorme, utopia monumental.

**Paleta de cores** branco de concreto, azul de céu, sombras limpas

**Melhores usos:** arquitetura, editorial, design

**MidJourney:** `[tema], Brasília modernist architecture by Oscar Niemeyer --v 6`

**Prompt universal (Seedream):** `Shot on a large format camera with 90mm tilt-shift lens, Oscar Niemeyer's sweeping white concrete curves rising against a vast cobalt sky, lone figure crossing a monumental empty plaza for scale, razor-clean shadows and utopian geometry, minimal architectural composition, crisp concrete texture, museum-grade print quality, 8k`

### **Bricolage Art**

**№ 125 / 1001** — *Assembled from the oddments of other lives*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Collage practice, vernacular repair, and found-object sculpture converge; remove the fine-art assemblage strand and the result reads as mere mending, remove the vernacular strand and it loses its scavenged biography — recombination across lineages.

**Atmosfera e mood**

**Montado com as sobras de outras vidas** — (1001 Aesthetics, interpretação)

Assemblage: escultura e colagem de objetos achados, fragmentos resgatados, memória material.

**Paleta de cores** tons gastos e mistos de objetos usados

**Melhores usos:** arte, texturas, editorial

**MidJourney:** `[tema], bricolage assemblage art from found objects --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a bricolage assemblage sculpture, found objects and salvaged fragments fused into a poetic figure, rusted tin worn wood and chipped enamel under raking gallery light, mismatched textures composing other lives' leftovers, Rauschenberg spirit, every scratch and patina in razor focus, 8k fine-art documentation`

### **Britishcore**

**№ 127 / 1001** — *Heritage held at the bar, the hedgerow, and the hearth*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ESTHETICS ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Country-house heritage, pub vernacular, and working-class dress converge into one national shorthand; each strand stays separately visible and none alone yields the mix, marking recombination rather than the reinterpretation of a single ancestor.

**Atmosfera e mood**

**Herança guardada no pub, na cerca viva e na lareira** — (1001 Aesthetics, interpretação)

Britânico: pub de madeira escura, tweed, chá da tarde, campo verde úmido e cottages de pedra.

**Paleta de cores** verdes úmidos, tweed, vermelho de cabine telefônica

**Melhores usos:** lifestyle, editorial, cenários

**MidJourney:** `[tema], British countryside and pub culture aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 160 medium format, a British heritage scene, cozy pub interior of dark wood and polished brass opening onto hedgerow lanes and stone cottages under damp green light, tweed jacket and afternoon tea beside a rain-specked window, quiet tradition, muted heritage grading, cinematic English melancholy, 8k`

### **BRUTALISM**

**№ 129 / 1001** — *Concrete's civic argument*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ESTHETICS ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** A single modernist lineage is inherited whole and re-argued in ethical terms — the same structural language persists while finish is refused as a moral position, a reinterpretation within one line rather than a fusion of several.

**Atmosfera e mood**

**O argumento cívico do concreto** — (1001 Aesthetics; código: sref-midjourney.com)

Brutalismo: volumes massivos de concreto aparente (béton brut), sombras geométricas duras, presença monumental dos anos 1960.

**Paleta de cores** cinzas de concreto, céu nublado, sombras duras

**Melhores usos:** arquitetura, editorial, cenários distopia/sci-fi

**MidJourney:** `--sref 3584377950 --sw 1000` (Brutalist Wilderness) — alternativa da comunidade: `--sref 4277144679 --stylize 150`

**LoRA (Civitai):** "Brutalist architecture" (Flux.1) — civitai.com/models/1626907; variantes SDXL: Brutalist Luxury Homes, Decaying Brutalism

**Prompt universal (Seedream):** `Shot on large format with 90mm tilt-shift lens, monumental brutalist architecture, massive raw béton brut volumes stacking into an overcast gray sky, hard geometric shadows and board-formed concrete texture in razor detail, lone figure for scale, 1960s heroic civic presence, monochrome-leaning grading, museum-grade architectural print, 8k`

### **Cabincore**

**№ 138 / 1001** — *One warm source against slow weather*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** One rustic-shelter lineage is carried forward whole and re-read as refuge — the same timber, hearth and scale persist while necessity is rewritten as chosen retreat, a reinterpretation within a single line rather than a hybrid.

**Atmosfera e mood**

**Uma fonte de calor contra o tempo lento** — (1001 Aesthetics, interpretação)

Cabana: fogão a lenha aceso, mantas de lã, café esmaltado e chuva nas janelas pequenas.

**Paleta de cores** madeira, xadrez, laranja de fogo

**Melhores usos:** inverno, lifestyle, cenários

**MidJourney:** `[tema], cabincore cozy cabin aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 35mm lens, a cabincore interior, log walls glowing from a cast-iron wood stove, wool blankets and enamel coffee pot steaming, rain streaking small windows against dark pines, single warm light source carving amber shadows, slow-weather serenity, tactile wood grain detail, 8k`

### **Cangaço**

**№ 140 / 1001** — *Leather armor, embroidered star, sertão refusal*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Sertão leatherwork, folk-Catholic emblem, and outlaw self-fashioning converge; strip the leather craft and the armor disappears, strip the devotional emblem and the star loses its meaning — several traditions welded into one refusal.

**Atmosfera e mood**

**Armadura de couro, estrela bordada, recusa do sertão** — (1001 Aesthetics, interpretação)

Cangaço: chapéu de meia-lua com estrelas bordadas à la Lampião, cartucheiras, caatinga seca e dignidade rebelde.

**Paleta de cores** couro, ocres de caatinga, prata de adornos

**Melhores usos:** cultura, cinema, ilustração

**MidJourney:** `[tema], Brazilian cangaço aesthetic, Lampião leather hat --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.4, a Brazilian cangaço portrait, leather armor and Lampião's star-embroidered half-moon hat, crossed cartridge belts in razor detail, dry caatinga thorn scrub under blazing sertão light, dust and sweat texture, Sebastião Salgado documentary dignity, fierce folk-outlaw presence, cinematic grading, 8k`

### **Coastal**

**№ 164 / 1001** — *Horizon every plane obeys*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Nothing earlier supplies this — the horizon itself is the founding law that every plane and opening must obey, generated by the site rather than by a prior style, so removing it collapses the whole system.

**Atmosfera e mood**

**O horizonte que todos os planos obedecem** — (1001 Aesthetics, interpretação)

Costeiro: linho claro, madeira lavada pelo sal, azuis de mar e a linha do horizonte organizando tudo.

**Paleta de cores** branco-areia, azul-mar, madeira clara

**Melhores usos:** interiores, lifestyle, verão

**MidJourney:** `[tema], coastal aesthetic, breezy seaside light --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a coastal scene, pale linen slipcovers and salt-washed driftwood against sea blues, gauzy curtains breathing in bright breezy light, every plane aligned to the horizon line through open doors, calm seaside serenity with Hamptons editorial polish, airy natural grading, 8k`

### **Constructivism**

**№ 173 / 1001** — *Wedge that strikes inert matter*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ESTHETICS ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No prior aesthetic can be named as its maker — the demand that form be construction for use, not composition for contemplation, is asserted at the root, and removing that premise collapses the whole rather than a branch.

**Atmosfera e mood**

**A cunha que golpeia a matéria inerte** — (1001 Aesthetics, interpretação)

Construtivismo russo: diagonais agressivas, fotomontagem, tipografia em blocos, vermelho e preto revolucionários (Rodchenko, El Lissitzky).

**Paleta de cores** vermelho, preto, creme de papel

**Melhores usos:** pôsteres, design gráfico, capas

**MidJourney:** `[tema], Russian constructivism poster, El Lissitzky style --v 6`

**LoRA (Civitai):** "Soviet-poster XL" (SDXL) — civitai.com/models/183892 (match aproximado)

**Prompt universal (Seedream):** `High-resolution scan of a Russian constructivist poster, aggressive diagonals and photomontage figures, bold block typography in revolutionary red black and cream, the wedge striking inert matter, Rodchenko and El Lissitzky energy, coarse 1920s lithograph texture with aged paper edges, 8k archival print quality`

### **Cyber Goth**

**№ 187 / 1001** — *Cyberlox, PVC, and the industrial pulse*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Cyberlox, PVC e o pulso industrial** — (1001 Aesthetics; código: match aproximado)

Cyber goth: dreads sintéticos fluorescentes, PVC preto, lentes de proteção, rave industrial sob UV.

**Paleta de cores** preto, verde/rosa UV fluorescente

**Melhores usos:** personagens, música, moda alternativa

**MidJourney:** `--sref 4052432800 --sw 1000` (Cyberpunk Gothic Dreams — match aproximado)

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a cyber goth portrait, fluorescent synthetic cyberlox dreads and black PVC outfit glowing under UV club light, goggles and gas-mask accents, neon green piping against deep black, industrial rave haze and laser slashes, high-contrast blacklight grading, hyperreal texture detail, 8k`

### **Danish Modern**

**№ 194 / 1001** — *Chair fitted to the body first*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**A cadeira ajustada primeiro ao corpo** — (1001 Aesthetics, interpretação)

Moderno dinamarquês: madeira teca curvada à mão, cadeiras Wegner/Jacobsen, função quente e artesanal.

**Paleta de cores** teca, couro conhaque, neutros claros

**Melhores usos:** mobiliário, interiores, produto

**MidJourney:** `[tema], Danish modern furniture design, teak and craftsmanship --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a Danish modern interior, hand-shaped teak chairs fitted to the body first, cognac leather and pale wool textiles in warm functional harmony, low afternoon sun grazing oiled wood grain, Wegner and Jacobsen lineage, quiet craftsmanship detail, refined Scandinavian grading, 8k`

### **Distressed**

**№ 234 / 1001** — *Iron Oxide as Cellulose Diary*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Óxido de ferro como diário da celulose** — (1001 Aesthetics; código: Lummi, match aproximado)

Desgaste: papel manchado e rasgado, ferrugem sobre fibra, textura envelhecida à força com história gravada.

**Paleta de cores** ferrugem, sépia, papel encardido

**Melhores usos:** texturas, capas, vintage

**MidJourney:** `--sref 152789083 --sw 1000` (Scratched Vintage — match aproximado)

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a distressed texture artwork, stained torn paper with rust bleeding into the fiber, scratched aged surfaces in raking side light, iron oxide writing its diary on cellulose, forced patina full of history, fine-art texture documentation, 8k`

### **Druidic**

**№ 246 / 1001** — *Liturgy of Oak, Stone, and Cyclical Light*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Liturgia de carvalho, pedra e luz cíclica** — (1001 Aesthetics, interpretação)

Druídico: círculo de pedras sob carvalho ancião, manto e foice de ouro, solstício como calendário sagrado.

**Paleta de cores** verde-musgo, pedra cinzenta, dourado de solstício

**Melhores usos:** fantasia, espiritual, narrativa

**MidJourney:** `[tema], druidic ritual, stone circle under ancient oak, solstice light --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a druidic scene, robed figure in a stone circle beneath an ancient oak, golden sickle and mistletoe catching solstice light aligned with the stones, mist threading the grass, liturgy of oak stone and cyclical light, cinematic pagan atmosphere, 8k`

### **Dutch Golden Age**

**№ 249 / 1001** — *Rendering of matter as the highest argument*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A renderização da matéria como argumento supremo** — (1001 Aesthetics, interpretação)

Século de Ouro holandês: luz de janela sobre interior silencioso, naturezas-mortas de veludo e vidro, chiaroscuro de Rembrandt e serenidade de Vermeer.

**Paleta de cores** âmbar profundo, azul-ultramar, sombras quentes

**Melhores usos:** retratos, still life, editorial

**MidJourney:** `[tema], Dutch Golden Age oil painting, Rembrandt chiaroscuro, Vermeer window light --v 6`

**LoRA (Civitai):** "Dutch Masters: Jan Vermeer Style" (Flux.1) — civitai.com/models/1023978; "Dutch Masters: Frans Hals Style" (Flux.1) — civitai.com/models/979166

**Prompt universal (Seedream):** `Museum-grade reproduction of a Dutch Golden Age oil painting, soft window light over a quiet interior, velvet glass and pewter rendered with supreme material fidelity, Rembrandt chiaroscuro and Vermeer stillness, deep amber and ultramarine, fine craquelure and varnish glow, 8k archival scan`

### **Earthy**

**№ 260 / 1001** — *Hand Finds Clay Before Language*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A mão encontra o barro antes da linguagem** — (1001 Aesthetics, interpretação)

Terroso: cerâmica crua e linho, texturas de terra e madeira, materialidade primal e quente.

**Paleta de cores** terracota, ocre, marrom de argila, creme

**Melhores usos:** branding orgânico, interiores, produto

**MidJourney:** `[tema], earthy aesthetic, raw ceramics and clay textures --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, an earthy still life, raw ceramics and natural linen in warm side light, terracotta ochre and clay brown textures at tactile clarity, warm primal materiality, the hand finding clay before language, Axel Vervoordt quietude, 8k`

### **Elemental Earth**

**№ 275 / 1001** — *Thumbprint Still Pressed in Clay*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A digital ainda impressa no barro** — (1001 Aesthetics; código: Lummi, match aproximado)

Terra: argila marcada pela mão, pedra e raíz, densidade mineral primordial.

**Paleta de cores** argila, basalto, ocres profundos

**Melhores usos:** espiritual, orgânico, texturas

**MidJourney:** `--sref 417488148 --sw 1000` (Elemental Abstract — match aproximado)

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 105mm macro lens, an elemental earth study, clay bearing a thumbprint still pressed into it, stone root and mineral density in raking side light, deep ochres and basalt grey at tactile clarity, primordial grounded matter, fine-art texture documentation, 8k`

### **Elemental Water**

**№ 277 / 1001** — *Meniscus Holding the Sky Upside Down*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O menisco segurando o céu de cabeça para baixo** — (1001 Aesthetics; código: Lummi, match aproximado)

Água: gota, reflexo e superfície, o céu invertido num espelho líquido, fluidez absoluta.

**Paleta de cores** azuis profundos, prata líquida, translúcidos

**Melhores usos:** elemental, macro, meditativo

**MidJourney:** `--sref 469710847 --sw 1000` (Blue Close Up — match aproximado)

**Prompt universal (Seedream):** `Shot on Canon R5 with 100mm macro lens, an elemental water study, a drop's meniscus holding the sky upside down, liquid mirror surface and absolute fluidity, deep blues and liquid silver, high-speed strobe freezing the crown splash, crystalline 8k clarity`

### **Entropic**

**№ 292 / 1001** — *Rebar Still Reads as Intention*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O vergalhão ainda se lê como intenção** — (1001 Aesthetics, interpretação)

Entrópico: estrutura em colapso lento, ordem se dissolvendo mas ainda legível, a forma perdendo para o tempo.

**Paleta de cores** ferrugem, concreto rachado, cinza de poeira

**Melhores usos:** conceitual, urbex, arte

**MidJourney:** `[tema], entropic decay, collapsing structure where rebar still reads as intention --v 6`

**LoRA (Civitai):** "Decaying Brutalism" (Flux) — civitai.com/models/2410113

**Prompt universal (Seedream):** `Shot on Phase One with 55mm lens, an entropic scene, slowly collapsing structure where exposed rebar still reads as intention, order dissolving but legible in flat overcast light, rust bleeding down cracked concrete, form losing to time, large-format documentary melancholy, 8k`

### **Favela**

**№ 324 / 1001** — *Laje poured over yesterday's roof*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Casas empilhadas e pintadas subindo o morro carioca** — (1001 Aesthetics, interpretação)

Favela: geometria orgânica de casas coloridas, vida densa e vibrante na encosta, beleza da improvisação coletiva.

**Paleta de cores** fachadas multicoloridas, tijolo, azul de céu tropical

**Melhores usos:** urbano, cultura brasileira, editorial

**MidJourney:** `[tema], stacked painted houses climbing the Rio hillside, vibrant favela geometry --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 32mm lens, a favela scene, stacked painted houses climbing the Rio hillside, organic geometry of multicolored facades and raw brick under tropical blue sky, laundry lines and satellite dishes, dense vibrant collective life, Vik Muniz color richness, 8k`

### **Flamenco**

**№ 334 / 1001** — *Ruffled Bata de Cola and the Stamped Heel*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A bata de cola de babados e o salto batido** — (1001 Aesthetics, interpretação)

Flamenco: vestido em espiral e mãos ao alto, duende andaluz, paixão percutida no tablado.

**Paleta de cores** vermelho profundo, preto, bolinhas brancas

**Melhores usos:** dança, cultura, editorial dramático

**MidJourney:** `[tema], flamenco dancer, ruffled bata de cola mid-spin, stamped heel --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 with 85mm lens at 1/2000s, a flamenco scene, ruffled bata de cola dress in mid-spin and the stamped heel frozen on the tablao, deep red and black with white polka dots, Andalusian duende and Antonio Gades percussive passion, motion-frozen drama, 8k`

### **Flapper**

**№ 335 / 1001** — *Bobbed Hair and Fringe That Swung to the Charleston*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Cabelo curto e franjas que dançaram o Charleston** — (1001 Aesthetics, interpretação)

Melindrosa: franjas e pérolas em movimento, jazz e champanhe de 1925, liberdade recém-conquistada dançando.

**Paleta de cores** preto de vestido, dourado de festa, pérola

**Melhores usos:** histórico, moda, festa Gatsby

**MidJourney:** `[tema], 1920s flapper, bobbed hair and fringe dress swinging to the Charleston --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with 50mm lens, a flapper scene 1925, bobbed hair and fringe dress swinging mid-Charleston under speakeasy chandelier light, pearls in motion with jazz-age gold and champagne, Gatsby-era freedom dancing, sepia-warm period grading, 8k scan`

### **Folk**

**№ 341 / 1001** — *Hand-Embroidered Motifs Passed Down Without a Signature*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Motivos bordados à mão, passados adiante sem assinatura** — (1001 Aesthetics, interpretação)

Folclore: bordado tradicional e motivo repetido por gerações, arte anônima e coletiva, beleza sem autor.

**Paleta de cores** vermelho e preto de bordado, linho cru

**Melhores usos:** artesanato, cultura, estampas

**MidJourney:** `[tema], traditional folk embroidery motifs, generations-old anonymous patterns --v 6`

**Prompt universal (Seedream):** `Shot on Leica M11 with 90mm macro lens, a folk art image, hand-embroidered traditional motifs passed down without a signature, embroidery red and black on raw linen in warm side light, every stitch resolved, anonymous collective beauty across generations, artisan detail, 8k`

### **Gemstone**

**№ 367 / 1001** — *Facet That Turns Geological Time Into Fire*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**A faceta que transforma tempo geológico em fogo** — (1001 Aesthetics, interpretação)

Gemas: macro de pedra lapidada, luz refratada em fogo interno, milhões de anos condensados em brilho.

**Paleta de cores** jewel tones puros: esmeralda, rubi, safira, âmbar

**Melhores usos:** joalheria, luxo, macro

**MidJourney:** `[tema], macro gemstone photography, faceted crystal refracting inner fire --v 6`

**Prompt universal (Seedream):** `Shot on Phase One XF with 120mm macro lens, a gemstone macro, faceted crystal turning geological time into fire, refracted light in pure jewel tones of emerald ruby and sapphire, black velvet backdrop, luxurious mineral brilliance, 8k`

### **Glacial**

**№ 380 / 1001** — *Compressed Blue Ice Above the Calving Line*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Gelo azul comprimido acima da linha de desprendimento** — (1001 Aesthetics, interpretação)

Glacial: parede de geleira em azul denso, silêncio mineral congelado, tempo comprimido em gelo.

**Paleta de cores** azul glacial profundo, branco de neve, cinza de água

**Melhores usos:** natureza, editorial, fundos dramáticos

**MidJourney:** `[tema], glacial wall of compressed blue ice above the calving line, frozen mineral silence --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad XPan with 45mm panoramic lens, a glacial image, compressed deep-blue ice wall above the calving line, snow white and meltwater grey under polar overcast, time compressed into frozen mineral silence, 8k`

### **GOBLINCORE**

**№ 385 / 1001** — *Fly Agaric Cluster at Knee Height*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**O aglomerado de fly agaric na altura do joelho** — (1001 Aesthetics, interpretação)

Goblincore: chão de floresta e tesouros úmidos, cogumelos, musgo e coisas brilhantes coletadas, beleza do que a floresta esconde embaixo.

**Paleta de cores** verde musgo, marrom de lama, vermelho de cogumelo, bronze

**Melhores usos:** natureza, ilustração, editorial alternativo

**MidJourney:** `[tema], goblincore, fly agaric mushrooms and moss at ground level, collected shiny forest treasures --v 6`

**Prompt universal (Seedream):** `Shot on Olympus OM-1 with 50mm macro lens, a goblincore scene, fly agaric cluster at knee height on the damp forest floor, moss and mud with collected shiny trinkets, mushroom red and moss green in soft forest light, the beauty the forest hides down low, 8k`

### **Gorpcore**

**№ 388 / 1001** — *Gore-Tex Shells Crossing Soho in Trail Shoes*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Gore-Tex atravessando o Soho de tênis de trilha** — (1001 Aesthetics, interpretação)

Gorpcore: equipamento de montanha usado na cidade, jaqueta técnica e mosquetão decorativo, funcionalidade como moda urbana.

**Paleta de cores** laranja de resgate, verde técnico, preto de shell

**Melhores usos:** moda urbana, streetwear, editorial

**MidJourney:** `[tema], gorpcore, Gore-Tex shells and trail shoes crossing the city, technical gear as fashion --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-Pro3 with 35mm lens, a gorpcore image, Gore-Tex shells crossing Soho in trail shoes, rescue orange and technical green with carabiners as ornament, overcast street-style light, mountain functionality worn as urban fashion, 8k`

### **Greek Aegean**

**№ 400 / 1001** — *Cycladic Marble Figure at Mediterranean Noon*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Atmosfera e mood**

**A figura cicládica de mármore ao meio-dia mediterrâneo** — (1001 Aesthetics, interpretação)

Egeu grego: mármore branco abstrato contra mar azul profundo, formas cicládicas milenares sob sol vertical.

**Paleta de cores** branco de mármore, azul Egeu, cal de ilha

**Melhores usos:** arte, viagem, editorial minimalista

**MidJourney:** `[tema], Cycladic marble figure at Mediterranean noon, Aegean white and deep blue --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya RZ67 with 110mm lens, an Aegean Greek image, an abstract Cycladic marble figure under vertical Mediterranean noon light, whitewashed island walls against deep Aegean blue, millennial simplicity in stone, 8k`

### **Grounded**

**№ 407 / 1001** — *Rammed-Earth Wall That Still Shows Each Lift*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A parede de taipa que ainda mostra cada camada** — (1001 Aesthetics, interpretação)

Aterrado: terra comprimida em estratos visíveis, materiais que contam sua construção, arquitetura com os pés no chão.

**Paleta de cores** estratos de terra, ocre, areia, ferrugem

**Melhores usos:** arquitetura, wellness, branding orgânico

**MidJourney:** `[tema], rammed earth architecture, visible strata layers in the wall, grounded earthy materiality --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 907X with 65mm lens, a grounded image, a rammed-earth wall that still shows each compressed lift, ochre and rust strata in warm low sun, architecture that tells its own construction, 8k`

### **Gutai**

**№ 409 / 1001** — *Shiraga's Feet Dragging Paint Across the Canvas*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Os pés de Shiraga arrastando tinta pela tela** — (1001 Aesthetics; código: Lummi, match aproximado)

Gutai: ação como pintura, corpo atravessando o material, vanguarda japonesa de 1954 onde o gesto é a obra.

**Paleta de cores** vermelho de tinta espessa, branco de tela, preto de gesto

**Melhores usos:** arte contemporânea, editorial, performance

**MidJourney:** `--sref 2421610009 --sw 1000` (Movement — match aproximado)

**Prompt universal (Seedream):** `Grainy 1950s documentary photograph, a Gutai action painting image, Kazuo Shiraga dragging thick red paint across raw canvas with his feet, the body crossing the material, 1954 Japanese avant-garde where the gesture is the work, 8k`

### **Haptic**

**№ 415 / 1001** — *Oak Grain Raked Until the Eye Feels It*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O veio do carvalho escovado até o olho sentir** — (1001 Aesthetics, interpretação)

Háptico: textura em close extremo, materiais que pedem toque, fotografia onde a superfície é o assunto.

**Paleta de cores** tons de material — madeira, lã, pedra, cerâmica

**Melhores usos:** produto, branding sensorial, editorial

**MidJourney:** `[tema], haptic texture photography, raked oak grain in extreme close-up, tactile surfaces the eye can feel --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 110mm macro lens, a haptic image, oak grain raked until the eye feels it, extreme close-up of wool, stone and ceramic surfaces, raking light that turns texture into the subject, 8k`

### **Homebodycore**

**№ 440 / 1001** — *Kettle Keeps the Evening Indoors*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → DOMAIN ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A chaleira mantém a noite dentro de casa** — (1001 Aesthetics, interpretação)

Homebody: sofá e manta, chá fumegando e série pausada, o lado de dentro escolhido de propósito.

**Paleta de cores** creme de manta, luz de abajur, madeira quente, chá

**Melhores usos:** lifestyle, wellness, branding acolhedor

**MidJourney:** `[tema], homebody cozy evening, steaming kettle and blanket on the sofa, warm lamp light indoors --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Gold 200 with 35mm lens, a homebodycore image, a kettle keeping the evening indoors, steaming tea and a blanket under lamp light, cream and warm wood tones, the inside chosen on purpose, 8k`

### **Icepunk**

**№ 452 / 1001** — *Cryogenic Towers Glow Beneath the Methane Aurora*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Torres criogênicas brilham sob a aurora de metano** — (1001 Aesthetics, interpretação)

Icepunk: sci-fi glacial, cidades de gelo e tecnologia criogênica, civilização construída no frio absoluto.

**Paleta de cores** azul glacial, ciano de aurora, branco de gelo, verde de metano

**Melhores usos:** sci-fi, concept art, games

**MidJourney:** `[tema], icepunk sci-fi, cryogenic towers glowing beneath a methane aurora, glacial ice city --v 6`

**Prompt universal (Seedream):** `Ultra-detailed sci-fi concept art, an icepunk image, cryogenic towers glowing beneath a green methane aurora, glacial blue ice city under absolute cold, Syd Mead futurist rendering, sci-fi civilization built into the frost, 8k`

### **Imperial Roman**

**№ 461 / 1001** — *Trajan's Forum Turns Conquest Into Civic Stone*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O Fórum de Trajano transforma conquista em pedra cívica** — (1001 Aesthetics, interpretação)

Romano imperial: colunatas e basílicas em escala de império, mármore e travertino organizando o poder em praça.

**Paleta de cores** travertino, mármore branco, vermelho pompeiano, bronze

**Melhores usos:** arquitetura, histórico, institucional

**MidJourney:** `[tema], Imperial Roman architecture, Trajan's Forum colonnades turning conquest into civic stone --v 6`

**Prompt universal (Seedream):** `Shot on Linhof 4x5 with 90mm lens, an Imperial Roman image, a forum turning conquest into civic stone, travertine colonnades and marble basilicas at empire scale, Pompeian red and bronze accents, 8k`

### **INDUSTRIAL**

**№ 469 / 1001** — *Riveted Beam Leaves Its Load Exposed*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**A viga rebitada deixa sua carga exposta** — (1001 Aesthetics, interpretação)

Industrial: estrutura sem disfarce, ferro, rebite e tijolo, a função exibida como ornamento.

**Paleta de cores** ferro oxidado, tijolo, cinza de concreto, preto de fuligem

**Melhores usos:** arquitetura, interiores, editorial urbano

**MidJourney:** `[tema], industrial aesthetic, riveted steel beam leaving its load exposed, iron brick and soot --v 6`

**Prompt universal (Seedream):** `Shot on 4x5 large format with 210mm lens, an industrial image, a riveted steel beam leaving its load exposed, oxidized iron and brick under soot grey light, Bernd and Hilla Becher typology rigor, function displayed as ornament, 8k`

### **Lagenlook**

**№ 511 / 1001** — *Linen layers, asymmetry, volume*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Atmosfera e mood**

**Camadas de linho, assimetria, volume** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lagenlook: a silhueta composta camada sobre camada, linho lavado, alfaiataria desconstruída e volume escultórico.

**Paleta de cores** cinza de pedra, linho cru, branco lavado

**Melhores usos:** moda, editorial, lookbook

**MidJourney:** `[tema], lagenlook aesthetic, layered linen and washed cotton, asymmetric volume, diffused studio light --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL3 with 90mm lens, a lagenlook image, layered linen and washed cotton building asymmetric sculptural volume on a walking figure, stone grey and undyed flax under diffused overcast studio light, Yohji Yamamoto shadow-play in the drape, hems stacked in deliberate imperfection, the silhouette composed layer over patient layer, 8k`

### **Luddism**

**№ 535 / 1001** — *Loom sabotage in Nottinghamshire (1811)*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Sabotagem de teares em Nottinghamshire (1811)** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ludismo: a máquina questionada em sua própria bancada, sombras hachuradas e ferro de oficina.

**Paleta de cores** sombras hachuradas, ferro, luz de lampião

**Melhores usos:** editorial histórico, ilustração, arte conceitual

**MidJourney:** `[tema], Luddism aesthetic, loom frames broken in 1811 Nottinghamshire workshop, 19th-century engraving style --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a 19th-century engraving, a Luddism image, stocking-frame looms broken in a Nottinghamshire workshop by swinging lantern light, 1811 crosshatched shadows over iron hammers and splintered wood, faces half-lit with desperate resolve, Gustave Dore density in the ink work, the machine questioned at its own bench, 8k`

### **Lumineer**

**№ 538 / 1001** — *Bioluminescent jellyfish wiring*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Fiação bioluminescente de água-viva** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lumineer: o abismo iluminado por dentro, filamentos azul-elétricos e sinos violeta pulsantes.

**Paleta de cores** azul elétrico, violeta, preto abissal

**Melhores usos:** arte, editorial, motion

**MidJourney:** `[tema], lumineer aesthetic, bioluminescent jellyfish wiring against abyssal black, electric blue filaments --v 6`

**Prompt universal (Seedream):** `Blackwater underwater photograph shot on Nikon D500 with 60mm macro lens, a lumineer image, bioluminescent jellyfish wiring glowing against absolute abyssal black, electric blue filaments and pulsing violet bells trailing light like slow fireworks, strobe-lit transparency revealing clockwork organs, the deep ocean lit entirely from inside itself, 8k`

### **Luxury**

**№ 542 / 1001** — *Hermès leather and bespoke tailoring*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Couro Hermès e alfaiataria sob medida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Luxo: qualidade legível à distância de um braço, pesponto conhaque e lã carvão.

**Paleta de cores** conhaque, carvão, dourado discreto

**Melhores usos:** produto premium, moda, branding

**MidJourney:** `[tema], luxury aesthetic, Hermes leather and bespoke tailoring, sculpted softbox light, cognac saddle stitching --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 II with 110mm lens, a luxury image, Hermes saddle-stitched leather and bespoke charcoal wool under sculpted softbox light, cognac grain and hand-polished brass hardware on honed black marble, Guido Mocafico still-life precision, the quiet grammar of expensive surfaces, quality legible at arm's length without a single logo, 8k`

### **Marshcore**

**№ 552 / 1001** — *Boardwalk Rot Under Dragonfly Wings*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → DENSITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Madeira podre de píer sob asas de libélula** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Marshcore: a decomposição como ecologia silenciosa, marrom de turfa e verde de junco na névoa.

**Paleta de cores** marrom de turfa, verde de junco, névoa de alvorada

**Melhores usos:** natureza, editorial, atmosfera

**MidJourney:** `[tema], marshcore aesthetic, boardwalk rot under dragonfly wings, peat and reed tones, dawn mist --v 6`

**Prompt universal (Seedream):** `Shot on Panasonic Lumix S5 with 105mm macro lens, a marshcore image, boardwalk rot blooming softly under iridescent dragonfly wings, peat brown and reed green dissolved in low dawn mist, spider silk strung with fog beads between the cattails, decay working patiently as quiet ecology, the wetland keeping its own unhurried time, 8k`

### **Mecha**

**№ 556 / 1001** — *Machines Built as Monumental Bodies*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Máquinas construídas como corpos monumentais** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mecha: engenharia com postura de herói, painel e hidráulica em escala de hangar.

**Paleta de cores** aço, sinalização industrial, luz de hangar

**Melhores usos:** concept art, games, editorial sci-fi

**MidJourney:** `[tema], mecha aesthetic, giant robot standing in a hangar, panel lines and hydraulics, monumental body --v 6`

**Prompt universal (Seedream):** `Ultra-detailed mecha concept art, a mecha image, a giant robot standing at attention in cathedral-scale hangar floodlight, panel lines hydraulic pistons and warning decals articulated at monumental body scale, Kunio Okawara engineering logic with Gundam silhouette gravity, steel grey broken by industrial signal orange, the machine granted a hero's posture, 8k`

### **Metamaterial Innovation**

**№ 565 / 1001** — *Matter Engineered to Disobey Nature*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Matéria projetada para desobedecer à natureza** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Metamaterial: estruturas menores que a luz dobrando o próprio comportamento da física.

**Paleta de cores** iridescência estrutural, prata de laboratório, azul óptico

**Melhores usos:** ciência, tech, editorial futurista

**MidJourney:** `[tema], metamaterial innovation aesthetic, engineered lattice bending light around itself, structural iridescence --v 6`

**Prompt universal (Seedream):** `Ultra-detailed scientific render, a metamaterial innovation image, an engineered nanoscale lattice bending light impossibly around itself, structural iridescence rippling across laboratory silver like a synthetic opal, optical blue caustics escaping where physics is being renegotiated, electron-microscope precision staged at cinematic scale, matter designed politely to disobey nature, 8k`

### **Neo Surrealism**

**№ 602 / 1001** — *Dreams Rendered at Screen Resolution*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↓ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Sonhos renderizados em resolução de tela** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neosurrealismo: lógica de sonho com acabamento digital perfeito, figuras fluidas em espaços impossíveis.

**Paleta de cores** gradientes oníricos, pele porcelana, azul profundo

**Melhores usos:** arte digital, capas, editorial

**MidJourney:** `[tema], neo surrealism aesthetic, dream logic at screen resolution, fluid figures impossible space --v 6`

**Prompt universal (Seedream):** `Ultra-detailed neo-surrealist digital painting, dream logic rendered at screen resolution, fluid figures dissolving through an impossible interior, porcelain skin against deep dusk gradients, James Jean flowing line with airbrushed calm, unsettling beauty in perfect focus, 8k`

### **Neo-Brutalism**

**№ 603 / 1001** — *Concrete Honesty in a Browser Window*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Honestidade de concreto numa janela de navegador** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neobrutalismo digital: bordas duras, sombras chapadas e HTML sem verniz como declaração de design.

**Paleta de cores** branco cru, preto de borda, um neon único

**Melhores usos:** web design, branding, portfólio

**MidJourney:** `[tema], neo-brutalism web design aesthetic, raw borders hard flat shadows, unstyled honesty --v 6`

**Prompt universal (Seedream):** `Ultra-crisp neubrutalist interface design, raw black borders and hard offset shadows on unapologetic white, default-font honesty with one electric accent color, concrete web architecture in a browser window, flat vector precision, 8k`

### **Neo-Industrial**

**№ 607 / 1001** — *Machine Logic After the Factory Closes*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**Lógica de máquina depois que a fábrica fecha** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neoindustrial: galpão desativado reocupado, treliças e polias como decoração consciente.

**Paleta de cores** aço escovado, tijolo, preto fosco

**Melhores usos:** interiores, estúdios, branding

**MidJourney:** `[tema], neo-industrial aesthetic, decommissioned factory reoccupied, trusses and pulleys as design --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R III with 24mm lens, a neo-industrial loft inside a decommissioned factory, steel trusses and pulley wheels kept as conscious decoration, brushed metal and old brick under skylight shafts, machine logic living on after the shift ended, 8k`

### **Neue Sachlichkeit**

**№ 614 / 1001** — *Cold Eye on the Weimar Republic*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → EXPRESSION ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Atmosfera e mood**

**Olho frio sobre a República de Weimar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nova Objetividade: retratos impiedosos de 1925, satíricos e cirúrgicos, sem uma pincelada de piedade.

**Paleta de cores** verdes doentios, cinza de cabaré, carmim duro

**Melhores usos:** retratos, arte, editorial crítico

**MidJourney:** `[tema], Neue Sachlichkeit aesthetic, merciless Weimar portrait, cold satirical precision --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Neue Sachlichkeit painting, a merciless 1925 Weimar portrait rendered with surgical cold precision, sickly greens and hard carmine under cabaret light, Otto Dix scrutiny with George Grosz bite, every wrinkle testifying, 8k archival scan`

### **New Figuration**

**№ 619 / 1001** — *Body Walks Back Into the Gallery*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**O corpo volta caminhando para a galeria** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nova figuração: a figura humana retornando depois da abstração, pesada, caricata e inevitável.

**Paleta de cores** rosa de carne, cinza fumaça, vermelho gasto

**Melhores usos:** arte, editorial, capas

**MidJourney:** `[tema], new figuration aesthetic, the body walks back into the gallery after abstraction --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a new figuration canvas, the human body walking back into the gallery after abstraction, heavy cartoon-boned figures in flesh pink and smoke gray, Philip Guston frankness with existential weight, thick honest paint, 8k documentation`

### **Nihilism**

**№ 626 / 1001** — *Nothing Matters, Carefully*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EMANATIO ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O nada arrumado com cuidado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Niilismo: sala vazia, parede sem quadro, a ausência de sentido composta com precisão estética.

**Paleta de cores** cinza neutro, branco sem promessa, preto

**Melhores usos:** conceito, arte, editorial

**MidJourney:** `[tema], nihilism aesthetic, empty room careful nothing, absence composed with precision --v 6`

**Prompt universal (Seedream):** `Shot on Ilford Pan F 50 with 50mm lens, a nihilist interior, one empty chair in a bare room with an unhung nail on the wall, careful nothing arranged with aesthetic precision, flat gray tones refusing every promise, immaculate grain and silence, 8k scan`

### **Nouveau Réalisme**

**№ 636 / 1001** — *Street Walks Into the Gallery*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**A rua colada direto na tela** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nouveau réalisme: cartazes rasgados em camadas, o real apropriado sem pintura, décollage como arqueologia urbana.

**Paleta de cores** camadas de cartaz, vermelho de circo, papel envelhecido

**Melhores usos:** arte, editorial urbano, colagem

**MidJourney:** `[tema], nouveau réalisme aesthetic, torn poster décollage layers, the street glued onto canvas --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a nouveau réalisme décollage, torn street posters layered into accidental composition, circus red and aged paper strata ripped by anonymous hands, Jacques Villeglé urban archaeology framed as-is, every tear edge in focus, 8k documentation`

### **Oxidizedcore**

**№ 660 / 1001** — *Rust Reading Like Industrial Archaeology*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Ferrugem como arqueologia industrial** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Oxidado: pátinas de cobre esverdeado e ferro sangrando óxido — o tempo escrevendo em metal.

**Paleta de cores** ferrugem, verdete, aço queimado

**Melhores usos:** texturas, arte, editorial

**MidJourney:** `[tema], oxidizedcore aesthetic, rust and verdigris patina, time writing on metal --v 6`

**Prompt universal (Seedream):** `Shot on Panasonic S1R with 90mm macro lens, an oxidizedcore study, copper verdigris blooming beside iron bleeding rust down burnt steel, patina layers read as industrial archaeology, time writing its signature on metal in raking light, extreme texture detail, 8k`

### **Plastic**

**№ 691 / 1001** — *Synthetic Surface Claims the Sublime*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O sublime sintético em alto brilho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Plástico: superfícies injetadas, shrink-wrap e cores que nunca existiram na natureza.

**Paleta de cores** rosa injetado, amarelo de brinquedo, transparente

**Melhores usos:** produto, arte, editorial

**MidJourney:** `[tema], plastic aesthetic, injection-molded gloss shrink-wrap, colors nature never made --v 6`

**Prompt universal (Seedream):** `Shot on Sinar P3 with 150mm lens, a plastic still life, injection-molded objects and shrink-wrapped forms in high-gloss studio light, toy yellow and synthetic pink that nature never manufactured, seam lines and specular highlights celebrated as the synthetic sublime, 8k`

### **Post-Minimalism**

**№ 706 / 1001** — *Less Learns Texture and Weight*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Minimalism's fabricated-metal grid and phenomenological viewer engagement remained intact inside Post-Minimalism, redirected from geometric precision toward process, decay, and gravity — the vocabulary preserved, its governing logic of fixed form dissolved.

**Atmosfera e mood**

**O menos aprendendo peso e corpo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pós-minimalismo: látex pendurado, corda e feltro — a geometria pura amolecida pela gravidade e pelo material.

**Paleta de cores** látex âmbar, feltro cinza, corda crua

**Melhores usos:** arte, instalação, editorial

**MidJourney:** `[tema], post-minimalism aesthetic, hanging latex rope and felt, geometry softened by gravity --v 6`

**Prompt universal (Seedream):** `Museum documentation of a post-minimalist installation, amber latex sheets and knotted rope hanging where pure geometry surrendered to gravity, Eva Hesse material tenderness in felt gray and raw fiber, less learning weight and body, white-cube light on sagging forms, 8k`

### **Post-Organic**

**№ 708 / 1001** — *Biology Opens Its Source Code*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Eduardo Kac's GFP Bunny (2000) fused BioArt's living-tissue medium, Posthumanism's postnatural argument, and cybernetics' organism-as-circuit into a single work that no single ancestor could have generated, dissolving all three source grammars into one irreducible new system.

**Atmosfera e mood**

**Biologia de código aberto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pós-orgânico: carne editável, treliças celulares impressas e a fronteira corpo-máquina dissolvida em render.

**Paleta de cores** rosa de tecido, branco de laboratório, azul de bioluz

**Melhores usos:** conceito, sci-fi, arte digital

**MidJourney:** `[tema], post-organic aesthetic, editable flesh printed cell lattice, biology gone open source --v 6`

**Prompt universal (Seedream):** `Ultra-detailed 3D render, a post-organic form where biology opens its source code, editable flesh growing through printed cell lattices, tissue pink and lab white lit by bioluminescent blue, the body-machine boundary dissolved in subsurface scattering, scientific-grade render, 8k`

### **Pre-Historic**

**№ 715 / 1001** — *Survival Leaves the First Design Brief*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Nota genealógica original (EN):** The grammar of image-as-collective-memory — red ochre on bone, the animal in profile, the hand outlined as presence — was carried from Lascaux through Çatalhöyük and into every later visual tradition, the founding transmission that no subsequent aesthetic could undo because all of them descended from it.

**Atmosfera e mood**

**O primeiro briefing de design da humanidade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pré-histórico: bisões de ocre à luz de tocha, mãos em negativo e a arte antes de qualquer palavra escrita.

**Paleta de cores** ocre, carvão, pedra de caverna

**Melhores usos:** histórico, arte, editorial

**MidJourney:** `[tema], prehistoric cave art aesthetic, ochre bison by torchlight, humanity's first design brief --v 6`

**Prompt universal (Seedream):** `High-resolution documentation photograph of a Lascaux-style cave wall by torchlight, ochre bison and charcoal horses flowing across living rock, stenciled hands signing humanity's first design brief, flame-warm light flickering over mineral texture, archaeological reverence, 8k`

### **Raw**

**№ 743 / 1001** — *Finish Stops Before Polishing Begins*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EDITING ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No prior aesthetic exists to inherit; the premise that any finishing step betrays the object's truth ruptures every tradition of artistic refinement, removing the one move that connected skilled making to recognized beauty.

**Atmosfera e mood**

**A imagem sem maquiagem nenhuma** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Cru: luz disponível, textura de pele real e o momento entregue sem tratamento ou desculpas.

**Paleta de cores** tons naturais sem correção, cinza honesto

**Melhores usos:** retratos, documental, editorial

**MidJourney:** `[tema], raw aesthetic, available light real skin texture, the moment without makeup --v 6`

**Prompt universal (Seedream):** `Shot on Ricoh GR IIIx with 40mm equivalent lens, a raw candid portrait in available light, real skin texture and uncorrected natural tones, the moment handed over without treatment or apology, honest gray shadows and street-level intimacy, unpolished truthful detail, 8k`

### **Realism**

**№ 745 / 1001** — *Art Finally Faces the Working Class*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No prior aesthetic exists to inherit; the premise that ordinary life without flattery is worthy of art ruptures the inherited hierarchy of subjects, lifting the laborer to the scale once kept for saints.

**Atmosfera e mood**

**O mundo como ele é, sem anjos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Realismo: quebradores de pedra e mãos calejadas — a pintura recusando mitologia para encarar o trabalho.

**Paleta de cores** terra de estrada, cinza de pedra, pele de sol

**Melhores usos:** arte, histórico, editorial

**MidJourney:** `[tema], realism aesthetic, stone breakers calloused hands, the world as it is no angels --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a realist painting, stone breakers bent over roadside labor with calloused hands and patched clothes, Gustave Courbet refusal of mythology in road-dirt browns and stone gray, the world painted as it is with no angels invited, 8k archival scan`

### **Rebirth**

**№ 746 / 1001** — *Destruction Leaves Material for the Next Form*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Romanticism's creative destruction and alchemy's nigredo-to-gold are recombined over a distributed phoenix substrate, producing the only grammar in which ruin is structurally required before renewal and the ash itself becomes the seedbed of the next form.

**Atmosfera e mood**

**O fim usado como adubo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Renascimento pessoal: broto verde na cinza, fênix e a primeira luz depois do incêndio.

**Paleta de cores** cinza de brasa, verde de broto, dourado de aurora

**Melhores usos:** conceito, capas, editorial

**MidJourney:** `[tema], rebirth aesthetic, green shoot through ash first light after the fire, ending used as soil --v 6`

**Prompt universal (Seedream):** `Ultra-detailed conceptual photograph, a rebirth image, one luminous green shoot breaking through a field of still-warm ash at first golden light, ember gray yielding to dawn gold, the ending literally used as soil, macro tenderness inside epic scale, 8k`

### **Rivethead**

**№ 761 / 1001** — *Steel-Toe Boots Under Factory Noise*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The mid-1980s industrial music scene arrives intact as the single ancestral grammar, and Rivethead re-instruments it by routing the sound through the body — the genre’s machine-noise, factory-floor aggression, and dehumanization vocabulary is worn as riveted leather rather than heard through speakers, so the inherited sonic argument becomes a visual one bolted onto skin.

**Atmosfera e mood**

**Bota de bico de aço sob ruído de fábrica** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rivethead: couro, correntes e industrial dançante — a estética das pistas EBM entre engrenagens e vapor.

**Paleta de cores** preto de couro, cinza de máquina, laranja de faísca

**Melhores usos:** música industrial, moda alternativa, editorial

**MidJourney:** `[tema], rivethead aesthetic, steel-toe boots industrial club, EBM under factory noise --v 6`

**Prompt universal (Seedream):** `Shot on Nikon FM2 with 35mm lens, a rivethead portrait in an industrial club, steel-toe boots and buckled leather under strobing machine light, chains and goggles against riveted iron walls, spark orange cutting machine gray, EBM danced beneath factory noise, gritty grain, 8k`

### **Romanesque**

**№ 768 / 1001** — *Stone Prayers*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No single aesthetic exists to inherit whole; the round arch is borrowed Roman vocabulary, but eleventh-century masons rebuilt it around a substitution Rome never made — cut stone in place of poured concrete — and that swap forced the wall itself to become the vault's only defense, producing a self-sufficient grammar that reads as parent to Gothic rather than as child of Rome.

**Atmosfera e mood**

**Orações feitas de pedra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Românico: arcos redondos, paredes de fortaleza e a fé medieval construída para durar mil anos.

**Paleta de cores** pedra clara, sombra de cripta, dourado de vela

**Melhores usos:** arquitetura, histórico, editorial

**MidJourney:** `[tema], romanesque aesthetic, round arches fortress walls barrel vault, stone prayers --v 6`

**Prompt universal (Seedream):** `Shot on a 4x5 field camera with 75mm lens, a Romanesque nave, round arches marching down a barrel vault on fortress-thick walls, candle gold pooling in crypt shadow over pale stone, medieval faith engineered to last a thousand years, monumental quiet detail, 8k`

### **Rough**

**№ 773 / 1001** — *Scars kept on display*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → NARRATIVE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Arts and Crafts' valorization of visible handcraft and honest construction arrives as the one constitutive parent, and Rough re-instruments it by routing truth-to-material through a wabi-sabi-inflected patience — the crack, the kintsugi seam, the unsanded edge — so a nineteenth-century argument against machine concealment becomes a twenty-first-century argument against digital smoothing.

**Atmosfera e mood**

**Cicatrizes mantidas à mostra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Bruto: concreto lascado, madeira serrada sem lixa e superfícies que recusam o acabamento como questão de honestidade.

**Paleta de cores** concreto lascado, ferro exposto, madeira crua

**Melhores usos:** texturas, industrial, editorial

**MidJourney:** `[tema], rough aesthetic, chipped concrete unsanded timber exposed scars, honesty over finish --v 6`

**Prompt universal (Seedream):** `Shot on Pentax K1000 with 28mm lens, a rough material study, chipped concrete and unsanded sawn timber with exposed rebar scars kept deliberately on display, raw iron staining crude wood in hard side light, finish refused as a matter of honesty, brutal tactile grain, 8k`

### **Rugged**

**№ 775 / 1001** — *Toughness that reads as beauty*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Romantic landscape tradition's reversal of beauty and grandeur — finding worth in the rough and irregular — arrives intact, and Rugged re-instruments it by dragging that gaze down off the painted vista and onto the worn object, swapping contemplation for use, so a way of looking at mountains becomes a way of valuing a creased jacket.

**Atmosfera e mood**

**A dureza lida como beleza** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rude: costa batida por vento, rosto marcado por sal e o desgaste usado como prova de vida vivida.

**Paleta de cores** granito, verde de tojo, cinza de vendaval

**Melhores usos:** retratos, paisagens, editorial

**MidJourney:** `[tema], rugged aesthetic, windbeaten coast salt-lined face, toughness reading as beauty --v 6`

**Prompt universal (Seedream):** `Shot on Fuji GW690 with 90mm lens, a rugged portrait on a wind-beaten granite coast, a salt-lined weathered face steady against gale gray skies, oilskin and gorse green whipped sideways, wear presented as proof of life fully lived, toughness reading plainly as beauty, 8k`

### **Rustic**

**№ 778 / 1001** — *Sophisticated Simplicity*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Nineteenth-century folk revaluation of agrarian and vernacular material culture arrives as the single premise, and Rustic re-instruments it by lifting the humble and worn into a deliberate design language — no new grammar and no second lineage enter, only rural simplicity reframed as sophistication — so a parent's plain material becomes, one turn later, a taste to display.

**Atmosfera e mood**

**Simplicidade sofisticada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rústico: mesa de fazenda, linho amassado e pão ainda quente — o campo editado com olho de decorador.

**Paleta de cores** madeira de celeiro, linho cru, verde de oliveira

**Melhores usos:** interiores, gastronomia, editorial

**MidJourney:** `[tema], rustic aesthetic, farmhouse table crumpled linen warm bread, sophisticated simplicity --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya RB67 with 127mm lens, a rustic still life, warm bread and olive branches on a scarred farmhouse table with crumpled raw linen, barn wood tones in low window light, the countryside edited by a decorator's eye without losing its calluses, rich tactile warmth, 8k`

### **Sculptural**

**№ 790 / 1001** — *Form's Eloquence*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Sculpture predates every movement that might claim to author it — strip away Classical idealization, Baroque theatricality, and Minimalist literalism and a prior root survives intact, matter displaced into three dimensions until form itself carries meaning — so Rodin, Brancusi, and Serra all inherit this founding act rather than reverse it, and the discipline answers to no ancestor above it.

**Atmosfera e mood**

**A eloquência da forma pura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Escultural: volume, sombra e curva falando sem palavras — o objeto reduzido ao seu gesto essencial.

**Paleta de cores** branco de gesso, sombra modelada, bronze

**Melhores usos:** arte, produto, editorial

**MidJourney:** `[tema], sculptural aesthetic, pure volume and carved shadow, form speaking without words --v 6`

**Prompt universal (Seedream):** `Shot on Sinar 8x10 with 240mm lens, a sculptural study, one sweeping abstract form turning from plaster white into carved shadow under a single raked light, bronze accent grounding the curve, the object reduced to its essential gesture, form speaking with total eloquence, 8k`

### **Sensual**

**№ 797 / 1001** — *Slow textures that pull the senses closer*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Aestheticism's doctrine that sensory pleasure needs no moral or narrative justification arrives as the single parent, and Sensual re-instruments that inheritance by relocating pleasure from the made object to the body that meets it — silk read as weight against skin rather than as pattern — so a philosophy of beautiful objects becomes, one turn later, a practice of touchable surfaces built to be lingered against.

**Atmosfera e mood**

**Texturas lentas que aproximam os sentidos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sensual: seda deslizando, luz de vela na pele e o tempo desacelerado até cada detalhe pedir atenção.

**Paleta de cores** champanhe, pele à luz de vela, sombra quente

**Melhores usos:** beleza, editorial, moda

**MidJourney:** `[tema], sensual aesthetic, silk sliding candlelit skin, slow textures pulling the senses closer --v 6`

**Prompt universal (Seedream):** `Shot on Contax RTS III with 85mm f/1.4 lens, a sensual close portrait, champagne silk sliding across a bare shoulder in candlelight, warm shadow pooling where the light ends, time slowed until every texture asks for attention, intimate shallow-focus elegance, tasteful and refined, 8k`

### **Sertão**

**№ 800 / 1001** — *Beauty Born of Hardship*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Brazilian Romantic regionalism's vaqueiro-as-protagonist and landscape-as-moral-force arrive as the single parent, and Sertão re-instruments that inheritance by stripping its sentiment into a material code of leather, drought, and stone — naturalist rigor sharpening the same lineage rather than crossing into another — so a romantic pastoral becomes, one turn later, a document of survival written in tanned hide and cracked clay.

**Atmosfera e mood**

**Beleza nascida da dureza** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sertão: caatinga cinza-prata, chão rachado e mandacaru contra o céu — a resistência como paisagem e caráter.

**Paleta de cores** cinza de caatinga, terra rachada, branco de sol a pino

**Melhores usos:** documental brasileiro, paisagens, editorial

**MidJourney:** `[tema], sertão aesthetic, silver-gray caatinga cracked earth mandacaru cactus, beauty born of hardship --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 6 with 75mm lens in black and white, a sertão landscape, a lone mandacaru cactus rising from cracked earth in the silver-gray caatinga, Sebastião Salgado tonal depth under a merciless zenith sun, resistance written as both landscape and character, epic documentary grain, 8k scan`

### **Steampunk**

**№ 847 / 1001** — *Brass gears turning a Victorian tomorrow*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → NARRATIVE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Cyberpunk's conviction that technology authors culture arrives as the single parent, and Steampunk re-instruments that inheritance by rerouting it from silicon into brass, so an invisible circuit becomes, one turn later, a wall of gearing accountable to the eye.

**Atmosfera e mood**

**Engrenagens de latão girando um amanhã vitoriano** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Steampunk: dirigíveis sobre Londres a vapor, óculos de latão e a revolução industrial sonhando o futuro que Verne prometeu.

**Paleta de cores** latão, couro conhaque, vapor esverdeado

**Melhores usos:** fantasia, conceito, editorial

**MidJourney:** `[tema], steampunk aesthetic, brass gears airships over victorian london, a Jules Verne tomorrow --v 6`

**Prompt universal (Seedream):** `Ultra-detailed steampunk illustration, brass gears and pressure gauges driving a Victorian tomorrow, airships sliding over a steam-wreathed London of riveted copper towers, cognac leather and verdigris vapor in gaslight, the industrial revolution dreaming in the Jules Verne register, intricate mechanical richness, 8k`

### **Steelpunk**

**№ 848 / 1001** — *Industrial Might Forges Raw Functionality*

**Nível:** ⚫ Quaternária

**Eixo:** MATTER ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Retrofuturism's backward-looking grammar arrives as the single parent, and Steelpunk re-instruments that inheritance through three successive narrowings — cyberpunk to steampunk to dieselpunk — until the same retrofuturist impulse becomes, one turn later, the steel age's exposed rivet and load path.

**Atmosfera e mood**

**A força industrial forjando funcionalidade bruta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Steelpunk: aço soldado sem disfarce, hidráulica exposta e máquinas que exibem a própria força como único ornamento.

**Paleta de cores** aço escovado, faísca de solda, óxido de forja

**Melhores usos:** industrial, conceito, capas

**MidJourney:** `[tema], steelpunk aesthetic, welded steel exposed hydraulics, raw functionality as the only ornament --v 6`

**Prompt universal (Seedream):** `Ultra-detailed industrial render, a steelpunk machine hall, welded steel colossi with exposed hydraulics and riveted plating working under showers of forge sparks, brushed metal and oxide heat with zero decoration, raw functionality flexed as the only ornament, heavy monumental grit, 8k`

### **Still Life**

**№ 850 / 1001** — *Domestic Poetry in Everyday Beauty*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No single movement precedes Still Life; Roman xenia mosaics, Egyptian tomb provisioning, and seventeenth-century Dutch crystallization each arrive independently at the same isolating gesture with no shared ancestor, so the aesthetic generates descendants across every later object-genre while descending from none of them, and no prior tradition can be traced upward into it.

**Atmosfera e mood**

**Poesia doméstica na beleza cotidiana** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Natureza-morta: pão partido, jarro de estanho e uva à meia-luz — o cotidiano parado até virar contemplação.

**Paleta de cores** castanho de mesa, estanho, dourado de casca

**Melhores usos:** arte, gastronomia, editorial

**MidJourney:** `[tema], still life aesthetic, broken bread pewter jug grapes in half light, domestic poetry --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a still life painting, broken bread beside a pewter jug and spilled grapes in raking half-light, Chardin patience over Dutch precision on a worn oak table, chestnut and pewter warmed by one gilded rind, the everyday held still until it becomes contemplation, 8k scan`

### **Sustainable**

**№ 875 / 1001** — *Design that answers to the planet first*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The Arts and Crafts Movement supplies the single parent, and Sustainable re-instruments that inheritance by re-framing material honesty as ecological accounting rather than moral craftsmanship alone.

**Atmosfera e mood**

**O design que responde primeiro ao planeta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sustentável: bambu, micélio e algodão sem tinta — objetos desenhados para voltar à terra sem pedir desculpas.

**Paleta de cores** cru de fibra, verde de folha, castanho de micélio

**Melhores usos:** produto, branding, editorial

**MidJourney:** `[tema], sustainable design aesthetic, bamboo mycelium undyed cotton, design answering to the planet first --v 6`

**Prompt universal (Seedream):** `Ultra-clean studio photograph in pure daylight, sustainable design objects, a mycelium lampshade beside bamboo vessels and undyed cotton textiles on raw fiber board, leaf green shadowed by mushroom brown, products designed to return to the earth without apology, honest material clarity, 8k`

### **Swordcore**

**№ 882 / 1001** — *Steel, honor, and the duel as dress code*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Medievalism supplies the single parent, and Swordcore re-instruments that inheritance by narrowing the whole medieval substrate to one object — the blade — fused with fantasy-romance into a dialect rather than a new grammar.

**Atmosfera e mood**

**Aço, honra e o duelo como código de vestimenta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Swordcore: lâmina desembainhada ao amanhecer, saudação antes do assalto e a esgrima como ética portátil.

**Paleta de cores** aço polido, couro de bainha, cinza de madrugada

**Melhores usos:** fantasia, esporte, editorial

**MidJourney:** `[tema], swordcore aesthetic, drawn blade at dawn salute before the bout, honor as dress code --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F5 with 135mm lens, a swordcore dawn, two duelists saluting with drawn blades in a mist-gray courtyard before the first pass, polished steel and scabbard leather catching the earliest light, honor worn as strictly as the uniform, poised pre-strike tension, 8k scan`

### **Tactile**

**№ 892 / 1001** — *Vision Wakes Under the Fingertip*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The wabi-sabi material tradition supplies the single parent, and Tactile re-instruments that inheritance by widening its reverence for aged, imperfect surfaces into a broader, cross-cultural sensory grammar.

**Atmosfera e mood**

**A visão despertando sob a ponta do dedo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tátil: o dedo afundando no veludo, a lã crua contra a porcelana lisa — a imagem que o corpo sente antes do olho terminar.

**Paleta de cores** veludo profundo, lã crua, porcelana fria

**Melhores usos:** produto, editorial, arte

**MidJourney:** `[tema], tactile aesthetic, fingertip sinking into velvet raw wool against smooth porcelain, vision waking under touch --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7CR with 90mm macro lens, a tactile study, a fingertip sinking into deep velvet beside raw wool coiled against cold smooth porcelain, every fiber and pore resolved in raking light, an image the body feels before the eye finishes reading it, intimate material precision, 8k`

### **Trash Art**

**№ 906 / 1001** — *Waste Returns as Material Argument*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SYNTHESIS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Assemblage / found-object art supplies the single parent, and Trash Art re-instruments that inheritance by turning the readymade's provocation into environmental repair.

**Atmosfera e mood**

**O resíduo retornando como argumento material** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Trash art: garrafas, circuitos e plástico de praia remontados em figura — o lixo devolvido à sociedade com moldura e tese.

**Paleta de cores** plástico desbotado, ferrugem, cor de rótulo sobrevivente

**Melhores usos:** arte, ativismo, editorial

**MidJourney:** `[tema], trash art aesthetic, bottles circuits beach plastic reassembled into figure, waste returned with a thesis --v 6`

**Prompt universal (Seedream):** `Ultra-detailed studio photograph, a trash art assemblage, a monumental human figure built entirely from beach plastic bottle caps and salvaged circuit boards in the HA Schult manner, faded plastic and rust arranged by color into flesh tones, waste walking back into society with a framed argument, confrontational precision, 8k`

### **Tribalism Art and Craft**

**№ 908 / 1001** — *Ancestral Craft Without Anonymous Extraction*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The vernacular folk-craft tradition of communal, anonymous production supplies the single parent, and Tribalism Art and Craft re-instruments that inheritance by laying an animist, ceremonial charge over ordinary making.

**Atmosfera e mood**

**O ofício ancestral sem extração anônima** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Arte e ofício ancestral: o padrão com nome, nação e artesão identificados — a beleza tradicional creditada em vez de colhida como “étnica genérica”.

**Paleta de cores** ocre de terra, negro de fibra tingida, vermelho cerimonial

**Melhores usos:** cultura, artesanato, documental respeitoso

**MidJourney:** `[tema], ancestral tribal craft aesthetic, named tradition named maker, heritage credited not extracted --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 645Z with 55mm lens, an ancestral craft portrait, a master weaver's hands finishing a ceremonial textile in earth ochre and dyed-fiber black, the pattern's nation and maker honored in frame rather than harvested as anonymous decor, workshop daylight on generational skill, dignified documentary respect, 8k`

### **Trinketcore**

**№ 909 / 1001** — *Memory Stored in Objects Too Small to Matter*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The cabinet-of-curiosities tradition (the Wunderkammer) supplies the single parent, and Trinketcore re-instruments that inheritance by scaling the princely cabinet down to the domestic shelf and re-pointing it toward memory-keeping.

**Atmosfera e mood**

**A memória guardada em objetos pequenos demais para importar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Trinketcore: a prateleira de miudezas — concha da viagem, dedal da avó, chaveiro quebrado — cada item inútil e absolutamente insubstituível.

**Paleta de cores** dourado de bugiganga, vidro colorido, madeira de prateleira

**Melhores usos:** nostalgia, editorial, conteúdo

**MidJourney:** `[tema], trinketcore aesthetic, shelf of tiny keepsakes shell thimble broken keychain, useless and irreplaceable --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-T5 with 30mm macro lens, a trinketcore shelf, a vacation shell beside a grandmother's thimble a broken keychain and one colored-glass animal arranged with archival care, trinket gold and dusty wood in soft window light, memory stored in objects too small to matter and too loved to discard, tender close detail, 8k`

### **Tuscan Rustic**

**№ 915 / 1001** — *Limewash, Terracotta, and the Long Table*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Mediterranean vernacular building, Italian Renaissance culture, and the European pastoral tradition converge here, each supplying a load-bearing feature nothing else replaces, fixing Tuscan Rustic as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Cal, terracota e a mesa comprida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rústico toscano: paredes caiadas com séculos à mostra, piso de terracota gasto e a mesa posta para doze sob o parreiral.

**Paleta de cores** cal quente, terracota, verde de oliveira

**Melhores usos:** interiores, gastronomia, viagem

**MidJourney:** `[tema], tuscan rustic aesthetic, limewashed walls worn terracotta long table under the vine, centuries showing --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 7 with 65mm lens, a Tuscan rustic courtyard, a long table set for twelve under the grape arbor beside limewashed walls and terracotta worn smooth by centuries, olive green and warm plaster in late golden light, hospitality older than any trend, sun-soaked material warmth, 8k`

### **Unpolished**

**№ 929 / 1001** — *Finish Stops at Evidence*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Wabi-sabi, the Arts and Crafts Movement, and Brutalism converge here, each supplying a load-bearing layer nothing else replaces, fixing Unpolished as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**O acabamento que para na evidência** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sem polimento: reboco interrompido, junta de madeira à mostra e a decisão estética de deixar o processo visível no produto.

**Paleta de cores** cinza de reboco cru, madeira sem verniz, ferro sem pintura

**Melhores usos:** interiores, design, editorial

**MidJourney:** `[tema], unpolished aesthetic, interrupted plaster exposed joinery, process left visible in the product --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 67 with 105mm lens, an unpolished interior, raw plaster stopping mid-wall above exposed dovetail joinery and unpainted iron brackets, trowel marks and pencil lines left as honest evidence, unvarnished wood warm against rough gray, the finish deliberately ending where the process shows, tactile truthful texture, 8k`

### **Veristic**

**№ 945 / 1001** — *Truth Refuses the Retouch*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ESTHETICS ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** The unembellished-truth mandate surfaces independently in Republican Rome, post-unification Sicily, and Weimar Germany with no shared teacher, the signature of an irreducible root grammar, not a reinterpretation.

**Atmosfera e mood**

**A verdade recusando o retoque** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Verístico: o busto romano que grava cada ruga e verruga do senador — a autoridade provada pela idade em vez de escondida dela.

**Paleta de cores** mármore envelhecido, sombra de ruga, cinza de pátina

**Melhores usos:** arte, retratos, editorial

**MidJourney:** `[tema], veristic aesthetic, roman bust recording every wrinkle and wart, authority proven by age --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of a Roman veristic marble bust, an elder senator's face recorded wrinkle by wrinkle and wart by wart in unforgiving carved honesty, aged marble and patina gray under raking gallery light, authority argued through every year survived rather than concealed, unflinching sculpted truth, 8k`

### **Verite**

**№ 946 / 1001** — *Cinema Keeps the Camera in the Room*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Verité recombines three irreducible lineages — the Vertov/Bazin indexical faith, the Zavattini neorealist body, and the portable-rig handheld sync-sound — into one multi-lineage hybrid grammar that no single parent could produce alone.

**Atmosfera e mood**

**O cinema mantendo a câmera na sala** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Cinéma vérité: a câmera no ombro, o foco corrigido no meio da frase e a vida acontecendo sem segunda tomada — os irmãos Maysles na cozinha.

**Paleta de cores** grão de 16mm, luz disponível, cinza de cozinha real

**Melhores usos:** documental, editorial, cinema

**MidJourney:** `[tema], cinema verite aesthetic, shoulder camera focus corrected mid-sentence no second take, the Maysles in the kitchen --v 6`

**Prompt universal (Seedream):** `16mm documentary film still in the Maysles manner, a vérité moment, a family argument caught over a kitchen table in available window light with the focus corrected mid-sentence, real gray and film grain refusing any staging, the camera allowed to stay in the room while life declines a second take, raw honest intimacy, 8k scan`

### **Vermeil**

**№ 947 / 1001** — *Gold's Skin, Silver's Bone*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Neither goldsmithing nor alchemical metaphor is a decomposable parent; the bimetallic conjunction of gold skin over silver body is an irreducible root grammar that generates ormolu, parcel-gilt, and gold-plate as descendants.

**Atmosfera e mood**

**Pele de ouro, osso de prata** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vermeil: a prata dourada dos serviços imperiais — o brilho integral do ouro sustentado por estrutura mais humilde e mais forte.

**Paleta de cores** dourado de vermeil, prata entrevista, veludo de estojo

**Melhores usos:** joalheria, produto, editorial

**MidJourney:** `[tema], vermeil aesthetic, gilded silver imperial service, gold's skin on silver's bone --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100S II with 120mm macro lens, a vermeil study, a gilded silver goblet and spoon from an imperial service resting on case velvet, gold's unbroken skin glowing over silver's stronger bone where one worn edge confesses the truth, warm precious luster in dark surroundings, sumptuous metallic detail, 8k`

### **Viking**

**№ 951 / 1001** — *Northern Myth Forged Into Portable Power*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → SAGA ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Vendel-period boat burials and Germanic animal ornament are contextual influence rather than parentage; the fused maritime-material-mythic grammar is a root that revivalist culture treats as an origin, not a derivative of any prior style.

**Atmosfera e mood**

**O mito nórdico forjado em poder portátil** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Viking: o machado com nós entrelaçados no cabo, o broche que carrega a linhagem e o drakkar desenhado para levar o mundo conhecido junto.

**Paleta de cores** ferro forjado, madeira de drakkar, azul de fiorde

**Melhores usos:** histórico, fantasia, editorial

**MidJourney:** `[tema], viking aesthetic, interlaced knotwork axe lineage brooch drakkar, northern myth as portable power --v 6`

**Prompt universal (Seedream):** `Ultra-detailed cinematic photograph, a Viking forge at fjord dusk, a smith's scarred hands finishing an axe head chased with interlaced knotwork beside a silver lineage brooch, forged iron and drakkar wood against deep fjord blue, northern myth hammered into objects built to travel, elemental smoky drama, 8k`

### **Wabi-Sabi**

**№ 962 / 1001** — *Crack Outranks the Perfect Surface*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Zen Buddhism and Taoism are belief frameworks, not aesthetic parents, and no prior visual grammar can be decomposed out of the reverence for wear; the one-way borrowing by later movements like shabby chic confirms Wabi-Sabi as a root rather than a branch.

**Atmosfera e mood**

**A rachadura superando a superfície perfeita** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Wabi-sabi: a tigela emendada em ouro kintsugi, a parede manchada pela estação e a beleza que só o tempo e o uso sabem terminar.

**Paleta de cores** argila crua, ouro de kintsugi, cinza de parede envelhecida

**Melhores usos:** interiores, cerâmica, editorial

**MidJourney:** `[tema], wabi-sabi aesthetic, kintsugi gold seams weathered wall, beauty only time can finish --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 501CM with 80mm lens, a wabi-sabi still, a kintsugi tea bowl with gold-mended cracks resting on weathered wood before a season-stained plaster wall, raw clay and aged gray honored by raking window light, the crack formally outranking the perfect surface, profound imperfect calm, 8k`

### **Web 1.0**

**№ 966 / 1001** — *Pixelated Dawn Before the Feed*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** Strip the blue underlined link, the table cell, and the constraint of an 8-bit display, and there is nothing left to call Web 1.0 — pre-web digital culture supplied context, not ancestry, and this grammar generates every web-native descendant rather than deriving from one.

**Atmosfera e mood**

**A alvorada pixelada antes do feed** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Web 1.0: GIF de construção girando, contador de visitas e a homepage do GeoCities com fundo estrelado — a internet artesanal de 1997.

**Paleta de cores** cinza de browser, azul de hyperlink, estrelado de GeoCities

**Melhores usos:** nostalgia, design, conceito

**MidJourney:** `[tema], web 1.0 aesthetic, spinning construction gif visitor counter geocities starfield, the handmade 1997 internet --v 6`

**Prompt universal (Seedream):** `Pixel-perfect digital artwork of a 1997 web page, a GeoCities homepage with a spinning under-construction GIF a visitor counter at 00042 and rainbow horizontal rules over a starfield background, browser gray framing hyperlink blue, the handmade internet before the feed was invented, charming pixelated dawn, 8k`

### **Weirdcore**

**№ 973 / 1001** — *Digital Surrealism Through Childhood Compression*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The Surrealist inheritance survives — the uncanny interior, the dream presented as document — but it is refined through a new instrument: digital decay, compression, deliberate signal loss.

**Atmosfera e mood**

**O surrealismo digital via compressão de infância** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Weirdcore: o playground vazio em JPEG saturado, texto flutuante que quase consola e a sensação de memória de outra pessoa carregando errado.

**Paleta de cores** saturado comprimido, vermelho de texto flutuante, verde de grama irreal

**Melhores usos:** arte digital, conceito, capas

**MidJourney:** `[tema], weirdcore aesthetic, oversaturated jpeg empty playground floating text, someone else's memory loading wrong --v 6`

**Prompt universal (Seedream):** `Low-resolution digital image with heavy JPEG compression, a weirdcore scene, an empty playground at impossible noon with oversaturated unreal grass and a floating red text caption that almost comforts, compression artifacts blooming at every edge, someone else's childhood memory loading incorrectly, deeply familiar and deeply wrong, 8k upscale of corrupted source`

### **Whimsicraft**

**№ 976 / 1001** — *Handmade Wonder With Tool Marks Intact*

**Nível:** 🟣 Secundária

**Eixo:** MATTER ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** William Morris's Arts and Crafts revival is the single load-bearing ancestor — strip it away and the moral weight of visible handwork collapses, while folk embroidery and quilting remain inherited soil rather than separate parents, marking one clean generation of reinterpretation.

**Atmosfera e mood**

**O deslumbre feito à mão com marcas de ferramenta intactas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Whimsicraft: o pássaro entalhado com a goiva visível, tinta fora da linha de propósito e a fantasia que faz questão de mostrar que foi feita por alguém.

**Paleta de cores** madeira de goiva, azul de tinta artesanal, vermelho de oficina

**Melhores usos:** craft, infantil, editorial

**MidJourney:** `[tema], whimsicraft aesthetic, carved bird with visible gouge marks paint outside the line on purpose, wonder made by hand --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS 90D with 50mm macro lens, a whimsicraft workshop still, a hand-carved wooden bird with every gouge mark left proud and paint wandering cheerfully outside its lines, craft blue and workshop red on shaving-dusted pine, wonder that insists on showing it was made by someone, warm handmade delight, 8k`

### **Wild**

**№ 978 / 1001** — *Beauty Outside the Fence*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → EDITING ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada é tratada como gramática fundadora: rompe uma regra anterior em vez de apenas reinterpretá-la.

**Nota genealógica original (EN):** No manifesto founded it and no studio holds the copyright — the Romantics re-valued the mountain but did not father the reverence for untamed land, so removing any single tradition leaves the irreducible core, reverence for land that answers to no human will, fully intact.

**Atmosfera e mood**

**A beleza do lado de fora da cerca** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Selvagem: o lobo parado onde a estrada desiste, o olhar que não negocia e a natureza inteira lembrando que nunca assinou o contrato.

**Paleta de cores** cinza de lobo, verde de mata fechada, âmbar de olhar

**Melhores usos:** natureza, capas, editorial

**MidJourney:** `[tema], wild aesthetic, wolf standing where the road gives up a gaze that does not negotiate, beauty outside the fence --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 II with 600mm lens, a wild encounter, a gray wolf standing exactly where the forest road gives up, amber eyes holding the lens without a flicker of negotiation, deep timber green swallowing everything behind it, beauty that never signed the fence's contract, breathless telephoto stillness, 8k`

### **Workwear**

**№ 982 / 1001** — *Labor Writes the Poetry Into Denim*

**Nível:** 🔴 Primária

**Eixo:** MATTER ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Atmosfera e mood**

**O trabalho escrevendo a poesia no denim** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Workwear: a jaqueta de lona desbotada exatamente onde o corpo dobra, costuras triplas e o desgaste como assinatura — a roupa biografada pelo ofício.

**Paleta de cores** índigo lavado por anos, lona de trigo, cobre de rebite

**Melhores usos:** moda, editorial, retratos

**MidJourney:** `[tema], workwear aesthetic, canvas jacket faded where the body bends triple stitching, clothing biographed by labor --v 6`

**Prompt universal (Seedream):** `Shot on Nikon FM3A with 35mm lens, a workwear portrait, a carpenter in a chore coat faded exactly where the body bends, triple stitching and copper rivets catching workshop light over years-washed indigo, sawdust on wheat canvas, labor writing its own poetry into the denim, honest worn dignity, 8k scan`

### **Zero-Waste**

**№ 998 / 1001** — *Minimal Impact and Maximum Resourcefulness*

**Nível:** 🟤 Terciária

**Eixo:** MATTER ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas em uma nova gramática relacional.

**Nota genealógica original (EN):** Three lineages converge and none can be quietly removed — pull composting and the closed-loop logic loses its biological anchor, pull DIY craft and the hand disappears from the work, pull anti-consumer minimalism and it collapses into ordinary recycling — confirming distinct traditions braided into one practice.

**Atmosfera e mood**

**Impacto mínimo e engenhosidade máxima** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lixo zero: potes de vidro alinhados a granel, sacolas de pano com biografia e a cozinha onde nada chega embalado — a resistência praticada por grama.

**Paleta de cores** vidro transparente, cru de algodão, verde de folha reaproveitada

**Melhores usos:** lifestyle, branding, editorial

**MidJourney:** `[tema], zero-waste aesthetic, bulk glass jars cloth bags with a biography nothing arrives packaged, resistance practiced by the gram --v 6`

**Prompt universal (Seedream):** `Ultra-clean studio photograph, a zero-waste kitchen still, labeled glass jars of bulk grains lined beside well-worn cotton bags and a wooden scoop with not one wrapper in sight, clear glass and unbleached cotton in honest daylight, minimal impact arranged as maximum resourcefulness, virtuous tactile order, 8k`

## Leitura do padrão — o que as 99 estéticas confirmam

MATTER é o maior inventário desta arquitetura e confirma uma lei única: **a resistência do material precisa permanecer visível como a primeira resposta do mundo.** Peso, trama, desgaste, ferramenta, suporte e transformação não são decoração; são argumento.

### Uma supressão que prova a lei pelo avesso

Neo Surrealism é a única entrada MATTER ↓. A matéria não desaparece por descuido: ela é substituída pela tela, pelo sinal e pela resolução digital para que o signo flutue. A exceção confirma o rigor do conjunto — toda estética precisa ser feita de alguma coisa, mesmo quando essa “coisa” é luz ou compressão.

### Seis famílias recorrentes

1. **Matéria e tempo:** pedra, barro, ferrugem, gelo, madeira e desgaste demonstram duração, memória e transformação.
2. **Recusa do acabamento:** Raw, Wild, Unpolished, Verite e Whimsicraft mantêm marcas de processo como prova, enquanto Bricolage Art e Zero-Waste reorganizam restos por meio do corte.
3. **Honestidade estrutural:** Arts and Crafts, Danish Modern, Alpine, Neo-Brutalism, Sustainable, BRUTALISM, Constructivism e Veristic exigem que forma, construção e substrato admitam o que são.
4. **Matéria como signo:** couro, metal, pixel, armadura, pigmento e superfície carregam códigos sociais, culturais e políticos.
5. **Matéria transformada:** ofício, trabalho, engenharia e transmutação deslocam o substrato de seu estado anterior para uma nova função ou gramática.
6. **Toque e ressonância:** superfícies táteis, objetos íntimos e até a degradação digital fazem a visão despertar como sensação física.

### O teste operacional

MATTER não é “materialidade” como etiqueta. A pergunta é mais precisa: **a resistência do substrato está visível no quadro?** Se a superfície não pesa, não reage, não desgasta, não reflete o trabalho ou não se dissolve de modo deliberado, a matéria foi apenas ilustrada — ainda não foi provada.

# ILLUMINATION — o Crescente de Ur

<aside>
☾

**Essência.** ILLUMINATION é o uso estrutural de luz, sombra e visibilidade. Seu ideograma é o Crescente de Ur — um corpo que não produz luz, mas administra por fases tudo o que recebe. No registro ↑, a linha de terminador governa a revelação e decide o quadro; no registro ↓, a luz abdica desse governo por nivelamento total ou pela escuridão tomada como chão.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para ILLUMINATION, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem a fonte luminosa própria de cada estética, enquanto a arquitetura preserva a lógica do Crescente de Ur — revelar por fases para que a luz decida o que pode ser visto.

> **↑ ILLUMINATION — universal prompt.** A figure rotated so the light's terminator line crosses the body deliberately — one shoulder lit, the torso falling into governed shade — stillness that lets the beam do the moving, chin lifted a degree into the light; gestures minimal and half-revealed, one hand emerging into the beam while the other stays in shadow, the gesture finished by the light rather than the body; eyes held at the exact edge of light and dark with one catching a point of brilliance, the composed interior expression of someone who decides what may be seen; skin prepped to a satin finish where lit, a glossed cheekbone placed exactly where the beam lands, hair with one polished plane reflecting and the rest absorbed into dark, lips in a deep quiet tone that holds detail in shadow; [the aesthetic's own signature garment] revealed in phases — folds staging the light, [the aesthetic's own detail: embroidery, a clasp, a seam] positioned exactly where the beam arrives, the rest surrendered; photographed static on a 70mm at f/4, exposure set for the highlights with blacks holding deep detail; one lit shoulder against a large governed dark field, the beam's geometry — [the aesthetic's own light source: a window shaft, a doorway slice, a single focused instrument] — as the frame's structural line; one directional motivated beam building the whole composition, hard shadow edges as drawn lines, slow smooth falloff, the light warm enough that the shadow reads as velvet rather than menace, faint haze making the beam visible; a dark ground with one governed opening — [the aesthetic's own dark room: atelier, corridor, nave, night street] — its surfaces chosen for how they take light, and nothing in the dark demanding to be seen.
> 

**Universal ILLUMINATION ↓ negative line (always pair with the ↑ prompt):**

> No flat even illumination, no on-camera flash, no multiple competing sources, no sourceless shadowless field, no full-face disclosure, no clinical brightness, no crushed empty blacks, no horror-adjacent menace, no light that merely documents, no shadow without a drawn edge.
> 

**Como usar para as 48 estéticas da lista.** Troque os colchetes pela fonte de luz própria da estética — a arquitetura só nomeia mecanismos (a linha de terminador, a revelação em fases, o feixe como estrutura do quadro, o escuro aveludado). Exemplos: para **Komorebi**, o feixe = sol filtrado pelas folhas de cânfora — a fase ditada pela árvore; para **DAWN / Duskcore / Lunar**, o planeta como gaffer — a hora rosada, a luz alugada que não volta, o crescente prateado; para **Bombshell**, o feixe de glamour de estúdio encontrando a boca laqueada primeiro; para **Noir**, a sombra como linguagem moral — o terminador cruzando o rosto como veredicto; para **Acidgoth / Acid Pixie**, a blacklight e o burn de CRT como fonte única governada; para **Golden / Illuminated**, a folha de ouro devolvendo a luz — a página que emite; para **Vectorcore / Silicon Dreams**, a linha luminosa sobre fundo escuro com a matéria suprimida de propósito (par MATTER ↓). Para **Winter**, use o registro ↓ integral — o branco nivelado sem aresta de sombra; para **Dark Elegance / Dark Naturalism**, a supressão pelo outro extremo — a escuridão como chão, não como fase.

## Fundamentos do elemento

### Identidade, fase e governo da revelação

**Identity.** Structural use of light, shadow, and visibility. Its ideogram is the moon-god of Ur, the administrator of light: a body that produces nothing and governs everything it receives, revealing by phase because showing all at once flattens. In an image this element is proven when light is the architect of the frame, or when it is flattened into pure disclosure.

**The terminator law.** The Crescent reveals by phase: every amplified frame needs one legible line where light ends and dark begins, and that line — not the subject — is the composition's first decision. A frame with light everywhere has no phase; a frame with dark everywhere has no government. The face held at the terminator is the instrument's signature because it proves the choice was made on the most expensive ground in the image.

**Warmth is the exclusion clause.** The governed dark must read as velvet, never as threat — the codex's global wellbeing calibration applied at its source. Tenebrist menace is the default failure of every generator asked for shadow; the Crescent administers what it receives, and administration implies care. Fascination without menace, or the beam has been handed to the wrong god.

## Corpo — postura, gesto e olhar

**Model posture & structure.** The body rotated so the terminator line crosses it deliberately — one shoulder lit, torso falling into shade; stillness that lets the beam do the moving; chin lifted a degree into the light. Suppressed register: square to camera, both shoulders equally presented — the frank stance of a document.

**Gesture.** Minimal and half-revealed — one hand emerging into the beam while the other stays in shadow; the gesture the light finishes rather than the body. Suppressed: arms relaxed at the sides or one neutral functional gesture — nothing staged for shadow because there is none.

**The look — how the eyes behave.** Eyes at the exact edge of light and dark, one catching a point of brilliance; composed and magnetic, interior rather than tense — the face of someone who decides what you may see. Suppressed: a direct, open, evenly lit gaze; expression plainly legible, nothing withheld and nothing implied.

## Regras de imagem — do figurino à prova de fase

**Look & styling continuity.** A garment revealed in phases — satin or structured wool whose folds stage the light; details positioned exactly where the beam lands; the rest surrendered. Suppressed: every seam, fold, and true colour readable at once, no detail privileged over another.

**Camera.** 50–85mm at f/4; exposure set for the highlights, blacks allowed to hold deep detail; static camera — the light is the movement. Suppressed: 50mm at f/8, frontal, mid-distance, textbook-neutral exposure with nothing left for the print to interpret.

**Composition.** One lit shoulder against a large governed dark field; the beam's geometry — a diagonal shaft, a window slice — as the frame's structural line; generous negative dark space that still breathes. Suppressed: centred and catalog-frank, background plain and equally lit, zero dark field.

**Lighting.** One directional motivated beam building the whole composition — window shaft, doorway slice, single focused source; hard shadow edges as drawn lines; slow smooth falloff; light warm enough that the shadow reads as velvet, never as menace; faint haze making the beam visible. Suppressed: overcast noon or open shade — sourceless, even, no shadow edge anywhere; light that only discloses.

**Beauty detail.** Skin prepped luminous where lit — satin, not oily; a glossed eyelid or cheekbone placed to catch the beam; hair with one polished plane reflecting light, the rest absorbed into dark; lips in a deep quiet tone that holds detail in shadow. Suppressed: an even, fully visible complexion with no strategic highlight, hair uniformly lit, makeup in complete daylight honesty.

**Cenography.** A dark atelier or corridor with one governed opening — a tall window, a cracked door; surfaces chosen for how they take light: plaster, silk, oiled wood; nothing in the dark that demands to be seen. Suppressed: a neutral outdoor wall or seamless grey — the anti-atelier; no beams, no haze, no openings.

**Colour.** A palette that exists to be found by the beam — deep quiet tones holding detail in shadow, one warm highlight family where the light lands; colour as a property of illumination, not of pigment. Suppressed: every true colour stated flatly and completely under even light.

**Phase proof.** Wherever the frame allows it, plant one device proving the revelation was staged in phases: the clasp lit and the hem surrendered, the terminator crossing the face with one eye in brilliance, the haze making the beam's geometry legible as the frame's structural line — or, in the disclosure register, a flatness so complete and so even that the refusal of drama reads as its own decision. A frame that cannot show what was withheld has only asserted government — this instrument's most legible failure.

**Practitioner lines (from the codices).** Baron Adolf de Meyer — the light governed so it reveals by veiling: backlit key, gauze over the lens, centre-sharp and edge-dissolved. Horst P. Horst — one hard key low and raking, no fill whatsoever, the shadow carving what the highlight cannot claim. AB+DM — the classic glamour key with velvet shadow and jewel tones, command staged as timeless portraiture. Rala Choi — the subject turned away into a saturated colour field, the image glowing from within. For the disclosure register: Brigitte Niedermair — metaphysical flat frontal light, still-life precision, the frame pared like a painting's inventory.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Light as compositional structure: one directional beam building the scene, hard shadow edges as drawn lines, revelation in phases, the face held at the terminator line, the rest surrendered to dark.

> **↑ Prompt.** A dark atelier where one directional beam builds the entire composition, the garment revealed in phases, a lit shoulder, a hard shadow edge across the waist, the rest surrendered to black, the model's face held half in the terminator line, light behaving as the architect of the frame rather than its servant.
> 

> **↑ Negative line.** No flat even illumination, no on-camera flash, no multiple competing sources, no horror-adjacent framing, no crushed empty blacks, no clinical brightness, no full-face disclosure.
> 

**↓ Suppressed — repertory.** Flattened light that only reveals: overcast or open shade, sourceless evenness, no shadow edges, every fold and colour stated completely and without drama.

> **↓ Prompt.** Overcast noon in open shade, a figure photographed in perfectly even, sourceless light, no shadow edge anywhere in the frame, every fold, seam, and colour stated flatly and completely, illumination doing nothing but disclosing.
> 

> **↓ Negative line.** No chiaroscuro, no beams or shafts, no haze, no dark negative space, no glossed strategic highlights, no half-revealed gestures, no mystery.
> 

## Estéticas relacionadas a ILLUMINATION (A–Z)

As 48 estéticas classificadas sob ILLUMINATION, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Acid Fairycore**

**№ 017 / 1001** — *Rave palette in the woodland*

**Nível:** ⚫ Quaternária

**Eixo:** ILLUMINATION ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Paleta de rave no bosque** — (1001 Aesthetics; código: sref-midjourney.com)

Fadas e cogumelos em cores ácidas de festa: natureza encantada iluminada por neon e luz UV, glitter e brilho psicodélico.

**Paleta de cores** verde-lima ácido, rosa-choque, roxo UV, turquesa neon sobre verdes de floresta

**Melhores usos:** ilustração fantasia, capas, identidade jovem, arte para festivais

**MidJourney:** `--sref 2402696576 --sw 1000` (match aproximado: Ethereal Fantasy in Nature — reforce o ácido no texto)

**Prompt universal (Seedream):** `Fantasy editorial photograph shot on Sony A1 with 85mm f/1.4 lens, an enchanted woodland fairy in acid rave palette, iridescent wings and glitter-dusted skin under UV blacklight, bioluminescent mushrooms glowing neon lime hot pink and ultraviolet purple against deep forest green, hyper-detailed psychedelic fantasy, 8k`

### **Acid Pixie**

**№ 018 / 1001** — *Glittered wings in CRT burn*

**Nível:** ⚫ Quaternária

**Eixo:** ILLUMINATION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Asas com glitter em queima de CRT** — (1001 Aesthetics, interpretação)

Fada digital dos anos 2000: glitter, brilho de tela CRT, aberração cromática, misticismo Y2K.

**Paleta de cores** rosa elétrico, lilás, verde ácido, brilhos metálicos e prata holográfica

**Melhores usos:** capas de música, estética Y2K, avatares

**MidJourney:** `[tema], acid pixie aesthetic, y2k glitter fairy, CRT screen glow --v 6`

**Prompt universal (Seedream):** `Y2K portrait shot on an early-2000s digital camera with harsh on-camera flash, an acid pixie fairy with glittered wings and holographic silver accessories, CRT screen glow and chromatic aberration bleeding electric pink lilac and acid green, retro digital fantasy with webcam grain and sticker-gloss shine`

### **Acidgoth**

**№ 019 / 1001** — *Gothic ritual under blacklight*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Ritual gótico sob luz negra** — (1001 Aesthetics; código: sref-midjourney.com)

Gótico banhado em neon UV: rendas pretas, arcos de catedral e símbolos ocultos sob verde-ácido e roxo blacklight.

**Paleta de cores** preto absoluto com verde ácido, roxo UV e magenta neon

**Melhores usos:** dark fantasy, música, moda alternativa

**MidJourney:** `--sref 4052432800 --sw 1000` (match aproximado: Cyberpunk Gothic Dreams)

**Prompt universal (Seedream):** `Dark editorial photograph shot on 35mm film with 50mm lens, a gothic ritual under blacklight, intricate black lace and cathedral arches bathed in acid green and UV purple neon, occult sigils fluorescing in the darkness, deep shadow detail with electric rim light, unsettling luminous atmosphere, 8k`

### **Aetherial**

**№ 028 / 1001** — *Matter caught mid-vanish*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Matéria flagrada sumindo** — (1001 Aesthetics, interpretação)

Formas em dissolução: véus, névoa e luz difusa; o corpo virando luz.

**Paleta de cores** brancos, azul pálido, tons opalescentes

**Melhores usos:** espiritual, beleza, capas

**MidJourney:** `[tema], aetherial dissolving forms, translucent veils of light --v 6`

**Prompt universal (Seedream):** `Ethereal portrait shot on 85mm f/1.2 wide open, a figure dissolving into backlit mist and translucent silk veils, opalescent whites and pale blues, weightless fabric suspended mid-air, luminous overexposed highlights with a soft spiritual glow, fine art quality with dreamy shallow depth of field, 8k`

### **Alien**

**№ 040 / 1001** — *Form no category can hold*

**Nível:** 🔴 Primária

**Eixo:** ILLUMINATION ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Forma que nenhuma categoria segura** — (1001 Aesthetics; código: sref-midjourney.com)

Biomorfismo alienígena: anatomia impossível, biomecânica à la Giger, texturas orgânicas estranhas.

**Paleta de cores** cinzas biomecânicos, verdes doentios, iridesência

**Melhores usos:** sci-fi, horror, concept art

**MidJourney:** `--sref 3939966570 --sw 1000` (match aproximado: Gothic Sci-Fi Horror Atmosphere)

**Prompt universal (Seedream):** `Sci-fi horror photograph shot on ARRI with 65mm lens, an alien biomorphic lifeform of impossible anatomy, glistening biomechanical textures in the manner of H.R. Giger, sickly green and iridescent gray flesh under cold clinical light, wet chitinous surface detail, unsettling cinematic realism, 8k`

### **Anthotype**

**№ 050 / 1001** — *Pressed Pigment, Patient Light*

**Nível:** ⚫ Quaternária

**Eixo:** ILLUMINATION ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Pigmento prensado, luz paciente** — (1001 Aesthetics, interpretação)

Impressão anthotype: emulsão de pétalas revelada pelo sol, imagem fantasmagórica monocromática vegetal.

**Paleta de cores** beterraba, açafrão, verde-clorofila desbotados

**Melhores usos:** botânico, arte alternativa, texturas

**MidJourney:** `[tema], anthotype print, plant pigment photography --v 6`

**Prompt universal (Seedream):** `Extreme close-up scan of an anthotype print, ghostly monochrome botanical image developed in flower-petal emulsion under weeks of sunlight, faded beetroot and chlorophyll tones sunk into thick cotton paper, visible fiber texture and brush-coated edges, fragile experimental photography artifact, ultra-high resolution`

### **Après-Ski**

**№ 053 / 1001** — *Mug the mountain hands you back*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**A caneca que a montanha te devolve** — (1001 Aesthetics, interpretação)

Pós-esqui: chalé aquecido, vinho quente, tricô, neve emoldurada pela janela.

**Paleta de cores** creme, vermelho, madeira, branco-neve

**Melhores usos:** inverno, lifestyle, hospitalidade

**MidJourney:** `[tema], après-ski cozy chalet aesthetic --v 6`

**Prompt universal (Seedream):** `Lifestyle photograph shot on 35mm f/1.4 lens, a cozy alpine lodge after skiing, steaming enamel mug and chunky knit sweaters by a roaring fire, snowy peaks glowing blue through the window, warm golden interior against the cold dusk, cinematic hygge warmth with shallow depth of field, 8k`

### **Bombshell**

**№ 108 / 1001** — *Lacquered mouth read first*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Nota genealógica original (EN):** Studio-era glamour lighting, cosmetic engineering, and pin-up iconography converge; strip the lighting grammar and the lacquered mouth stops reading first, strip the pin-up lineage and the pose loses its address — fusion of distinct lines rather than revision of one.

**Atmosfera e mood**

**A boca laqueada é lida primeiro** — (1001 Aesthetics, interpretação)

Glamour bombshell anos 50: batom vermelho laqueado, ondas platinadas, magnetismo de estúdio.

**Paleta de cores** vermelho-lábio, platinado, preto, dourado

**Melhores usos:** retratos, beleza, editorial

**MidJourney:** `[tema], 1950s bombshell glamour portrait --v 6`

**Prompt universal (Seedream):** `Shot on 8x10 large format with 300mm lens, a 1950s bombshell glamour portrait, lacquered red lips and platinum waves lit with classic butterfly lighting, satin gown hugging an hourglass silhouette, Marilyn-era magnetism through George Hurrell's lens, creamy highlights and deep velvet shadows, old Hollywood studio perfection, 8k`

### **Danish Pastel**

**№ 195 / 1001** — *Soft pigment, slow light, hyggelig hours*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → NUANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Pigmento suave, luz lenta, horas hyggelig** — (1001 Aesthetics, interpretação)

Pastel dinamarquês: interiores em lilás e menta suaves, espelhos ondulados, velas e listras arco-íris dessaturadas.

**Paleta de cores** lilás, menta, amarelo-manteiga, rosa pó

**Melhores usos:** interiores, social media, branding

**MidJourney:** `[tema], Danish pastel interior aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.8, a Danish pastel interior, soft lilac mint and butter yellow surfaces, wavy mirror and checkered throw styled with candles in slow northern light, gentle shadows and matte ceramic textures, hyggelig pastel hours, airy editorial softness, 8k`

### **Dark Elegance**

**№ 198 / 1001** — *Refusal of daylight as method*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↓ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**A recusa da luz do dia como método** — (1001 Aesthetics; código: Lummi, match aproximado)

Elegância sombria: moda e retrato em pretos profundos, brilho de cetim na penumbra, sofisticação noturna.

**Paleta de cores** pretos, grafite, brilhos frios

**Melhores usos:** moda, retratos, branding premium

**MidJourney:** `--sref 3841075374 --sw 1000` (Dark Shades — match aproximado)

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a dark elegance editorial, deep blacks with satin sheen carved by one cold rim light, refined nocturnal sophistication in graphite shadows, model in sculptural black couture against the void, daylight refused as method, Nick Knight drama, obsidian grading with razor highlights, 8k`

### **Dark Naturalism**

**№ 199 / 1001** — *Darkness as ground, not absence*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↓ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Escuridão como solo, não como ausência** — (1001 Aesthetics; código: Lummi, match aproximado)

Naturalismo sombrio: floresta e matéria orgânica emergindo de fundo escuro, luz rara e precisa como em pintura holandesa.

**Paleta de cores** pretos-terrosos, verdes profundos, luz pontual

**Melhores usos:** natureza, still life, editorial

**MidJourney:** `--sref 3740460837 --sw 1000` (Moody Grain — match aproximado)

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a dark naturalism still life, forest moss lichen and gnarled roots emerging from deep black ground, one precise beam of light like a Dutch master painting, dew and spore texture in raking illumination, darkness as soil not absence, oil-dark grading, museum-grade detail, 8k`

### **DAWN**

**№ 203 / 1001** — *Rose-fingered hour*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**A hora de dedos róseos** — (1001 Aesthetics; código: Lummi, match aproximado)

Amanhecer: primeira luz rosada sobre névoa baixa, mundo ainda em silêncio, promessa do dia.

**Paleta de cores** rosa-aurora, lilás, dourado pálido

**Melhores usos:** paisagem, espiritual, lifestyle

**MidJourney:** `--sref 364111995 --sw 1000` (Morning — match aproximado)

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a dawn landscape, rose-fingered first light over low mist, world still silent under a pale gold and lilac horizon, dew catching the earliest rays in the foreground grass, quiet promise of the day beginning, luminous fine-art grading, 8k`

### **Daylight**

**№ 205 / 1001** — *Wall keeps no secret from the sun*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**A parede não guarda segredo do sol** — (1001 Aesthetics, interpretação)

Luz do dia: interiores banhados de sol direto, sombras nítidas de janela, honestidade luminosa total.

**Paleta de cores** branco solar, sombras nítidas, tons reais

**Melhores usos:** arquitetura, lifestyle, produto

**MidJourney:** `[tema], full daylight interior, sharp window shadows --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm tilt-shift lens, a daylight interior photograph, rooms flooded with direct sun, sharp window-frame shadows raking across pale floors, true honest colors and dust motes in the beams, walls keeping no secret from the light, architectural editorial clarity, 8k`

### **Dazzling**

**№ 207 / 1001** — *Light made spectacle*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Luz feita espetáculo** — (1001 Aesthetics, interpretação)

Deslumbrante: brilhos estourando em estrela, lantejoulas e cristais, flash e glamour máximo.

**Paleta de cores** prata, dourado, brilhos brancos

**Melhores usos:** moda, eventos, capas

**MidJourney:** `[tema], dazzling sparkle glamour, starburst lights --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a dazzling glamour shot, sequins and crystals exploding into starburst highlights under direct flash, silver and gold sparkle at facet-level sharpness against a jet-black backdrop, light itself made spectacle, high-gloss campaign polish, 8k`

### **Deep Sea**

**№ 215 / 1001** — *Covenant of Bioluminescence, Pressure, and Perpetual Dark*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Bioluminescência, pressão e escuridão perpétua** — (1001 Aesthetics, interpretação)

Mar profundo: criaturas abissais brilhando no negro total, água-viva luminosa, silêncio esmagador do fundo.

**Paleta de cores** preto abissal, azul elétrico, bioluminância

**Melhores usos:** natureza, fantasia, capas

**MidJourney:** `[tema], deep sea bioluminescence, abyssal darkness --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7S with 24mm underwater housing, a deep sea scene, bioluminescent creatures glowing in total abyssal blackness, luminous jellyfish trailing electric blue filaments, crushing pressure and perpetual dark, silent alien world, BBC Blue Planet clarity, 8k`

### **Dewy**

**№ 224 / 1001** — *Discipline of Surfaces That Refuse Matte*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**A disciplina das superfícies que recusam o fosco** — (1001 Aesthetics, interpretação)

Orvalhado: pele luminosa úmida, gotas em pétalas, frescor de manhã em toda superfície.

**Paleta de cores** rosados frescos, translúcidos, brilho úmido

**Melhores usos:** beleza, skincare, macro

**MidJourney:** `[tema], dewy glowing skin, water droplets macro --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a dewy beauty macro, luminous moist skin with glass-like glow, water droplets beading on fresh petals, translucent rosy tones in soft diffused light, every surface refusing matte, K-beauty campaign perfection, pore-level clarity, 8k`

### **Duskcore**

**№ 247 / 1001** — *Beauty rented by the hour, paid in light that won't return*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Beleza alugada por hora, paga em luz que não volta** — (1001 Aesthetics; código: Lummi, match aproximado)

Crepúsculo: céu entre rosa e roxo apagando, silhuetas contra a última luz, melancolia dourada do fim do dia.

**Paleta de cores** roxo-crepúsculo, rosa apagando, azul da hora azul

**Melhores usos:** paisagem, lifestyle, editorial

**MidJourney:** `--sref 1857672673 --sw 1000` (Twilight Tales — match aproximado)

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 50mm lens, a duskcore scene, sky fading from rose to purple at the blue hour, silhouettes against the last light, golden melancholy of a day ending, film halation on the horizon glow, light that will not return, wistful cinematic grading, 8k`

### **Elemental Fire**

**№ 276 / 1001** — *Hammer Falls, Iron Answers*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**O martelo cai, o ferro responde** — (1001 Aesthetics; código: Lummi, match aproximado)

Fogo: forja e faísca, metal incandescente, calor como força criadora e destruidora.

**Paleta de cores** laranja de brasa, vermelho incandescente, preto de carvão

**Melhores usos:** elemental, dramático, texturas

**MidJourney:** `--sref 2713582720 --sw 1000` (Flame & Fabric — match aproximado)

**Prompt universal (Seedream):** `Shot on Sony A9 with 85mm lens at 1/8000s, an elemental fire study, forge sparks frozen mid-air as the hammer falls on incandescent metal, ember orange against charcoal black, heat shimmer distorting the anvil, creative and destructive force in one frame, cinematic contrast, 8k`

### **Enlightenment**

**№ 290 / 1001** — *Three Verticals, One Argument*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Três verticais, um argumento** — (1001 Aesthetics, interpretação)

Iluminismo: biblioteca neoclássica e instrumentos científicos, luz da razão, ordem como ideal.

**Paleta de cores** creme, azul de tinta, bronze de instrumento

**Melhores usos:** histórico, editorial, conceitual

**MidJourney:** `[tema], Age of Enlightenment, neoclassical library, scientific instruments, rational light --v 6`

**Prompt universal (Seedream):** `Shot on a Sinar 4x5 view camera with 90mm lens, an Enlightenment scene, neoclassical library with three vertical columns making one argument, scientific instruments and ink blue on cream in clear window light, brass orrery gleaming, the light of reason as ideal order, painterly academic grandeur, 8k`

### **Ethereal**

**№ 305 / 1001** — *Backlit Gauze and the Body Half-Dissolved*

**Nível:** 🔴 Primária

**Eixo:** ILLUMINATION ↑ → MATTER ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Gaze em contraluz e o corpo meio dissolvido** — (1001 Aesthetics; código: srefs.co, match direto)

Etéreo: tecido translúcido em contraluz, figura se dissolvendo em luz, leveza sobrenatural.

**Paleta de cores** branco luminoso, pastel de névoa, contraluz dourada

**Melhores usos:** espiritual, retratos, fine art

**MidJourney:** `--sref 2696696027 --sw 1000` (Ethereal Dreamscape with Surrealist Overtones — já catalogado nesta página)

**Prompt universal (Seedream):** `Shot on Phase One XF with 150mm lens, an ethereal portrait, backlit translucent gauze and a body half-dissolved into light, luminous white and mist pastels, hair floating weightless, supernatural glow blooming through the fabric, Paolo Roversi softness, 8k fine-art editorial`

### **Film Noir**

**№ 329 / 1001** — *Venetian-Blind Shadows Across a Rain-Slick Street*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↓ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Sombras de persiana sobre a rua molhada de chuva** — (1001 Aesthetics; código: sref-midjourney.com, categoria Film Noir)

Noir: preto e branco de alto contraste, persianas e fumaça, detetive e fatalidade sob o poste de luz.

**Paleta de cores** preto e branco de alto contraste, cinza de fumaça

**Melhores usos:** cinematográfico, retratos, narrativa

**MidJourney:** `--sref 3510839419 --sw 1000` (Glamour Noir)

**LoRA (Civitai):** "Film noir style" (Illustrious) — civitai.com/models/1612373; "Film Noir Transformation" (Qwen) — civitai.com/models/2003239

**Prompt universal (Seedream):** `Shot on 35mm Tri-X with 50mm lens, a film noir scene, venetian-blind shadows across a rain-slick street, high-contrast black and white, trench coat and cigarette smoke curling under a street lamp, Gregg Toland deep-focus fatalism, hard chiaroscuro grain, 8k scan`

### **Frutiger Aero**

**№ 352 / 1001** — *Aqua Glass, Water Droplets, and the Vista Wallpaper*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Vidro aqua, gotas d'água e o papel de parede do Vista** — (1001 Aesthetics, interpretação)

Frutiger Aero: otimismo tecnológico de 2004–2013, bolhas e golfinhos, plástico translúcido sobre gramado ensolarado.

**Paleta de cores** azul aqua, verde grama, branco brilhante, lens flare

**Melhores usos:** tech, branding retrô-digital, editorial

**MidJourney:** `[tema], Frutiger Aero aesthetic, aqua glass and water droplets, glossy skeuomorphic 2000s tech optimism --v 6`

**LoRA (Civitai):** "Frutiger Aero" (SDXL) — civitai.com/models/309887; "Frutiger Aero FLUX" — civitai.com/models/677728

**Prompt universal (Seedream):** `Ultra-detailed digital render at 8k, a Frutiger Aero image, aqua glass and water droplets over a sunny green hill like a Windows Vista wallpaper, translucent plastic bubbles dolphins and lens flares, glossy 2004–2013 tech optimism, glassy hyper-reflective surfaces`

### **Golden**

**№ 386 / 1001** — *Gold Leaf at 0.1 Microns, Catching the Last Light*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Folha de ouro a 0,1 mícron apanhando a última luz** — (1001 Aesthetics, interpretação)

Dourado: superfície de ouro em luz rasante, brilho quente e sagrado, o metal que transforma qualquer coisa em relíquia.

**Paleta de cores** ouro em todos os tons, sombra quente

**Melhores usos:** luxo, sacro, editorial

**MidJourney:** `[tema], gold leaf surface catching the last light, warm sacred gilded glow --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 90mm lens, a golden image, gold leaf at 0.1 microns catching the last raking light, warm sacred glow in every tone of gold, Klimt-like luminous surface, the metal that turns anything into a relic, 8k`

### **Illuminated**

**№ 456 / 1001** — *Gold Leaf Makes the Manuscript Page Emit Light*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**A folha de ouro faz a página do manuscrito emitir luz** — (1001 Aesthetics, interpretação)

Iluminura: manuscrito medieval dourado, capitulares ornadas e margens vivas, a página como relíquia luminosa.

**Paleta de cores** folha de ouro, azul ultramar, vermelho de mínio, pergaminho

**Melhores usos:** ilustração, editorial histórico, identidade

**MidJourney:** `[tema], illuminated manuscript style, gold leaf making the page emit light, ornate initials and living margins --v 6`

**LoRA (Civitai):** "Medieval Manuscript Style" (FLUX/KONTEXT) — civitai.com/models/1260139; "Medieval Illumination" (Qwen) — civitai.com/models/1856273

**Prompt universal (Seedream):** `Ultra-high-resolution codex scan, an illuminated manuscript image, gold leaf making the vellum page emit its own light, ornate initial letters with ultramarine and minium red, Très Riches Heures precision, living creatures in the margins, 8k`

### **Impressionism**

**№ 463 / 1001** — *Monet's Haystack Changes Color Before the Brush Dries*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → NUANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**O palheiro de Monet muda de cor antes do pincel secar** — (1001 Aesthetics; código: sref-midjourney.com, confirmado)

Impressionismo: luz capturada em pinceladas soltas, cor quebrada e instante fugidio, a atmosfera acima do contorno.

**Paleta de cores** lilás de sombra, dourado de feno, azul de ar livre, rosa de amanhecer

**Melhores usos:** arte, paisagem, editorial poético

**MidJourney:** `--sref 151289788 --sw 1000` (Poetic Impressionism); alternativa: `--sref 2383924935` (Pastel Impression)

**LoRA (Civitai):** "Monet's Touch — Impressionist" (Flux) — civitai.com/models/1959748; "Claude Monet" (FLUX) — civitai.com/models/705130

**Prompt universal (Seedream):** `Museum-grade oil painting reproduction, an impressionist painting, a haystack changing color before the brush dries like Monet's series, broken color in loose visible strokes, lilac shadows and hay gold in fleeting open-air light, 8k`

### **Komorebi**

**№ 506 / 1001** — *Sacred light through camphor leaves*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Luz sagrada através das folhas de cânfora** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Komorebi: a palavra japonesa para o sol filtrado pelas árvores, dourado pontilhado e sombra verde profunda.

**Paleta de cores** dourado filtrado, verde profundo, sombra de trilha

**Melhores usos:** fotografia contemplativa, natureza, editorial zen

**MidJourney:** `[tema], komorebi aesthetic, sacred sunlight through camphor leaves, dappled gold, shrine path --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-T5 with 56mm lens, a komorebi image, sacred light sifting through camphor leaves onto a shrine path, dappled gold and deep green shadow, Rinko Kawauchi luminous ephemera, the sun made visible by the tree, 8k`

### **Light Academia**

**№ 523 / 1001** — *Cream paper, oat blazers, morning desk*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Papel creme, blazer de aveia, escrivaninha matinal** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Light academia: o estudo como ritual gentil, madeira mel e café com leite em luz de janela.

**Paleta de cores** creme, aveia, madeira mel

**Melhores usos:** lifestyle, editorial, moda

**MidJourney:** `[tema], light academia aesthetic, cream paper and oat blazer at a morning desk, soft window light --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 85mm lens, a light academia image, cream paper and an oat blazer at a morning desk, honeyed wood and white coffee in soft window light, study as gentle ritual, optimism with footnotes, 8k`

### **Lunar**

**№ 539 / 1001** — *Tidal pull and silver crescent light*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Maré puxada e luz de crescente prateado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lunar: a gravidade tornada visível, sombra de cratera na linha do terminador, platina fria sobre água negra.

**Paleta de cores** platina, prata, negro de mar noturno

**Melhores usos:** astro, editorial poético, arte

**MidJourney:** `[tema], lunar aesthetic, silver crescent pulling the tide, crater shadow along the terminator, cold platinum light --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS Ra with 600mm lens, a lunar image, a razor silver crescent pulling the tide across a black glass sea, crater shadows etched deep along the terminator line, cold platinum light laying one trembling path over the water, Ansel Adams tonal discipline at astronomical distance, gravity made quietly visible, 8k`

### **Metaverse**

**№ 566 / 1001** — *Digital Worlds With Persistent Social Gravity*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Mundos digitais com gravidade social persistente** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Metaverso: avatares reunidos em praças que nunca fecham, arquitetura impossível em luz renderizada.

**Paleta de cores** gradientes digitais, neon de avatar, horizonte renderizado

**Melhores usos:** tech, campanha, arte conceitual

**MidJourney:** `[tema], metaverse aesthetic, avatars gathering in an impossible digital plaza, persistent virtual world --v 6`

**Prompt universal (Seedream):** `Ultra-crisp 3D virtual world render, a metaverse image, avatars gathering in an impossible floating plaza that never closes, gradient skies cycling over rendered architecture with no weather and no dust, neon nametags drifting above the crowd, persistent social gravity binding a world that exists only while believed in, flawless real-time engine light, 8k`

### **Microflora**

**№ 568 / 1001** — *Forest Smaller Than a Fingernail*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Floresta menor que uma unha** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Microflora: musgos e esporos como dossel em miniatura, esmeralda orgânica em gota de orvalho.

**Paleta de cores** esmeralda de musgo, orvalho, marrom de húmus

**Melhores usos:** natureza macro, ciência, editorial

**MidJourney:** `[tema], microflora aesthetic, moss forest smaller than a fingernail, spore stalks and dew drops --v 6`

**Prompt universal (Seedream):** `Focus-stacked macro photograph shot on Sony A6700 with 90mm macro lens, a microflora image, a moss forest smaller than a fingernail with spore stalks rising through morning dew, emerald canopy glowing over humus brown, each water drop a lens holding the whole sky, Levon Biss museum-scale attention, wilderness complete at thumbnail size, 8k`

### **Neumorphism**

**№ 615 / 1001** — *Interfaces Pressed from Digital Foam*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Interfaces prensadas em espuma digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neumorfismo: botões que afundam suavemente na própria superfície, sombras duplas e maçiez tátil.

**Paleta de cores** cinza-pérola, branco suave, sombras gemelares

**Melhores usos:** UI, produto, branding tech

**MidJourney:** `[tema], neumorphism aesthetic, soft extruded interface pressed from digital foam, twin shadows --v 6`

**Prompt universal (Seedream):** `Ultra-crisp UI design render, a neumorphic interface pressed from digital foam, soft extruded buttons sinking into their own pearl-gray surface, twin light and dark shadows defining every edge, tactile matte softness with obsessive alignment, 8k product-design clarity`

### **Neuromanticism**

**№ 616 / 1001** — *Brain Drawn in Gold Leaf*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Atmosfera e mood**

**Cérebro desenhado em folha de ouro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neurorromantismo: dendritos dourados como galhos de Klimt, a mente tratada como paiságem sagrada.

**Paleta de cores** ouro, índigo profundo, rosa sináptico

**Melhores usos:** ciência, arte, editorial

**MidJourney:** `[tema], neuromanticism aesthetic, gilded neural dendrites, brain as sacred landscape --v 6`

**Prompt universal (Seedream):** `Ultra-detailed mixed-media artwork, a human brain drawn in gold leaf, gilded dendrites branching like Klimt trees across deep indigo, synaptic sparks in rose and amber, the mind treated as sacred landscape, luminous museum finish, 8k`

### **Noir**

**№ 629 / 1001** — *Shadow as Moral Language*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → ETERNITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Moralidade em preto e branco, ambos negociáveis** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Noir: persianas cortando o rosto, fumaça de cigarro na luz dura e ninguém inteiramente inocente.

**Paleta de cores** preto profundo, branco cortante, cinza de fumaça

**Melhores usos:** cinema, retratos, capas

**MidJourney:** `[tema], film noir aesthetic, venetian blind shadows cigarette smoke, negotiable morality --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Double-X film with 40mm lens, a film noir frame, venetian blind shadows slicing a guarded face, cigarette smoke curling through one hard shaft of light, John Alton darkness where nobody is entirely innocent, deep black and cutting white, 8k scan`

### **Nordic**

**№ 632 / 1001** — *Light as the Landscape's Only Luxury*

**Nível:** 🔴 Primária

**Eixo:** ILLUMINATION ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Atmosfera e mood**

**Luz baixa de inverno como único luxo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nórdico: madeira pálida, lã grossa e um sol rasante que dura três horas e vale o dia inteiro.

**Paleta de cores** branco de neve, cinza-azulado, madeira clara

**Melhores usos:** interiores, lifestyle, branding

**MidJourney:** `[tema], nordic aesthetic, low winter light as the only luxury, pale wood thick wool --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 7 II with 43mm lens, a Nordic interior, pale birch wood and thick undyed wool washed by low winter sun through a deep window, snow-white and blue-gray restraint where three hours of light become the whole luxury, serene medium-format clarity, 8k`

### **Orphism**

**№ 655 / 1001** — *Color Leaves the Object and Starts Singing*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Cor girando até virar música** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Orfismo: discos concêntricos de cor pura, abstração solar que canta em círculos.

**Paleta de cores** espectro completo em círculos, laranja solar

**Melhores usos:** arte, padrões, capas

**MidJourney:** `[tema], orphism aesthetic, concentric discs of pure color, abstraction singing in circles --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an orphist painting, concentric discs of pure prismatic color spinning until they become music, Robert and Sonia Delaunay simultaneous contrast around a solar orange core, rhythmic circular abstraction in luminous flat oil, 8k scan`

### **Pearlcore**

**№ 677 / 1001** — *Irritation Polished Into Moonlight*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → NUANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Irritação polida até virar joia** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pearlcore: nácar, luz de lua e superfícies que respondem em tons de dentro de concha.

**Paleta de cores** branco perolado, rosa de nácar, prata de lua

**Melhores usos:** joias, beleza, produto

**MidJourney:** `[tema], pearlcore aesthetic, nacre moonlight iridescence, irritation polished into jewel --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX50S with 120mm macro lens, a pearlcore still life, loose pearls spilling across mother-of-pearl shell in cool moonlight tones, nacre iridescence shifting between pearl white and blush pink, an irritation patiently polished into jewelry, luminous macro detail, 8k`

### **Photognosis**

**№ 683 / 1001** — *Light as Language of Truth*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Luz como linguagem direta da verdade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Fotognose: fotogramas sem câmera, objetos falando por suas sombras diretamente no papel.

**Paleta de cores** prata fotográfica, branco de exposição, preto profundo

**Melhores usos:** arte, experimental, editorial

**MidJourney:** `[tema], photognosis aesthetic, cameraless photogram, objects speaking through their shadows --v 6`

**Prompt universal (Seedream):** `Fine-art photogram in the darkroom tradition of Man Ray, everyday objects speaking through their own shadows directly onto silver paper, ghostly whites bleeding into profound black, light used as the unmediated language of truth, cameraless poetry in archival detail, 8k scan`

### **Prismatic**

**№ 722 / 1001** — *Newton's Prism Becomes a Belief System*

**Nível:** 🔴 Primária

**Eixo:** ILLUMINATION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática é transmitida como continuidade reconhecível, mantendo a relação luminosa herdada.

**Nota genealógica original (EN):** Newton's prism event — one white beam bent into seven named rays read as revelation — is passed forward intact as the founding scripture; every successor expression repeats the identical gesture without cutting the parent grammar.

**Atmosfera e mood**

**Luz branca confessando suas cores** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Prismático: o espectro aberto em leque, arestas de vidro e arco-íris cortados com precisão óptica.

**Paleta de cores** espectro completo, vidro, branco de laboratório

**Melhores usos:** arte, produto, capas

**MidJourney:** `[tema], prismatic aesthetic, white light split through a glass prism, spectrum fanned in precision --v 6`

**Prompt universal (Seedream):** `Studio photograph of light through a triangular glass prism, a white beam confessing its full spectrum across matte paper, Newton's experiment staged with laboratory precision, razor rainbow edges and clean glass reflections in darkness, optical purity, 8k`

### **Prismatic Perfection**

**№ 723 / 1001** — *Light Achieved Consciousness*

**Nível:** 🔴 Primária

**Eixo:** ILLUMINATION ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Nota genealógica original (EN):** Pythagorean harmonic cosmology, Suhrawardi's Ishraqi light-philosophy, and Dzogchen's clear-light doctrine were each complete systems before this aesthetic existed; here they are recombined into a single equation — light as consciousness — that none of the three sources could produce alone.

**Atmosfera e mood**

**A luz alcançando consciência** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Perfeição prismática: cáusticas imaculadas, cristais impossíveis e o arco-íris renderizado sem uma imperfeição.

**Paleta de cores** iridescência total, cristal, branco absoluto

**Melhores usos:** arte digital, produto, capas

**MidJourney:** `[tema], prismatic perfection aesthetic, flawless crystal caustics, light achieving consciousness --v 6`

**Prompt universal (Seedream):** `Ultra-crisp 3D render, prismatic perfection, caustic rainbows refracting through flawless impossible crystals onto absolute white, light behaving as if it achieved consciousness, full iridescence with zero imperfection, physically accurate raytraced dispersion, 8k`

### **Provençal Charming**

**№ 729 / 1001** — *Ochre, Mistral, and the Long Afternoon*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The Mediterranean grammar of sun-warmed stone, cultivated terrace, and shuttered façade is re-instrumented through the regional filter of iron-oxide cliff and mistral wind — the inherited template is not cut but re-keyed to a single delta of land, so that Aegean cobalt becomes ochre render and Iberian whitewash becomes olive grey.

**Atmosfera e mood**

**Ocre, lavanda e a tarde que não acaba** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Provençal: janelas azul-desbotado em paredes de ocre, mercado de lavanda e o mistral penteando os plátanos.

**Paleta de cores** ocre de parede, lavanda, azul desbotado

**Melhores usos:** viagem, interiores, editorial

**MidJourney:** `[tema], provençal charming aesthetic, ochre walls faded blue shutters lavender market, endless afternoon --v 6`

**Prompt universal (Seedream):** `Shot on Fuji Velvia 50 with 50mm lens, a Provençal scene, faded blue shutters on ochre walls above a lavender market stall, plane-tree shade combed by the mistral through an afternoon that refuses to end, saturated southern light and honest charm, 8k scan`

### **Radiology**

**№ 740 / 1001** — *Body Revealed as Shadow Architecture*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → MATTER ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de revelação ao romper uma convenção luminosa anterior.

**Nota genealógica original (EN):** The clinical-scientific gaze of accurate observation is inherited as the premise, then the operating surface is cut; Radiology refuses the skin all authority and reroutes seeing through matter rather than onto it, removing the one move — surface observation — that made clinical diagnosis clinical.

**Atmosfera e mood**

**O corpo como arquitetura de sombras** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Radiologia: raio-X em azul-cianotipo, ossos como vigas e o interior humano lido como planta baixa.

**Paleta de cores** azul de raio-X, branco de osso, preto clínico

**Melhores usos:** ciência, arte, editorial

**MidJourney:** `[tema], radiology aesthetic, x-ray bones as beams, the body read as blueprint --v 6`

**Prompt universal (Seedream):** `High-resolution X-ray photograph, the body rendered as shadow architecture, bones reading like structural beams in cyanotype blue against clinical black, soft tissue as translucent gray veils, the human interior studied like a blueprint, diagnostic-grade clarity, 8k`

### **Reverent**

**№ 758 / 1001** — *Design That Kneels Before the Sacred*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Classical proportion's compass-and-straightedge grammar arrives intact, and Reverent re-instruments it by redirecting the same ratios — the golden section, the √2 rectangle — from the celebration of human harmony toward an order that precedes and exceeds the human, so the inherited geometry no longer measures the perfected body but argues for a divine that made it.

**Atmosfera e mood**

**Silêncio inclinado diante do maior** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Reverente: velas na catedral, cabeças baixas e a luz descendo como se soubesse onde pisar.

**Paleta de cores** dourado de vela, sombra de nave, azul de vitral

**Melhores usos:** espiritual, editorial, arte

**MidJourney:** `[tema], reverent aesthetic, candlelit cathedral bowed heads, light that knows where to step --v 6`

**Prompt universal (Seedream):** `Shot on 35mm with 50mm f/2 lens, a reverent scene inside a candlelit cathedral, bowed heads in pews as stained-glass blue drifts down through incense, candle gold against nave shadow, silence bending before something larger, hushed available-light grain, 8k`

### **Seapunk**

**№ 791 / 1001** — *Surfing the Digital*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Nota genealógica original (EN):** Seapunk and Vaporwave rise from one shared root — 1990s net art and rave-culture kitsch — with neither descended from the other, and Seapunk fuses that common inheritance with oceanic fantasy into a single narrowed register neither source could produce alone; drag the whole ironic-commodity vocabulary underwater and rave kitsch, net art, and reef fantasy weld into one glowing register, so the checkerboard floor and the neon dolphin are welded together rather than descended in a line.

**Atmosfera e mood**

**Surfando o digital em aqua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Seapunk: golfinhos em grades 3D, gradientes aqua e a internet de 2012 sonhando com um oceano de pixels.

**Paleta de cores** aqua, turquesa de tela, roxo de gradiente

**Melhores usos:** arte digital, música, capas

**MidJourney:** `[tema], seapunk aesthetic, dolphins on 3D grids aqua gradients, 2012 internet dreaming in pixels --v 6`

**Prompt universal (Seedream):** `Ultra-vivid digital collage, a seapunk composition, chrome dolphins leaping over a 3D wireframe ocean under an aqua-to-purple gradient sky, spinning yin-yangs and pixel palm trees from the 2012 Tumblr web, the internet dreaming itself as an ocean, glossy early-net sheen, 8k`

### **Silicon Dreams**

**№ 807 / 1001** — *Machines caught dreaming in pixels*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Early computer-graphics research culture — the labs that first taught machines to draw lines, then surfaces, then worlds — arrives as the single parent, and Silicon Dreams re-instruments that inheritance by turning demonstration exercises built to prove a technique into visions built to enchant, so a wireframe sphere meant to test a rendering algorithm becomes, one turn later, a chrome dream floating over an infinite grid.

**Atmosfera e mood**

**Máquinas flagradas sonhando em pixels** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sonhos de silício: redes neurais em repouso, luz pulsando por circuitos — o subconsciente da máquina visualizado.

**Paleta de cores** azul de circuito, violeta de sonho, brilho de dado

**Melhores usos:** tecnologia, conceito, arte digital

**MidJourney:** `[tema], silicon dreams aesthetic, resting neural networks pulsing circuits, machines caught dreaming in pixels --v 6`

**Prompt universal (Seedream):** `Ultra-detailed 3D render, silicon dreams, a sleeping server's neural pathways glowing in slow violet pulses across circuit-board cities, pixel fragments drifting upward like REM imagery, the machine subconscious visualized in dream blue and data glow, cinematic depth, 8k`

### **Spycore**

**№ 843 / 1001** — *Trench coats, dead drops, and calculated cool*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Nota genealógica original (EN):** Film noir's shadow grammar, Cold War modernism's institutional architecture, and military field doctrine's equipment logic are welded into one form, no single ancestor surviving intact, so three lineages fuse into an espionage register that none of the three could produce alone.

**Atmosfera e mood**

**Trench coats, dead drops e frieza calculada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Spycore: Berlim na Guerra Fria, envelope deixado no banco da praça e o olhar que confere o reflexo da vitrine antes de atravessar.

**Paleta de cores** cinza de gabardine, sódio de poste, sombra de checkpoint

**Melhores usos:** editorial, cinema, conceito

**MidJourney:** `[tema], spycore aesthetic, cold war Berlin trench coat dead drop, calculated cool --v 6`

**Prompt universal (Seedream):** `Shot on a Minox subminiature spy camera, a spycore frame in Cold War Berlin, a gabardine trench pausing at a park bench where an envelope waits under yesterday's newspaper, sodium lamplight and checkpoint shadow, the glance checking a shop-window reflection before crossing, grainy clandestine tension, 8k scan`

### **Tropical**

**№ 910 / 1001** — *Heat, Broadleaf Shade, and Open-Air Ease*

**Nível:** 🟤 Terciária

**Eixo:** ILLUMINATION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Fontes e linhagens distintas são recombinadas numa nova gramática de luz e visibilidade.

**Nota genealógica original (EN):** European Exoticism's projected paradise and regional vernacular building and craft converge here, each supplying a load-bearing layer nothing else replaces, fixing Tropical as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Calor, sombra de folha larga e leveza ao ar livre** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tropical: a varanda aberta sob bananeiras, ventilador de teto girando devagar e a vida acontecendo sem parede entre dentro e fora.

**Paleta de cores** verde de folha larga, branco de varanda, amarelo de manga

**Melhores usos:** interiores, viagem, lifestyle

**MidJourney:** `[tema], tropical aesthetic, open veranda under banana leaves slow ceiling fan, heat and open-air ease --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R5 with 24mm lens, a tropical veranda, broadleaf banana shade dappling white wicker as a ceiling fan turns slow over sliced mango and sweating glasses, leaf green and veranda white breathing in open-air heat, no wall left between inside and out, languid humid ease, 8k`

### **Vectorcore**

**№ 942 / 1001** — *Digital Precision With No Grain to Hide*

**Nível:** 🟣 Secundária

**Eixo:** ILLUMINATION ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem luminosa reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Vectorcore reinterprets the random-scan vector display's luminous-line grammar alone, promoting the coordinate stroke from engineering signal to visual law without fusing in a second structural parent.

**Atmosfera e mood**

**A precisão digital sem grão onde se esconder** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vectorcore: curvas de Bézier perfeitas, cores chapadas sem ruído e a honestidade radical de uma imagem que não pode fingir textura.

**Paleta de cores** azul de interface, coral chapado, branco absoluto

**Melhores usos:** design, ilustração, branding

**MidJourney:** `[tema], vectorcore aesthetic, perfect bezier curves flat noiseless color, digital precision with no grain to hide --v 6`

**Prompt universal (Seedream):** `Ultra-crisp flat vector illustration, a vectorcore composition, perfect Bézier curves building a landscape of flat coral and interface blue with zero gradient noise, every anchor point exactly where it must be on absolute white, digital precision with no grain left to hide behind, immaculate geometric clarity, 8k`

### **Winter**

**№ 979 / 1001** — *Crystalline Stillness Under a White Horizon*

**Nível:** 🔴 Primária

**Eixo:** ILLUMINATION ↓ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de revelação ao romper uma convenção luminosa anterior.

**Nota genealógica original (EN):** No design movement fathered this; the cold season did — strip away Northern landscape painting, alpine modernism, and the festive calendar and the look still stands, because its source is a planetary tilt, not a studio, the mark of a root node no lineage can reduce.

**Atmosfera e mood**

**A quietude cristalina sob o horizonte branco** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Inverno: a neve absorvendo o som do vale, galhos vidrados de gelo e o fôlego visível como único movimento na paisagem inteira.

**Paleta de cores** branco de neve funda, azul de sombra gelada, cinza de galho vidrado

**Melhores usos:** natureza, editorial, capas

**MidJourney:** `[tema], winter aesthetic, snow absorbing the valley's sound ice-glazed branches visible breath, crystalline stillness --v 6`

**Prompt universal (Seedream):** `Shot on Bronica SQ-A with 80mm lens, a winter morning, fresh snow absorbing every sound in the valley as ice-glazed branches hold perfectly still under a white horizon, deep-snow white and frozen shadow blue with one plume of visible breath as the only movement, crystalline muffled serenity, 8k`

## Leitura do padrão — o que as 48 estéticas confirmam

A lista inteira de ILLUMINATION confirma que o sistema mede **governo da revelação, não quantidade de brilho** — e é a lista onde o polo suprimido é mais eloquente.

### Quatro entradas suprimidas — e duas maneiras de abdicar

Winter, Dark Elegance, Dark Naturalism e Film Noir são os quatro ILLUMINATION ↓, e eles se dividem exatamente como o registro prevê. Winter abdica pelo nivelamento total — a luz de neve encoberta, sem aresta de sombra, tudo declarado ("Crystalline Stillness Under a White Horizon", a rara ruptura-raiz cuja fonte é a inclinação do planeta, não um estúdio). Dark Elegance e Dark Naturalism abdicam pelo extremo oposto — a recusa da luz do dia como método, a escuridão como chão e não como fase, com a matéria assumindo o governo (par → MATTER ↑). E Film Noir entrega a persiana à SEMIOTICS — a sombra listrada que sobrevive como código herdado, não como revelação. Nota fina do Locus: **Noir** (№ 629) é ILLUMINATION ↑ e **Film Noir** (№ 329) é ILLUMINATION ↓ — a sombra como linguagem moral ainda governa; a sombra como convenção apenas assina.

### Cinco famílias recorrentes

**1. A luz como hora** — DAWN, Duskcore, Lunar, Komorebi, Daylight, Aetherial, Deep Sea, Nordic: a revelação por fase literal — o gaffer é o planeta. Nordic é a tese primária do cluster: "Light as the Landscape's Only Luxury".

**2. A luz emitida** — Metaverse, Silicon Dreams, Vectorcore, Neumorphism, Seapunk, Frutiger Aero, e o trio Acid (Pixie, Fairycore, Acidgoth) com Alien e Dazzling: a fonte sem sol — tela, neon, blacklight; o cluster onde EFFECT ↑ e EMANATIO ↑ aparecem como pares recorrentes.

**3. A luz como doutrina** — Prismatic ("Newton's Prism Becomes a Belief System"), Prismatic Perfection, Photognosis, Illuminated, Enlightenment, Reverent, Neuromanticism: a luz lida como linguagem de verdade ou consciência; pares recorrentes SEMIOTICS ↑ e EMANATIO ↑.

**4. A luz encontrando a matéria** — o par → MATTER ↑ (Frutiger Aero, Elemental Fire, Golden, Nordic, Après-Ski) e o espelho exato → MATTER ↓ (Ethereal, Radiology, Silicon Dreams, Vectorcore): a mesma luz que faz o ouro pesar consegue dissolver o corpo — o gauze retroiluminado meio-dissolvido e o corpo revelado como arquitetura de sombra.

**5. A luz como gradação e clima** — Impressionism, Danish Pastel, Pearlcore (→ NUANCE ↑); Dewy, Provençal Charming, Duskcore, Anthotype (→ RESONANCE ↑): a fase desacelerada até virar nuance ou atmosfera.

### Polaridades

as luzes naturais transmitem intactas (DAWN, Komorebi, Lunar, Deep Sea, Daylight, Golden, Elemental Fire, Nordic, Ethereal, Prismatic, Alien — XX-transmission: ninguém revisa o sol); as luzes tecnológicas e de cena rearticulam (o trio Acid, Spycore, Bombshell, Neumorphism, Impressionism, Seapunk — XY-rearticulation: fusões de linhagens); e Winter é a ruptura sem autor — a estação como fonte.

### O teste operacional

ILLUMINATION não é "boa iluminação" — é qualquer estética cuja prova visual responde a uma pergunta só: *a luz decide o que se vê?* Por isso Bombshell, Komorebi e Radiology convivem: a boca laqueada lida primeiro, a luz sagrada entre folhas e o corpo revelado por atravessamento são objetos incomparáveis, mas todos passam pelo mesmo teste — e os quatro ↓ mostram o instrumento por dentro: quando a luz abdica do governo, ou tudo é declarado, ou outro instrumento assume o trono.

# SEMIOTICS — o Trigrama de Fogo

<aside>
☲

**Essência.** SEMIOTICS mede a complexidade, a procedência e a legibilidade dos sistemas de signos. Seu ideograma é Li, o Trigrama de Fogo — duas linhas inteiras ao redor de uma linha partida: o signo brilha por fora, mas só permanece vivo quando se agarra à gramática e à comunidade que o sustentam. No registro ↑, um código decodificável divide o público entre quem reconhece pertencimento e quem vê apenas aparência; no registro ↓, a remoção do signo continua legível como vestígio.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para SEMIOTICS, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem o dispositivo codificado próprio de cada estética, enquanto a arquitetura preserva a lógica de Li — um código sem comunidade é apenas decoração.

> **↑ SEMIOTICS — universal prompt.** A figure standing at [the aesthetic's own threshold world: a club doorway, a members' room, a backstage corridor, a marked gate] whose natural stance presents one decodable device — [the aesthetic's own coded element: a knot tied the meaningful way, a pin at the exact placement, a marked cuff, a lining flashed in a coded colour] — at reading height; a hand resting near the device without pointing at it, the initiate's unconscious touch, or one coded gesture performed as habit rather than display; a complicit gaze aimed slightly past the lens at someone who understands, the held almost-smile of shared knowledge, the face of a member rather than a mannequin; one deliberate mark reading as affiliation — [the aesthetic's own grooming code: a drawn line at the cheekbone, a specific parting, a single earring in a meaningful position] — grooming exact by the tribe's own logic, never by fashion logic; classic or uniform-adjacent dress carrying the device, the same motif echoed once more at smaller scale in [the aesthetic's own echo carrier: a ring, a stitch, a sole]; photographed on a 35mm at f/5.6 from across the room at a fellow member's eye height, sign and context both legible; the device placed on a focal intersection and its echo on a secondary line, the background holding the community that ratifies the code — half-seen figures, signage, a doorway; motivated location light — doorway spill, sign-glow, interior tungsten — with one accent quietly favouring the device, the code lit like information rather than jewelry; a threshold ground where objects repeat the motif for those who look twice, the image built to divide its audience into those who decode it and those who only see a garment.
> 

**Universal SEMIOTICS ↓ negative line (always pair with the ↑ prompt):**

> No literal text or logos spelled out, no pointing at the device, no product-shot lighting on the sign, no empty studio background, no mannequin blankness, no costume-party excess, no cut-out labels or ghost stitching, no blank flags, no forensic copy-stand framing, no deadpan administrative expression, no sign left without a community to ratify it.
> 

**Como usar para as 111 estéticas da lista.** Troque os colchetes pelo dispositivo próprio da estética — a arquitetura só nomeia mecanismos (o signo em altura de leitura, o eco em escala menor, a comunidade que ratifica, a luz motivada que favorece a informação). Exemplos: para **Black Power**, o punho que dispensa legenda — o signo gerado na raiz, sem pai; para **Stealth Wealth / Snob**, a etiqueta virada para dentro que só um igual sabe precificar — o código pelo corte; para **Ivy League / Royalcore**, o brasão e o suéter Shetland — o código que envelhece em instituição; para **Hypebeast / Paninaro**, a fila e a escassez como prova de pertencimento — o signo sem o lastro da vida que o sustentaria; para **Victorian Mourning**, o azeviche e o crepe como gramática codificada do luto; para **Venetian Carnival**, a máscara como permissão — o ocultamento que licencia; para **Memecore / Vaporwave**, a piada que virou dialeto visual — o détournement como assinatura; para **CONCEPTUAL ART / Simulacrum**, mantenha o signo no comando e empurre a matéria para o registro ↓ do MATTER — a ideia como obra, o objeto como nota de rodapé. Lembre a exceção licenciada: o trigrama de três barras pode entrar em quadro como dispositivo físico — uma vez por imagem, e uma só.

## Fundamentos do elemento

### Identidade, aderência e audiência dividida

**Identity.** Complexity, provenance, and legibility of sign systems. Its ideogram is Li, the fire trigram, two whole lines around a broken one: the oldest binary code in continuous use, naming the fire that burns bright outside and hollow at the centre, existing only by clinging to what sustains it. A sign means nothing without shared grammar. In an image this element is proven by one decodable, sourced sign, or by signs stripped until the image resists decoding. One exception is declared here: the ↑ prompt below plants the trigram itself in frame as a physical device — the only place in the glossary where an ideogram enters its own prompt, a deliberate self-demonstration of the sign that exists only by clinging to its grammar. At assembly, the mark may appear once, and only once.

**The clinging law.** Li names the mechanism exactly: fire exists only by clinging to what sustains it. A device severed from its community reads as decoration, so the frame must carry both the mark and the world that ratifies it — half-seen figures, answering signage, a doorkeeper's pin. The suppressed register inverts the law without escaping it: the cut label and the ghost stitching still signify, but what they signify is removal — a forensic record of designification, legible only because the sign was once there.

**The divided audience.** The image's test is sociological: it must produce two readings at once — membership at a glance for the initiate, mere garment for the outsider. If everyone can decode it, it is advertising; if no one can, it is noise. The second reading must reward attention: the motif echoed once at smaller scale, placed where only the eye that already knows will look.

## Corpo — postura, gesto e olhar

**Model posture & structure.** Posture that presents the sign at reading height — the coded element held at chest or eye level by the natural stand of the body; the stance of belonging, relaxed inside the code. Suppressed register: neutral frontal catalog stance, feet parallel, the body as an evidence stand.

**Gesture.** A hand resting near the device without pointing at it — the initiate's unconscious touch; or a coded gesture itself (a specific way of holding a lapel, a two-finger grip) performed as habit, not display. Suppressed: none, or hands holding the garment open flat to show the absence — the cut label, the unpicked emblem.

**The look — how the eyes behave.** Complicit, aware gaze — slightly past the lens toward someone who understands; the micro-expression of shared knowledge, a held almost-smile; the face of a member, not a mannequin. Suppressed: deadpan administrative expression, eyes level and uninvested — the face of a document, not a wearer.

## Regras de imagem — do código à prova de pertencimento

**Look & styling continuity.** Classic tailoring or uniform-adjacent dress carrying one insider device — the knot tied the meaningful way, the badge in the exact placement, the lining flashed in a coded colour; the same motif echoed once more at smaller scale (ring, stitch, sole). Suppressed: labels cut out, ghost stitching where insignia were unpicked, a blank armband — the visible scar of removed meaning.

**Camera.** 35mm environmental at f/5.6 — sign and context both legible; camera at the height of a fellow member across the room; close enough to decode, far enough to show the world that gives the sign meaning. Suppressed: 50mm frontal at f/8, evidence-record framing, consistent copy-stand geometry, no angle rhetoric.

**Composition.** The device placed on a focal intersection; its echo on a secondary line; the background containing the community that ratifies the code — half-seen figures, signage, a doorway; the frame constructed so the second reading rewards attention. Suppressed: centred, symmetrical, catalog register — nothing echoes anything.

**Lighting.** Motivated location light — doorway spill, sign-glow, interior tungsten — with one accent quietly favouring the device; the code lit like information, never like jewelry advertising. Suppressed: flat, even, forensic — twin soft sources, zero accent, shadows neutralized.

**Beauty detail.** Codified beauty — one deliberate mark that reads as affiliation: a drawn line at the cheekbone, a specific parting, a single earring in a meaningful position; grooming exact but with subculture logic, not fashion logic. Suppressed: scrubbed neutrality — clean bare skin, hair pulled flat, no mark of any kind.

**Cenography.** A threshold world — club doorway, members' room, backstage corridor; coded signage, a doorkeeper's presence implied; objects in the set that repeat the motif for those who look twice. Suppressed: seamless grey or an institutional wall, a numbered card or empty hook the only prop — the anti-club.

**Colour.** Palette obeying the tribe's chart rather than the season's — the coded colour carried in one flash of lining, one accent the initiated recognize as assignment, the rest disciplined so the code stays the loudest colour decision. Suppressed: institutional neutrals, colour drained of any assignment.

**Membership proof.** Wherever the frame allows it, plant one device proving the code has a community: the motif recurring at smaller scale, a half-seen figure wearing the same mark, the doorkeeper's pin answering the armband. A sign that no one else in the image's world could read is this instrument's most legible failure — decoration wearing the costume of code.

**Practitioner lines (from the codices).** Terence Donovan — two sign systems fashion keeps separate photographed in contact under hard neutral flash, brick and chain-link kept legible against couture, neither side softened. Helmut Newton — a fixed vocabulary of recurring coded props returned to until the audience reads it without caption. Steven Meisel — every era's grammar reconstructed forensically until the image reads as coded text to those who know the reference and pure glamour to those who don't. Estelle Hanania — European folk masquerade and carnival ritual decoded, costume read as an ancient sign system still transmitting. For the stripped register: Casper Sejersen — clinical forensic precision, cold restraint, every frame premeditated like evidence the viewer must decode.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** One legible insider device placed where a knowing viewer reads membership at a glance: an armband, a pin, a knot echoed across garment and setting, decoration to outsiders, code to initiates.

> **↑ Prompt.** A club doorway at night, the model's jacket carrying one exact decodable device, a three-bar armband with two solid bars and one broken, echoed in the door's neon sign and the doorkeeper's pin, the insider mark placed where a knowing viewer reads membership at a glance and an outsider sees only decoration.
> 

> **↑ Negative line.** No literal text or logos spelled out, no pointing at the device, no product-shot lighting on the sign, no empty studio background, no mannequin blankness, no costume-party excess.
> 

**↓ Suppressed — repertory.** Signs stripped: labels removed, embroidery unpicked to ghost stitching, blank flags, frontal evidence-record framing, the image refusing to be read as a message.

> **↓ Prompt.** A figure in garments deliberately scrubbed of signs, labels cut out, embroidery unpicked leaving ghost stitching, a blank folded flag over the arm, photographed frontally like an evidence record, the image refusing every attempt to decode it.
> 

> **↓ Negative line.** No insider devices, no echoes or motifs, no complicit expression, no motivated location light, no community in the background, no accessories.
> 

## Estéticas relacionadas a SEMIOTICS (A–Z)

As 111 estéticas classificadas sob SEMIOTICS, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Advertising**

**№ 025 / 1001** — *Want, manufactured on schedule*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**Desejo fabricado no prazo** — (1001 Aesthetics, interpretação)

Publicidade clássica: produto heroico, luz de estúdio perfeita, composição que vende.

**Paleta de cores** alta saturação controlada sobre fundos limpos

**Melhores usos:** fotos de produto, mockups, campanhas

**MidJourney:** `[tema], polished advertising photography, studio lighting --v 6`

**Prompt universal (Seedream):** `High-end product photograph shot on Phase One with 120mm macro lens, hero object floating on a seamless minimal backdrop, perfect three-point studio lighting with controlled specular highlights, glossy commercial finish and razor-sharp edge detail, saturated yet disciplined palette, award-winning campaign polish, 8k`

### **Agender Fashion**

**№ 035 / 1001** — *Tailoring with no gender column*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → THEME ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Alfaiataria sem coluna de gênero** — (1001 Aesthetics, interpretação)

Moda sem gênero: alfaiataria fluida, silhuetas neutras, minimalismo estrutural.

**Paleta de cores** neutros — preto, branco, cinza, bege

**Melhores usos:** moda, editorial, branding

**MidJourney:** `[tema], agender fashion editorial, gender-neutral fluid tailoring --v 6`

**Prompt universal (Seedream):** `Fashion editorial shot on medium format with 80mm lens, androgynous model in fluid gender-neutral tailoring, structural minimal silhouette in monochrome black white and gray, clean seamless studio set, single soft key light with a precise shadow line, quiet radical elegance, Vogue-grade sharpness, 8k`

### **Americana**

**№ 044 / 1001** — *Porch, not the flag*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Atmosfera e mood**

**A varanda, não a bandeira** — (1001 Aesthetics; código: kajimelo.com)

América cotidiana e nostálgica: varandas, diners, estradas de interior, textura de impressão vintage.

**Paleta de cores** vermelho desbotado, azul jeans, creme, textura de papel envelhecido

**Melhores usos:** nostalgia, branding rústico, editorial

**MidJourney:** `--sref 946229656 --sw 1000` (Vintage Print Texture & Americana Outdoors)

**Prompt universal (Seedream):** `Nostalgic photograph shot on Kodak Portra 400 with 35mm lens, a small-town front porch and main street at dusk, faded red white and denim blue, string lights and pickup trucks, vintage print texture with warm grain, Norman Rockwell everyday warmth, timeless American memory`

### **Anarchism**

**№ 045 / 1001** — *Order without authority*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Atmosfera e mood**

**Ordem sem autoridade** — (1001 Aesthetics, interpretação)

Gráfica punk-anarquista: xerox, colagem, estêncil, tipografia recortada, espírito DIY.

**Paleta de cores** preto e branco de fotocópia com vermelho de protesto

**Melhores usos:** pôsteres, zines, protesto

**MidJourney:** `[tema], anarchist punk zine collage, stencil and xerox --v 6`

**Prompt universal (Seedream):** `High-resolution scan of an anarchist punk zine graphic, xeroxed photocopy collage with authentic toner texture and staple shadows, cut-out ransom-note typography and stencil spray paint, black white and protest red, torn paper layers, raw DIY urgency in extreme tactile detail`

### **Balletcore**

**№ 078 / 1001** — *Pointe shoe worn by feet that never trained*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Classical ballet dress, soft-girl fashion coding, and platform-native nostalgia converge; strip the ballet vocabulary and the silhouette loses its reference, strip the fashion-cycle framing and it stays inside the studio — recombination across lineages, not the revision of one.

**Atmosfera e mood**

**Sapatilha de ponta usada por pés que nunca treinaram** — (1001 Aesthetics, interpretação)

Balletcore: tule, laços de cetim, rosa-pó, o ensaio transformado em estilo.

**Paleta de cores** rosa-pó, branco, bege

**Melhores usos:** moda, editorial, lifestyle

**MidJourney:** `[tema], balletcore aesthetic, tulle and ribbons --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H6D with 80mm lens, an ethereal ballerina in blush tulle skirt, satin wrap cardigan and ribboned pointe shoes stretches at a sunlit barre, dust motes floating in soft window light, delicate collarbones and loose chignon, Degas-meets-Vogue rehearsal romance, creamy pastel grading, 8k editorial elegance`

### **BEATNIK**

**№ 083 / 1001** — *Basement literature with the daylight switched off*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Sits generations downstream of Beat literature, existentialist dress, and mass-media caricature at once; strip the media stereotype and the black turtleneck stops signaling, strip the literary parent and there is nothing to caricature — hybridization, not revision.

**Atmosfera e mood**

**Literatura de porão com a luz do dia desligada** — (1001 Aesthetics, interpretação)

Beatnik: porão esfumaçado, gola alta preta, boina, bongô e poesia sob um único spot.

**Paleta de cores** preto, cinza-fumaça, luz de spot

**Melhores usos:** retratos, música, editorial

**MidJourney:** `[tema], beatnik basement poetry scene --v 6`

**Prompt universal (Seedream):** `Shot on 35mm black and white film with 35mm lens, a beatnik poet in black turtleneck and beret reads under a single hard spotlight in a basement café, bongo player blurred in shadow, espresso cups and cigarette smoke haze, deep noir contrast with silvery midtones, 1959 Greenwich Village cool, documentary grain`

### **Bizarre**

**№ 100 / 1001** — *Face that melts and refuses to resolve*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Surrealist distortion, grotesque caricature, and digital image manipulation converge; strip the surrealist parent and the melting face loses its logic, strip the digital tooling and the distortion cannot reach that speed — a weld of several lineages.

**Atmosfera e mood**

**Rosto que derrete e se recusa a resolver** — (1001 Aesthetics, interpretação)

Bizarro: surrealismo perturbador, anatomia distorcida, lógica de sonho que não fecha.

**Paleta de cores** qualquer uma — errada de propósito

**Melhores usos:** arte, horror, experimental

**MidJourney:** `[tema], bizarre surreal melting distortion --v 6`

**Prompt universal (Seedream):** `Ultra-detailed surreal artwork at 8k, a portrait whose melting face refuses to resolve, uncanny distorted anatomy with too many correct details in wrong places, deliberately clashing mustard and bruise-violet palette, dream-logic composition in the lineage of Francis Bacon and Dalí, oily brush texture, unsettling museum-grade finish`

### **Black Power**

**№ 102 / 1001** — *Fist that needed no caption*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** The raised fist is not inherited from an earlier style — it is generated at the root by the movement itself as a sign that needs no caption, and removing it dissolves the system entirely rather than removing one branch.

**Atmosfera e mood**

**Punho que dispensou legenda** — (1001 Aesthetics, interpretação)

Gráfica do movimento Black Power dos anos 60–70: punho erguido, afros, urgência de serigrafia.

**Paleta de cores** preto, vermelho, verde — alto contraste de cartaz

**Melhores usos:** cartazes, cultura, editorial

**MidJourney:** `[tema], Black Power movement poster art, 1968 --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a 1968 screen-print protest poster, raised fist silhouette and proud afro portraits in bold flat black red and green, coarse halftone texture and slightly misregistered ink layers, Emory Douglas urgency, aged paper grain and worn fold lines, gallery-archive quality, no caption needed`

### **BOUJEE**

**№ 112 / 1001** — *Spending that insists on being heard*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Luxury-brand signaling, hip-hop's display vocabulary, and platform-era self-presentation braid here; each donor stays traceable and none alone makes spending audible in this way, marking recombination rather than the reinterpretation of a single parent.

**Atmosfera e mood**

**Gasto que insiste em ser ouvido** — (1001 Aesthetics, interpretação)

Boujee: luxo ostensivo, logos, champanhe, dourado sobre mármore.

**Paleta de cores** dourado, preto, branco-mármore

**Melhores usos:** lifestyle, branding, social

**MidJourney:** `[tema], boujee luxury lifestyle flex --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a boujee luxury tableau, designer handbags and a champagne coupe on white marble, gold accents catching private-jet window light at altitude, red-bottom heels crossed over cream leather, wealth that insists on being heard, glossy magazine grading, hyperreal material detail, 8k`

### **Bridal**

**№ 126 / 1001** — *Threshold that makes it binding*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Religious rite, couture dressmaking, and commercial wedding industry braid together; strip the rite and the threshold stops binding, strip the couture line and the garment loses its construction — fusion of distinct lineages rather than one revised parent.

**Atmosfera e mood**

**O limiar que torna vinculante** — (1001 Aesthetics, interpretação)

Noiva: renda fluida, véu delicado, buquê e luz suave de janela.

**Paleta de cores** branco, marfim, champanhe

**Melhores usos:** casamento, editorial, convites

**MidJourney:** `[tema], bridal editorial, lace and veil --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H6D with 100mm lens, a bridal editorial in soft window light, flowing white lace gown and cathedral veil caught mid-turn, ivory and champagne palette with pearl detail in macro clarity, romantic threshold moment beside tall shutters, fine-art wedding photography in the manner of Jose Villa, luminous grading, 8k`

### **CABARET**

**№ 137 / 1001** — *Satire in a sequined mask*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Variety performance, political satire, and nightclub intimacy fuse here; strip the satire and only entertainment remains, strip the small room and the critique loses its safety — distinct lineages braided into a form that behaves like none of them alone.

**Atmosfera e mood**

**Sátira numa máscara de lantejoulas** — (1001 Aesthetics, interpretação)

Cabaré de Weimar: palco pequeno e esfumaçado, sátira afiada, meia arrastão e luz de ribalta dura.

**Paleta de cores** preto, vermelho, dourado fumacento

**Melhores usos:** teatro, música, editorial

**MidJourney:** `[tema], Weimar cabaret aesthetic, satirical stage --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with 50mm lens, a Weimar-era cabaret scene, satirical performer in sequined mask and fishnets caught in harsh footlights, smoky intimate stage with tarnished gold proscenium, black and red palette in the manner of Brassaï, decadent sharp-witted glamour, cinematic grain, 8k`

### **Changelingcore**

**№ 146 / 1001** — *Identity you can put on and take off*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Folklore's substituted child, subcultural identity play, and online avatar practice converge; strip the folklore and the swap has no myth, strip the platform strand and identity stops being removable at will — fusion of distinct lines.

**Atmosfera e mood**

**Identidade que se veste e se tira** — (1001 Aesthetics, interpretação)

Changeling: figura féerica ambígua, máscaras trocadas, floresta liminal entre humano e outro.

**Paleta de cores** verdes pálidos, cinza-névoa, brilho féerico

**Melhores usos:** fantasia, retratos conceituais

**MidJourney:** `[tema], changeling fae liminal portrait --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a changeling portrait, ambiguous fae figure half-shifting identity in a liminal misty forest, discarded porcelain masks at bare feet, pale green and silver rim light through fog, uncanny beauty caught between selves, ethereal fine-art styling in the manner of Kirsty Mitchell, painterly grading, 8k`

### **Chinoiserie**

**№ 150 / 1001** — *Painted Cathay held in European hands*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Chinese decorative motifs, European rococo composition, and trade-goods imitation converge; strip the rococo frame and the motifs return to their source, strip the trade lineage and the fantasy has no evidence — fusion rather than the revision of one parent.

**Atmosfera e mood**

**Catai pintado por mãos europeias** — (1001 Aesthetics, interpretação)

Chinoiserie: papel de parede com pássaros e flores orientais, porcelana azul e branca, pavilhões fantasiosos.

**Paleta de cores** azul-porcelana, branco, dourado, verde-jade

**Melhores usos:** decoração, padronagem, editorial

**MidJourney:** `[tema], chinoiserie wallpaper style, blue and white porcelain motifs --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, a chinoiserie decorative panel, hand-painted birds and blossoms on celadon silk, blue-and-white porcelain motifs and gilded pavilions, raking light revealing brushstroke relief and gold leaf shimmer, eighteenth-century European fantasy of Cathay, ornate museum-grade elegance, 8k`

### **Cloisonnism**

**№ 162 / 1001** — *Leaded line that keeps each color apart*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Stained-glass leading, Japanese print flatness, and post-impressionist colour theory converge; strip the print lineage and the flatness disappears, strip the glass reference and the contour loses its authority — fusion of distinct traditions.

**Atmosfera e mood**

**O traço de chumbo que separa cada cor** — (1001 Aesthetics, interpretação)

Cloisonnismo (Gauguin, Émile Bernard): áreas chapadas de cor cercadas por contornos escuros grossos, como vitral ou esmalte.

**Paleta de cores** cores puras chapadas, contorno azul-escuro

**Melhores usos:** pintura, ilustração, padronagem

**MidJourney:** `[tema], cloisonnism painting style, flat color fields with bold dark outlines --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a cloisonnist painting, flat pure color fields separated by thick dark outlines like stained-glass lead, Breton women in a mustard field under simplified skies, post-impressionist Pont-Aven mood of Gauguin and Émile Bernard, visible matte brush texture and canvas weave, 8k archival scan`

### **CONCEPTUAL ART**

**№ 170 / 1001** — *Language as substance, object as footnote*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** Its founding law — that the idea is the work and the object merely its record — cannot be inherited from any earlier style; it is asserted at the root, and removing that premise dissolves the category entirely.

**Atmosfera e mood**

**Linguagem como substância, objeto como nota de rodapé** — (1001 Aesthetics, interpretação)

Arte conceitual: galeria branca, texto na parede, objeto banal deslocado, a ideia acima da forma.

**Paleta de cores** branco de galeria, preto de texto

**Melhores usos:** arte, editorial, provocação

**MidJourney:** `[tema], conceptual art installation, white gallery, text on wall --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 55mm lens, a conceptual art installation, stark white gallery holding one displaced ordinary object under even museum light, statement text in Helvetica on the far wall, idea over form, quiet intellectual provocation in the lineage of Duchamp and Joseph Kosuth, immaculate documentation clarity, 8k`

### **Counter-Reformation Baroque**

**№ 180 / 1001** — *Marble, crimson, and a single beam of light*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Baroque theatricality, Tridentine doctrine, and Roman marble craft converge; strip the doctrine and the drama has no instruction, strip the baroque staging and the beam of light loses its theatre — several traditions welded into one instrument of persuasion.

**Atmosfera e mood**

**Mármore, carmesim e um único feixe de luz** — (1001 Aesthetics, interpretação)

Barroco da Contrarreforma: chiaroscuro dramático de Caravaggio, êxtase esculpido, teatro sacro em mármore e ouro.

**Paleta de cores** carmesim, dourado, sombras profundas

**Melhores usos:** arte sacra, dramático, editorial

**MidJourney:** `[tema], counter-reformation baroque, Caravaggio chiaroscuro --v 6`

**Prompt universal (Seedream):** `Museum-grade capture at 8k, a counter-reformation baroque scene, single divine beam of light cutting Caravaggio darkness onto sculpted marble ecstasy, crimson drapery and gilded altar detail, incense haze making the light solid, Bernini theatrical intensity, oil-dark grading with razor-sharp stone texture`

### **Dapper**

**№ 196 / 1001** — *Shoulder line, lapel roll, trouser break*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**Linha do ombro, curva da lapela, quebra da calça** — (1001 Aesthetics, interpretação)

Dapper: alfaiataria precisa, tweed e risca de giz, relógio de bolso e sapato polido a espelho.

**Paleta de cores** cinza-chumbo, azul-marinho, conhaque

**Melhores usos:** moda masculina, retratos, branding

**MidJourney:** `[tema], dapper tailored menswear portrait --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, a dapper menswear portrait, precise shoulder line and lapel roll in tweed and pinstripe, pocket watch chain and mirror-polished oxfords in specular detail, directional window light carving fabric texture, exacting sartorial discipline with The Rake magazine polish, timeless grading, 8k`

### **Doppelganger**

**№ 240 / 1001** — *Almost identical, never identical*

**Nível:** ⚫ Quaternária

**Eixo:** SEMIOTICS ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Quase idêntico, nunca idêntico** — (1001 Aesthetics, interpretação)

Duplo: duas figuras espelhadas com uma diferença mínima e perturbadora, simetria que engana.

**Paleta de cores** tons gêmeos, contraste sutil, penumbra

**Melhores usos:** narrativa, horror psicológico, arte

**MidJourney:** `[tema], doppelganger twins, mirrored figures with one unsettling difference --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a doppelganger scene, two mirrored figures almost identical but never identical, one minimal unsettling difference between them, twin tones in cold half-light, deceptive symmetry with cinematic tension, Kubrick stillness, 8k`

### **Drip**

**№ 245 / 1001** — *Outfit speaks before the body does*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**O look fala antes do corpo** — (1001 Aesthetics, interpretação)

Drip: streetwear de grife em camadas, sneakers raros e correntes, atitude de quem sabe que está sendo visto.

**Paleta de cores** preto de grife, dourado, acentos de hype

**Melhores usos:** moda urbana, música, social

**MidJourney:** `[tema], drip streetwear fit, designer layers and rare sneakers --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a drip streetwear portrait, layered designer fit with rare sneakers and chains in crisp detail, confident stance that knows it is being watched, golden-hour city backdrop with flash fill, the outfit speaking before the body does, hypebeast editorial polish, 8k`

### **Détournement**

**№ 223 / 1001** — *Theft, Inversion, Hostile Return*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Atmosfera e mood**

**Roubo, inversão, devolução hostil** — (1001 Aesthetics, interpretação)

Détournement situacionista: publicidade sequestrada e subvertida, slogan invertido contra si mesmo, colágem de mídia hostil.

**Paleta de cores** cores de anúncio corrompidas, preto de protesto

**Melhores usos:** arte política, sátira, editorial

**MidJourney:** `[tema], situationist détournement, subverted advertising collage --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a détournement artwork, hijacked advertising imagery turned against itself, inverted slogans and hostile media collage, corrupted commercial colors slashed with protest black, situationist subversion with wheat-paste texture and torn edges, street-poster grit, 8k archival capture`

### **E Core**

**№ 252 / 1001** — *Ring Light Still On at Noon*

**Nível:** ⚫ Quaternária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Ring light ainda aceso ao meio-dia** — (1001 Aesthetics, interpretação)

E-girl/e-boy: delineador gráfico e blush intenso, luz de ring light, quarto iluminado por LED rosa e roxo.

**Paleta de cores** rosa e roxo LED, preto, pele iluminada

**Melhores usos:** retratos, social media, música

**MidJourney:** `[tema], e-girl aesthetic, ring light and pink LED room --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R6 with 35mm lens and ring-light flash, an e-core portrait, graphic eyeliner and heavy blush under ring light glow, bedroom lit by pink and purple LED strips, chains and striped sleeves in crisp detail, extremely online energy, webcam-flash aesthetic elevated to editorial, 8k`

### **Eagle**

**№ 253 / 1001** — *Talons Hold the Verdict*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**As garras seguram o veredito** — (1001 Aesthetics, interpretação)

Águia: rapina em close heráldico, olhar que não negocia, envergadura contra céu aberto.

**Paleta de cores** castanho-dourado, branco de cabeça, céu vasto

**Melhores usos:** natureza, heráldica, branding

**MidJourney:** `[tema], majestic eagle portrait, heraldic power --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 with 600mm f/4, an eagle portrait, raptor in heraldic close-up with an uncompromising amber gaze, every golden-brown feather resolved against vast open sky, talons holding the verdict, sovereign power of the air, National Geographic sharpness, 8k`

### **Enigmatic**

**№ 289 / 1001** — *Fourth Letter Deliberately Effaced*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**A quarta letra deliberadamente apagada** — (1001 Aesthetics, interpretação)

Enigmático: mensagem incompleta de propósito, rosto meio oculto, sentido que se recusa a fechar.

**Paleta de cores** sombras, dourado de pista, neutros ambíguos

**Melhores usos:** conceitual, retratos, narrativa

**MidJourney:** `[tema], enigmatic composition, deliberately incomplete message, half-hidden face --v 6`

**Prompt universal (Seedream):** `Shot on Leica M6 with 35mm film, an enigmatic image, an inscription with the fourth letter deliberately effaced, half-hidden face in ambiguous split shadow, meaning that refuses to close, muted golds sinking into darkness, chiaroscuro mystery, painterly 8k finish`

### **Esoteric**

**№ 304 / 1001** — *Cipher That Admits Only the Initiate*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**A cifra que só admite o iniciado** — (1001 Aesthetics; código: match aproximado)

Esotérico: símbolos herméticos e geometria oculta, conhecimento velado em camadas, mistério deliberado.

**Paleta de cores** preto, dourado de símbolo, roxo profundo

**Melhores usos:** místico, tarô, arte simbólica

**MidJourney:** `--sref 2582564782 --sw 1000` (Dark Sorcery and Mysticism — match aproximado)

**Prompt universal (Seedream):** `Shot on Pentax 67 with 90mm lens, an esoteric image, hermetic symbols and hidden geometry in layered candlelit darkness, cipher that admits only the initiate, black and deep purple with symbol gold leafing, deliberate mystery, occult still-life chiaroscuro, 8k`

### **Exoticism**

**№ 311 / 1001** — *Imagined East, Painted for Eyes That Never Went*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**O Oriente imaginado, pintado para olhos que nunca foram** — (1001 Aesthetics; código: lista Kinomoto, match aproximado)

Exotismo orientalista: cenários sonhados do século XIX, tapetes e especiarias de fantasia, o distante como projeção.

**Paleta de cores** açafrão, turquesa, dourado de bazar

**Melhores usos:** histórico, ilustração, editorial

**MidJourney:** `--sref 471699972 --sw 1000` (Vintage Oriental Illustration Style — match aproximado)

**Prompt universal (Seedream):** `Museum-grade reproduction of a 19th century orientalist painting, an imagined East of carpets and fantasy spices painted for eyes that never went, saffron and turquoise with bazaar gold in academic oil glazes, visible varnish glow, distance as projection, 8k gallery documentation`

### **Factory Pomo**

**№ 316 / 1001** — *Exposed Ductwork Worn as Ornament*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Dutos expostos usados como ornamento** — (1001 Aesthetics, interpretação)

Pós-moderno industrial: galpão convertido, tubulação pintada como decoração, estrutura exibida com ironia.

**Paleta de cores** cinza industrial, tubos coloridos, tijolo

**Melhores usos:** arquitetura, interiores, editorial

**MidJourney:** `[tema], postmodern industrial interior, exposed ductwork worn as ornament --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 21mm lens, a factory pomo interior, converted warehouse with exposed ductwork worn as ornament, brightly painted pipes against industrial grey and brick under hard skylight beams, structure displayed with irony, Herzog & de Meuron industrial wit, 8k`

### **Fantastic Realism**

**№ 319 / 1001** — *Vienna's Old-Master Glaze on Impossible Scenes*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**O verniz de velho mestre de Viena sobre cenas impossíveis** — (1001 Aesthetics, interpretação)

Realismo fantástico: técnica renascentista aplicada ao impossível, Escola de Viena, sonho pintado com precisão de mestre.

**Paleta de cores** verniz âmbar, jewel tones antigos

**Melhores usos:** arte, surreal, capas

**MidJourney:** `[tema], Vienna School of Fantastic Realism, old-master oil glaze on impossible scenes --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a fantastic realism painting, Vienna School style in the manner of Ernst Fuchs, old-master oil glazes and Renaissance precision applied to an impossible dreamlike scene, amber varnish and antique jewel tones under gallery raking light, 8k archival detail`

### **Fantasy Punk**

**№ 321 / 1001** — *Spellwork in Studded Leather Against the Crown*

**Nível:** ⚫ Quaternária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Feitiçaria em couro cravejado contra a coroa** — (1001 Aesthetics, interpretação)

Fantasia punk: magia rebelde e couro com tachas, feitiço como arma contra o trono, fantasia com atitude de rua.

**Paleta de cores** preto de couro, roxo de feitiço, metal

**Melhores usos:** personagens, capas, concept art

**MidJourney:** `[tema], fantasy punk, spellcaster in studded leather rebelling against the crown --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa Mini with 28mm lens, a fantasy punk character, spellwork glowing from hands in studded leather under rain-slick torchlight, rebel mage against the crown, leather black and spell purple with metal studs catching the glow, Mad Max meets sorcery grading, street attitude in a fantasy world, 8k`

### **Flat Design**

**№ 336 / 1001** — *Solid Color With the Drop Shadow Stripped Away*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**Cor sólida com a sombra projetada removida** — (1001 Aesthetics; código: sref-midjourney.com, categoria Flat)

Flat design: formas chapadas sem sombra nem gradiente, clareza gráfica total, o design digital pós-esqueumorfismo.

**Paleta de cores** cores sólidas e saturadas, fundos limpos

**Melhores usos:** UI, ilustração, branding

**MidJourney:** `--sref 436134421 --sw 1000` (Cartoon Vector)

**LoRA (Civitai):** "Flat Vector Art" (Pony) — civitai.com/models/438813; "Flat Vector Style" (Flux) — civitai.com/models/930353

**Prompt universal (Seedream):** `Ultra-crisp graphic composition at 8k, a flat design illustration, solid color shapes with the drop shadow stripped away, no gradients, total graphic clarity, saturated colors on clean background, Google Material Design lineage, vector-perfect edges`

### **Futuristic Minimalism**

**№ 358 / 1001** — *Bonded Glass Slab With No Visible Fastener*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**Placa de vidro colado sem nenhum fixador visível** — (1001 Aesthetics; código: Lummi, match aproximado)

Minimalismo futurista: superfície contínua e sem parafuso, tecnologia invisível, silêncio material de laboratório do futuro.

**Paleta de cores** branco, vidro, cinza lunar

**Melhores usos:** produto, arquitetura, tech

**MidJourney:** `--sref 1648693186 --sw 1000` (Futuristic Feel — match aproximado)

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a futuristic minimalist object, bonded glass slab with no visible fastener, continuous seamless surface in white and lunar grey under soft studio light, Naoto Fukasawa material silence, invisible technology, product-design precision, 8k`

### **Galaxy Hipster**

**№ 361 / 1001** — *NASA Nebulae Printed on Mall-Grade Leggings*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Nebulosas da NASA estampadas em leggings de shopping** — (1001 Aesthetics, interpretação)

Galáxia pop: estampa cósmica de 2012, Tumblr e leggings de nebulosa, o universo como moda acessível.

**Paleta de cores** roxo e rosa de nebulosa, preto estrelado

**Melhores usos:** moda, estampas, editorial nostálgico

**MidJourney:** `[tema], 2012 galaxy print fashion, NASA nebulae on leggings, Tumblr era cosmic pattern --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS 5D Mark II with 35mm lens, a galaxy hipster image, NASA nebula prints on mall-grade leggings and 2012 Tumblr fashion, purple and pink cosmic pattern on starry black, soft indie-blog daylight, the universe as affordable style, 8k`

### **Gangster**

**№ 363 / 1001** — *Pinstripe Suit Concealing the Holster*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**O terno risca de giz escondendo o coldre** — (1001 Aesthetics, interpretação)

Gângster: elegância ameaçadora dos anos 1930, fedôra e charuto, poder que não precisa levantar a voz.

**Paleta de cores** cinza risca de giz, preto, dourado de charuto

**Melhores usos:** narrativa, retratos, cinematográfico

**MidJourney:** `[tema], 1930s gangster, pinstripe suit and fedora, menacing elegance --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a gangster scene, 1930s pinstripe suit concealing the holster, fedora and cigar smoke in a dim speakeasy, charcoal grey and black with cigar gold, Gordon Willis low-key shadows, power that never raises its voice, 8k`

### **Gothic III Victorian Gothic Revival**

**№ 391 / 1001** — *Pugin's Pointed Arch Against the Smokestack*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**O arco ogival de Pugin contra a chaminé industrial** — (1001 Aesthetics; código: sref-midjourney.com, match aproximado)

Neogótico vitoriano: ogivas e pináculos renascidos na era do carvão, fé medieval reconstruída contra a fumaça da fábrica.

**Paleta de cores** pedra escurecida de fuligem, vitral, céu de carvão

**Melhores usos:** arquitetura, histórico, editorial

**MidJourney:** `--sref 306744668 --sw 1000` (Architectural Sketch of Classic Mansion — match aproximado)

**Prompt universal (Seedream):** `Shot on 8x10 wet plate collodion, a Victorian gothic revival scene, Pugin-style pointed arches and pinnacles against industrial smokestacks, soot-darkened stone and stained glass under a coal sky, medieval faith rebuilt in the factory age, 8k`

### **Greek Revival**

**№ 404 / 1001** — *Stuart and Revett's 1762 Athens Measured Again*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**A Atenas de 1762 de Stuart e Revett, medida de novo** — (1001 Aesthetics, interpretação)

Neogrego: pórticos dóricos em bancos e capitólios, a Grécia medida e reconstruída em fachadas cívicas brancas.

**Paleta de cores** branco cívico, cinza de pedra, verde de bronze

**Melhores usos:** arquitetura, institucional, histórico

**MidJourney:** `[tema], Greek Revival architecture, white Doric portico on a civic building, measured neoclassical facade --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 30mm lens, a Greek Revival image, a white Doric portico on a nineteenth century civic building, Athens measured again by Stuart and Revett, bronze-green details on civic white stone in clear morning light, 8k`

### **Halloween**

**№ 412 / 1001** — *Jack-o'-Lantern Lit for One Porous Night*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**A abóbora acesa para uma única noite porosa** — (1001 Aesthetics; código: sref-midjourney.com, match aproximado)

Halloween: jack-o'-lantern e névoa de outubro, a noite em que o véu afina, doce e assustador na mesma vela.

**Paleta de cores** laranja de abóbora, preto de noite, roxo de bruxa

**Melhores usos:** sazonal, ilustração, conteúdo temático

**MidJourney:** `--sref 422453607 --sw 1000` (Moody Gothic Horror Montage — match aproximado)

**Prompt universal (Seedream):** `Shot on 35mm anamorphic cine film, a Halloween image, a jack-o'-lantern lit for one porous night, October fog and bare branches, pumpkin orange against witch purple and night black, Dean Cundey widescreen night glow, sweet and eerie in the same candle, 8k`

### **Harlequin**

**№ 417 / 1001** — *Batocio Cracks Beneath Twenty-Four Lozenges*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**O batocio estala sob vinte e quatro losangos** — (1001 Aesthetics, interpretação)

Arlequim: losangos multicoloridos da commedia dell'arte, máscara e malandragem, o padrão que dança antes do corpo.

**Paleta de cores** losangos vermelho, azul, amarelo e verde, preto de máscara

**Melhores usos:** teatro, moda, ilustração

**MidJourney:** `[tema], harlequin aesthetic, commedia dell'arte diamond lozenge costume, masked trickster energy --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 503CW with 120mm lens, a harlequin image, twenty-four colored lozenges on a commedia dell'arte costume, black mask and batocio slapstick under theatrical spotlight, echoes of Picasso's Rose Period, the diamond pattern dancing before the body does, 8k`

### **Hermeticism**

**№ 427 / 1001** — *Sealed Vessel Turns Lead Toward Gold*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**O vaso selado transforma chumbo em direção ao ouro** — (1001 Aesthetics, interpretação)

Hermetismo: laboratório alquímico e símbolos gravados, selos e vasos sob luz de vela, o segredo como método.

**Paleta de cores** dourado alquímico, verde de vidro, preto de tinta, vermelho de selo

**Melhores usos:** esotérico, ilustração, editorial simbólico

**MidJourney:** `[tema], hermetic alchemy aesthetic, sealed vessel turning lead toward gold, engraved symbols by candlelight --v 6`

**Prompt universal (Seedream):** `Shot on Leica M11 with 50mm lens, a hermeticism image, a sealed alchemical vessel turning lead toward gold, engraved sigils and green glass by candlelight, Georges de La Tour chiaroscuro, secrecy as method in an occult laboratory, 8k`

### **Hipster**

**№ 438 / 1001** — *2007 Williamsburg Shelf Curates Itself*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**A estante de Williamsburg 2007 se autocuradoria** — (1001 Aesthetics, interpretação)

Hipster: vinil e café de método, bicicleta fixa e flanela irônica, o gosto como identidade exibida.

**Paleta de cores** mostarda, marrom vintage, verde de garrafa, filtro analógico

**Melhores usos:** lifestyle, branding indie, editorial

**MidJourney:** `[tema], 2007 hipster aesthetic, curated vinyl shelf and pour-over coffee, fixed-gear bike and analog filter --v 6`

**Prompt universal (Seedream):** `Shot on Canon AE-1 with 50mm lens, a hipster image, a 2007 Williamsburg shelf curating itself with vinyl and film cameras, pour-over coffee and fixed-gear bike, mustard and vintage brown under an analog filter, 8k`

### **Hypebeast**

**№ 445 / 1001** — *Supreme Thursday Queue Turns Scarcity Into Proof*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**A fila de quinta da Supreme transforma escassez em prova** — (1001 Aesthetics, interpretação)

Hypebeast: drop e box logo, sneaker lacrado como troféu, o streetwear medido em raridade.

**Paleta de cores** vermelho de box logo, branco de drop, preto de fila

**Melhores usos:** streetwear, branding jovem, editorial

**MidJourney:** `[tema], hypebeast aesthetic, Thursday drop queue and box logo, deadstock sneakers as trophies --v 6`

**Prompt universal (Seedream):** `Shot on Ricoh GR III with harsh flash, a hypebeast image, a Thursday drop queue turning scarcity into proof, box-logo red on drop white, sealed deadstock sneakers displayed like trophies, 8k`

### **Iconic**

**№ 453 / 1001** — *Warhol's Soup Can Outlives the Product*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**A lata de sopa de Warhol sobrevive ao produto** — (1001 Aesthetics, interpretação)

Icônico: imagem única que substitui mil palavras, objeto elevado a símbolo, pop art de reconhecimento instantâneo.

**Paleta de cores** vermelho e branco de rótulo, cores chapadas de serigrafia

**Melhores usos:** branding, pop art, editorial

**MidJourney:** `[tema], iconic pop art style, Warhol soup can screenprint flatness, single instantly recognizable image --v 6`

**Prompt universal (Seedream):** `Museum-grade screenprint reproduction, an iconic pop art image, a soup can outliving the product it advertised, flat screenprint red and white in Andy Warhol Factory style, one object elevated to instant symbol, 8k`

### **Iki (粋, late Edo chōnin)**

**№ 455 / 1001** — *Edo Restraint Leaves Desire One Step Unfinished*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**A contenção de Edo deixa o desejo um passo inacabado** — (1001 Aesthetics, interpretação)

Iki: elegância chōnin do fim de Edo, listra discreta e gesto contido, sedução pelo que não se completa.

**Paleta de cores** índigo de Edo, cinza discreto, um toque de vermelho contido

**Melhores usos:** moda, editorial japonês, branding sofisticado

**MidJourney:** `[tema], iki late Edo aesthetic, understated indigo stripes and restrained elegance, desire left one step unfinished, ukiyo-e --v 6`

**LoRA (Civitai):** "Ukiyo-e Style by Hokusai" (FLUX) — civitai.com/models/706042

**Prompt universal (Seedream):** `High-resolution woodblock print scan, an iki image, late Edo chic restraint in understated indigo stripes, a contained gesture leaving desire one step unfinished, ukiyo-e elegance in the lineage of Utamaro with one restrained touch of red, 8k`

### **Imperial Russian**

**№ 462 / 1001** — *Winter Palace Turns Gold Into State Power*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**O Palácio de Inverno transforma ouro em poder de Estado** — (1001 Aesthetics, interpretação)

Russo imperial: barroco de São Petersburgo, ouro e malaquita em salas infinitas, o luxo como declaração política.

**Paleta de cores** dourado imperial, verde malaquita, branco de palácio, vermelho czarista

**Melhores usos:** histórico, luxo, editorial

**MidJourney:** `[tema], Imperial Russian style, Winter Palace gold and malachite halls, tsarist baroque grandeur --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 23mm lens, an Imperial Russian image, Winter Palace gold turned into state power, malachite green and palace white in endless baroque halls, tsarist luxury as political declaration, 8k`

### **Intellectual**

**№ 473 / 1001** — *Marginalia Crowds the Desk Before the Argument Begins*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**As anotações de margem lotam a mesa antes do argumento começar** — (1001 Aesthetics, interpretação)

Intelectual: escrivaninha coberta de livros abertos, marginalia e café esfriando, o pensamento como paisagem física.

**Paleta de cores** papel envelhecido, tinta azul-preta, couro de encadernação, luz de luminária

**Melhores usos:** editorial, educação, branding acadêmico

**MidJourney:** `[tema], intellectual aesthetic, desk crowded with open books and marginalia, lamp light before the argument begins --v 6`

**Prompt universal (Seedream):** `Shot on Contax G2 with 45mm lens, an intellectual image, marginalia crowding the desk before the argument begins, open books and cooling coffee under lamp light, thought as physical landscape, 8k`

### **Ivy League**

**№ 483 / 1001** — *Shetland Sweater Crosses Harvard Yard*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**O suéter Shetland atravessa o pátio de Harvard** — (1001 Aesthetics, interpretação)

Ivy League: preppy de campus de 1955, tweed e loafer sobre folhas de outono, tradição vestida com displicência estudada.

**Paleta de cores** verde de hera, bordô acadêmico, caqui, azul-marinho

**Melhores usos:** moda, editorial, branding acadêmico

**MidJourney:** `[tema], Ivy League style, Shetland sweater crossing Harvard Yard, 1955 campus preppy, autumn leaves --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Ektar with 85mm lens, an Ivy League image, a Shetland sweater crossing Harvard Yard over autumn leaves, 1955 campus preppy in ivy green and burgundy, Teruyoshi Hayashida Take Ivy candor, tradition worn with studied ease, 8k`

### **Jewish**

**№ 493 / 1001** — *Menorah Keeps Eight Nights in Hammered Brass*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**A menorá guarda oito noites em latão martelado** — (1001 Aesthetics, interpretação)

Judaico: luz ritual e texto, latão e pergaminho, a memória mantida acesa vela por vela.

**Paleta de cores** latão e dourado, azul profundo, branco de vela, pergaminho

**Melhores usos:** cultural, ritual, editorial

**MidJourney:** `[tema], Jewish heritage aesthetic, hammered brass menorah holding eight nights of light, deep blue and parchment --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Df with 58mm lens by candlelight, a Jewish heritage image, a hammered brass menorah keeping eight nights of flame, deep blue and candle white over parchment, Roman Vishniac reverence, memory kept lit candle by candle, 8k`

### **Kinderwhore**

**№ 501 / 1001** — *Courtney Love Tears the Babydoll Dress at the Hem*

**Nível:** ⚫ Quaternária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Courtney Love rasga o vestido babydoll na bainha** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Kinderwhore: doçura infantil transformada em arma grunge, renda rasgada, batom borrado e desafio de 1993.

**Paleta de cores** branco de renda suja, vermelho de batom, preto de meia rasgada

**Melhores usos:** moda, editorial musical, retrato

**MidJourney:** `[tema], kinderwhore aesthetic, torn babydoll dress, smeared red lipstick, 90s grunge defiance --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Tri-X pushed to 1600 with 50mm lens, a kinderwhore image, a torn babydoll dress with smeared red lipstick and ripped tights, Courtney Love 1993 defiance, Juergen Teller raw flash honesty, sweetness weaponized against itself, 8k`

### **Ladcore**

**№ 509 / 1001** — *Football terraces, lager, blunt pride*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Arquibancada, cerveja e orgulho direto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ladcore: cultura de torcida britânica, cachecóis de clube, holofote e afeto sem sentimentalismo.

**Paleta de cores** cores de clube, cinza de concreto, dourado de lager

**Melhores usos:** editorial esportivo, documental, streetwear

**MidJourney:** `[tema], ladcore aesthetic, football terraces under floodlights, club scarves, working-class pride --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Fujicolor with 28mm lens, a ladcore image, football terraces roaring under white floodlights with pints of lager raised high, club scarves stretched between raw red hands, chants condensing in the cold air, concrete grey and lager gold in Martin Parr unsentimental affection, working-class pride photographed without apology, 8k`

### **Magic**

**№ 543 / 1001** — *Rabbit, top hat, impossible reveal*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → COHERENCE ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**Coelho, cartola, revelação impossível** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Magia: o assombro projetado à vista de todos, veludo negro de palco e branco de luva.

**Paleta de cores** veludo negro, branco de luva, dourado de palco

**Melhores usos:** editorial teatral, cartaz, arte narrativa

**MidJourney:** `[tema], magic aesthetic, white rabbit lifted from a top hat, single stage spotlight, impossible reveal --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 501CM with 80mm lens under a single stage spotlight, a magic image, a white rabbit lifted from a top hat at the impossible instant, black velvet dark and glove white, wonder engineered in plain sight, 8k`

### **Memecore**

**№ 560 / 1001** — *Joke That Became a Visual Dialect*

**Nível:** ⚫ Quaternária

**Eixo:** SEMIOTICS ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**A piada que virou dialeto visual** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Memecore: compressão como estética, JPEG estourado, Impact branco e ironia em camadas.

**Paleta de cores** artefato JPEG, branco Impact, saturação estourada

**Melhores usos:** conteúdo de internet, arte irônica, social

**MidJourney:** `[tema], memecore aesthetic, deep-fried JPEG with white Impact text, compression artifacts, layered irony --v 6`

**Prompt universal (Seedream):** `Low-resolution digital collage, a memecore image, a deep-fried JPEG with white Impact captions and saturation blown past legibility, compression artifacts and lens-flare emojis worn proudly as style, layers of ironic recaptioning fossilized in the pixels, internet folk art in its purest dialect, the joke that became a shared visual language, 8k upscale`

### **Mesopotamian**

**№ 563 / 1001** — *Clay Tablets Under a Stepped Sky*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**Tabuletas de argila sob um céu escalonado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mesopotâmico: a civilização em seu primeiro rascunho, cuneiforme e zigurate em barro e ocre.

**Paleta de cores** barro, ocre, azul de Ishtar

**Melhores usos:** histórico, museu, editorial

**MidJourney:** `[tema], Mesopotamian aesthetic, cuneiform clay tablets under a ziggurat stepped sky, clay and ochre --v 6`

**Prompt universal (Seedream):** `Museum-grade artifact photograph under raking light, a Mesopotamian image, cuneiform clay tablets beneath a stepped ziggurat skyline, wedge marks casting millimeter shadows across sun-dried clay, ochre and Ishtar-blue glaze recalling Babylon's processional gate, lamassu guardians waiting at the frame's edge, civilization photographed in its confident first draft, 8k`

### **Meta**

**№ 564 / 1001** — *Frame Pointing at Its Own Frame*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**A moldura apontando para a própria moldura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Meta: a imagem ciente de ser imagem, recursão calma em luz de galeria.

**Paleta de cores** neutros de galeria, recursão, luz plana

**Melhores usos:** arte conceitual, editorial, campanha criativa

**MidJourney:** `[tema], meta aesthetic, a frame pointing at its own frame, image aware of being an image --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R with 50mm lens, a meta image, a framed picture containing its own frame receding in calm recursion, gallery neutrals under flat even light, Magritte logic, the image aware of being an image, 8k`

### **Minet**

**№ 574 / 1001** — *Parisian Privilege in a Navy Blazer*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Privilégio parisiense num blazer marinho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Minet: juventude burguesa de Paris anos 60, mocassim, cabelo escovado e Rive Droite.

**Paleta de cores** marinho, camel, pedra parisiense

**Melhores usos:** moda, retrato, editorial retrô

**MidJourney:** `[tema], minet aesthetic, 1960s Parisian preppy youth in navy blazer and loafers, Rive Droite polish --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Vision3 250D with 40mm lens, a minet image, 1960s Parisian preppy youth in a navy blazer and polished loafers on the Rive Droite, camel and stone tones, Jacques Henri Lartigue ease, privilege worn as nonchalance, 8k`

### **Moroccan**

**№ 582 / 1001** — *Zellige Geometry Under Cedar and Lime*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**Geometria zellige sob cedro e cal** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Marroquino: riad em mosaico esmeralda e cobalto, luz coada por lanternárias de latão.

**Paleta de cores** cobalto, esmeralda, terracota de Marrakech

**Melhores usos:** interiores, viagem, editorial

**MidJourney:** `[tema], Moroccan aesthetic, zellige mosaic riad courtyard under carved cedar, brass lantern light --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm Velvia 100 with 35mm lens, a Moroccan image, a zellige-tiled riad courtyard under carved cedar and lime plaster, cobalt and emerald mosaic against Marrakech terracotta, pierced brass lanterns pooling star patterns on cool stone, mint tea steam rising through a single column of afternoon sun, hospitality built as architecture, 8k`

### **Mythopoeic**

**№ 587 / 1001** — *Private Myth Built from Borrowed Gods*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → NARRATIVE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**Mito privado construído com deuses emprestados** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mitopoese: uma cosmologia pessoal pintada como escritura, figuras visionárias em céus inventados.

**Paleta de cores** âmbar visionário, azul profundo, chama de escritura

**Melhores usos:** arte visionária, ilustração, editorial

**MidJourney:** `[tema], mythopoeic aesthetic, personal cosmology painted as scripture, visionary figures in invented skies --v 6`

**Prompt universal (Seedream):** `Ultra-detailed visionary painting, a mythopoeic image, a private cosmology rendered as scripture with figures ascending invented skies, visionary amber and deep ultramarine threaded with flame accents, William Blake prophetic line married to Ernst Fuchs jeweled precision, angels wearing borrowed wings from three mythologies, a personal myth built from inherited gods, 8k`

### **Neo Pop**

**№ 600 / 1001** — *Warhol's Ghost Scrolls the Feed*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**O fantasma de Warhol rolando o feed** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neo pop: serigrafia reencarnada em interface, ícones de consumo trocados por ícones de app.

**Paleta de cores** CMYK saturado, branco de tela

**Melhores usos:** arte, capas, campanha

**MidJourney:** `[tema], neo pop aesthetic, Warhol silkscreen ghost scrolling a feed, app icons as soup cans --v 6`

**Prompt universal (Seedream):** `Ultra-crisp contemporary pop artwork, Warhol's silkscreen ghost scrolling an infinite feed, repeated app icons treated like soup cans in saturated CMYK, KAWS-era gloss over halftone memory, flat vivid irony at billboard scale, 8k`

### **Neo-Punk**

**№ 611 / 1001** — *Rebellion After the Uniform Sold Out*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Atmosfera e mood**

**Rebeldia depois que o uniforme esgotou** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neo-punk: jaqueta cravejada com etiqueta de preço, a revolta procurando um corpo novo pós-vitrine.

**Paleta de cores** preto, xadrez, vermelho de liquidação

**Melhores usos:** moda alternativa, música, editorial

**MidJourney:** `[tema], neo-punk aesthetic, studded jacket with price tag still on, rebellion after the sellout --v 6`

**Prompt universal (Seedream):** `Shot on Ricoh GR1v with direct flash, a neo-punk portrait outside a mall, studded leather jacket with the price tag still hanging, tartan and torn mesh under fluorescent signage, rebellion shopping for a new body after the uniform sold out, gritty flash grain, 8k`

### **Neoism**

**№ 608 / 1001** — *Anti-Art Filing Its Own Paperwork*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Anti-arte arquivando a própria papelada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neoísmo: mail art, carimbos, identidades coletivas e burocracia usada como mídia subversiva.

**Paleta de cores** papel de formulário, tinta de carimbo vermelha e preta

**Melhores usos:** arte experimental, zines, editorial

**MidJourney:** `[tema], neoism aesthetic, mail art rubber stamps, bureaucratic forms as subversive media --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a neoist mail-art assemblage, rubber stamps and altered bureaucratic forms filed as anti-art paperwork, shared pseudonym signatures and postal franking layered in red and black ink, Monty Cantsin mischief, creased envelope texture in archival detail, 8k`

### [**Net.art**](http://Net.art)

**№ 613 / 1001** — *Code Misbehaving Inside the Gallery*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Código se comportando mal dentro da galeria** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Net.art: janelas de navegador de 1997 empilhadas, erro 404 como obra, HTML quebrado de propósito.

**Paleta de cores** cinza de sistema, azul de hyperlink, verde de terminal

**Melhores usos:** arte digital, editorial tech, capas

**MidJourney:** `[tema], net.art aesthetic, 1997 browser windows stacked, 404 error as artwork, broken HTML --v 6`

**Prompt universal (Seedream):** `High-resolution capture of a 1990s net.art piece on a CRT monitor, stacked browser windows and deliberate 404 errors as the artwork, hyperlink blue and system gray with terminal green glitches, jodi.org misbehavior inside the gallery, scanline texture in crisp detail, 8k`

### **New Wave**

**№ 624 / 1001** — *Synthesizer Pop and the Painted Face*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Geometria pop em rotação de videoclipe** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

New wave: maquiagem geométrica, cores de sintetizador e o futuro de 1982 em ritmo de MTV.

**Paleta de cores** magenta elétrico, ciano, preto de vinil

**Melhores usos:** música, moda, capas

**MidJourney:** `[tema], new wave 1982 aesthetic, geometric makeup synth colors, MTV future --v 6`

**Prompt universal (Seedream):** `Shot on cross-processed 35mm slide film, a new wave portrait from 1982, geometric asymmetric makeup in electric magenta and cyan against vinyl black, synth-pop angles and a skinny tie, the future broadcast at MTV rhythm, saturated shifted color, 8k`

### **Normcore**

**№ 633 / 1001** — *Strip the Disguise and It Becomes Ordinary Plainness*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**A rebelião de não se destacar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Normcore: jeans reto, tênis branco básico e mochila sem marca — o anônimo como declaração.

**Paleta de cores** jeans médio, branco básico, cinza mescla

**Melhores usos:** moda, editorial, conceito

**MidJourney:** `[tema], normcore aesthetic, plain straight jeans white sneakers, blending in as rebellion --v 6`

**Prompt universal (Seedream):** `Shot on Canon 6D with 40mm pancake lens, a normcore portrait, plain straight jeans white sneakers and an unbranded fleece in a generic plaza, medium-wash denim and heather gray refusing every trend, blending in performed as the boldest statement, honest neutral light, 8k`

### **Offbeat**

**№ 641 / 1001** — *Quirk Calibrated One Degree Past Normal*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Um grau fora do normal, de propósito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Offbeat: o detalhe excêntrico que salva a cena do comum — meias trocadas, quadro torto, charme desalinhado.

**Paleta de cores** mostarda, azul-petróleo, um toque discordante

**Melhores usos:** editorial, retratos, branding

**MidJourney:** `[tema], offbeat aesthetic, one degree past normal on purpose, eccentric charming detail --v 6`

**Prompt universal (Seedream):** `Shot on Contax G1 with 28mm lens, an offbeat portrait, everything correct except one eccentric detail tilted a single degree past normal, mustard and petrol blue with one deliberately discordant accent, mismatched charm framed with dry wit, crisp film rendering, 8k`

### **Paninaro**

**№ 664 / 1001** — *Designer Labels Parked Beside the Scooter*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Milão 1986 em jaqueta de pluma** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Paninaro: Moncler brilhante, Timberland amarela e scooter na porta da lanchonete — consumo como dialeto juvenil.

**Paleta de cores** vermelho Moncler, amarelo Timberland, jeans lavado

**Melhores usos:** moda, nostalgia, editorial

**MidJourney:** `[tema], paninaro aesthetic, Milan 1986, glossy puffer jacket yellow boots scooter --v 6`

**Prompt universal (Seedream):** `Shot on Minolta Hi-Matic 7sII with 40mm lens, a paninaro group outside a Milan burger bar in 1986, glossy Moncler puffers and yellow Timberlands beside a parked scooter, washed denim and label pride as teenage dialect, warm Italian street light, 8k`

### **Pijos**

**№ 685 / 1001** — *Spanish Privilege in Designer Casual*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**Privilégio casual do bairro de Salamanca** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pijos: suéter no ombro, mocassim sem meia e o código espanhol de riqueza jovem exibido como descuido.

**Paleta de cores** marinho, rosa-polo, bege de mocassim

**Melhores usos:** moda, editorial, cultura

**MidJourney:** `[tema], pijos aesthetic, sweater over shoulders loafers no socks, Madrid Salamanca casual privilege --v 6`

**Prompt universal (Seedream):** `Shot on Contax T2 with 38mm lens, a pijo portrait in Madrid's Salamanca district, pastel sweater knotted over the shoulders and loafers without socks beside a café terrace, navy and polo pink worn as careless privilege, warm Spanish afternoon light, crisp compact-film rendering, 8k`

### **Pittura Metafisica**

**№ 687 / 1001** — *Architecture Waiting for a Dream to Return*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Atmosfera e mood**

**Arcadas vazias esperando um sonho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pintura metafísica: praças desertas, sombras longas demais e manequins no lugar de pessoas.

**Paleta de cores** ocre de tarde parada, verde de céu estranho, sombra longa

**Melhores usos:** arte, conceito, capas

**MidJourney:** `[tema], pittura metafisica aesthetic, empty arcades too-long shadows, mannequins instead of people --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a pittura metafisica painting, an empty arcaded piazza with shadows stretched too long for the hour, a tailor's mannequin waiting where a person should stand, de Chirico ochre and strange green sky, stillness thick with unspoken dream, 8k scan`

### **Plaguecore**

**№ 690 / 1001** — *Medical History Romanticized in Black Linen*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**O medo histórico romantizado em linho preto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Plaguecore: máscara de médico da peste, ervas secas e velas — a estética gótica da epidemia histórica.

**Paleta de cores** preto de linho, cera de vela, ervas secas

**Melhores usos:** dark academia, fantasia, editorial

**MidJourney:** `[tema], plaguecore aesthetic, plague doctor mask dried herbs candlelight, historic dread romanticized --v 6`

**Prompt universal (Seedream):** `Large format wet plate collodion photograph, a plaguecore portrait, beaked plague doctor mask above black linen robes with dried herbs and guttering candles, historic dread romanticized in silver streaks and chemical edge flaws, chiaroscuro dread with antique process texture, 8k scan`

### **Pop Art**

**№ 699 / 1001** — *Soup Can Takes the Altar*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Atmosfera e mood**

**A lata de sopa no altar da galeria** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pop art: serigrafia repetida, retícula de quadrinhos e o consumo elevado a ícone de museu.

**Paleta de cores** CMYK de serigrafia, amarelo banana, vermelho de lata

**Melhores usos:** arte, capas, editorial

**MidJourney:** `[tema], pop art aesthetic, repeated silkscreen halftone dots, consumer product as museum icon --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a pop art canvas, a consumer icon repeated in silkscreen rows with Warhol color shifts and Lichtenstein halftone dots, soup-can red and banana yellow elevated to the gallery altar, flat mechanical registration with deliberate misprints, 8k`

### **Pop Punk**

**№ 700 / 1001** — *Rebellion You Can Ring Up at the Register*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Atmosfera e mood**

**Rebeldia pronta para a caixa registradora** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pop punk: Vans quadriculado, gravata sobre camiseta e o skate no estácionamento do subúrbio em 2002.

**Paleta de cores** xadrez preto e branco, vermelho de palheta, jeans

**Melhores usos:** música, moda jovem, editorial

**MidJourney:** `[tema], pop punk 2002 aesthetic, checkerboard Vans loose tie over tee, suburban skate rebellion --v 6`

**Prompt universal (Seedream):** `Shot on 35mm at a 2002 Warped Tour side stage, a pop punk scene, checkerboard Vans and a loose tie over a band tee mid-jump with a skateboard below, suburban rebellion priced for the register, flash-lit grain and sweat, spiky silhouettes against amp stacks, 8k scan`

### **Poppare**

**№ 701 / 1001** — *Stockholm Syndrome för Britpop*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Nota genealógica original (EN):** Three British lineages — the Mod silhouette, the indie orthodoxy, and the Britpop canon — arrived in Stockholm and were maintained without alteration, the Nordic scene adding only a reception layer while leaving the inherited grammar untouched.

**Atmosfera e mood**

**Estocolmo anos 80 em topete e broche** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Poppare: a juventude pop sueca de topete armado, jaqueta com bottons e synth-pop no walkman.

**Paleta de cores** pastel nórdico, jeans claro, rosa de bottom

**Melhores usos:** moda retrô, música, editorial

**MidJourney:** `[tema], poppare aesthetic, 1980s Stockholm pop youth, teased hair badge jacket walkman --v 6`

**Prompt universal (Seedream):** `Shot on Kodacolor VR 200, a poppare portrait in 1980s Stockholm, teased blond hair and a denim jacket armored with pop badges, walkman headphones around the collar, Nordic pastel light on light-wash jeans, synth-pop optimism in soft consumer-film color, 8k scan`

### **Post-Modernism**

**№ 707 / 1001** — *Age of Infinite Quotation*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** Robert Venturi's 1966 Complexity and Contradiction in Architecture made the break explicit, treating Modernism's commitment to unified coherence as the thing to be broken — every classical fragment re-cited out of context was a cut in the Modernist grammar's claim to totalizing authority.

**Atmosfera e mood**

**A era da citação infinita** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pós-modernismo: colunas de brincadeira, fróntões quebrados e a história inteira usada como caixa de amostras.

**Paleta de cores** pastel de Miami, terracota pop, cinza de vidro

**Melhores usos:** arquitetura, design, editorial

**MidJourney:** `[tema], postmodern architecture aesthetic, broken pediments playful columns, history as sample box --v 6`

**Prompt universal (Seedream):** `Shot on medium format with 50mm lens, a postmodern building at golden hour, broken pediments and oversized playful columns quoting all of history at once, Michael Graves terracotta pop against Miami pastel and glass gray, the age of infinite quotation photographed deadpan, 8k`

### **Pre-Modernism**

**№ 716 / 1001** — *Ornament Before the Apology*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Nota genealógica original (EN):** The acanthus leaf, Gothic tracery, and arabesque — the exact motif grammar of Greek, Roman, and Baroque practice — were reproduced across Victorian interiors without grammatical alteration; only the means changed from hand-carving to industrial molding, while the classical ornamental language passed intact across every generation of European building.

**Atmosfera e mood**

**Ornamento antes do pedido de desculpas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pré-modernismo: excesso vitoriano sem culpa, cada superfície decorada porque podia ser.

**Paleta de cores** mogno, veludo verde, dourado de moldura

**Melhores usos:** histórico, interiores, editorial

**MidJourney:** `[tema], pre-modernism aesthetic, unapologetic Victorian ornament, every surface decorated --v 6`

**Prompt universal (Seedream):** `Shot on an 8x10 camera with a brass Petzval lens, a pre-modernist interior, Victorian ornament layered without apology across mahogany, green velvet and gilt frames, every surface decorated because it could be, swirling Petzval bokeh at the edges, antique plate richness, 8k`

### **Primitivism**

**№ 720 / 1001** — *Paris Raids the World for Modernity*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** When Picasso entered the Trocadéro ethnographic museum in 1907 and took Fang and Kongo masks as a formal instrument against the salon picture, he made the break explicit — African and Oceanic carving was not synthesized with European painting but weaponized against it, the borrowed grammar cutting through the academic surface as a tool of rupture rather than enrichment.

**Atmosfera e mood**

**Paris saqueando o mundo em nome do novo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Primitivismo: máscaras e formas não-europeias absorvidas pela vanguarda — hoje lido com olhar crítico.

**Paleta de cores** terracota, ocre de máscara, rosa quebrado

**Melhores usos:** arte, histórico, editorial crítico

**MidJourney:** `[tema], primitivism aesthetic, avant-garde faces angular like carved masks, 1907 Paris borrowing the world --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an early modernist primitivist painting, angular figures with faces carved like borrowed masks in the Demoiselles lineage, terracotta ochre and broken rose planes fracturing academic beauty, 1907 Paris raiding the world for its new language, presented with critical distance, 8k scan`

### **Prohibition**

**№ 725 / 1001** — *Illegality Poured Into a Crystal Glass*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Art Deco's geometric glamour, the jazz tradition's sonic grammar, and the pre-Prohibition saloon's spatial logic of organized vice were each complete vocabularies; recombined under the pressure of the Volstead Act they produced a nocturnal economy of gilded illegality that none of the three parents could generate alone.

**Atmosfera e mood**

**Ilegalidade servida pura em 1927** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Proibição: speakeasy atrás da lavanderia, cristal lapidado e jazz abafado pela porta dupla.

**Paleta de cores** âmbar de uísque, veludo escuro, latão de bar

**Melhores usos:** histórico, bares, editorial

**MidJourney:** `[tema], prohibition 1927 aesthetic, hidden speakeasy cut crystal, illegality poured neat --v 6`

**Prompt universal (Seedream):** `Shot on a Speed Graphic 4x5 with flashbulb, a 1927 speakeasy interior behind the laundry door, cut crystal glasses and whiskey amber against dark velvet booths, muffled jazz and brass bar rails, illegality poured neat under one hard pop of flash, period press-photo grain, 8k`

### **Protestant**

**№ 727 / 1001** — *God Made Readable, Ornament Put on Trial*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** O código é transmitido como continuidade reconhecível, mantendo sua gramática compartilhada.

**Nota genealógica original (EN):** Luther's sola scriptura claim — the unmediated Word above any sensory reward — is passed forward intact as the founding ordinance; every downstream tradition, from Calvinist stripped church to Shaker utility, inherits the identical displacement of image by text without altering the parent grammar.

**Atmosfera e mood**

**Deus legível em paredes caiadas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Protestante: igreja branca sem imagem, luz pela janela clara e a sobriedade como forma de devoção.

**Paleta de cores** cal branca, madeira de banco, cinza de luz

**Melhores usos:** arquitetura, histórico, editorial

**MidJourney:** `[tema], protestant aesthetic, whitewashed bare church interior, sobriety as devotion --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Dutch church interior painting, a whitewashed protestant nave stripped of every image, clear window light across pew wood and stone floor, Pieter Saenredam perspective where God is kept legible, sober luminous emptiness, 8k scan`

### **Proto-Cubism**

**№ 728 / 1001** — *Moment Before Reality Shattered*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** Cézanne's constructive stroke and geometric grammar were inherited whole, then the single vantage point — the one foundation Cézanne never abandoned — was cut from underneath it; the faceted plane that results has no place to stand that Cézanne's naturalism could have sanctioned.

**Atmosfera e mood**

**O momento antes do estilhaçamento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Proto-cubismo: casas de aldeia viradas em blocos, 1907–1908, a perspectiva começando a ceder.

**Paleta de cores** ocre de telhado, verde-oliva, cinza de pedra

**Melhores usos:** arte, histórico, editorial

**MidJourney:** `[tema], proto-cubism aesthetic, village houses turning into blocks 1908, perspective starting to crack --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a proto-cubist landscape, village houses at Horta de Ebro compressing into faceted blocks around 1908, roof ochre and olive green as perspective starts to crack but has not yet shattered, the exact moment before cubism, dense Cézanne-fed geometry, 8k scan`

### **Royalcore**

**№ 774 / 1001** — *Palace fantasy dressed for the present*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Romantic medievalism's idealized superior past arrives as the single premise, and Royalcore re-instruments it by handing the Gothic Revival's castle imagery and Baroque's gilded excess to the unroyal — anyone literate in the code may claim the rank — so an aristocratic grammar built to exclude becomes a purchasable performance of belonging.

**Atmosfera e mood**

**Fantasia de palácio vestida para o presente** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Royalcore: luvas de cetim, mini-coroas e brocado no cotidiano — a realeza reimaginada como guarda-roupa pessoal.

**Paleta de cores** azul real, dourado de brocado, marfim de luva

**Melhores usos:** moda, editorial, lifestyle

**MidJourney:** `[tema], royalcore aesthetic, satin gloves brocade in daily life, palace fantasy dressed for the present --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Zf with 85mm lens, a royalcore portrait, satin gloves and a brocade coat with a small crown worn to an entirely modern street, royal blue and glove ivory against everyday city light, palace fantasy tailored confidently for the present tense, regal shallow depth, 8k`

### **Safari**

**№ 780 / 1001** — *Adventure Dressed in Khaki*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → DOMAIN ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Boer War-era Khaki Drill field dress arrives as the single parent — bellows pockets, revere collar, epaulettes, belted waist — and Safari re-instruments that combat utility into a leisure grammar of watched wilderness, changing the use of the uniform's marks without fusing in any second lineage — so a soldier's working cut becomes, one transformation later, a spectator's costume of command.

**Atmosfera e mood**

**A aventura vestida de cáqui** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Safari: Land Rover na poeira dourada, binóculos e acácias no horizonte — a savana como destino e figurino.

**Paleta de cores** cáqui, dourado de capim, verde de acácia

**Melhores usos:** viagem, moda, editorial

**MidJourney:** `[tema], safari aesthetic, khaki and dust Land Rover acacia horizon, adventure dressed for the bush --v 6`

**Prompt universal (Seedream):** `Shot on Leica R6 with 180mm lens, a safari scene, a dusty Land Rover paused in golden grass as giraffes cross toward flat-topped acacias, khaki layers and worn leather binocular straps in low amber light, adventure properly dressed for the bush, warm film rendering, 8k`

### **Satirical Art**

**№ 784 / 1001** — *Laughter That Stings*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Classical rhetoric's persuasion tradition arrives as the single parent, and satirical art re-instruments verbal argument into a picture that prosecutes — swelling one condemning feature on a borrowed public sign — so a case once made in words becomes, one transposition later, a case made in ink that a crowd reads in five seconds.

**Atmosfera e mood**

**O riso que ferroa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Arte satírica: caricaturas de tribunal e salão, exageros cirúrgicos e o poder desenhado do tamanho da própria vaidade.

**Paleta de cores** sépia de gravura, preto de nanquim, papel amarelado

**Melhores usos:** editorial, histórico, ilustração

**MidJourney:** `[tema], satirical art aesthetic, courtroom caricature surgical exaggeration, laughter that stings --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a satirical print, courtroom figures swollen with self-importance in the Daumier manner with Hogarth moral detail, surgical exaggeration in ink black over aged sepia paper, power drawn exactly the size of its own vanity, biting lithographic texture, 8k`

### **Schoolcore**

**№ 787 / 1001** — *Class Is in Session*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** The codified school-uniform tradition arrives as the single parent, and Schoolcore re-instruments its regulation pleat and crest into nostalgic preppy consumer dress — one lineage transformed for screen and sentiment, no second tradition fused in — so a mandatory dress code built to erase individuality becomes, one restyling later, a wardrobe chosen to perform belonging that was never actually granted.

**Atmosfera e mood**

**A aula está em sessão** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Schoolcore: quadro de giz, lápis apontados e mochilas de lona — a nostalgia da sala de aula em ordem perfeita.

**Paleta de cores** verde de quadro, madeira de carteira, amarelo de lápis

**Melhores usos:** nostalgia, editorial, branding

**MidJourney:** `[tema], schoolcore aesthetic, chalkboard sharpened pencils canvas satchels, class in session --v 6`

**Prompt universal (Seedream):** `Shot on Minolta X-700 with 50mm lens, a schoolcore scene, cursive chalk on a green board above rows of worn wooden desks with sharpened pencils and canvas satchels, pencil yellow and blackboard green in dusty window light, class permanently in session, warm nostalgic film, 8k`

### **Serpentcore**

**№ 798 / 1001** — *Reptilian Grace*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Animalism's broad reverence for creature-form arrives as the single parent, and Serpentcore re-instruments that inheritance by collapsing the whole animal kingdom into one lineage — the ophidian — reading every surface through the coil, so a wide field of nature-worship becomes, one turn later, a single serpent's closed and unbroken line.

**Atmosfera e mood**

**Graça reptiliana em escamas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Serpentcore: escamas iridescentes, curvas hipnóticas e a elegância fria que desliza sem pressa.

**Paleta de cores** verde iridescente, dourado de escama, preto de víbora

**Melhores usos:** moda, arte, editorial

**MidJourney:** `[tema], serpentcore aesthetic, iridescent scales hypnotic coils, cold reptilian grace --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z8 with 105mm macro lens, a serpentcore study, iridescent snake scales shifting green to gold along a slow hypnotic coil, viper black grounding the shimmer under controlled studio light, cold elegance that glides without hurry, mesmerizing scale-by-scale detail, 8k`

### **Shanzhai**

**№ 803 / 1001** — *Counterfeit culture that out-invents the original*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → SYNTHESIS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** The workshop discipline of linmo — copying a master's scroll stroke for stroke until the hand learns its logic — arrives as the single parent, and Shanzhai re-instruments that inheritance by rewiring reverent copying into commercial undercut, the disciple's brush swapped for the small workshop's mold, so a tradition of copying to honor becomes, one turn later, a practice of copying to outsell.

**Atmosfera e mood**

**A cópia que inventa mais que o original** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Shanzhai: eletrônicos híbridos de mercado de Shenzhen, logos quase-certos e a pirataria como laboratório de inovação.

**Paleta de cores** neon de barraca, plástico multicor, LED

**Melhores usos:** conceito, tecnologia, editorial

**MidJourney:** `[tema], shanzhai aesthetic, Shenzhen market hybrid gadgets almost-right logos, counterfeit out-inventing the original --v 6`

**Prompt universal (Seedream):** `Shot on Sony RX100 pocket camera, a shanzhai market stall in Shenzhen, hybrid phones with seven speakers and almost-right logos stacked under stall neon, multicolor plastic and LED excess as an unlicensed innovation lab, the counterfeit out-inventing its original, dense electric detail, 8k`

### **Simulacrum**

**№ 809 / 1001** — *Copies Become Reality*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Postmodernism's Baudrillardian claim that signs no longer answer to anything beneath them arrives as the single parent, and Simulacrum re-instruments that inheritance by committing to a position its parent only entertained — that the simulation is now preferable to the original — so a diagnosis of the sign's detachment from the real becomes, one turn later, a celebration of the copy that has earned the right to replace it.

**Atmosfera e mood**

**Cópias que se tornam realidade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Simulacro: a cópia da cópia sem original — manequins fotografando manequins num espelho de referências.

**Paleta de cores** pele de vitrine, cinza de estoque, luz duplicada

**Melhores usos:** conceito, arte, editorial

**MidJourney:** `[tema], simulacrum aesthetic, copy of a copy with no original, mannequins photographing mannequins --v 6`

**Prompt universal (Seedream):** `Ultra-crisp conceptual photograph, a simulacrum tableau, a showroom mannequin photographing another mannequin posed before a printed backdrop of the same scene, copies nesting until the original quietly disappears, Baudrillard staged in showroom skin tones and duplicated light, 8k`

### **Simulation Theory**

**№ 810 / 1001** — *Reality interrogated down to its last pixel*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Cyberpunk's cold screen-light, backlit darkness, and grid-and-wireframe vocabulary arrive as the single parent, and Simulation Theory re-instruments that inheritance by turning the neon city into a question — not who controls the high-tech world, but whether the world is a render at all — so a dystopian vision of technological control becomes, one turn later, an ontological doubt about reality's own substrate.

**Atmosfera e mood**

**A realidade interrogada até o último pixel** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Teoria da simulação: o mundo com a renderização falhando nos cantos, wireframe sob a pele do real.

**Paleta de cores** verde de matriz, glitch magenta, cinza de malha

**Melhores usos:** conceito, sci-fi, arte digital

**MidJourney:** `[tema], simulation theory aesthetic, reality glitching at the edges wireframe under skin, interrogated to the last pixel --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital render, simulation theory, an ordinary street corner where the render fails at the edges revealing wireframe mesh beneath brick and skin, matrix green code bleeding through a magenta glitch seam, reality interrogated down to its final pixel, uncanny precision, 8k`

### **Situationism**

**№ 811 / 1001** — *Art as Disruption*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Lettrism's drift through the city, hatred of the finished art object, and cut-up reuse of found material arrive as the single parent, and Situationism re-instruments that inheritance by turning the collage cut into a weapon of political reversal, so a poetic wandering through the streets becomes, one turn later, a détournement that seizes the spectacle's own images and turns them against it.

**Atmosfera e mood**

**A arte como interrupção do cotidiano** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Situacionismo: quadrinhos desviados com legendas trocadas, Paris 1968 e o espetáculo sabotado por dentro.

**Paleta de cores** preto de quadrinho, vermelho de palavra de ordem, papel de panfleto

**Melhores usos:** conceito, design, histórico

**MidJourney:** `[tema], situationist aesthetic, détourned comic swapped captions Paris 1968, art as disruption --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a situationist détournement, a romance comic panel with its captions swapped for Debord slogans about the spectacle, pamphlet paper and comic black hit with one slogan red, everyday imagery hijacked against itself in the Paris 1968 manner, raw print urgency, 8k`

### **Skater**

**№ 812 / 1001** — *Rolling Through the City*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Sidewalk surfing's ocean-carve stance and its read of a curved wave face arrive as the single parent, and Skater re-instruments that inheritance by transposing the wave onto poured concrete, so a drop down a wave face becomes, one turn later, a drop-in down a ramp and a handrail becomes equipment the instant the trucks lock on.

**Atmosfera e mood**

**Rolando pela cidade como quadra livre** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Skater: kickflip no corrimão, tênis ralado e a arquitetura urbana relida como playground de concreto.

**Paleta de cores** cinza de praça, grip preto, branco ralado de tênis

**Melhores usos:** esporte, moda urbana, editorial

**MidJourney:** `[tema], skater aesthetic, kickflip over the rail scuffed sneakers, the city read as concrete playground --v 6`

**Prompt universal (Seedream):** `Shot on Yashica T4 with flash, a skater moment at dusk, a kickflip frozen over a plaza rail with scuffed sneakers and grip tape mid-rotation, flash popping against concrete gray while friends film on the curb, city architecture reread as free playground, raw 35mm energy, 8k scan`

### **Snob**

**№ 816 / 1001** — *Taste wielded as a velvet rope*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Aristocratic distinction's visible hierarchy read through possession arrives as the single parent, and Snob re-instruments that inheritance by translating court-and-class display into the language of consumer capital, so a birthright crest becomes, one turn later, a turned-in label that only a fellow insider can price.

**Atmosfera e mood**

**O gosto empunhado como corda de veludo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Esnobe: sobrancelha erguida sobre a taça, lista de espera como decoração e o critério usado para separar salões.

**Paleta de cores** borgonha de adega, veludo escuro, dourado de clube

**Melhores usos:** editorial, sátira, moda

**MidJourney:** `[tema], snob aesthetic, raised eyebrow over the wine glass velvet rope, taste as gatekeeping --v 6`

**Prompt universal (Seedream):** `Shot on Leica M10-P with 75mm lens, a snob portrait in a private club, an eyebrow raised over a Burgundy glass beside a velvet rope no one may pass, dark velvet and club gold in low tasteful light, taste wielded precisely as a gate, deliciously judgmental composure, 8k`

### **Southern Grassland Indigenous**

**№ 834 / 1001** — *Prairie Geometry Woven as Living Law*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** No earlier aesthetic stands upstream of the Kaingang and Guaraní Mbyá geometric body-painting tradition; it generates descendants such as Paraguayan ñandutí lacework and Pampa Hybrid Identity while descending from none of them, so no parent can be traced upward into the bilateral line ruled across living skin.

**Atmosfera e mood**

**Geometria da pradaria tecida como lei viva** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Povos das pradarias do sul: tramas geométricas em lã e fibra carregando território e memória — o padrão como documento.

**Paleta de cores** terra de pampa, vermelho de trama, cru de lã

**Melhores usos:** cultura, documental respeitoso, editorial

**MidJourney:** `[tema], southern grassland indigenous weaving aesthetic, geometric wool patterns as living law, dignified documentation --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 67II with 90mm lens, a respectful documentation of southern grassland indigenous weaving, geometric wool patterns in earth red and raw cream stretched on a hand loom against open pampa horizon, territory and memory encoded thread by thread as living law, honest golden light, 8k`

### **Speakeasycore**

**№ 838 / 1001** — *Jazz Rebellion in Prohibition's Underground Cathedral*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Art Deco's geometric luxury arrives as the single parent, and Speakeasycore re-instruments that inheritance by wiring it to Prohibition's engineered concealment, so ordinary decorative glamour becomes, one turn later, a threshold system that hides the very ornament it wears.

**Atmosfera e mood**

**Jazz rebelde na catedral subterrânea** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Speakeasycore: senha na porta sem placa, coquetel à luz de vela e o revival atual dos bares escondidos dos anos 1920.

**Paleta de cores** âmbar de uísque, veludo verde-garrafa, latão de balcão

**Melhores usos:** bares, lifestyle, editorial

**MidJourney:** `[tema], speakeasycore aesthetic, password door candlelit cocktails hidden bar revival, jazz rebellion underground --v 6`

**Prompt universal (Seedream):** `Shot on Contax G2 with 45mm lens, a speakeasycore night, a candlelit cocktail sliding across a brass-railed bar behind an unmarked password door, whiskey amber and bottle-green velvet under low jazz light, the 1920s underground reverently revived one coupe at a time, intimate warm grain, 8k`

### **Spellbindingcore**

**№ 839 / 1001** — *Enchantment worn as everyday armor*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Western Esotericism's correspondence-doctrine arrives as the single parent, and Spellbindingcore re-instruments that inheritance by compressing it into a contemporary, internet-native visual identity, so a centuries-deep occult system becomes, one turn later, an altar staged for a lit phone screen.

**Atmosfera e mood**

**O encantamento usado como armadura diária** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Spellbindingcore: amuletos sobre o casaco comum, faíscas discretas na mão e a magia tratada como acessório de rotina.

**Paleta de cores** violeta de faísca, prata de amuleto, preto de casaco

**Melhores usos:** fantasia, moda, editorial

**MidJourney:** `[tema], spellbindingcore aesthetic, amulets over an everyday coat quiet sparks, enchantment as daily armor --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-H2 with 56mm lens, a spellbindingcore portrait at a bus stop, layered silver amulets over an ordinary black coat while faint violet sparks curl from a gloved palm, enchantment worn as casually as a scarf, magic treated as everyday armor, subtle cinematic glow, 8k`

### **Stealth Wealth**

**№ 846 / 1001** — *Fortune fluent in understatement*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Old money's inherited restraint, modernist minimalism's discipline of subtraction, and post-2008 conscious consumption's ethical sourcing are welded into one form, no single ancestor surviving intact, so three lineages fuse into a quiet-luxury code that none of the three could produce alone.

**Atmosfera e mood**

**A fortuna fluente em discrição** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Stealth wealth: relógio raro sem alarde, cashmere sem logo e o carro comum na garagem errada — o dinheiro falando baixo de propósito.

**Paleta de cores** cinza de cashmere, aço escovado, verde de nota discreta

**Melhores usos:** moda, lifestyle, editorial

**MidJourney:** `[tema], stealth wealth aesthetic, rare unbranded watch logoless cashmere, fortune fluent in understatement --v 6`

**Prompt universal (Seedream):** `Shot on Leica M10 Monochrom with 50mm lens, a stealth wealth detail study, a rare unbranded steel watch under a logoless cashmere cuff resting on an old-money doorframe, brushed gray tones with zero ostentation, fortune speaking quietly and only to those who already know, restrained monochrome depth, 8k`

### **Streetwear**

**№ 856 / 1001** — *Subcultural Identity Woven into Democratic Fashion*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Sportswear supplies the single parent — the jersey-knit tee, the fleece hoodie, the cushioned sneaker — and Streetwear re-instruments that inheritance by loading it with subcultural code, turning athletic function into semiotic currency without ever severing the garment lineage.

**Atmosfera e mood**

**Identidade subcultural tecida em moda democrática** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Streetwear: fila do drop na madrugada, tênis raro e camiseta gráfica — o vestuário como filiação de tribo e moeda cultural.

**Paleta de cores** preto de hoodie, branco de sneaker, laranja de caixa

**Melhores usos:** moda urbana, branding, editorial

**MidJourney:** `[tema], streetwear aesthetic, dawn drop queue rare sneakers graphic tees, subculture woven into fashion --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7 III with 35mm lens, a streetwear scene, a dawn queue outside the drop wearing layered hoodies and rare sneakers as box-fresh pairs change hands, hoodie black and sneaker white sparked by brand orange, identity worn as tribal affiliation and cultural currency, crisp urban light, 8k`

### **Summoning**

**№ 863 / 1001** — *Ritual staged to call something back*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Western ceremonial magic (the Clavicula Salomonis, the Goetic grimoire tradition) supplies the single parent, and Summoning re-instruments that inheritance as compelled contact — the circle, the seal, the constraining name — without fusing in a second co-equal lineage.

**Atmosfera e mood**

**O ritual montado para chamar algo de volta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Invocação: círculo de velas e giz, fumaça subindo reta demais e o ar do quarto mudando de opinião — encenação de mística teatral.

**Paleta de cores** preto de rito, dourado de vela, giz pálido

**Melhores usos:** fantasia, capas, conceito

**MidJourney:** `[tema], summoning aesthetic, chalk circle candle ring smoke rising too straight, ritual staged to call something back --v 6`

**Prompt universal (Seedream):** `Ultra-atmospheric long-exposure photograph, a summoning tableau, a chalk circle ringed with guttering candles as incense smoke rises impossibly straight in the still room, pale sigils and ritual black warmed only by candle gold, the air visibly changing its mind, theatrical occult staging, 8k`

### **Superflat**

**№ 865 / 1001** — *Japanese Pop Culture Flattens Reality Into Commercial Art*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Pop Art's serial-commercial engine supplies the single parent, and Superflat re-instruments that inheritance by re-pointing factory logic at Japanese mass culture — otaku content and Edo flatness arrive as surface, not as co-equal structural parents.

**Atmosfera e mood**

**A cultura pop japonesa achatando a realidade em arte comercial** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Superflat: flores sorridentes de Murakami, perspectiva abolida e a linhagem ukiyo-e desembocando no anime e na vitrine.

**Paleta de cores** arco-íris saturado, contorno preto, branco de vinil

**Melhores usos:** arte, design, branding

**MidJourney:** `[tema], superflat aesthetic, Murakami smiling flowers abolished perspective, ukiyo-e flowing into anime --v 6`

**Prompt universal (Seedream):** `Ultra-vivid flat vector composition in the superflat manner, grinning rainbow flowers and wide-eyed characters tiled edge to edge with perspective abolished entirely, Takashi Murakami candy saturation over vinyl white, the ukiyo-e lineage flattened straight into anime and the gallery gift shop, immaculate flat color, 8k`

### **Supernatural**

**№ 868 / 1001** — *Presence felt before it is seen*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → ILLUMINATION ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Gothic's sublunary darkness and architecture of dread supply the single parent, and Supernatural re-instruments that inheritance by flooding it with celestial and esoteric signs, converting a fear of the dark into a system for reading it.

**Atmosfera e mood**

**A presença sentida antes de ser vista** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sobrenatural: a cortina mexendo sem vento, o vulto no limite do foco e a câmera registrando o que a razão ainda nega.

**Paleta de cores** cinza de penumbra, branco de cortina, preto de corredor

**Melhores usos:** terror, capas, conceito

**MidJourney:** `[tema], supernatural aesthetic, curtain moving without wind figure at the edge of focus, presence felt before seen --v 6`

**Prompt universal (Seedream):** `Shot on Ilford Delta 3200 handheld, a supernatural frame, a curtain moving in a windless hallway while something almost resolves at the edge of focus, penumbra gray and corridor black pressing against thin curtain white, presence arriving before sight agrees to confirm it, unsettled high-ISO grain, 8k scan`

### **Superrealism**

**№ 869 / 1001** — *Paint sharpened past the camera's eye*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Pop Art's photographic appropriation supplies the single parent, and Superrealism re-instruments that inheritance by discarding the irony and raising optical fidelity above every other value.

**Atmosfera e mood**

**A pintura afiada além do olho da câmera** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Superrealismo: o retrato em escala de parede onde cada poro é decisão pintada — Chuck Close vencendo a lente no próprio jogo.

**Paleta de cores** tons de pele ampliados, cinza de fundo neutro, brilho de íris

**Melhores usos:** arte, retratos, editorial

**MidJourney:** `[tema], superrealism aesthetic, wall-scale portrait every pore a painted decision, sharper than the camera --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a superrealist painting, a wall-scale frontal portrait where every pore stubble shadow and iris flare is an individually painted decision in the Chuck Close manner, magnified skin tones against neutral gray, paint out-resolving the camera at its own game, staggering detail, 8k scan`

### **Symbolism**

**№ 883 / 1001** — *Painting that speaks in riddles and omens*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** The system reduces no further — Romantic imagination and Neo-Platonic participation supply surrounding pressure but not parenthood, since removing the irreducible symbol collapses the whole system into mere allegory, the signature of a root node.

**Atmosfera e mood**

**A pintura que fala em enigmas e presságios** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Simbolismo: olhos fechados, esfinges e flores que significam outra coisa — Redon e Moreau pintando o que só o sonho confessa.

**Paleta de cores** violeta de presságio, dourado de mito, negro de enigma

**Melhores usos:** arte, capas, conceito

**MidJourney:** `[tema], symbolism aesthetic, closed eyes sphinxes flowers meaning something else, riddles and omens --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a symbolist painting, a closed-eyed figure drifting among sphinxes and flowers that clearly mean something else, Redon violet and Moreau gold smoldering out of enigmatic black, the canvas speaking only in riddles and omens, dreamlike painted mystery, 8k scan`

### **Tudor Elizabethan (1558–1603)**

**№ 912 / 1001** — *Power Embroidered Across the Golden Court*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Perpendicular Gothic, mediated Italian Renaissance, and Burgundian court culture converge here, each supplying a load-bearing feature nothing else replaces, fixing Tudor Elizabethan as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**O poder bordado pela corte dourada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Elisabetano: a rainha em gola de renda impossível, pérolas às centenas e cada bordado do vestido funcionando como comunicado de Estado.

**Paleta de cores** branco de cerusa, dourado de corte, vermelho Tudor

**Melhores usos:** histórico, moda, editorial

**MidJourney:** `[tema], elizabethan aesthetic, impossible lace ruff hundreds of pearls, embroidery as state communiqué --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an Elizabethan court portrait in the Nicholas Hilliard manner, a monarch in an impossible lace ruff and gown sewn with hundreds of pearls, ceruse white and court gold against Tudor red drapery, every embroidered emblem issuing a communiqué of state power, jeweled period precision, 8k scan`

### **Turquerie**

**№ 914 / 1001** — *Ottoman Fantasy Tailored for Europe*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → SYNTHESIS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Early-modern European exoticism supplies the single parent, and Turquerie re-instruments that inheritance by refracting it through one specific object of desire: the Ottoman court.

**Atmosfera e mood**

**A fantasia otomana talhada para a Europa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Turquerie: aristocratas do século XVIII posando de caftã e turbante em salões parisienses — o Oriente imaginado como moda de corte.

**Paleta de cores** turquesa de caftã, dourado de brocado, vermelho de tapete

**Melhores usos:** histórico, arte, editorial

**MidJourney:** `[tema], turquerie aesthetic, 18th century aristocrat in kaftan and turban parisian salon, the imagined orient as court fashion --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an eighteenth-century turquerie portrait in the Liotard manner, a European aristocrat posed in a turquoise kaftan and jeweled turban on carpet-draped cushions in a Parisian salon, brocade gold against carpet red, the Ottoman world refashioned as court fantasy, delicate pastel precision, 8k scan`

### **Tweencore**

**№ 917 / 1001** — *Glitter, Catazines, and the Mall Between Childhood and Teen*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** McBling's bedazzled maximalism, Kidcore's brightness, and Old Web messenger culture's screen-name selfhood converge here, each supplying a load-bearing layer nothing else replaces, fixing Tweencore as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Glitter, revistas e o shopping entre a infância e a adolescência** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tweencore: gloss com glitter, pôster dobrado da revista e a praça de alimentação como primeiro território próprio — 2004 entre dois mundos.

**Paleta de cores** rosa de gloss, lilás de mochila, prata de glitter

**Melhores usos:** nostalgia, conteúdo, editorial

**MidJourney:** `[tema], tweencore aesthetic, glitter lip gloss folded magazine poster food court 2004, between childhood and teen --v 6`

**Prompt universal (Seedream):** `Shot on a 2004 Sony Cybershot with flash, a tweencore afternoon, glitter lip gloss and a folded magazine poster spilling from a lilac backpack on a mall food-court table, gloss pink and silver sparkle under fluorescent light, the first territory owned between childhood and teen, sweet digicam nostalgia, 8k scan`

### **Uncanny Valley**

**№ 924 / 1001** — *Almost Human Is the Problem*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → NUANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Photographic Realism and synthetic Simulation converge here, each supplying a load-bearing layer nothing else replaces, fixing Uncanny Valley as a two-parent hybrid rather than a single-parent revision.

**Atmosfera e mood**

**O quase-humano é o problema** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vale da estranheza: o rosto sintético com um sorriso meio segundo atrasado, pele perfeita demais e olhos que refletem a luz errada.

**Paleta de cores** pele de silicone, branco de laboratório, cinza de servo

**Melhores usos:** conceito, sci-fi, capas

**MidJourney:** `[tema], uncanny valley aesthetic, synthetic face smile half a second late too-perfect skin, almost human is the problem --v 6`

**Prompt universal (Seedream):** `Ultra-photoreal 3D render, an uncanny valley portrait, an android face with flawless silicone skin holding a smile exactly half a second too long, lab white background and servo gray at the jaw seam, eyes reflecting light from a source that is not in the room, almost human and therefore deeply wrong, unsettling perfection, 8k`

### **Urban Fantasy**

**№ 931 / 1001** — *Magic Takes the Last Train Home*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → THEME ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Secondary-world fantasy keeps its supernatural order, bestiary, and laws of enchantment; the revision changes only the address — magic re-housed in the contemporary city.

**Atmosfera e mood**

**A magia pegando o último trem para casa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Fantasia urbana: runas brilhando sob o grafite, a fada cochilando no vagão vazio e o feitiço conjurado entre uma estação e outra.

**Paleta de cores** azul de metrô noturno, dourado de runa, violeta de feitiço

**Melhores usos:** capas, conceito, arte digital

**MidJourney:** `[tema], urban fantasy aesthetic, runes glowing under graffiti fae asleep on the empty carriage, magic takes the last train home --v 6`

**Prompt universal (Seedream):** `Ultra-detailed cinematic digital painting, an urban fantasy night, golden runes glowing faintly beneath the graffiti of a rattling last-train carriage while a winged figure dozes against the window, subway blue cut with spell violet, magic commuting home like everyone else, enchanted metropolitan atmosphere, 8k`

### **UrBling**

**№ 933 / 1001** — *Street Status in Chrome and Crystal*

**Nível:** 🟣 Secundária

**Eixo:** SEMIOTICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem semiótica reconhecível é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** UrBling reinterprets McBling's glossy, logo-saturated maximalism alone, recoding its display logic for a different street, gender, and source culture without fusing in a second structural parent.

**Atmosfera e mood**

**Status de rua em cromo e cristal** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

UrBling: correntes espelhadas, grillz lapidados e a roda cromada girando parada — o luxo declarado em quilates e brilho de esquina.

**Paleta de cores** cromo espelhado, dourado de corrente, branco de cristal

**Melhores usos:** moda urbana, música, editorial

**MidJourney:** `[tema], urbling aesthetic, mirror chains cut grillz chrome spinners, street status in carats --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS-1D X Mark III with 35mm lens, an urbling portrait at night, mirror-polished chains and crystal-set grillz flashing over a chromed lowrider wheel still spinning at the curb, chrome and chain gold detonating under streetlight, status declared in carats and corner shine, hard glossy brilliance, 8k`

### **Valley**

**№ 935 / 1001** — *California Sun on Suburban Aspiration*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** The Golden State booster myth and 1980s mall-consumer culture converge here, each supplying a load-bearing layer nothing else replaces, fixing Valley as a two-parent hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Sol californiano sobre aspiração suburbana** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Valley: piscina no quintal do San Fernando, shopping como centro cívico e o bronzeado como currículo — like, totalmente os anos 80.

**Paleta de cores** azul de piscina, rosa de maiô 80s, bege de estuque

**Melhores usos:** nostalgia, lifestyle, editorial

**MidJourney:** `[tema], valley aesthetic, san fernando backyard pool mall as civic center, california sun on suburban aspiration --v 6`

**Prompt universal (Seedream):** `Shot on Canon AE-1 Program with 28mm lens, a Valley afternoon in 1985, a turquoise backyard pool ringed by lounge chairs and stucco beige under flat San Fernando sun, eighties swimsuit pink against permanent tan, the mall waiting as civic center beyond the fence, sun-bleached aspirational haze, 8k scan`

### **Vaporwave**

**№ 940 / 1001** — *Mall Music Melting Under a Digital Sunset*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Hypnagogic pop/chillwave, hauntology, and plunderphonics converge here, each supplying a load-bearing layer nothing else replaces, fixing Vaporwave as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**A música de shopping derretendo sob um pôr do sol digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vaporwave: busto grego em rosa, janela do Windows 95 flutuando e o muzak desacelerado até virar saudade de um shopping que nunca existiu.

**Paleta de cores** rosa de vapor, ciano de grade, roxo de crepúsculo digital

**Melhores usos:** arte digital, música, capas

**MidJourney:** `[tema], vaporwave aesthetic, pink greek bust floating windows 95 slowed muzak, nostalgia for a mall that never existed --v 6`

**Prompt universal (Seedream):** `Ultra-vivid digital collage, a vaporwave dreamscape, a pink marble Greek bust floating between Windows 95 windows and a checkerboard floor dissolving into a gradient digital sunset, vapor pink and grid cyan bleeding into dusk purple, mall muzak slowed until it becomes longing for a place that never existed, glitch-soft nostalgia, 8k`

### **Venetian Carnival**

**№ 943 / 1001** — *Identity Hidden Behind Baroque Permission*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** The concealment-that-licenses-transgression grammar survives the removal of any single antecedent and generates diluted downstream copies rather than descending from them, the signature of a foundational node.

**Atmosfera e mood**

**A identidade escondida atrás da permissão barroca** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Carnaval de Veneza: a máscara bauta na alvorada da Piazza San Marco, capas de seda na névoa da laguna e a cidade inteira autorizada a ser outra.

**Paleta de cores** dourado de máscara, vinho de capa, névoa de laguna

**Melhores usos:** cultura, editorial, capas

**MidJourney:** `[tema], venetian carnival aesthetic, bauta mask at dawn piazza san marco silk capes in lagoon mist, licensed to be someone else --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 III with 85mm lens, a Venetian carnival dawn, a gilded bauta mask and wine-dark silk cape turning in the empty Piazza San Marco as lagoon mist softens the colonnades, mask gold burning through pearl fog, an entire city licensed by the baroque to be someone else, mysterious opulent stillness, 8k`

### **Victorian Mourning**

**№ 949 / 1001** — *Grief Codified in Jet and Black Crepe*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** The codified grief-protocol has no constitutive parent — Georgian memorial custom and Romantic melancholy supply atmosphere, not structure — and the system stands as the irreducible root every later death-aesthetic inherits.

**Atmosfera e mood**

**O luto codificado em azeviche e crepe negro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Luto vitoriano: dois anos de preto regulamentado, broche com mecha de cabelo e o véu de crepe — a dor administrada por etiqueta.

**Paleta de cores** negro de crepe, azeviche lapidado, cinza de retrato memorial

**Melhores usos:** histórico, gótico, editorial

**MidJourney:** `[tema], victorian mourning aesthetic, two regulated years of black jet brooch with a lock of hair, grief administered by etiquette --v 6`

**Prompt universal (Seedream):** `Collodion portrait photograph, Victorian mourning, a veiled widow in regulation black crepe holding a jet brooch woven with a lock of hair beside a draped memorial frame, lapidary black on black relieved only by pale skin, grief codified into two administered years of etiquette, solemn period gravity, 8k scan`

### **Vintage**

**№ 953 / 1001** — *Time Adds Value the Factory Cannot*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Vintage braids three lineages — Romanticism's reverence for ruins, Arts and Crafts's handmade warmth, and the broader nostalgia mode — into a multi-generation hybrid that fathers Steampunk, Vaporwave, and Cottagecore in turn.

**Atmosfera e mood**

**O tempo agregando o valor que a fábrica não consegue** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vintage: o relógio com pátina de três donos, o vinil com a capa gasta no canto certo e a feira onde cada objeto chega com biografia.

**Paleta de cores** couro envelhecido, latão com pátina, papel amarelado

**Melhores usos:** produto, lifestyle, editorial

**MidJourney:** `[tema], vintage aesthetic, three-owner patina worn vinyl corner flea market biography, value the factory cannot add --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Retina IIIc, a vintage flea market still, a three-owner wristwatch with honest patina beside worn vinyl sleeves and yellowed paperbacks on aged leather, brass and amber softened by decades of hands, every object arriving with its own biography, nostalgic tactile richness, 8k scan`

### **Web 3.0**

**№ 968 / 1001** — *Decentralization Drawn as Tomorrow*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Four lineages converge with visible DNA — Cyberpunk's texture, Vaporwave's gradient sweep inverted from irony to earnest futurism, Net Art's browser-native production, Silicon Valley's tech-utopian confidence — fused into a node-graph grammar that resists decomposition into any one ancestor.

**Atmosfera e mood**

**A descentralização desenhada como amanhã** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Web 3.0: nós luminosos sem centro, blocos encadeados em órbita e o gradiente roxo-ciano prometendo que desta vez a rede pertence a todos.

**Paleta de cores** roxo de protocolo, ciano de nó, preto de fundo infinito

**Melhores usos:** tech, branding, conceito

**MidJourney:** `[tema], web 3.0 aesthetic, centerless glowing nodes chained blocks in orbit, decentralization drawn as tomorrow --v 6`

**Prompt universal (Seedream):** `Ultra-sleek isometric 3D render, a Web 3.0 vision, luminous nodes linked in a centerless lattice as chained translucent blocks orbit through protocol purple and node cyan, no tower and no middleman anywhere in frame, decentralization illustrated as a confident tomorrow, glowing crystalline network, 8k`

### **Witchcraft**

**№ 980 / 1001** — *Ritual Power Returns to Daily Objects*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** No movement fathered the witch — Gardnerian ceremony, feminist reclamation, and the digital #WitchTok revival are descendants quoting a category that preceded them, so stripping any one away leaves the irreducible core, a practitioner working symbolic correspondence between matter and unseen force, fully intact.

**Atmosfera e mood**

**O poder ritual devolvido aos objetos diários** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Bruxaria: ervas secando de cabeça para baixo, a vela riscada com intenção e a cozinha operando como altar — o sagrado no gesto doméstico.

**Paleta de cores** verde de erva seca, âmbar de vela, negro de caldeirão

**Melhores usos:** místico, editorial, conteúdo

**MidJourney:** `[tema], witchcraft aesthetic, herbs drying upside down intention-carved candle kitchen as altar, ritual power in daily objects --v 6`

**Prompt universal (Seedream):** `Shot on Pentax MX with 50mm lens, a witchcraft kitchen altar, bundled herbs drying upside down over a carved intention candle beside a mortar of crushed rosemary and one iron pot, dried green and candle amber against cauldron black, ritual power returned quietly to daily objects, intimate candlelit mystery, 8k scan`

### **Woke**

**№ 981 / 1001** — *Black Awareness Worn as Visual Language*

**Nível:** 🟤 Terciária

**Eixo:** SEMIOTICS ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos de linhagens distintas são recombinados numa nova gramática relacional.

**Nota genealógica original (EN):** Three documented bloodlines converge — Civil Rights placard culture, Black Power's fist-forward iconography, and Crenshaw's intersectional frame — with synthesis running at least two generations deep since Black Power had already reworked Civil Rights grammar before #BlackLivesMatter recombined both with feminist and queer codes.

**Atmosfera e mood**

**A consciência negra vestida como linguagem visual** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Woke: o retrato na linhagem de Kwame Brathwaite — cabelo natural coroado, estampas afirmadas e a beleza negra fotografada como declaração política e orgulho.

**Paleta de cores** dourado de pele iluminada, laranja de estampa, negro de fundo digno

**Melhores usos:** cultura, retratos, editorial respeitoso

**MidJourney:** `[tema], black is beautiful aesthetic, natural crown affirmed prints Kwame Brathwaite lineage, awareness worn as visual language --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 500EL with 80mm lens in the Kwame Brathwaite manner, a Black is Beautiful portrait, a model with a natural crowned afro and bold affirmed prints lit in warm studio gold against dignified black, awareness worn openly as visual language and beauty photographed as a political statement, regal luminous pride, 8k`

### **Yuppie**

**№ 994 / 1001** — *Corporate Ambition Tailored as Armor*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** Three named descendants — Yuccie, Bobo, Tech Bro — each fork this same signaling logic into new domains without crediting a shared parent, the structural signature of a root that spawns branches; strip the finance costume and the irreducible law, convert income into a readable sign, survives intact.

**Atmosfera e mood**

**A ambição corporativa alfaiatada como armadura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Yuppie: 1987 — suspensórios sobre camisa de colarinho branco, o Rolex conferido em público e o cartão de visita como duelo — a carreira vestida para intimidar.

**Paleta de cores** risca de giz, branco de colarinho, dourado de Rolex

**Melhores usos:** editorial, cinema, conceito

**MidJourney:** `[tema], yuppie aesthetic, 1987 suspenders over contrast collar Rolex checked in public, career dressed to intimidate --v 6`

**Prompt universal (Seedream):** `Shot on Canon New F-1 with 85mm lens, a yuppie portrait in 1987, red suspenders over a white contrast collar as a Rolex is checked for the room's benefit against the trading floor's glow, pinstripe gray and gold conducting the whole negotiation, corporate ambition tailored explicitly as armor, sharp predatory polish, 8k scan`

### **Zoomorphic**

**№ 1000 / 1001** — *Animal Form Rewrites the Human Object*

**Nível:** 🔴 Primária

**Eixo:** SEMIOTICS ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova gramática de signos ao romper uma convenção anterior.

**Nota genealógica original (EN):** There is nothing earlier for this to descend from — the Löwenmensch and the Chauvet cave animals arrive with anatomical certainty before writing or agriculture, and its spread is universal since every culture produced it independently; strip the animal referent and the whole system evaporates, the mark of an irreducible root.

**Atmosfera e mood**

**A forma animal reescrevendo o objeto humano** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Zoomórfico: a cadeira com pernas de gazela, o bule com bico de garça, a arquitetura que respira como um organismo — o reino animal contratado como engenheiro-chefe.

**Paleta de cores** madeira escultórica, bronze de garra, marfim de curva orgânica

**Melhores usos:** design, produto, arquitetura

**MidJourney:** `[tema], zoomorphic aesthetic, gazelle-legged chair heron-spout teapot breathing architecture, the animal kingdom as chief engineer --v 6`

**Prompt universal (Seedream):** `Ultra-clean studio photograph, a zoomorphic design object, a sculptural chair whose carved legs resolve into gazelle hooves beside a bronze teapot with a heron-neck spout, sculptural wood and claw bronze on seamless ivory, animal anatomy formally rewriting the human object, elegant biomimetic craft, 8k`

## Leitura do padrão — o que as 111 estéticas confirmam

### Zero entradas suprimidas — o segundo instrumento unidirecional

Todas as 111 são SEMIOTICS ↑ — a lista repete o padrão de INTENTIONALITY: o signo removido não funda identidade sozinho. O registro ↓ (o signo raspado, a etiqueta cortada) existe no corpus apenas como slot secundário de outros ideogramas — Parisian (ESTHETICS ↑ → SEMIOTICS ↓), CONCRETE ART (INTENTIONALITY ↑ → SEMIOTICS ↓). E Normcore é a prova pelo limite: "Strip the Disguise and It Becomes Ordinary Plainness" ainda é SEMIOTICS ↑ — o disfarce despido vira uniforme, a remoção só significa enquanto ainda é lida como signo. Faz sentido estrutural: este é o instrumento da legibilidade; negá-la por inteiro é sair do jogo, não fundar um.

### Seis famílias recorrentes

**1. O signo sem lastro** — o maior par único da lista é INTEGRITY ↓ (Balletcore "pointe shoe worn by feet that never trained", Hipster, Hypebeast, Paninaro, Gangster, Pop Punk, Offbeat, Galaxy Hipster, Changelingcore): o código emprestado sem a vida que o sustentaria — a sapatilha sem o treino, a rebeldia passada no caixa. É o cluster que mais prova a lei do Li: o fogo brilha por fora e é oco no centro.

**2. Signo como doutrina** — EMANATIO ↑ (Symbolism, Esoteric, Hermeticism, Summoning, Pop Art, Neo Pop, Détournement, Serpentcore, Flat Design, BOUJEE): o signo que irradia — do selo goético à lata de sopa no altar.

**3. O código que envelhece em instituição** — ETERNITY ↑ (Victorian Mourning, Iconic, Jewish, Ivy League, Royalcore, Greek Revival, Gothic Revival Vitoriano, Pittura Metafisica) e o contraponto exato em ETERNITY ↓ (Americana "Porch, not the flag", Exoticism, Imperial Russian, Factory Pomo): o código datado de propósito.

**4. Signo contra substrato** — SEMIOTICS ↑ → MATTER ↓ (CONCEPTUAL ART, Simulacrum, Superrealism, Chinoiserie, BEATNIK, Iki, Futuristic Minimalism, [Net.art](http://Net.art)): a ideia, a cópia e o desejo inacabado acima da matéria — com o espelho em MATTER ↑ (Zoomorphic, Mesopotamian, Southern Grassland Indigenous, Fantastic Realism): o signo escrito na argila, no corpo, na pele viva.

**5. O corte do código** — EDITING ↑ (Situationism, Snob, Stealth Wealth, Normcore, Neo-Punk, Vaporwave, Cloisonnism): o signo editado, subtraído ou roubado e devolvido hostil.

**6. A declaração decidida** — INTENTIONALITY ↑ (Woke, Bridal, Meta, Enigmatic, Kinderwhore, Fantasy Punk, E Core): o signo como ato — o limiar que torna vinculante, a consciência vestida como linguagem.

### Polaridades

os signos fundadores rompem (Black Power, Zoomorphic, Southern Grassland Indigenous, Victorian Mourning, Venetian Carnival, Yuppie, Symbolism, Witchcraft, CONCEPTUAL ART, Post-Modernism — XY-rupture: o punho, o animal, a máscara e o luto geram gramática em vez de herdá-la); os códigos sagrados e de ofício transmitem intactos (Esoteric, Hermeticism, Pop Art, Jewish, Moroccan, Mesopotamian, Protestant, Pre-Modernism, Magic, Dapper, Eagle — XX); e as tribos de consumo e de plataforma rearticulam (Hipster, Hypebeast, Vaporwave, Tweencore, Memecore, Web 3.0 — XY-rearticulation, o bloco mais numeroso).

### O teste operacional

SEMIOTICS não é "simbolismo" como etiqueta — é qualquer estética cuja prova visual responde a uma pergunta só: *há um signo decodificável com procedência, e um público dividido entre quem lê e quem só vê?* Por isso Black Power, Stealth Wealth e Memecore convivem — o punho sem legenda, a etiqueta virada para dentro e a piada que virou dialeto são objetos incomparáveis, mas todos passam pelo mesmo teste: removido o código compartilhado, não sobra estética; sobra roupa.

# ESTHETICS — a Espiral de Phi

<aside>
🌀

**Essência.** ESTHETICS mede a prioridade dada à organização sensorial e ao prazer formal. Seu ideograma é a Espiral de Phi — uma lei de crescimento, não um ornamento: cada volta nasce da relação estabelecida pelas anteriores. No registro ↑, a beleza resulta de uma proporção interna que o corpo reconhece antes do argumento; no registro ↓, a crueza recebe deliberadamente mais autoridade que a harmonia.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para ESTHETICS, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem a curva própria de cada estética, enquanto a arquitetura preserva a lógica da Espiral de Phi — uma lei de crescimento descrita sem recorrer aos rótulos banidos pelo glossário.

> **↑ ESTHETICS — universal prompt.** A figure composed along one continuous curve — weight on the back foot, hip and shoulder counter-rotated in classical contrapposto, the neck elongated as the curve's final interval — posture resolving like a cadence; one unbroken line from shoulder to fingertip, a wrist continuing the drape's arc, every gesture completing the composition's geometry rather than interrupting it; a serene proportioned gaze turned along the composition's own path so the eye enters the frame exactly where it is wanted, effortless resolution with no strain anywhere in the face; luminous even skin with softly sculpted contour, hair shaped into one architectural curve — [the aesthetic's own curve: a rolled sweep, a coiled chignon, a lacquered wave] — repeating the composition's arc, brows and lips balanced to the face's own proportions and nothing exaggerated beyond its ratio; [the aesthetic's own line-holding garment: bias-cut drape, structured couture, a fluid column] whose seams travel on growth curves, the hem's arc echoing the architecture's arc; photographed level on an 85mm at f/5.6 on tripod at sternum height so vertical proportions stay true, the framing decided by ratio before the model enters; the figure placed on the frame's major division and the key gesture on the minor, [the aesthetic's own proportioned architecture: a spiral stair, an arched colonnade, a domed rotunda] as the built echo of the same law; polished soft key with slow continuous falloff travelling the curve without breaking it, highlights placed on cheekbone, shoulder and hip like points on one growth line; a set that demonstrates the law the body obeys, every interval in the frame related to the last exactly as the last was to the one before, beauty that could not be otherwise.
> 

**Universal ESTHETICS ↓ negative line (always pair with the ↑ prompt):**

> No broken lines, no hard shadow edges cutting the curve, no off-balance crops, no harsh on-camera flash, no exaggerated makeup outside the face's ratio, no cluttered set, no visible strain, no stained walls, no graceless dumped stances, no garment worn wrong on purpose, no snapshot framing with the head at the frame's edge.
> 

**Como usar para as 30 estéticas da lista.** Troque os colchetes pela curva própria da estética — a arquitetura só nomeia mecanismos (a linha contínua do ombro à ponta do dedo, o intervalo repetido, a luz que percorre a curva sem quebrá-la, a prova da razão em quadro). Exemplos: para **Renaissance**, a perspectiva e a proporção harmônica como a própria arquitetura — a rotunda e o nu proporcionado; para **Art Nouveau / Modernisme**, a linha-chicote como curva contínua tirada do crescimento botânico, a pedra catalã florescendo contra a grade; para **Rococo / Rocaille / Louis XVI**, a concha e o cartucho em escala íntima, a gravidade drenada sem perder a lei; para **Dolce Vita / Parisian / Ladylike**, a ease engenheirada — luvas, pérolas e postura como cadência social; para **Kitsch / McBling / BUBBLEGUM BLING**, mantenha a lei da curva e troque o mármore pelo strass — o polimento a serviço do exagero, a razão sobrevivendo ao flamingo rosa; para **Idealism**, a Forma acima do mármore — o par MATTER ↓ dizendo que a proporção importa mais que a pedra. Para **Hauntology**, inverta para o registro ↓ — a beleza deliberadamente degradada, o disco de biblioteca de 1973 que nunca chegou ao ar.

## Fundamentos do elemento

### Identidade, proporção e lei de crescimento

**Identity.** Priority given to sensory organization and formal pleasure. Its ideogram is the spiral a Franciscan mathematician called divine in 1509: each turn related to the last exactly as the last was to the one before, a law of growth rather than an ornament, proportion the body recognizes before any argument. In an image this element is proven by beauty that needs no defence, or by rawness given rank above prettiness. **Prompt guard:** the words *golden ratio* and *golden spiral* never enter a prompt — image models have ingested them as a style label millions of times — sand drawn by hand, in the Vale's own words; describe the law of growth instead, each turn related to the last exactly as the last was to the one before.

**The law of growth.** The spiral is a rule, not an ornament: one ratio decided before the model enters, and every interval — figure, gesture, architecture, crop — answering it. Beauty here is structural consequence (beleza funcional): the curve is not added to please; it grows from the frame's own law, and the viewer cannot say why it is beautiful, only that it could not be otherwise. The failure mode is decoration — a graceful line that answers nothing.

**Rank, not prettiness.** The suppressed register is not ugliness but a verdict about rank: rawness deliberately placed above harmony — the flat-footed stance, the flash on the stained wall, the garment worn wrong on purpose. It gains authority precisely by refusing composition, and it must read as refusal, never as failed beauty: one convention overturned against a frame that is otherwise fully committed.

## Corpo — postura, gesto e olhar

**Model posture & structure.** The body composed along one continuous curve — weight on the back foot, hip and shoulder counter-rotated in classical contrapposto, the neck elongated as the curve's final interval; posture that resolves like a cadence. Suppressed register: flat-footed, knees soft, weight dumped into one hip without elegance — posture that refuses composition and gains authority by refusing it.

**Gesture.** One unbroken line from shoulder to fingertip — a wrist continuing the drape's arc; gestures that complete the composition's geometry rather than interrupt it. Suppressed: blunt functional gestures — a hand shoved in a pocket, an arm hanging, nothing continuing any line.

**The look — how the eyes behave.** A serene, proportioned gaze turned along the composition's path so the eye enters the frame where the composition wants it; effortless resolution, no strain anywhere in the face. Suppressed: a hard, unaccommodating stare straight down the lens — presence ranked above prettiness.

## Regras de imagem — da curva à prova de proporção

**Look & styling continuity.** Bias-cut drape or structured couture whose seams travel on growth curves, the hem's arc echoing the architecture's arc; fabric chosen for how it holds a continuous line — satin crepe, duchesse, fluid wool. Suppressed: the garment worn wrong on purpose — buttoned off by one, collar crushed, hem uneven; utilitarian pieces with no drape logic.

**Camera.** 85mm at f/5.6, tripod, level; camera height at the model's sternum so vertical proportions stay true; framing decided by ratio before the model enters. Suppressed: 35mm with direct on-camera flash, handheld, slightly too close, f/8 hard depth — the vernacular snapshot register executed with total commitment.

**Composition.** The figure on the frame's major division, the key gesture on the minor; a spiral staircase, arched colonnade or domed rotunda as the architectural echo; every interval in frame answering the same proportion; the crop itself a ratio decision. Suppressed: off-balance and confrontational — head near the frame edge, horizon ignored, empty space in the wrong place and kept there.

**Lighting.** Polished soft key with slow, continuous falloff — light that travels the curve without breaking it; highlights placed on the arcs (cheekbone, shoulder, hip) like points on one growth line; no hard edges to interrupt the line. Suppressed: raw on-camera flash flattening the face and throwing one hard halo shadow on the wall behind — no fill, no grace.

**Beauty detail.** Polished, harmonized beauty — luminous even skin with sculpted soft contour; hair shaped into one architectural curve (a rolled sweep, a coiled chignon) repeating the composition's arc; brows and lips balanced to the face's own proportions, nothing exaggerated beyond the ratio. Suppressed: deliberately unpolished — visible pores and asymmetry kept, hair roughly shoved back, yesterday's liner faded in place, grooming honest to the hour it was shot.

**Cenography.** Proportioned architecture — a marble spiral stair, a colonnade with harmonic bays, a domed rotunda; materials that carry curves gracefully; the set as a built demonstration of the same law the body obeys. Suppressed: a stained wall, a strip-lit corridor, a curb — surfaces with history and no charm, the set found, not built.

**Colour.** Marble-pale families held at one temperature so nothing interrupts the line — colour as another interval in the same scale, saturation admitted only where it obeys the ratio. Suppressed: whatever the flash found — colour honest to the hour, uncorrected and kept.

**Proportion proof.** Wherever the frame allows it, plant one device proving the ratio governs: the hem's arc repeating the staircase's arc, the same interval legible at three scales, the highlight chain reading as points on one curve — or, in the refusal register, one convention of harmony visibly overturned against an otherwise committed frame. An image that is merely pretty, with no governing law recoverable from it, is this instrument's most legible failure.

**Practitioner lines (from the codices).** Clifford Coffin — one dominant compositional curve doing the work a dozen props would do, the silhouette readable at a glance before any detail resolves. Cecil Beaton — the sitter as one element inside a decorative pattern built from unlikely materials, flat high-key light, the artifice declared. Gian Paolo Barbieri — theatrical constructed sets with set-builder precision, couture treated as heritage object. Jeanloup Sieff — the body elongated into one sculptural curve, proportion deliberately stretched rather than classically balanced. For the refusal register: Hanna Moon — 'wrong' composition made a language, off-centre crops and deadpan domestic strangeness ranked above polish.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Classical formal pleasure: drape unfurling along a growth curve, composition agreeing with the architecture's own proportions, polished light with slow falloff, symmetry of pose and setting.

> **↑ Prompt.** A gown whose drape unfurls along one continuous curve from shoulder to train, the composition ruled into proportions that agree with the staircase behind it, a marble-pale palette, polished light with slow smooth falloff, symmetry of pose and architecture, an image built to please the eye before it informs it.
> 

> **↑ Negative line.** No broken lines, no hard shadow edges cutting the curve, no off-balance crops, no harsh flash, no exaggerated makeup outside the face's ratio, no cluttered set, no visible strain.
> 

**↓ Suppressed — repertory.** Rawness outranking prettiness: hard on-camera flash, stained walls, garments worn wrong on purpose, graceless honest stances, off-balance composition.

> **↓ Prompt.** Harsh on-camera flash against a water-stained wall, a beautiful garment worn wrong, buttoned off by one, hem caught in a boot, the model's stance graceless and honest, the composition off-balance with the head near the frame's edge, rawness given rank above harmony.
> 

> **↓ Negative line.** No ruled proportion, no continuous curves, no polished soft light, no contrapposto, no sculpted beauty, no marble or colonnades, no graceful drape.
> 

## Estéticas relacionadas a ESTHETICS (A–Z)

As 30 estéticas classificadas sob ESTHETICS, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Art Nouveau**

**№ 060 / 1001** — *Whiplash line traced from a peacock's train*

**Nível:** 🔴 Primária

**Eixo:** ESTHETICS ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova lei formal ao romper uma convenção estética anterior.

**Nota genealógica original (EN):** No prior aesthetic can be named as its maker — the whiplash line arrives as a first principle drawn directly from botanical growth rather than from an earlier style, and every element bears load, so removing the organic line collapses the whole rather than a branch.

**Atmosfera e mood**

**Linha-chicote traçada da cauda do pavão** — (1001 Aesthetics, interpretação)

Nouveau: linhas orgânicas sinuosas, mulheres-flor, molduras ornamentais à la Mucha.

**Paleta de cores** dourado, oliva, marfim, pêssego

**Melhores usos:** pôsteres, ilustração, decoração

**MidJourney:** `[tema], art nouveau style by Alphonse Mucha --v 6`

**Prompt universal (Seedream):** `Exquisite illustration in Alphonse Mucha poster style, a woman framed by an ornamental floral halo, flowing whiplash lines and hand-lettered borders, muted gold olive and peach lithograph palette, delicate stippled shading and gilded accents, 1900 Parisian elegance, ultra-fine print reproduction, 8k`

### **Belle Époque**

**№ 085 / 1001** — *Iron painted gold and called peace*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Nota genealógica original (EN):** Academic classicism, Art Nouveau's organic line, and industrial iron engineering converge in the same frame; each donor remains legible and none alone produces gilded iron, marking fusion across lineages rather than the reworking of one parent.

**Atmosfera e mood**

**Ferro pintado de ouro e chamado de paz** — (1001 Aesthetics, interpretação)

Belle Époque: Paris 1900, cafés dourados, varandas de ferro, otimismo de cartaz.

**Paleta de cores** dourado, creme, verde-parisiense, rosa

**Melhores usos:** cenários, pôsteres, romance

**MidJourney:** `[tema], Belle Époque Paris 1900 --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a Belle Époque evening on a gilded Parisian café terrace, elegant figures in 1900 silk gowns and top hats beneath cast-iron balconies and gas lamps, champagne sparkle and warm golden optimism, Toulouse-Lautrec poster palette translated into cinematic photography, soft lamplight bloom, richly detailed period costume, 8k`

### **Bubbleglam**

**№ 130 / 1001** — *Glamour held at the edge of collapse*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → RESONANCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Nota genealógica original (EN):** Old-Hollywood glamour, kitsch pastel palettes, and digital hyperreal rendering converge; strip the glamour parent and there is nothing to destabilize, strip the digital surface and the collapse never becomes visible — a weld of several lines.

**Atmosfera e mood**

**Glamour à beira do colapso** — (1001 Aesthetics, interpretação)

Glamour-bolha: brilho iridescente de bolha de sabão, pele gloss, fragilidade prestes a estourar.

**Paleta de cores** iridescente, rosa e lilás perolados

**Melhores usos:** beleza, editorial, capas

**MidJourney:** `[tema], bubbleglam iridescent glossy beauty --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a bubbleglam beauty editorial, iridescent soap-bubble sheen stretched across glossy skin, pearlescent pink and lilac highlights swirling like oil on water, fragile glamour a breath from bursting, dreamy diffused beauty-dish light, hyperreal pore-level detail, futuristic cosmetics-campaign polish, 8k`

### **BUBBLEGUM BLING**

**№ 131 / 1001** — *Rhinestone covenant of post-Y2K hyperpop*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Nota genealógica original (EN):** Y2K pop styling, club-kid excess, and hyperpop's digital maximalism fuse; remove the Y2K strand and the rhinestone loses its period, remove the hyperpop strand and the excess loses its speed — recombination rather than single-parent revision.

**Atmosfera e mood**

**Pacto de strass do hyperpop pós-Y2K** — (1001 Aesthetics, interpretação)

Bling chiclete: celular flip coberto de pedrinhas, acessórios gloss, brilho máximo hyperpop.

**Paleta de cores** rosa-chiclete, prata, brilho de strass

**Melhores usos:** música, moda jovem, social

**MidJourney:** `[tema], bubblegum bling y2k hyperpop, rhinestones --v 6`

**Prompt universal (Seedream):** `Shot on an early-2000s digicam with direct flash, a bubblegum bling y2k still life, rhinestone-encrusted flip phone and glossy pink accessories on holographic vinyl, glitter charms and butterfly clips, hot pink and silver sparkle overload, harsh flash bloom with Paris Hilton-era attitude, hyperpop saturation, 8k detail`

### **Chunyu**

**№ 155 / 1001** — *Innocence held at the edge of desire*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Nota genealógica original (EN):** East Asian youth-idol imagery, romantic literary convention, and contemporary photographic styling converge; strip the literary line and the tension has no plot, strip the styling and it cannot circulate — fusion of separate lineages.

**Atmosfera e mood**

**Inocência à beira do desejo** — (1001 Aesthetics, interpretação)

Chunyu (“chuva de primavera”): retrato suave e púdico, pele em luz difusa, flor molhada e ambiguidade delicada.

**Paleta de cores** rosa-pétala, branco, verdes de chuva

**Melhores usos:** retratos, editorial artístico

**MidJourney:** `[tema], soft spring rain portrait, delicate innocence --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a soft chunyu portrait, spring rain beading on petals and skin in diffuse silver light, petal-pink and rain-washed green palette, wet lashes and porcelain glow in macro clarity, modest delicate beauty held at the edge of longing, ethereal editorial grading, 8k`

### **Decadent**

**№ 209 / 1001** — *Luxurious excess at the threshold of moral surrender*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática formal é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Excesso luxuoso no limiar da rendição moral** — (1001 Aesthetics, interpretação)

Decadentismo: banquete abandonado, veludo amassado e ouro, beleza madura demais prestes a estragar.

**Paleta de cores** vinho, dourado envelhecido, sombras quentes

**Melhores usos:** editorial, arte, still life

**MidJourney:** `[tema], decadent opulence, abandoned banquet, overripe beauty --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 32mm lens, a decadent scene, abandoned banquet with crushed velvet and tarnished gold, overripe fruit and dripping candles in caravaggesque low light, luxurious excess at the threshold of moral surrender, cinematic oil-painting grading, sumptuous texture detail, 8k`

### **DECO-LUXE**

**№ 211 / 1001** — *Geometric glamour made inhabitable*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Glamour geométrico tornado habitável** — (1001 Aesthetics, interpretação)

Deco de luxo: leques e raios art déco em latão e mármore, veludo esmeralda, glamour de Gatsby para viver.

**Paleta de cores** esmeralda, latão dourado, mármore negro

**Melhores usos:** interiores, hotelaria, branding premium

**MidJourney:** `[tema], deco-luxe interior, brass fan motifs and emerald velvet --v 6`

**LoRA (Civitai):** "Art Deco — CE" — civitai.com/models/998799 (base art déco, match aproximado)

**Prompt universal (Seedream):** `Shot on Hasselblad with 50mm lens, a deco-luxe interior, art deco fan and sunburst motifs in polished brass against black marble, emerald velvet seating under a low warm glow, Gatsby glamour made inhabitable, specular reflections on lacquered surfaces, opulent editorial grading, 8k`

### **Dolce Vita**

**№ 236 / 1001** — *Ease engineered to glide through the city*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática formal é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A leveza projetada para deslizar pela cidade** — (1001 Aesthetics, interpretação)

Dolce vita: Roma anos 60, Vespa e óculos escuros, fonte e vestido de noite, glória despreocupada italiana.

**Paleta de cores** preto e branco de Fellini, dourado romano

**Melhores usos:** moda, viagem, editorial

**MidJourney:** `[tema], la dolce vita, 1960s Rome elegance, Fellini style --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Tri-X with 50mm lens, a dolce vita scene, 1960s Rome elegance with Vespa and dark sunglasses, evening gown trailing past a baroque fountain at night, Fellini black-and-white glamour with paparazzi flash, effortless Italian ease gliding through the city, rich film grain, timeless cinema still`

### **Dollcore**

**№ 237 / 1001** — *Made by hand, mistaken for human*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Atmosfera e mood**

**Feito à mão, confundido com humano** — (1001 Aesthetics; código: sref-midjourney.com, categoria doll-like, match aproximado)

Bonecas: porcelana e olhos de vidro, vestidos de renda em miniatura, doce com um toque inquietante.

**Paleta de cores** porcelana, rosa antigo, renda creme

**Melhores usos:** personagens, arte, editorial

**MidJourney:** `--sref 4161297525 --sw 1000` (Elegant Floral Harmony — categoria doll-like)

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, a dollcore portrait, porcelain doll with glass eyes and miniature lace dress, handmade sweetness with an uncanny edge, antique pink and cream under soft attic light, hairline cracks in the glaze at macro clarity, made by hand mistaken for human, 8k`

### **Edwardian (1901–1910)**

**№ 268 / 1001** — *Gaslight Gilds the Peacock Wallpaper*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática formal é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A luz de gás doura o papel de parede de pavão** — (1001 Aesthetics, interpretação)

Eduardiano: blusas de renda de gola alta e cintura de vespa, salões dourados a gás, o último brilho antes da guerra.

**Paleta de cores** marfim de renda, dourado de gás, azul-pavão

**Melhores usos:** histórico, moda, narrativa

**MidJourney:** `[tema], Edwardian era 1900s, lace high-collar gowns, gaslit interiors --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, an Edwardian scene 1901-1910, high-collar lace blouse and wasp waist in exquisite fabric detail, gaslight gilding peacock wallpaper in a drawing room, ivory and gold with peacock blue, the last glow before the war, painterly period-drama grading, 8k`

### **Epicurean**

**№ 298 / 1001** — *Swirl Before the First Sip*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → INTENTIONALITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O girar da taça antes do primeiro gole** — (1001 Aesthetics, interpretação)

Epicurista: mesa posta com prazer consciente, vinho e luz de vela, o saborear como filosofia.

**Paleta de cores** borgonha, dourado de vela, linho

**Melhores usos:** gastronomia, lifestyle, editorial

**MidJourney:** `[tema], epicurean table, wine swirl in candlelight, mindful pleasure --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 50mm f/1.2, an epicurean scene, wine swirling in the glass before the first sip, set table in candlelight with linen and burgundy tones, steam rising from the plate, savoring as philosophy, chiaroscuro food editorial, 8k`

### **Floral**

**№ 338 / 1001** — *Chintz Botanicals Blooming Across Every Surface*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Botânicas de chintz florescendo sobre toda superfície** — (1001 Aesthetics; código: sref-midjourney.com, categoria Floral Patterns)

Floral: flores cobrindo tudo, padrão botânico total, exuberância de jardim domesticada em estampa.

**Paleta de cores** rosas, verdes de folha, creme de fundo

**Melhores usos:** estampas, decorativo, branding

**MidJourney:** `--sref 763718510 --sw 1000` (categoria Floral Patterns)

**Prompt universal (Seedream):** `Shot on Mamiya 645 with 120mm macro lens, a floral pattern design, chintz botanicals blooming across every surface, roses and leaf greens on cream in soft daylight, every petal vein resolved, garden exuberance domesticated into print, textile editorial clarity, 8k`

### **Fruitcore**

**№ 351 / 1001** — *Cherry Prints and Citrus Color at Full Ripeness*

**Nível:** ⚫ Quaternária

**Eixo:** ESTHETICS ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Atmosfera e mood**

**Estampas de cereja e cor cítrica em plena maduração** — (1001 Aesthetics; código: Lummi, match aproximado)

Frutal: cerejas e limões como estampa e cenário, doçura vitaminada, verão em ponto de colheita.

**Paleta de cores** vermelho cereja, amarelo limão, laranja, verde de folha

**Melhores usos:** branding, estampas, editorial verão

**MidJourney:** `--sref 1239975060 --sw 1000` (Macro Orange — match aproximado)

**Prompt universal (Seedream):** `Shot on Canon R5 with 100mm macro lens, a fruitcore image, cherry prints and citrus color at full ripeness, lemon yellow and cherry red with leaf green under bright studio light, dewy skin of the fruit sharp in focus, vitamin sweetness and harvest-point summer, 8k`

### **Hauntology**

**№ 420 / 1001** — *1973 Library Record That Never Reached Broadcast*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↓ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Atmosfera e mood**

**O disco de biblioteca de 1973 que nunca foi ao ar** — (1001 Aesthetics; código: Lummi, match aproximado)

Hauntologia: mídia retrô assombrada, VHS de programa educativo que não existe, o futuro perdido transmitindo em estática.

**Paleta de cores** cores desbotadas de TV analógica, sépia de arquivo, estática

**Melhores usos:** arte conceitual, música, editorial experimental

**MidJourney:** `--sref 4075906083 --sw 1000` (Old Film — match aproximado)

**Prompt universal (Seedream):** `Scanned archival print, a hauntology image, a 1973 library record sleeve that never reached broadcast, faded analog TV colors and archival static, Julian House Ghost Box collage style, an educational program from a lost future still transmitting, 8k`

### **Idealism**

**№ 454 / 1001** — *Plato's Form Holds the Marble Figure Above the World*

**Nível:** 🔴 Primária

**Eixo:** ESTHETICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática formal é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**A Forma de Platão sustenta a figura de mármore acima do mundo** — (1001 Aesthetics, interpretação)

Idealismo: beleza perfeita acima do real, figura clássica banhada em luz ideal, o mundo como sombra da forma.

**Paleta de cores** mármore luminoso, azul de éter, dourado de ideal

**Melhores usos:** arte, filosofia visual, editorial

**MidJourney:** `[tema], idealist classical aesthetic, perfect marble figure held above the world in ideal light --v 6`

**Prompt universal (Seedream):** `Shot on Phase One XF with 80mm lens, an idealism image, a perfect marble figure held above the world in ideal light, Platonic form more real than reality, luminous ether blue and gold, 8k`

### **Joie de Vivre**

**№ 495 / 1001** — *Renoir's Luncheon Lets the Table Run Past Afternoon*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O almoço de Renoir deixa a mesa avançar pela tarde** — (1001 Aesthetics; código: Lummi, match aproximado)

Joie de vivre: prazer de viver pintado, mesa farta e riso ao ar livre, a tarde que ninguém quer encerrar.

**Paleta de cores** rosa de pele ao sol, branco de toalha, vinho, verde de pérgola

**Melhores usos:** gastronomia, lifestyle, editorial alegre

**MidJourney:** `--sref 59239704 --sw 1000` (Paint Strokes — match aproximado)

**Prompt universal (Seedream):** `Museum-grade reproduction of an impressionist canvas, a joie de vivre painting, a luncheon letting the table run past afternoon like Renoir's Luncheon of the Boating Party, loose strokes on sunlit skin and white cloth, wine and pergola green, laughter no one wants to end, 8k`

### **Kitsch**

**№ 504 / 1001** — *Featherstone’s 1957 pink flamingo*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → INTEGRITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática formal é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O flamingo rosa de Featherstone (1957)** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Kitsch: mau gosto elevado a afeto, subúrbio americano, plástico rosa contra gramado verde.

**Paleta de cores** rosa flamingo, verde de gramado, céu suburbano

**Melhores usos:** editorial irônico, decoração, campanha pop

**MidJourney:** `[tema], kitsch aesthetic, 1957 pink plastic flamingo on manicured lawn, suburban irony --v 6`

**Prompt universal (Seedream):** `Shot on Kodachrome 64 with 35mm lens, a kitsch image, Don Featherstone's 1957 pink flamingo planted in a manicured lawn, flamingo pink against suburban green, John Waters suburbia irony, bad taste elevated to affection, 8k`

### **Ladylike**

**№ 510 / 1001** — *Gloves, pearls, posture held*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Luvas, pérolas, postura mantida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ladylike: etiqueta como silhueta, rosa-pó e marfim, elegância de salão em postura perfeita.

**Paleta de cores** rosa-pó, marfim, pérola

**Melhores usos:** moda clássica, editorial, retrato

**MidJourney:** `[tema], ladylike aesthetic, white gloves and pearls, perfect posture at tea, soft salon light --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 500C/M with 150mm lens, a ladylike image, white gloves and a single pearl strand holding perfect posture over afternoon tea, powder rose and ivory silk under soft north-window salon light, Norman Parkinson poise with a Grace Kelly stillness, etiquette worn as silhouette, refinement measured in millimetres, 8k`

### **Louis XVI Style (c. 1760–1790)**

**№ 530 / 1001** — *Fluted legs and gilded laurel*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Pernas caneladas e louro dourado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Luís XVI: a ordem restaurada depois do excesso rococó, boiserie cinza-pérola e ormolu.

**Paleta de cores** cinza-pérola, dourado ormolu, branco de palácio

**Melhores usos:** interiores, mobiliário, editorial histórico

**MidJourney:** `[tema], Louis XVI style aesthetic, fluted legs and gilded laurel, pearl grey boiserie, palace daylight --v 6`

**Prompt universal (Seedream):** `Shot on Phase One XT with 70mm lens, a Louis XVI style image, fluted tapering legs and gilded laurel garlands on a neoclassical mahogany commode, pearl grey boiserie and ormolu mounts under tall palace daylight, Versailles restraint in the Petit Trianon manner, straight lines returned as a moral argument after rococo excess, 8k`

### **Lustercore**

**№ 541 / 1001** — *Mother-of-pearl and chrome glare*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Madrepérola e brilho de cromo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lustercore: superfícies competindo para segurar a luz, arco-íris de óleo sobre prata polida.

**Paleta de cores** madrepérola, cromo, iridescência

**Melhores usos:** joalheria, produto, editorial

**MidJourney:** `[tema], lustercore aesthetic, mother-of-pearl iridescence against hard chrome glare, oil-slick rainbows --v 6`

**Prompt universal (Seedream):** `Shot on Leica S with 100mm macro lens, a lustercore image, mother-of-pearl iridescence colliding with hard chrome glare, oil-slick rainbows sliding across polished silver curves, a single studio strip light stretched into liquid highlights, nacre pink and petrol violet trading places as the angle shifts, surfaces competing to keep the light, 8k`

### **Magnetcore**

**№ 545 / 1001** — *Iron filings snapping to field lines*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Atmosfera e mood**

**Limalha de ferro estalando nas linhas de campo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Magnetcore: a física desenhando o próprio diagrama, arcos de grafite sobre branco.

**Paleta de cores** grafite, preto de ferro, branco de laboratório

**Melhores usos:** ciência, arte abstrata, editorial

**MidJourney:** `[tema], magnetcore aesthetic, iron filings snapping into arcs along invisible field lines --v 6`

**Prompt universal (Seedream):** `Extreme macro photograph shot with Canon MP-E 65mm lens, a magnetcore image, iron filings snapping into perfect arcs along invisible field lines, graphite black patterns bristling on laboratory white, a bar magnet combing its poles into symmetrical fur, Berenice Abbott science-photography elegance, physics caught drawing its own diagram, 8k`

### **McBling**

**№ 555 / 1001** — *Rhinestones at the Speed of a Motorola Razr*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Atmosfera e mood**

**Strass na velocidade de um Motorola Razr** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

McBling: o excesso dos anos 2000 sem pedir desculpas, rosa chiclete, cromo e logomania.

**Paleta de cores** rosa chiclete, cromo, strass

**Melhores usos:** moda Y2K, editorial pop, campanha retrô

**MidJourney:** `[tema], McBling aesthetic, rhinestones and a pink Motorola Razr, velour tracksuit, harsh 2000s flash --v 6`

**Prompt universal (Seedream):** `Shot on an early-2000s Sony Cyber-shot with harsh onboard flash, a McBling image, rhinestones spelling a name across a pink Motorola Razr, velour tracksuit and chrome logomania blown out by tabloid flash, bubblegum pink against limo-tint black, red-carpet-adjacent excess grinning without apology, wealth performed at maximum sparkle, 8k`

### **Modernisme**

**№ 579 / 1001** — *Catalan Stone Blooming Against the Grid*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Pedra catalã florescendo contra a grade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Modernisme: Barcelona ondulando em trencadís e ferro forjado, a fachada de Gaudí como organismo.

**Paleta de cores** trencadís multicor, pedra ondulada, azul mediterrâneo

**Melhores usos:** arquitetura, viagem, editorial

**MidJourney:** `[tema], modernisme aesthetic, Gaudi's Casa Batllo facade rippling in trencadis mosaic, Catalan stone in bloom --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Zf with 20mm lens, a modernisme image, Gaudi's Casa Batllo facade rippling in trencadis mosaic and bone-curved stone, multicolor tile shimmering over wrought-iron balconies against Mediterranean blue, morning sun sliding across the scales like a dragon's back, Catalan architecture flowering deliberately against the grid, organic line refusing the ruler, 8k`

### **Parisian**

**№ 668 / 1001** — *Effortless Style With Expensive Training*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → SEMIOTICS ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Atmosfera e mood**

**Descuido ensaiado com treino caro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Parisiense: trench amassado no ponto certo, café na calçada e a elegância que finge não ter espelho.

**Paleta de cores** bege trench, cinza zinco, vinho de bistrô

**Melhores usos:** moda, lifestyle, editorial

**MidJourney:** `[tema], parisian aesthetic, effortless with expensive training, café terrace trench coat --v 6`

**Prompt universal (Seedream):** `Shot on Leica M2 with 35mm Summicron lens, a Parisian scene, a trench coat creased exactly right at a café terrace with zinc rooftops beyond, effortless posture that took expensive training, beige gray and bistro wine tones in soft overcast light, 8k`

### **Renaissance**

**№ 752 / 1001** — *Humanity's Rediscovery of Divinity*

**Nível:** 🔴 Primária

**Eixo:** ESTHETICS ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova lei formal ao romper uma convenção estética anterior.

**Nota genealógica original (EN):** No prior aesthetic exists to inherit; perspective, harmonic proportion, and the proportioned nude were assembled from dissection, geometry, and Roman ruin in fifteenth-century Florence — each device cut the medieval grammar of gold ground and additive pattern that preceded it, refusing the flat surface and the unmeasured figure as structurally incompatible with its new order.

**Atmosfera e mood**

**O humano medido em proporção divina** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Renascença: perspectiva florentina, sfumato e a razão áurea organizando rosto, arquitetura e fé.

**Paleta de cores** terracota florentina, azul ultramar, dourado de têmpera

**Melhores usos:** arte, histórico, editorial

**MidJourney:** `[tema], renaissance aesthetic, Florentine perspective sfumato golden ratio, the human divinely measured --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Florentine quattrocento painting, a portrait organized by the golden ratio with one-point perspective opening onto Tuscan hills, sfumato modeling in ultramarine terracotta and tempera gold, the human figure measured in divine proportion, 8k archival scan`

### **Rocaille**

**№ 764 / 1001** — *Baroque's Playful Cousin*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → INTEGRITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Italian Baroque’s ornamental vocabulary arrives intact, and Rocaille re-instruments it by subtracting gravity — the same shell-scroll, acanthus, and cartouche grammar is kept but halved in scale, drained of solemnity, and broken away from bilateral symmetry, so the inherited weight of seventeenth-century Counter-Reformation grandeur becomes the lightness of an intimate aristocratic pleasure-room.

**Atmosfera e mood**

**O primo brincalhão do barroco** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rocaille: conchas, volutas e espuma dourada — o ornamento assimétrico que ri da simetria barroca.

**Paleta de cores** dourado de talha, concha rosada, creme de boiserie

**Melhores usos:** ornamento, interiores, histórico

**MidJourney:** `[tema], rocaille aesthetic, asymmetric shell and scroll gilded ornament, baroque's playful cousin --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of rocaille ornament, asymmetric gilded shells and scrolling foam curling across cream boiserie panels, shell pink blushing through carved gold, baroque's playful cousin laughing at symmetry, raking light on every chisel mark, 8k documentation`

### **Rococo**

**№ 767 / 1001** — *Art Forgot Seriousness*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Baroque's gilded, theatrical grammar arrives intact — the same shell-scroll, cartouche, and total-environment ambition — and Rococo re-instruments it by draining the gravity out, scaling the monumental down to the intimate townhouse and the saturated dark up into candlelit pastel, so inherited drama becomes inherited delight.

**Atmosfera e mood**

**A arte que esqueceu a seriedade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rococó: balanços em jardins de açúcar, pastel espumante e o flerte pintado como assunto de Estado.

**Paleta de cores** rosa de Fragonard, azul-pó, dourado espumante

**Melhores usos:** arte, moda, editorial

**MidJourney:** `[tema], rococo aesthetic, garden swing frothy pastel silk, art that forgot seriousness --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a rococo painting, a silk-gowned figure on a garden swing kicking a slipper into frothy foliage, Fragonard pink and powder blue whipped with sparkling gold, flirtation painted as affair of state while seriousness waits outside, 8k archival scan`

### **Social Media II Instagram**

**№ 818 / 1001** — *Life color-graded for public approval*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Vernacular mobile photography's democratized snapshot arrives as the single parent, and Instagram re-instruments that inheritance by running the same frame through a second corrective pass, so an ordinary photo becomes, one turn later, a warmed, grid-ranked claim that a life is worth looking at.

**Atmosfera e mood**

**A vida gradada para aprovação pública** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Instagram: brunch em flat lay, golden hour agendada e a vida editada até caber na grade — perfeição como formato.

**Paleta de cores** terracota gradada, creme de latte, dourado de golden hour

**Melhores usos:** conceito, marketing, editorial

**MidJourney:** `[tema], instagram aesthetic, flat lay brunch scheduled golden hour curated grid, life color-graded for approval --v 6`

**Prompt universal (Seedream):** `Ultra-clean lifestyle photograph, an Instagram tableau, a flat-lay brunch with latte art angled beside linen and eucalyptus in scheduled golden hour, terracotta grade warming every surface toward the same approved palette, life edited until it fits the grid, flawless envy-ready light, 8k`

### **Streamline Moderne**

**№ 854 / 1001** — *Aerodynamic Dreams Take Flight*

**Nível:** 🟣 Secundária

**Eixo:** ESTHETICS ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem estética reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Art Deco's decorative vocabulary arrives as the single parent, and Streamline Moderne re-instruments that inheritance by rotating ornament onto a wind-tunnel curve, so the stacked zigzag becomes, one turn later, the unbroken teardrop line.

**Atmosfera e mood**

**Sonhos aerodinâmicos levantando voo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Streamline moderne: curvas de transatlântico em terra firme, cromo horizontal e a velocidade esculpida mesmo parada — 1937 em movimento perpétuo.

**Paleta de cores** branco de transatlântico, cromo de friso, verde-água de época

**Melhores usos:** arquitetura, design, editorial

**MidJourney:** `[tema], streamline moderne aesthetic, ocean liner curves horizontal chrome 1937, aerodynamic dreams --v 6`

**Prompt universal (Seedream):** `Ultra-clean architectural photograph, a streamline moderne building at golden hour, ocean-liner curves and porthole windows banded in horizontal chrome speed lines, liner white and period seafoam sculpted for a velocity it never needs, 1937 dreaming aerodynamically while standing still, 8k`

### **Tenniscore**

**№ 897 / 1001** — *Court Whites Hiding Competitive Heat*

**Nível:** 🟤 Terciária

**Eixo:** ESTHETICS ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens formais distintas são recombinadas numa nova gramática sensorial.

**Nota genealógica original (EN):** Victorian lawn-tennis dress, preppy institutional culture, and couture sportswear converge here, each leaving a load-bearing mark nothing else replaces, fixing Tenniscore as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Brancos de quadra escondendo calor competitivo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tenniscore: saia plissada imaculada, suéter de cable no ombro e a etiqueta do clube disfarçando a vontade feroz de vencer.

**Paleta de cores** branco de quadra, verde de saibro sintético, creme de suéter

**Melhores usos:** moda, esporte, editorial

**MidJourney:** `[tema], tenniscore aesthetic, immaculate pleated whites cable knit on shoulders, court etiquette hiding competitive heat --v 6`

**Prompt universal (Seedream):** `Shot on Minolta Dynax 9 with 200mm lens, a tenniscore moment, an immaculate pleated white skirt mid-serve with a cable-knit sweater draped on the bench beyond, court green ruled by white lines in high clean sun, club etiquette barely containing the ferocious will to win, crisp athletic elegance, 8k`

## Leitura do padrão — o que as 30 estéticas confirmam

### Uma entrada suprimida — e sua rima com MATTER

Hauntology é o único ESTHETICS ↓ da lista ("1973 Library Record That Never Reached Broadcast", ESTHETICS ↓ → SEMIOTICS ↑): a recusa do prazer formal só vira identidade quando o signo assume o comando — exatamente como Neo Surrealism, o único MATTER ↓, entregou o substrato ao signo. O padrão se confirma dos dois lados da estação MISE: SEMIOTICS é o herdeiro universal das supressões — o que a beleza e a matéria abdicam, o código recolhe.

### Cinco famílias recorrentes

**1. A curva herdada da corte** — Rococo, Rocaille, Louis XVI, Edwardian, Decadent, DECO-LUXE, Belle Époque: a linhagem do ornamento aristocrático, quase toda XX — o prazer formal como herança que se transmite de salão em salão.

**2. O prazer como modo de vida** — Dolce Vita, Joie de Vivre, Epicurean, Ladylike, Parisian: a elegância como performance social — a mesa de Renoir que atravessa a tarde, o swirl antes do primeiro gole.

**3. A lei de crescimento fundada** — Art Nouveau ("whiplash line traced from a peacock's train") e Renaissance, as duas rupturas-raiz da lista: a proporção assumida como primeiro princípio, não herdada — os Primaries que geram descendência em vez de citá-la. Modernisme e Floral como as revisões da mesma linha orgânica.

**4. O brilho acelerado** — McBling, BUBBLEGUM BLING, Bubbleglam, Lustercore, Kitsch, Fruitcore, Tenniscore: o prazer formal em velocidade comercial — rhinestone, cromo e fruta madura; o cluster onde a era da internet rearticula a curva clássica em plástico.

**5. Beleza contra a matéria** — o eixo MATTER: Idealism, Louis XVI e Lustercore no ↓ (a Forma acima do mármore, o brilho acima do peso) contra Art Nouveau e Floral no ↑ (a linha nascida da botânica) — ESTHETICS decidindo, caso a caso, se a proporção precisa da pedra ou a dispensa.

### Polaridades

é a lista mais transmissível do corpus depois das linhagens elementares — XX domina (Rococo, Rocaille, Edwardian, Decadent, Dolce Vita, Ladylike, Kitsch, Idealism, Floral: a beleza se herda e se revisa de corte em corte); as únicas rupturas-raiz são Art Nouveau e Renaissance — quando o prazer formal rompe, ele funda uma lei de crescimento inteira; e as rearticulações concentram-se na era da tela (McBling, BUBBLEGUM BLING, Bubbleglam, Chunyu, Dollcore, Magnetcore, Fruitcore, Tenniscore, Hauntology).

### O teste operacional

ESTHETICS não é "beleza" como elogio — é qualquer estética cuja prova visual responde a uma pergunta só: *a organização sensorial obedece a uma lei interna que dispensa defesa?* Por isso Renaissance, Dolce Vita e Kitsch convivem — a perspectiva harmônica, a ease ensaiada e o flamingo de 1957 são objetos incomparáveis, mas todos passam pelo mesmo teste em registros opostos: removida a lei da proporção (ou a recusa deliberada dela), não sobra estética; sobra enfeite.

# EDITING — o Obelos

<aside>
<img src="https://app.notion.com—" alt="https://app.notion.com—" width="40px" />

**Essência.** EDITING é a disciplina seletiva de inclusão, remoção, contenção e recusa. Seu ideograma é o Obelos — a marca horizontal que o bibliotecário de Alexandria colocava ao lado de um verso duvidoso: ela não apaga; declara que aquilo não pertence ao autor. No registro ↑, o corte continua visível como prova de autoria; no registro ↓, a acumulação é admitida inteira, sem hierarquia nem julgamento.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para EDITING, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem os sobreviventes e as marcas de remoção próprios de cada estética, enquanto a arquitetura preserva a lógica do Obelos — autoria por exclusão, com o removido ainda legível.

> **↑ EDITING — universal prompt.** A space stripped to three objects at most — [the aesthetic's own survivors: the one garment on a rail, the one tool, the one chair] — each given generous room, the emptiness reading as verdict rather than vacancy, the cleared floor's sheen almost holding the shadow of everything removed; one trace of the cull kept legible — [the aesthetic's own removal mark: an empty hook, a pale rectangle where something hung, ghost stitching where an emblem was unpicked] — because the cut declares itself instead of hiding; a single figure upright and economical as the author of the cleared space, the body itself edited to its essential line, hands empty and quiet because the cutting is finished or caught in one terminal gesture setting the last unnecessary object aside, never two gestures where one carries; an appraising steady gaze without cruelty, the expression of someone who knows exactly what was removed and why, judgment worn calmly and no approval requested; subtractive grooming holding exactly one decision — [the aesthetic's own single feature: a precise lip, one drawn line, a blunt cut] — with everything else cleaned back to bare skin and no second idea anywhere on the head; one garment cut perfectly and nothing competing — [the aesthetic's own surviving piece] — sharper for the absence of alternatives; photographed static on a 50mm at f/8 from a tripod with the edges patrolled so nothing enters the frame that was not chosen, one considered frame and never coverage; one clean soft directional source with quiet falloff, light that adds nothing and only confirms, the illumination itself edited; bare cared-for surfaces demonstrating what refusal builds — [the aesthetic's own cleared ground: a stripped dressing room, an emptied studio, a bare corridor, raked gravel] — the whole image legible as the last state of a long subtraction, never the first state of an empty room.
> 

**Universal EDITING ↓ negative line (always pair with the ↑ prompt):**

> No clutter, no second accessory or competing object, no layered styling, no decorative prop nobody touches, no busy background, no double gesture, no compensating camera angle, no maximalist makeup, no filler attitude in the body, no coverage where one frame carries, no emptiness that reads as budget or vacancy instead of decision, no accumulation admitted anywhere.
> 

**Como usar para as 45 estéticas da lista.** Troque só os colchetes pelo vocabulário material da estética — a arquitetura não nomeia lugar, tribo ou estilo, só os mecanismos que a página define como EDITING (o corte visível, a marca do removido, um gesto onde um basta, a moldura patrulhada). Para **Minimalism / Zen / Simplicity / Erasercore**, os sobreviventes são o objeto único e a pedra na areia rastelada; para **Quiet Luxury / Stealth / Platinumcore**, a marca do corte é o emblema removido — o status re-roteado para peso de tecido e acabamento; para **French / DANDY / Mod / Gamine**, a peça sobrevivente é o código enxuto que dispensa o resto (a listra bretã e o batom, o cravat, o target, o corte à Seberg); para **Sprezzatura / Chic / Sleek**, o que foi cortado é a evidência do esforço — a lei de que trabalho visível desqualifica o resultado; para **Suprematism / Abstract Art / Formalist / DADAISM**, o corte aplica-se à própria arte: o objeto removido, a figuração removida, o autor removido (o acaso como editor — DADAISM inverte o segundo eixo para ESTHETICS ↓); para **Boudoir**, o que se edita é a própria luz do dia, com o espelho embaçado como marca do removido.

## Fundamentos do elemento

### Identidade, exclusão e marca do corte

**Identity.** Selective discipline of inclusion, removal, restraint, and refusal. Its ideogram is the horizontal spit a librarian of Alexandria set beside every verse that sounded false: the mark does not erase, it declares *this does not belong to the author*. Authorship by exclusion; what is refused defines more than what is admitted. In an image this element is proven by visible restraint, or by accumulation admitted whole.

**The mark that does not erase.** The obelus's whole jurisprudence is that removal stays visible. Photographically this means one trace of the cull kept in frame — the empty hook, the pale rectangle on the wall, the ghost stitching of an unpicked emblem — because an edit that hides its own cutting is indistinguishable from poverty. The frame must prove that fullness was available and refused; a room that was always empty proves nothing about anyone's discipline.

**Authority by exclusion.** What is refused defines more than what is admitted, and the audience trusts an eye that has visibly cut. The working ratio is absolute: one gesture where one carries, one feature where one carries, one object where one carries — the second of anything is the beginning of clutter, and clutter is the confession that no verdict was reached.

**The open gap.** The manuscript names Editing's two escalations: the ensō's unclosed circle is Editing in its purest state — the mark that stops before completeness — and Despojar, the pruning verb, is Editing raised to rite. Both teach the same law: the cut is fidelity, not loss. What is removed is removed on behalf of what remains.

## Corpo — postura, gesto e olhar

**Model posture & structure.** The stillness of a decision already made — upright, economical, occupying the cleared space as its author; no compensating angles, no filler attitude; weight settled, the spine at its essential line, the body itself edited. Movement, where present, is terminal: it sets something aside and stops.

**Gesture.** One gesture of refusal or completion — a hand setting the last unnecessary object aside, or hands empty and quiet because the cutting is finished. The shadow is demonstrative decluttering: tidying performed at the lens so the restraint can be admired — the moment the cut asks for applause it has become inventory of another kind. Where the register escalates to ceremony, the gesture borrows the pruning verb: releasing rather than grasping, the gaze already past the released thing.

**The look — how the eyes behave.** The appraising editorial gaze — steady, discriminating, without cruelty; the expression of someone who knows exactly what was removed and why. Judgment worn calmly, blink rate low, mouth at rest; never the anxious re-check of the room, because re-checking implies the edit is not finished. One permitted exception per series: the gaze resting on the removal mark itself — the empty hook — for one frame, acknowledgment without regret.

## Regras de imagem — da subtração à prova de autoria

**Look & styling continuity.** One garment that survived the cull, cut perfectly, nothing competing; closures resolved, hem in one decided line, the piece sharper for the absence of alternatives. One trace of the removal may live on the body itself — the ghost stitching of an unpicked emblem, the pale band where a watch was retired. Refused: layering, a second accessory, and any element that would need to be explained.

**Camera.** 50mm at f/8, tripod, static considered frame; edges patrolled — nothing enters that was not chosen; one frame, not coverage. The crop is a cut and behaves like one: decided before the exposure, never rescued after it. If the image moves, it moves once and then holds.

**Composition.** Three objects maximum, each given room; negative space that reads as verdict, not vacancy; the floor's clean sheen almost holding the shadow of everything removed. The frame is built by subtraction in visible order: what remains sits where the removed things used to be, and their absence still organizes the geometry.

**Lighting.** One clean soft directional source, quiet falloff, no effects; light that adds nothing and only confirms — the illumination itself edited. A second source is a second opinion, and this element permits one.

**Beauty detail.** Subtractive beauty — one deliberate feature (a precise lip, or a drawn line, never both) and everything else cleaned back to skin; hair resolved in a single decision, a blunt cut or one severe sweep; no layering, no second idea anywhere on the face. The finish must read as the last state of a longer routine, never the first state of no routine: care visible in the quality of the skin, absence visible everywhere else.

**Cenography.** A room that demonstrates what refusal builds — one coat on a rail, one pair of shoes squared to the wall, one chair; surfaces bare and cared for. The set carries its own obelus: one legible mark of what was removed, because a rented void with no history of fullness makes no claim. Refused: decoration, a prop nobody touches, three objects that cannot each justify their survival.

**Colour.** A palette culled to one ground and one figure tone — the chromatic version of three objects. One colour is permitted to survive the cut and it must be the image's whole argument; everything else concedes to neutrals that read as chosen rather than as default.

**Refusal proof.** Wherever the composition allows it, plant one device proving the emptiness is authored: the empty hook beside the one occupied hook, the pale rectangle on the wall, a rail long enough for twenty holding one garment, the single discarded draft still in the bin. This is the obelus made photographic — the closest a still image comes to proving that what is absent was removed on purpose. A frame whose emptiness could be mistaken for a room not yet furnished is the single most legible failure this element can produce.

**Practitioner lines (from the codices).** David Sims — flat stark ground holding zero information, hard clean light making the silhouette a graphic fact, every lifestyle element removed, the isolated silhouette as what remains when the editorial process has been honest. Karim Sadli — a sculptor's economy: generous negative space, precise body geometry, the garment reduced to its strongest line. Peter Knapp — the Swiss grid and cut brought into the fashion page, aerial angles, geometric crops, the layout designed before the shutter. Brigitte Niedermair — metaphysical still-life flatness, every element pared until the frame is as considered as a painting's inventory. Harri Peccinotti — the typographer's blade applied to the body, radical graphic crops of lips and limbs, layout-first composition. Dario Catellani — the editor's blade applied to shooting itself: limbs bisected, motion sliced mid-arc, energy left deliberately unresolved. For the suppressed register: Roe Ethridge — commercial outtakes, stock imagery, and fashion frames spliced into one deadpan sequence, the rejected image promoted to thesis; Michel Comte — the frame kept is the one where the mask slipped.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Restraint made visible: a space stripped to three objects, the emptiness reading as decision rather than absence, what remains sharper for everything that was cut.

> **↑ Prompt.** A dressing room stripped to three objects, one black coat on a rail, one pair of shoes squared to the wall, one chair, the emptiness reading as decision rather than absence, the clean floor's sheen almost holding the shadow of everything removed, what is left standing sharper for everything that was cut.
> 

> **↑ Negative line.** No clutter, no second accessory, no layered styling, no decorative prop nobody touches, no busy background, no double gesture, no compensating camera angle, no maximalist makeup, no four eras worn at once, no walls shingled with images, no bowing garment rails, no emptiness without an authored trace of the cut.
> 

**↓ Suppressed — repertory.** Accumulation unedited: four eras worn at once, walls shingled with unsorted images, bowing garment rails, every surface an inventory, the camera wide enough to admit it all.

> **↓ Prompt.** A collector's bedroom where nothing was ever thrown away, the model dressed in four eras at once, walls shingled with unsorted photographs, garment rails bowing under their load, every surface an inventory, the camera pulled wide enough to admit all of it without judgement.
> 

> **↓ Negative line.** No minimalism, no empty surfaces, no curated negative space, no single-source dramatic light, no editorial restraint, no patrolled edges, no verdict emptiness, no irony toward the accumulation, no spotlighting or ranking of any object over another.
> 

## Estéticas relacionadas a EDITING (A–Z)

As 45 estéticas classificadas sob EDITING, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Abstract Art**

**№ 012 / 1001** — *Painting that stopped pretending*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → THEME ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Atmosfera e mood**

**Pintura que parou de fingir** — (1001 Aesthetics, interpretação)

Formas, cores e gestos livres de qualquer compromisso com a representação: composição pura, ritmo visual e equilíbrio.

**Paleta de cores** livre — blocos de cor saturada ou neutros com acentos fortes

**Melhores usos:** arte de parede, fundos, branding expressivo

**MidJourney:** `[tema], abstract art, non-representational composition --v 6`

**Prompt universal (Seedream):** `High-resolution fine art photograph captured on Hasselblad H6D with 80mm lens of a monumental abstract non-representational canvas, bold geometric shapes and layered color fields with visible brush texture and matte-gloss contrast, hung in a white gallery under precise track lighting, museum catalog quality, ultra sharp 8k detail`

### **Anti-Fashion**

**№ 051 / 1001** — *Two safety pins, 1977*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Atmosfera e mood**

**Dois alfinetes, 1977** — (1001 Aesthetics, interpretação)

Punk anti-moda: rasgado, alfinetes de segurança, DIY contra o sistema da moda.

**Paleta de cores** preto, xadrez tartan, vermelho

**Melhores usos:** moda alternativa, editorial, música

**MidJourney:** `[tema], 1977 punk anti-fashion, safety pins --v 6`

**Prompt universal (Seedream):** `Raw portrait shot on 35mm film with harsh direct flash, a 1977 London punk in ripped tartan and leather held together by safety pins, smeared eyeliner and a defiant sneer, gritty brick backdrop, high-contrast grain, anti-fashion rebellion, authentic documentary energy`

### **Avant-Garde**

**№ 076 / 1001** — *Cut before the manifesto*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** Its defining law — that the work must arrive before the framework that can explain it — cannot be inherited from any predecessor; it is a root condition, and removing the demand for precedence dissolves the category entirely.

**Atmosfera e mood**

**O corte antes do manifesto** — (1001 Aesthetics, interpretação)

Vanguarda: formas radicais e esculturais, quebra deliberada de regras antes da teoria.

**Paleta de cores** monocromia radical ou contraste extremo

**Melhores usos:** moda conceitual, editorial, arte

**MidJourney:** `[tema], avant-garde conceptual fashion --v 6`

**Prompt universal (Seedream):** `Conceptual fashion photograph shot on Phase One with 80mm lens, a radical sculptural silhouette in stark monochrome, deliberate rule-breaking pose and an extreme architectural garment, single hard light carving deep shadow on seamless white, Alexander McQueen meets Comme des Garçons, gallery-ready provocation, 8k`

### **Boudoir**

**№ 111 / 1001** — *Foxed mirror that keeps the daylight out*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Nota genealógica original (EN):** Private-interior decoration, portrait photography, and lingerie's dress codes converge; strip the photographic lineage and the room stops being staged for a viewer, strip the interior tradition and the intimacy loses its architecture — fusion of several lines.

**Atmosfera e mood**

**Espelho manchado que mantém a luz do dia do lado de fora** — (1001 Aesthetics, interpretação)

Boudoir: intimidade em luz baixa e quente, renda, espelhos antigos manchados.

**Paleta de cores** pele, champanhe, bordô, sombras quentes

**Melhores usos:** fotografia íntima, editorial

**MidJourney:** `[tema], boudoir photography, intimate warm low light --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.2, an intimate boudoir portrait in warm low light, figure in vintage lace beside an antique foxed mirror, champagne and burgundy tones with silk sheets catching candle glow, soft sensual privacy and tasteful shadow play, fine skin texture with film-like grain, editorial elegance, 8k`

### **Boutique**

**№ 115 / 1001** — *Edit made visible in ink on kraft*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → DOMAIN ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** A single retail lineage is carried forward and re-specified around scarcity — the shop's fixtures and rituals stay intact while the selection itself becomes the product, a reinterpretation within one line rather than a fusion of several.

**Atmosfera e mood**

**Edição visível em tinta sobre kraft** — (1001 Aesthetics, interpretação)

Curadoria de loja pequena: embalagens kraft, carimbos à mão, etiquetas escritas, charme artesanal editado.

**Paleta de cores** kraft, preto de carimbo, um acento de cor

**Melhores usos:** branding, embalagem, e-commerce

**MidJourney:** `[tema], boutique branding, kraft paper and stamped ink --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 50mm f/1.8, a boutique packaging still life, kraft paper parcels with hand-stamped ink logos, twine bows and handwritten labels on a worn oak counter, soft daylight from a shop window, curated small-shop charm, tactile paper grain and ink texture, Kinfolk editorial warmth, 8k`

### **Chic**

**№ 147 / 1001** — *Discipline of apparent ease*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** Its founding law — that visible effort disqualifies the result — cannot be inherited from any predecessor; it is asserted at the root, and removing the demand for concealed labour dissolves the category entirely rather than pruning a branch.

**Atmosfera e mood**

**Disciplina da facilidade aparente** — (1001 Aesthetics, interpretação)

Chique: alfaiataria limpa, poucos acessórios certos, elegância que parece casual.

**Paleta de cores** preto, creme, camel

**Melhores usos:** moda, branding, retratos

**MidJourney:** `[tema], effortlessly chic Parisian fashion editorial --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, a chic fashion editorial, clean tailoring in black cream and camel against a limestone Parisian facade, minimal perfect accessories and disciplined ease, soft overcast light sculpting cashmere texture, old Céline restraint through Peter Lindbergh's lens, refined neutral grading, 8k`

### **Clean**

**№ 160 / 1001** — *Wall that thinks before it decorates*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Nota genealógica original (EN):** Modernist reduction, Scandinavian domestic design, and commercial interior styling converge; strip the modernist parent and the restraint has no argument, strip the commercial strand and it never becomes a widely reproduced look — fusion of several lines.

**Atmosfera e mood**

**Parede que pensa antes de decorar** — (1001 Aesthetics, interpretação)

Clean: superfícies desimpedidas, luz difusa uniforme, um objeto por vez, silêncio visual deliberado.

**Paleta de cores** branco, cinza-claro, madeira clara

**Melhores usos:** produto, branding, interiores

**MidJourney:** `[tema], clean minimal design, uncluttered white space --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a clean minimal composition, one considered ceramic object on uncluttered white surfaces, soft even north light with barely-there shadows, pale wood and light gray accents, deliberate visual silence in Kinfolk-magazine restraint, immaculate texture detail, gallery-print quality, 8k`

### **DADAISM**

**№ 191 / 1001** — *Shake the hat, trust the order*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → ESTHETICS ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Atmosfera e mood**

**Sacuda o chapéu, confie na ordem** — (1001 Aesthetics, interpretação)

Dadaísmo: fotomontagem absurda, tipografia recortada e caótica, anti-arte que zomba da lógica (Hannah Höch, Tzara).

**Paleta de cores** preto e branco de jornal, acentos vermelhos

**Melhores usos:** arte, sátira, editorial

**MidJourney:** `[tema], dadaist photomontage, absurd cut-up typography --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a dadaist photomontage, absurd collage of newspaper cutouts and chaotic scattered typography, anti-art mockery of logic in black and white with red accents, razor-cut edges and glue shadows, Hannah Höch and Raoul Hausmann Berlin spirit, coarse 1920s print grain, 8k archival capture`

### **DANDY**

**№ 193 / 1001** — *Cut, the cravat, and the calculus of studied ease*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O corte, o lenço e o cálculo da elegância estudada** — (1001 Aesthetics, interpretação)

Dandismo: terno impecável excessivo, lenço de seda, bengala e a vaidade como filosofia (Beau Brummell, Wilde).

**Paleta de cores** veludo profundo, marfim, dourado discreto

**Melhores usos:** moda, retratos, editorial

**MidJourney:** `[tema], dandy fashion portrait, silk cravat and velvet tailoring --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a dandy portrait, impeccably excessive velvet tailoring with silk cravat and silver-topped cane, studied ease and calculated vanity in deep jewel tones against ivory, Rembrandt lighting on brocade texture, Oscar Wilde elegance with Cecil Beaton polish, museum-rich grading, 8k`

### **Degrowth**

**№ 216 / 1001** — *Discipline Held at Mended Seam, Rammed Wall, Seed Bank*

**Nível:** ⚫ Quaternária

**Eixo:** EDITING ↑ → EXPRESSION ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Atmosfera e mood**

**Costura remendada, parede de taipa, banco de sementes** — (1001 Aesthetics, interpretação)

Decrescimento: consertar em vez de comprar — remendos visíveis, taipa, horta comunitária e suficiência digna.

**Paleta de cores** terra crua, linho natural, verdes de horta

**Melhores usos:** sustentabilidade, editorial, lifestyle

**MidJourney:** `[tema], degrowth aesthetic, visible mending and rammed earth --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 35mm lens, a degrowth lifestyle scene, visible mending on well-worn clothes, rammed earth wall and community seed bank in soft morning light, repaired objects and garden abundance, dignified sufficiency over consumption, warm documentary honesty, 8k`

### **Demure**

**№ 219 / 1001** — *Discipline Held at Collar, Cuff, and Lowered Voice*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A disciplina de corte é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**Disciplina no colarinho, no punho e na voz baixa** — (1001 Aesthetics, interpretação)

Recato: gola alta e punhos fechados, olhar baixo elegante, contenção como sofisticação.

**Paleta de cores** creme, cinza-pérola, marinho discreto

**Melhores usos:** moda, retratos, branding

**MidJourney:** `[tema], demure fashion portrait, high collar modest elegance --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a demure portrait, high collar and buttoned cuffs, gracefully lowered gaze in soft window light, restrained pearl grey and cream palette, quiet composure as sophistication, painterly softness with fine fabric detail, 8k`

### **Eminent**

**№ 280 / 1001** — *Stamp That Outlasts the Signer*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A disciplina de corte é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O selo que sobrevive a quem assinou** — (1001 Aesthetics, interpretação)

Eminente: retrato de autoridade, selo e brasão, dignidade institucional que atravessa gerações.

**Paleta de cores** borgonha, dourado de selo, madeira escura

**Melhores usos:** retratos formais, institucional, histórico

**MidJourney:** `[tema], eminent formal portrait, seal and crest, institutional dignity --v 6`

**Prompt universal (Seedream):** `Shot on Leica M11 with 90mm lens, an eminent formal portrait, wax seal and crest on the desk, burgundy and dark wood with seal gold in low library light, institutional dignity, the stamp that outlasts the signer, old-master portrait lighting, 8k`

### **Erasercore**

**№ 300 / 1001** — *One Stone in the Raked Sand*

**Nível:** ⚫ Quaternária

**Eixo:** EDITING ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Uma pedra na areia rastelada** — (1001 Aesthetics, interpretação)

Apagamento: quase nada no quadro, jardim zen e página em branco, o que foi removido importa mais que o que ficou.

**Paleta de cores** branco, areia, cinza mínimo

**Melhores usos:** minimalismo, meditativo, conceitual

**MidJourney:** `[tema], extreme minimalism, one stone in raked zen sand --v 6`

**Prompt universal (Seedream):** `Shot on Leica M11 with 50mm lens, an erasercore image, one stone in raked sand, almost nothing in the frame under flat even light, white and pale grey, Hiroshi Sugimoto stillness, what was removed mattering more than what remains, 8k`

### **Fluxus**

**№ 340 / 1001** — *Maciunas's Event Scores and the Fluxkit Box*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → TECHNIQUE ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**As partituras de eventos de Maciunas e a caixa Fluxkit** — (1001 Aesthetics, interpretação)

Fluxus: anti-arte lúdica dos anos 1960, instruções datilografadas e caixas de objetos, arte como evento e piada séria.

**Paleta de cores** papel datilografado, preto de carimbo, caixas cruas

**Melhores usos:** conceitual, arte, editorial

**MidJourney:** `[tema], Fluxus art movement, typed event scores and Fluxkit box of objects --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex with 80mm lens, a Fluxus artwork, typed event score cards and a Fluxkit box of small found objects on a plain table, stamp black on typewriter paper under flat gallery light, George Maciunas playful anti-art as event and serious joke, 8k archival documentation`

### **Formalist**

**№ 344 / 1001** — *Clive Bell's 'Significant Form' Over Any Subject*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Atmosfera e mood**

**A 'forma significante' de Clive Bell acima de qualquer assunto** — (1001 Aesthetics, interpretação)

Formalista: composição pura de linha, cor e plano, o assunto irrelevante, a forma como único argumento.

**Paleta de cores** cores como elementos formais puros

**Melhores usos:** arte abstrata, editorial, conceitual

**MidJourney:** `[tema], formalist abstract composition, pure line color and plane over subject --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a formalist composition, pure arrangement of line color and plane where the subject is irrelevant, Ellsworth Kelly's significant form as the only argument, balanced abstract structure under flat gallery light, crisp edge fidelity, 8k`

### **French**

**№ 350 / 1001** — *Breton Stripe, the Red Lip, and Effortless Restraint*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Listra bretã, batom vermelho e contenção sem esforço** — (1001 Aesthetics, interpretação)

Francês: chique parisiense de poucos gestos, listra e trench coat, elegância que parece acidental.

**Paleta de cores** marinho e branco de listra, vermelho de batom, bege de trench

**Melhores usos:** moda, lifestyle, branding

**MidJourney:** `[tema], effortless French chic, Breton stripes and red lip, Parisian restraint --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 50mm lens, a French chic portrait, Breton stripe and red lip with a beige trench on a Parisian street, Jeanloup Sieff restraint, navy white and red, elegance that looks accidental, soft natural light, 8k editorial`

### **Gamine**

**№ 362 / 1001** — *Jean Seberg's Cropped Cut on the Champs-Élysées*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → INTENTIONALITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A disciplina de corte é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O corte curto de Jean Seberg na Champs-Élysées** — (1001 Aesthetics, interpretação)

Gamine: charme de menina-moça parisiense, cabelo curtinho e listra, leveza travessa da nouvelle vague.

**Paleta de cores** preto e branco de filme, marinho, batom discreto

**Melhores usos:** moda, retratos, editorial

**MidJourney:** `[tema], gamine style, Jean Seberg cropped pixie cut, nouvelle vague Paris --v 6`

**Prompt universal (Seedream):** `Shot on Leica M3 with 50mm lens on Ilford HP5 film, a gamine portrait, cropped pixie cut and striped shirt on the Champs-Élysées, nouvelle vague mood in black and white with navy, Raymond Cauchetier street candor, mischievous Parisian lightness, 8k`

### **Gen X**

**№ 369 / 1001** — *Cassette Click at the End of Side A*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A disciplina de corte é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O clique do cassete no fim do lado A** — (1001 Aesthetics, interpretação)

Geração X: quarto com pôster de banda e walkman, flanela e ceticismo, analógico vivido sem nostalgia ainda.

**Paleta de cores** cinza de fita, flanela desbotada, luz de tarde de TV

**Melhores usos:** nostálgico, editorial, retratos

**MidJourney:** `[tema], Gen X 90s bedroom, cassette walkman and band posters, flannel skepticism --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Fujifilm Superia film with 28mm lens, a Gen X scene, the cassette click at the end of side A in a 90s bedroom with band posters and a walkman, faded flannel and TV-afternoon light, analog lived without nostalgia yet, 8k`

### **Japandi**

**№ 485 / 1001** — *Wegner Chair Faces the Shōji Screen*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Atmosfera e mood**

**A cadeira Wegner encara o biombo shōji** — (1001 Aesthetics, interpretação)

Japandi: escandinavo e japonês em diálogo, madeira clara e papel de arroz, o wabi-sabi encontrando o hygge.

**Paleta de cores** carvalho claro, branco de shōji, cinza nórdico, verde de bonsai

**Melhores usos:** interiores, branding wellness, editorial

**MidJourney:** `[tema], Japandi interior, Wegner chair facing a shoji screen, pale oak and rice paper, wabi-sabi meets hygge --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX 100S with 45mm lens, a Japandi interior, a Wegner chair facing the shoji screen, pale oak and diffused rice-paper light, Scandinavian and Japanese calm in dialogue, wabi-sabi meeting hygge, 8k`

### **Minimalism**

**№ 575 / 1001** — *Last Object Left After Refusal*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A disciplina de corte é transmitida como continuidade reconhecível, sem ruptura estrutural.

**Atmosfera e mood**

**O último objeto que sobrou da recusa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Minimalismo: a forma reduzida até restar só o essencial, um volume preciso em espaço branco.

**Paleta de cores** branco, cinza neutro, um acento único

**Melhores usos:** design, arquitetura, branding

**MidJourney:** `[tema], minimalism aesthetic, one precise object in white space, Donald Judd reduction, nothing extra --v 6`

**Prompt universal (Seedream):** `Shot on Phase One XF with 55mm lens, a minimalism image, one precise volume placed in generous white space, neutral grey planes meeting at a single perfect shadow line, Donald Judd reduction with John Pawson calm, a lone accent of muted color carrying the entire composition, the last object left standing after refusal, 8k`

### **Mod**

**№ 577 / 1001** — *Target, the Scooter, the Clean Break*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**O alvo, a scooter, o corte limpo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mod: juventude britânica de 1966 em linhas afiadas, terno slim, parka e Vespa em Carnaby Street.

**Paleta de cores** alvo RAF, marinho, cromo de scooter

**Melhores usos:** moda retrô, editorial, capa musical

**MidJourney:** `[tema], mod aesthetic, slim suit and parka beside a Vespa on 1966 Carnaby Street, RAF target --v 6`

**Prompt universal (Seedream):** `Shot on Ilford FP4 with 35mm lens, a mod image, a slim suit and parka beside a chrome Vespa on 1966 Carnaby Street, RAF target and sharp navy tailoring, David Bailey crispness, youth cut on clean lines, 8k`

### **New Hollywood**

**№ 621 / 1001** — *Studio System Loses Final Cut*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → NARRATIVE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Atmosfera e mood**

**O estúdio entrega as chaves aos rebeldes** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nova Hollywood: grão de 1971, sombras que escondem metade do rosto e heróis moralmente ambíguos.

**Paleta de cores** âmbar de bar, marrom setentista, sombra profunda

**Melhores usos:** cinema, retratos, editorial

**MidJourney:** `[tema], New Hollywood 1971 aesthetic, grainy amber underexposure, morally ambiguous hero --v 6`

**Prompt universal (Seedream):** `Shot on Kodak 5254 film stock with a Panavision 40mm lens, a New Hollywood 1971 frame, a morally ambiguous face half-lost in Gordon Willis underexposure, amber bar light and seventies brown, the studio handing the keys to the rebels, rich cinematic grain, 8k scan`

### **Pixel**

**№ 688 / 1001** — *Nostalgia Built One Square at a Time*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Atmosfera e mood**

**Nostalgia construída um quadrado por vez** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pixel: sprites de 16 bits, dithering artesanal e pôr do sol em blocos perfeitos.

**Paleta de cores** paleta limitada 16-bit, ciano e magenta de crepúsculo

**Melhores usos:** games, arte digital, capas

**MidJourney:** `[tema], pixel art aesthetic, 16-bit sprites hand-placed dithering, blocky nostalgia sunset --v 6`

**Prompt universal (Seedream):** `Ultra-crisp pixel art scene, a 16-bit dusk built one square at a time, hand-placed dithering gradients across a cyan and magenta sky, tiny lit windows and sprite silhouettes, limited-palette nostalgia with every pixel intentional, clean upscaled sharpness, 8k`

### **Platinumcore**

**№ 692 / 1001** — *Wealth Coded Below the Volume of Silver*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Atmosfera e mood**

**Riqueza abaixo do volume da prata** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Platinumcore: metal escovado, frio e denso — o luxo que não reflete, absorve.

**Paleta de cores** platina escovada, cinza gelo, branco técnico

**Melhores usos:** luxo, produto, branding

**MidJourney:** `[tema], platinumcore aesthetic, brushed platinum cold density, luxury below silver's volume --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 90mm lens, a platinumcore composition, brushed platinum surfaces in cold dense light that absorbs more than it reflects, ice gray and technical white restraint, wealth pitched below the volume of silver, machined edges in flawless detail, 8k`

### **Post-Internet Minimalism**

**№ 705 / 1001** — *Digital Detox Through Design*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Mid-century Minimalism's empty ground, refusal of ornament, and single-object-on-wide-plane grammar transferred intact into this system, re-aimed from industrial commercial excess to digital saturation — the reduction vocabulary preserved while its adversary changed.

**Atmosfera e mood**

**O detox digital como projeto de design** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Minimalismo pós-internet: o celular virado para baixo, mesa limpa e a atenção tratada como o último luxo.

**Paleta de cores** branco de mesa, cinza de alumínio, verde de planta única

**Melhores usos:** lifestyle, branding, editorial

**MidJourney:** `[tema], post-internet minimalism aesthetic, phone face-down on empty desk, attention as last luxury --v 6`

**Prompt universal (Seedream):** `Ultra-clean lifestyle photograph, a post-internet minimalist desk, one phone face-down beside a single plant and nothing else, table white and aluminum gray under even daylight, the digital detox composed as deliberate design, attention framed as the final luxury, 8k`

### **Precisionism**

**№ 713 / 1001** — *America Found God in Steel and Smoke*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → EXPRESSION ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** When Charles Sheeler sanded the brushstroke out of his Rouge paintings and set aside both Cubist fragmentation and Futurist blur, he made the break explicit — the factory could not be worshipped if the hand that painted it remained visible, and the erasure of European gesture was the grammar's founding act.

**Atmosfera e mood**

**Deus encontrado no aço e na fumaça** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Precisionismo: fábricas e silos pintados como catedrais, geometria industrial sem uma alma humana no quadro.

**Paleta de cores** cinza de silo, azul de aço, branco de fumaça

**Melhores usos:** arte, industrial, editorial

**MidJourney:** `[tema], precisionism aesthetic, factories painted as cathedrals, industrial geometry without people --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a precisionist painting, grain silos and factory stacks painted as cathedrals in immaculate geometry, Charles Sheeler cool light with Charles Demuth angular smoke, steel blue and silo gray without one human soul in frame, razor-clean edges, 8k scan`

### **Primcore**

**№ 719 / 1001** — *Before Minimalism Had a Manifesto*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** When Adolf Loos attacked the Secession's ornamental program in 1900, naming every applied molding a crime against the surface that carried it, he made the rupture public — the law of accumulation that had governed Western building since antiquity was not reformed but cut, and the bare wall was declared the structural answer.

**Atmosfera e mood**

**Antes do minimalismo ter manifesto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Primcore: interior shaker, cadeiras penduradas na parede e a simplicidade praticada como virtude, não como estilo.

**Paleta de cores** madeira de bordo, branco de cal, azul shaker

**Melhores usos:** interiores, editorial, conceito

**MidJourney:** `[tema], primcore aesthetic, Shaker interior chairs hung on pegs, simplicity as virtue not style --v 6`

**Prompt universal (Seedream):** `Shot on a 4x5 camera with 135mm lens, a primcore Shaker interior, ladder-back chairs hung on peg rails above scrubbed maple floors, whitewash and Shaker blue in honest window light, simplicity practiced as virtue a century before minimalism wrote its manifesto, 8k`

### **Purecore**

**№ 734 / 1001** — *Innocence Used as Radical Refusal*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Nota genealógica original (EN):** Blake’s philosophy of embodied innocence, Victorian sentimentalism’s cultural fixation on purity, and Minimalism’s grammar of formal reduction were each complete positions; recombined here they produce the only aesthetic for which an undyed white room is simultaneously a moral claim, a childhood memory, and a philosophical proof that the unspoiled surface is the only honest one.

**Atmosfera e mood**

**Inçocência como recusa deliberada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Purecore: branco sobre branco, algodão limpo e luz sem sombra — a pureza escolhida, não ingenuidade.

**Paleta de cores** branco sobre branco, marfim, luz leitosa

**Melhores usos:** beleza, editorial, branding

**MidJourney:** `[tema], purecore aesthetic, white on white clean cotton shadowless light, innocence as refusal --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 203FE with 110mm lens, a purecore portrait, white cotton on white linen against a white wall in milky shadowless light, ivory gradations separating only by texture, innocence worn as deliberate refusal rather than naivety, serene medium-format purity, 8k`

### **Quiet Luxury**

**№ 737 / 1001** — *Wealth Learns to Whisper*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Old Money’s inherited dress codes arrive intact — the heavy cashmere, the country-house silhouette, the earned patina — then the visible emblem is removed and the status signal is re-routed entirely into fabric weight and hand-feel, re-instrumenting the parent grammar without cutting it.

**Atmosfera e mood**

**Riqueza falando em voz baixa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Luxo silencioso: cashmere em tons de osso, corte impecável e nenhuma marca visível — quem sabe, sabe.

**Paleta de cores** osso, greige, camel pálido

**Melhores usos:** moda, branding, editorial

**MidJourney:** `[tema], quiet luxury aesthetic, bone cashmere impeccable cut no visible brand, wealth whispering --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q2 with 28mm lens, a quiet luxury portrait, bone and greige cashmere cut impeccably with not one visible logo, The Row restraint in soft directional daylight, wealth speaking below conversation volume to those who already know, refined muted tonality, 8k`

### **Regency (1811–1820)**

**№ 750 / 1001** — *Romance Wore Rules Like Jewelry*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** The Georgian Neoclassical grammar arrives intact — the same column, proportion, and restraint — and the Regency re-instruments it by routing the inherited order through courtship, the domestic interior, and the social calendar, so that classical symmetry becomes the vehicle for governing longing rather than displaying civic virtue.

**Atmosfera e mood**

**Elegância de 1815 em musselina e salão** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Regência: vestidos de cintura império, cartas selladas e bailes onde cada dança era um contrato social.

**Paleta de cores** musselina branca, azul de salão, dourado de vela

**Melhores usos:** histórico, moda, editorial

**MidJourney:** `[tema], regency 1815 aesthetic, empire-line muslin sealed letters candlelit ballroom --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Regency portrait, an empire-line white muslin gown against drawing-room blue around 1815, sealed letters and candlelight where every dance is a social contract, Jane Austen era grace in soft painted glazes, 8k archival scan`

### **Silent Generation**

**№ 806 / 1001** — *Quiet Achievers*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Victorian and Edwardian genteel propriety culture arrives as the single parent, and Silent Generation re-instruments that inheritance by transposing inherited gentility from the drawing room onto the corporation and the suburban home, so an aristocratic quietness bred to separate refined classes from the uncivilised masses becomes, one turn later, an institutional discipline that proves belonging through the same refusal to be seen.

**Atmosfera e mood**

**Realizadores em silêncio** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Geração silenciosa: chapéu, pasta e pontualidade — a década de 1950 trabalhando muito e reclamando pouco.

**Paleta de cores** cinza de terno, sépia de escritório, marfim de camisa

**Melhores usos:** histórico, editorial, retratos

**MidJourney:** `[tema], silent generation aesthetic, hat briefcase punctuality 1950s office, quiet achievers --v 6`

**Prompt universal (Seedream):** `Shot on a Graflex Crown Graphic with Verichrome Pan film, a Silent Generation scene, a man in a gray suit and felt hat with a leather briefcase waiting punctually at a 1950s office elevator, sepia-toned diligence and pressed ivory shirt, achievement kept deliberately quiet, period press sharpness, 8k scan`

### **Simplicity**

**№ 808 / 1001** — *Power of Less*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → DENSITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** No style precedes Simplicity as its parent, because subtraction is the operation other aesthetics borrow rather than a blend inherited from any one of them, and removing the single act of reduction does not weaken the identity but erases it entirely. It generates descendants across minimalism, modernism, and mindful design while descending from none of them, so the whole grammar of the empty room and the single object branches outward and none can be traced upward into it.

**Atmosfera e mood**

**O poder do menos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Simplicidade: uma tigela, uma sombra, uma decisão — a imagem reduzida até só restar o necessário.

**Paleta de cores** branco quebrado, cerâmica crua, sombra única

**Melhores usos:** branding, produto, editorial

**MidJourney:** `[tema], simplicity aesthetic, one bowl one shadow one decision, the power of less --v 6`

**Prompt universal (Seedream):** `Shot on Leica M-A with 50mm lens, a study in simplicity, a single raw ceramic bowl on an off-white table casting one precise shadow, everything removed until only the necessary remains, quiet tonal restraint and perfect placement, the power of less made visible, 8k`

### **Sleek**

**№ 814 / 1001** — *Understated Cool*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Minimalism's subtractive grammar arrives as the single parent, and Sleek re-instruments that inheritance by continuing the same reduction one decisive step further — erasing not just ornament but the evidence of making itself — so an honest exposed material becomes, one turn later, a seamless surface that reads as though it was never assembled at all.

**Atmosfera e mood**

**Frieza discreta e polida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sleek: linhas contínuas, superfícies sem ruído e o brilho contido de quem não precisa se anunciar.

**Paleta de cores** grafite, prata acetinada, preto profundo

**Melhores usos:** produto, automotivo, branding

**MidJourney:** `[tema], sleek aesthetic, continuous lines noiseless surfaces contained shine, understated cool --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z7 II with 85mm lens, a sleek study, one continuous graphite curve of brushed metal catching a single satin highlight against deep black, surfaces engineered free of noise, the contained shine of something that never needs to announce itself, immaculate minimal cool, 8k`

### **Sprezzatura**

**№ 841 / 1001** — *Mastery Disguised as Effortless Perfection*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Classical dissimulatio artis's doctrine of concealed labor arrives as the single parent, and Sprezzatura re-instruments that inheritance by extending it from rhetoric into dress, gesture, and bearing, so hidden rhetorical art becomes, one turn later, a loosened tie that reads as mastery.

**Atmosfera e mood**

**A maestria disfarçada de descuido perfeito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sprezzatura: gravata levemente torta de propósito, relógio sobre o punho da camisa e a elegância italiana ensaiada para parecer acaso.

**Paleta de cores** azul de Napoli, camurça, branco amassado com intenção

**Melhores usos:** moda masculina, editorial, lifestyle

**MidJourney:** `[tema], sprezzatura aesthetic, deliberately imperfect tailoring at Pitti Uomo, mastery disguised as carelessness --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q3 with 28mm lens, a sprezzatura portrait outside Pitti Uomo, an unstructured Neapolitan jacket with the tie knotted just off-center and a watch worn over the shirt cuff, suede and rumpled white arranged to look accidental, mastery rehearsed into carelessness, effortless Florentine light, 8k`

### **Stealth**

**№ 845 / 1001** — *Presence engineered to go unnoticed*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Military camouflage's concealment grammar arrives as the single parent, and Stealth re-instruments that inheritance by turning tactic into conviction, so a battlefield hiding technique becomes, one turn later, a philosophy of engineered invisibility.

**Atmosfera e mood**

**Presença projetada para não ser notada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Stealth: preto fosco sobre preto, silhueta sem reflexo e o design que trabalha para desaparecer do radar — e do olhar.

**Paleta de cores** preto fosco, grafite sem brilho, sombra total

**Melhores usos:** produto, moda técnica, conceito

**MidJourney:** `[tema], stealth aesthetic, matte black on black no reflections, presence engineered to go unnoticed --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D850 with 58mm lens, a stealth study, a matte black technical silhouette against unlit black with every reflection engineered away, faceted graphite surfaces swallowing the single low light, presence designed to slide off the radar and the eye alike, near-invisible tonal control, 8k`

### **Stoic**

**№ 852 / 1001** — *Calm built to withstand any weather*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** No aesthetic precedes Stoic; the reductive method of keeping only the necessary is a practice rather than a style, and modern minimalism and contemplative restraint read as its later dialects, so the aesthetic generates descendants while descending from none of them, and no prior tradition can be traced upward into it.

**Atmosfera e mood**

**A calma construída para atravessar qualquer tempestade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Estoico: rosto imperturbável contra o vendaval, farol firme no mar revolto — a serenidade como decisão, não como ausência.

**Paleta de cores** cinza de tempestade, pedra de farol, azul escuro de mar

**Melhores usos:** retratos, editorial, conceito

**MidJourney:** `[tema], stoic aesthetic, unmoved face against the gale lighthouse in rough sea, calm as a decision --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex SL66 with 80mm lens, a stoic portrait on a storm coast, a weathered face holding perfect calm as spray bursts against the lighthouse behind, storm gray and dark sea blue framing unmoved eyes, serenity built as a decision rather than an absence, granite composure, 8k`

### **Suprematism**

**№ 870 / 1001** — *White on white, still a subject*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** The system reduces no further — Cubo-Futurism stands behind it but is not parenthood, since the break with the object is total and the grammar survives the removal of every proposed ancestor.

**Atmosfera e mood**

**A pureza geométrica revelando a abstração espiritual** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Suprematismo: o quadrado preto flutuando no branco infinito, retângulos em deriva diagonal — Malevich zerando a pintura para começar do espírito.

**Paleta de cores** preto absoluto, branco infinito, vermelho em deriva

**Melhores usos:** arte, design, conceito

**MidJourney:** `[tema], suprematism aesthetic, black square on infinite white drifting diagonal rectangles, Malevich spiritual zero --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a suprematist composition, a black square holding the void while red and black rectangles drift in diagonal formation across infinite white, Malevich resetting painting to zero so it could begin again from pure spirit, absolute geometric silence, 8k archival scan`

### **Tomboy**

**№ 902 / 1001** — *Comfort Cuts Across Gender Rules*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → EXPRESSION ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Androgyny supplies the single parent, and Tomboy re-instruments that inheritance by narrowing the refusal of gendered dress to one vector, reworked through Workwear and Americana.

**Atmosfera e mood**

**O conforto cortando através das regras de gênero** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tomboy: jeans surrado, camisa de flanela emprestada e o skate encostado na cerca — vestir-se para viver, não para performar.

**Paleta de cores** índigo gasto, xadrez de flanela, branco de camiseta

**Melhores usos:** moda, retratos, lifestyle

**MidJourney:** `[tema], tomboy aesthetic, worn jeans borrowed flannel skateboard on the fence, comfort across gender rules --v 6`

**Prompt universal (Seedream):** `Shot on Nikon FE with 35mm lens on Portra 400, a tomboy portrait, worn indigo jeans and an oversized borrowed flannel leaning on a fence beside a scuffed skateboard, plaid and t-shirt white in easy afternoon light, dressed for living rather than performing, relaxed confident warmth, 8k scan`

### **Ukiyo-e**

**№ 920 / 1001** — *Edo Life Floating Between Ink and Paper*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** The floating-world grammar survives the removal of any single precursor and generated descendants of its own — shin-hanga, Superflat, manga — rather than descending from one parent, the signature of a foundational node, not a reinterpretation.

**Atmosfera e mood**

**A vida de Edo flutuando entre tinta e papel** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ukiyo-e: a onda de Hokusai, as chuvas de Hiroshige e o teatro kabuki gravados em madeira — o mundo flutuante impresso para todos.

**Paleta de cores** azul de Prússia, sépia de papel, vermelho de selo

**Melhores usos:** arte, editorial, design

**MidJourney:** `[tema], ukiyo-e aesthetic, Hokusai wave Hiroshige rain kabuki woodblock, the floating world in print --v 6`

**Prompt universal (Seedream):** `High-resolution scan of an ukiyo-e woodblock print, travelers caught in slanting Hiroshige rain beneath a great Hokusai wave curling over Edo rooftops, Prussian blue and paper sepia stamped with one red seal, the floating world pressed from cherry wood for everyone, exquisite printed line, 8k`

### **Ultra-Modern**

**№ 922 / 1001** — *Innovation Balanced on a Clean Edge*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Nota genealógica original (EN):** International Style modernism, High-Tech architecture, and Brutalism converge here, each supplying a load-bearing feature nothing else replaces, fixing Ultra-Modern as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**A inovação equilibrada numa aresta limpa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ultramoderno: o cantilever impossível, vidro sem caixilho e a casa reduzida a três planos perfeitos sobre a paisagem.

**Paleta de cores** branco absoluto, vidro incolor, grafite de aço

**Melhores usos:** arquitetura, design, editorial

**MidJourney:** `[tema], ultra-modern aesthetic, impossible cantilever frameless glass three perfect planes, innovation on a clean edge --v 6`

**Prompt universal (Seedream):** `Shot on Sigma fp L with 45mm lens, an ultra-modern house at dusk, an impossible cantilever of absolute white floating over the hillside on frameless glass, three perfect planes and one steel edge against the darkening landscape, innovation balanced exactly on the clean line, pristine architectural minimalism, 8k`

### **Understimulation**

**№ 925 / 1001** — *Calm Designed Below the Noise Floor*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → DENSITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Nota genealógica original (EN):** Minimalism, wabi-sabi, and Scandinavian interior practice converge here, each supplying a load-bearing layer nothing else replaces, fixing Understimulation as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**A calma projetada abaixo do piso de ruído** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Subestimulação: a sala bege sem tela, uma xícara, uma janela — o ambiente desenhado para devolver a atenção ao dono.

**Paleta de cores** bege uniforme, cinza de manhã nublada, branco sem brilho

**Melhores usos:** interiores, conceito, editorial

**MidJourney:** `[tema], understimulation aesthetic, beige screenless room one cup one window, calm below the noise floor --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X100VI, an understimulation interior, a single beige armchair facing a bare window with one ceramic cup on the sill and nothing else demanding anything, matte white and overcast gray flattened into low contrast, a room engineered below the noise floor to hand attention back to its owner, serene empty calm, 8k`

### **Unisex**

**№ 928 / 1001** — *Clothing Without a Gender Gate*

**Nível:** 🟤 Terciária

**Eixo:** EDITING ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de corte e recusa.

**Nota genealógica original (EN):** Tailoring, dress reform, and minimalism converge here, each supplying a load-bearing layer nothing else replaces, fixing Unisex as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**A roupa sem portão de gênero** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Unissex: a alfaiataria fluida no mesmo cabide para todos, proporção neutra e o caimento decidido pelo corpo, não pelo rótulo.

**Paleta de cores** cru neutro, cinza de alfaiataria, preto universal

**Melhores usos:** moda, branding, editorial

**MidJourney:** `[tema], unisex aesthetic, fluid tailoring one rack for everyone, fit decided by the body not the label --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad X2D with 55mm lens, a unisex fashion study, two models of different builds wearing the same fluid ecru tailoring from one shared rack, neutral gray and universal black draped by body rather than label, clothing with the gender gate removed entirely, clean sculptural equality, 8k`

### **Vanilla**

**№ 938 / 1001** — *Restraint Without the Apology*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → NUANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** Vanilla reinterprets minimalism's cleared-surface grammar alone, warming its discipline into comfort without fusing in a second structural parent.

**Atmosfera e mood**

**A contenção sem pedido de desculpas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vanilla: creme sobre creme, a textura como único evento e a recusa serena de provar que é interessante — o básico defendido como escolha.

**Paleta de cores** creme de baunilha, branco quente, bege de linho

**Melhores usos:** interiores, branding, editorial

**MidJourney:** `[tema], vanilla aesthetic, cream on cream texture as the only event, restraint without apology --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX 50S II with 80mm lens, a vanilla still life, cream ceramics on warm white linen where texture is the only event scheduled, vanilla and soft beige layered tone on tone in diffused morning light, restraint stated flatly and without apology, luxurious quiet simplicity, 8k`

### **VSCO**

**№ 961 / 1001** — *Youth Culture Under the Same Preset*

**Nível:** 🟣 Secundária

**Eixo:** EDITING ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de subtração reconhecível é preservada e reinstrumentada em um novo uso.

**Nota genealógica original (EN):** VSCO takes the single inherited lesson of Instagram filter culture — that editing constructs photographic identity — and reinterprets it through one decisive move, the removal of public metrics, without fusing in a second lineage.

**Atmosfera e mood**

**A cultura jovem sob o mesmo preset** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

VSCO: scrunchies no pulso, garrafa adesivada e o pôr do sol na praia com o filtro C1 — 2019 inteiro editado na mesma temperatura.

**Paleta de cores** dourado de preset, rosa de scrunchie, turquesa de garrafa

**Melhores usos:** lifestyle, conteúdo, nostalgia

**MidJourney:** `[tema], vsco aesthetic, wrist scrunchies sticker-covered water bottle beach sunset C1 filter, 2019 at one temperature --v 6`

**Prompt universal (Seedream):** `iPhone photograph graded with a warm VSCO preset, a 2019 golden hour, friends with scrunchie-stacked wrists and a sticker-covered water bottle laughing on a beach blanket at sunset, preset gold and scrunchie pink over turquoise, an entire youth culture edited to the same gentle temperature, soft filtered glow, 8k`

### **Zen**

**№ 996 / 1001** — *Emptiness Holding the Whole Composition*

**Nível:** 🔴 Primária

**Eixo:** EDITING ↑ → DENSITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova regra de exclusão ao romper uma convenção anterior.

**Nota genealógica original (EN):** No earlier aesthetic can be named as its maker — the grammar crossed whole from Chan Buddhist practice into Japanese material culture with no intermediary style to reshape it, and each core principle bears load; losing any one collapses the whole rather than a branch, fixing it at the root rather than on it.

**Atmosfera e mood**

**O vazio sustentando a composição inteira** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Zen: o jardim de pedras rastelado ao amanhecer, o ensō pintado num gesto único e o espaço negativo fazendo todo o trabalho — ma, o intervalo que significa.

**Paleta de cores** areia rastelada, cinza de pedra, negro de tinta única

**Melhores usos:** interiores, espiritual, editorial

**MidJourney:** `[tema], zen aesthetic, raked rock garden at dawn single-gesture enso, negative space doing all the work --v 6`

**Prompt universal (Seedream):** `Shot on Linhof Master Technika with 150mm lens, a zen garden at first light, fifteen stones anchored in raked gravel rings while morning mist holds the far wall in suspension, sand white and stone gray composed around a vast deliberate emptiness, the interval itself carrying the meaning, absolute contemplative stillness, 8k`

## Leitura do padrão — o que as 45 estéticas confirmam

### Zero entradas suprimidas — o terceiro instrumento unidirecional

Das 45 entradas, todas são EDITING ↑. E o polo ↓ está longe de ser raro no corpus — é um dos slots secundários mais movimentados que existem: só a lista de EXPRESSION nas 9 Posições guarda treze casos de EXPRESSION ↑ → EDITING ↓ (Camp, Tacky, Sensational, Romanticism, Memphis, Tachisme, Periguete, Gaudy...). O excesso existe em abundância, mas sempre chega como negação do corte operada por outra posição, nunca como identidade própria do Obelos: quem acumula não está editando mal — está fazendo outra coisa. O obelos só cataloga quem cortou.

### Seis famílias recorrentes

**1. Subtração como fundação (→ DENSITY ↓):** Zen, Simplicity, Minimalism, Understimulation — o vazio como o próprio assunto, três Primárias em quatro entradas. **2. Esforço escondido (→ ESTHETICS ↑):** Sprezzatura, Sleek, Chic, Ukiyo-e — a lei do trabalho invisível: o que se corta é a evidência da mão. **3. O código enxuto (→ SEMIOTICS ↑):** French, DANDY, Mod, Unisex, Boudoir — o corte que vira código legível: reduzido ao mínimo, o que sobra significa mais. **4. Presença editada (→ EXPRESSION ↓):** Stealth, Silent Generation, Demure, Precisionism, Degrowth — o sinal reduzido até a invisibilidade engenheirada; Precisionism lixando a pincelada para fora da própria tela. **5. A vanguarda do corte (→ TECHNIQUE / THEME / EMANATIO / DOMAIN):** Avant-Garde, Abstract Art, Suprematism, Formalist, Fluxus, Erasercore, DADAISM — o corte aplicado à própria arte, camada por camada: o ornamento, o objeto, a figuração, por fim o autor. **6. Luxo por remoção (→ MATTER / ILLUMINATION):** Quiet Luxury, Post-Internet Minimalism, Primcore, Platinumcore, Ultra-Modern — o emblema removido e a parede nua declarada resposta estrutural, de Loos em diante. E uma rima interna que fecha a Station EN sobre si mesma: Vanilla carrega EDITING ↑ → NUANCE ↑ e Bossa Nova carrega NUANCE ↑ → EDITING ↑ — os dois ideogramas do Corte guardam um ao outro como secundários.

### A densidade de Primárias

Catorze 🔴 em 45 — Zen, Simplicity, Minimalism, Formalist, Suprematism, Chic, Ukiyo-e, DADAISM, Stoic, Precisionism, Primcore, French, Avant-Garde, Abstract Art — uma das maiores concentrações da página. Confirma o que Simplicity afirma na própria justificativa: a subtração é a operação que as outras estéticas pegam emprestada, não uma mistura herdada de alguma delas. Corte não desce de pai — corte funda.

### Polaridades

o padrão é bimodal e limpo. As revisões XX (VSCO, Boutique, Sprezzatura, Sleek, Quiet Luxury, Post-Internet Minimalism, Tomboy, Stealth, Silent Generation, Regency, Pixel...) herdam a redução inteira e a re-instrumentam — mudam o adversário, mantêm a tesoura. Já doze das catorze Primárias são XY-ruptura (as duas exceções, Minimalism por transmissão e French por revisão, herdam um corte já fundado): quando o corte é a lei de origem, não há gramática anterior a revisar — Loos não reformou o ornamento, cortou.

### O teste operacional

EDITING não é "minimalismo" como estilo — Minimalism é uma entrada entre 45. É qualquer estética cuja prova visual é a decisão de remoção legível: o vazio com autoria. O teste: aponte a marca do corte — o gancho vazio, o logo ausente, a etiqueta removida, o esforço escondido. Se o vazio não tiver assinatura, é só um cômodo desocupado; e se o cheio não tiver juízo, pertence a outra posição.

# NUANCE — a Gradação 濃淡

<aside>
<img src="https://app.notion.com濃" alt="https://app.notion.com濃" width="40px" />

**Essência.** NUANCE mede a atenção dedicada à gradação, à microdiferença e à distinção fina. Seu ideograma é 濃淡 — a escala do pintor de sumi-ê, com cinco diluições de um único preto: a maestria não reside na marca, mas no intervalo entre as marcas. No registro ↑, a diferença recompensa o olhar paciente; no registro ↓, ela é declarada em volume máximo e se torna legível à primeira vista.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para NUANCE, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem a escala material própria de cada estética, enquanto a arquitetura preserva a lógica de 濃淡. A palavra romanizada do glifo permanece fora do prompt; descrevem-se as diluições, os acabamentos e os meios-tons protegidos.

> **↑ NUANCE — universal prompt.** A measured row of near-identical elements separated only by the finest legible difference — [the aesthetic's own scale: nine garments in one deep tone differing by weave, warmth, and finish; the same object in graduated states; one tonal family laid side by side] — spaced evenly enough that each step registers, the whole image built around ranking what a hurried eye would call identical; a single figure in exact calibrated stillness placed as one more interval in the scale — [the aesthetic's own tenth step: a sleeve resting beside the row, a hand entering the family] — a quarter-turn measured in degrees, posture that changes meaning if moved a centimetre; the connoisseur's micro-gesture, two fingers separating two nearly identical surfaces or a sleeve laid deliberately beside a swatch, touch calibrated to compare and never to hold; a patient discriminating gaze narrowed a degree in assessment, the face of someone reading intervals invisible to a hurried viewer, nothing performed at the lens; grooming built from five dilutions of a single pigment — [the aesthetic's own pigment family] — lid, cheek, and lip differing in finish, matte against satin against sheer, rather than in colour, hair tone-on-tone with its own shadow; photographed on a 90mm at f/8 from a tripod with colour-managed exposure protecting every midtone, side light angled softly across the finishes so matte and satin separate and no step of the scale is crushed; neutral walls in a tone that joins the scale — [the aesthetic's own quiet ground] — nothing saturated anywhere on set; the viewer made to slow down, and rewarded for slowing.
> 

**Universal NUANCE ↓ negative line (always pair with the ↑ prompt):**

> No primary colours, no hard contrast, no bold graphic makeup, no pattern, no saturated prop, no wide-angle drama, no rushed gesture, no billboard stance, no poster-flat finish, no difference readable at thumbnail distance, no tonal crushing in the blacks or the whites, no midtone sacrificed anywhere.
> 

**Como usar para as 22 estéticas da lista.** Troque os colchetes pela família material da estética. Para **Old Money / High-Classcore / Sophisticated**, a escala é a do olho treinado — o grosgrain de Brummell ainda testando quem sabe ler, a herança usada sem logo, cada superfície escolhida duas vezes; para **Pastel / Delicate / Intimism**, a família tonal é a cor que sussurra — o quarto de Vuillard onde a mesa vira universo; para **Languid / Mellow / Loungecore / Kittencore / Loving**, o intervalo é de tônus: o roupão de seda, a hora tardia, a respiração sem pressa; para **Bossa Nova**, o volume do sussurro — ambição em voz baixa; para **Lo-fi**, o chiado da fita como a textura que só o ouvido paciente ranqueia; para **Mysterious / Softcore / Blurry**, mostrar menos do que o olho exige — Blurry inverte o segundo eixo (SEMIOTICS ↓): a borda dissolvida de propósito; para **Quantum**, o próprio ruído como material gerador.

## Fundamentos do elemento

### Identidade, intervalo e olhar desacelerado

**Identity.** Attention to gradation, micro-difference, and fine distinction. Its ideogram is 濃淡 — the gradation of ink concentration, the sumi-e painter's scale of five dilutions from one black: mastery measured not by the mark but by the interval between marks, meaning carried in the smallest legible difference. In an image this element is proven by a distinction only a patient eye can rank, or by differences declared at maximum volume. **Prompt guard:** the romanized word *notan* never enters a prompt — generators have learned it as hard light-dark contrast, which is this entry's ↓ pole; prompts describe five dilutions of one black.

**The interval, not the mark.** Mastery here is measured between marks — the millimetre of the dilution. A frame where the marks themselves compete for attention has already left the element: the subject of a NUANCE image is never the strongest step of the scale but the legibility of the distance between steps.

**The slowed viewer.** The perceived effect is sophistication: the viewer made to slow down, and rewarded for slowing. Both halves are binding — an image that yields everything at feed speed has chosen the other pole, and an image that yields nothing even to patience has only withheld. The reward must exist and must be findable.

**The guard against the loud reading.** This is the one entry whose failure mode is triggered by its own name: generators collapse the glyph's romanized word into hard light-dark blocking, which is precisely the ↓ pole. The discipline holds at the level of vocabulary — describe the scale of dilutions, the finishes, the protected midtones, and never name the glyph.

## Corpo — postura, gesto e olhar

**Model posture & structure.** Exact calibrated stillness — the body placed as one more interval in the scale; a quarter-turn measured in degrees; posture that changes meaning if moved a centimetre. Weight settled, breath low, nothing spent on performance, because the subject is the difference and not the figure.

**Gesture.** The connoisseur's micro-gesture — two fingers separating two nearly identical fabrics, a sleeve laid deliberately beside a swatch; touch calibrated to compare, not to hold. This is the refining verb's home register — the manuscript gives this action to Refinar as its dominant instrument: the tolerance judged in the millimetre of dilution. The shadow is taste performed as rank — the connoisseur's gesture aimed at excluding an audience rather than at reading an interval.

**The look — how the eyes behave.** The patient discriminating gaze — eyes narrowed a degree in assessment, blink rate low, the face of someone reading intervals invisible to a hurried viewer. Never the demonstrative squint: the assessment is real, not performed. One permitted exception per series — the gaze lifting to the lens for one frame between comparisons, unhurried, the look of someone who will return to the scale.

**Look & styling continuity.** Near-identical garments separated only by weave, warmth, and finish — one charcoal warmer, one woven, one milled — with the model's sleeve resting as the tenth step in the row. Nothing patterned, nothing saturated, nothing that can be told apart at a glance: the wardrobe is a scale and the wearer is its final interval.

**Camera.** 85–100mm at f/5.6–f/8, tripod, colour-managed exposure protecting the midtones; focus and framing precise enough that gradation itself is the subject. The grade must hold nine steps without crushing any — a lost midtone here is a lost sentence.

**Composition.** Serial arrangement — a row, a scale, an interval structure; comparison as the composition itself; generous even spacing that lets each step register. The frame is read the way a scale is read, in order, and the one figure is placed where the eye finishes ranking.

**Lighting.** Side light angled so gradation becomes legible — raking softly across finishes so matte and satin separate; no contrast spikes; a tonal range wide enough to hold every step. The light's job is to make difference readable, never to create it: a shadow that manufactures drama has changed elements.

**Beauty detail.** Tonal beauty within one family — makeup built from five dilutions of a single pigment, lid to cheek to lip differing in finish rather than colour; hair tone-on-tone with its own shadow; distinctions of texture, never of hue. The face rewards the same slow reading the wardrobe does: at feed speed it reads as bare, at attention it reads as built.

**Cenography.** The appraiser's room — a rail of nine charcoal garments, a table of swatches, neutral walls in a grey that joins the scale; nothing saturated anywhere on set. Every object is admissible only if it can take a place in the scale; a prop that refuses to be ranked is a foreign body.

**Colour.** One family, held; difference carried by warmth, weight, and finish rather than by hue; the ground itself a member of the scale. The diagnostic failure is a single saturated element — one primary anywhere collapses the entire reading into the stadium register, this entry's own ↓ pole.

**Interval proof.** Wherever the composition allows it, plant one device proving the gradation is real and rankable: the row of nine with the tenth entering; a swatch fanned against its own garment; two cuffs of the same tone crossing so the warmer reads against the cooler; one pigment at three finishes on one face. This is the ink scale made photographic — the closest a still image comes to proving that the differences exist outside the caption. A frame whose steps cannot be ranked by a patient eye has only asserted subtlety, which is the single most legible failure this element can produce.

**Practitioner lines (from the codices).** Lillian Bassman — the frame bleached toward white, detail held only in a narrow band of near-black, the image stripped to the one line it cannot afford to lose and that line defended against every impulse toward completeness. Paolo Roversi — the dilution zone itself: 8x10 Polaroid, long exposures painted with a Maglite, a narrow tonal band of diluted colour, immense stillness so that only what is essential survives the duration. Dominique Issermann — black-and-white living in the grey dilutions, fine grain in close tonal values, wind-touched fabric, the gaze at something the frame withholds. Jack Davison — the deciphering register: shadow, reflection, and obscuration demanding that the viewer actively read the image. Gui Paganini — muted desaturated palettes, hazy interior light, the story held in its quiet middle rather than its climax. Bibi Borthwick — analogue film, soft nuanced natural light, unforced intimacy read slowly. Casper Sejersen — the forensic dilution: clinical precision, cold restrained palette, every frame premeditated like evidence the viewer must decode. And at the register's afterimage edge: Sarah Moon — soft focus and Polaroid degradation, the image as a fading memory that resists full resolution.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** The millimetre of difference as subject: near-identical tones separated by weave, warmth, and finish; side light angled so gradation becomes legible; the viewer made to slow down.

> **↑ Prompt.** Nine garments in the same charcoal grey hung in a row, the photograph built around the millimetre of difference between them, one warmer, one woven, one milled, the model's sleeve resting beside them as the tenth grey, side light angled so only a patient eye can rank them, the entire image an exercise in the smallest legible distinction.
> 

> **↑ Negative line.** No primary colours, no hard contrast, no bold graphic makeup, no pattern, no saturated props, no wide-angle drama, no rushed gesture, no tonal crushing in blacks or whites, no billboard stance, no semaphore gesture, no poster-flat complexion, no difference declared at full volume.
> 

**↓ Suppressed — repertory.** Broad immediate contrast: primary against primary, no midtones, no textures requiring inspection, differences readable across a stadium.

> **↓ Prompt.** Primary red against primary blue on a white ground, a colour-blocked ensemble readable across a stadium, no midtones anywhere, no texture requiring inspection, every difference in the frame declared at maximum volume.
> 

> **↓ Negative line.** No tonal gradation, no texture requiring inspection, no side light, no grey scale, no subtle finishes, no patient framing, no midtones, no near-identical elements, no connoisseur micro-gesture, no viewer asked to slow down.
> 

## Estéticas relacionadas a NUANCE (A–Z)

As 22 estéticas classificadas sob NUANCE, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Artsy**

**№ 065 / 1001** — *Credential that leaves no receipt*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Nota genealógica original (EN):** Gallery-going taste, bohemian dress codes, and consumer signaling converge into a legible social marker; none of the three alone yields it, so the classification rests on recombination rather than on reinterpreting a single ancestor.

**Atmosfera e mood**

**Credencial que não deixa recibo** — (1001 Aesthetics, interpretação)

Vida artsy: galerias, café, caderno de esboços, cultura vestida com naturalidade.

**Paleta de cores** neutros com um acento de cor de tinta

**Melhores usos:** lifestyle, branding, editorial

**MidJourney:** `[tema], artsy gallery lifestyle editorial --v 6`

**Prompt universal (Seedream):** `Candid editorial photograph shot on 35mm f/1.8 lens, a gallery visitor with sketchbook and canvas tote, paint-splattered casual tailoring, espresso and exhibition catalogs on a marble café table, soft museum daylight, effortless creative credibility, neutral palette with one paint-bright accent, 8k`

### **Blurry**

**№ 103 / 1001** — *Edge dissolved on purpose*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → SEMIOTICS ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Nota genealógica original (EN):** Photographic accident, atmospheric painting, and digital post-processing converge; strip the camera lineage and the softness loses its alibi, strip the digital tooling and it cannot be applied deliberately — fusion of separate lines rather than the revision of one.

**Atmosfera e mood**

**Borda dissolvida de propósito** — (1001 Aesthetics, interpretação)

Desfoque intencional: movimento, sonho, figura lembrada pela metade.

**Paleta de cores** qualquer uma, suavizada pelo desfoque

**Melhores usos:** fine art, capas, editorial

**MidJourney:** `[tema], intentional motion blur, dreamlike soft focus --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with deliberate slow shutter, an intentionally blurred figure dissolving into motion down a rain-lit street, edges melting into bokeh smears of amber and teal, half-remembered dream presence in the manner of Saul Leiter and Bill Henson, poetic out-of-focus atmosphere, painterly grain, cinematic melancholy`

### **Bossa Nova**

**№ 109 / 1001** — *Ambition at the volume of a whisper*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Nota genealógica original (EN):** Samba rhythm, cool-jazz harmony, and modernist restraint are welded into one voice; remove the samba and the syncopation dies, remove the jazz harmony and the chords flatten, remove the modernist edit and the whisper turns into a song — recombination.

**Atmosfera e mood**

**Ambição no volume de um sussurro** — (1001 Aesthetics, interpretação)

Bossa nova: Rio anos 60, violão na varanda, luz de Ipanema, elegância de capa de vinil.

**Paleta de cores** areia, azul-mar, verde, tons de capa de vinil

**Melhores usos:** música, lifestyle, editorial

**MidJourney:** `[tema], bossa nova 1960s Rio aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 35mm with 50mm lens, a 1960s Rio apartment balcony above Ipanema, acoustic guitar resting against a modernist chair, gauzy curtains breathing in ocean light, whiskey glass and vinyl sleeves in soft focus, jazz album cover elegance, whispered João Gilberto sophistication, warm nostalgic grading, 8k`

### **Daintycore**

**№ 192 / 1001** — *Discipline of the small*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**A disciplina do pequeno** — (1001 Aesthetics, interpretação)

Delicadeza miniatural: xícaras de porcelana minúsculas, laços finos, detalhes que pedem lupa e cuidado.

**Paleta de cores** pastel pálido, branco-porcelana, rosa

**Melhores usos:** ilustração, produtos, social

**MidJourney:** `[tema], daintycore, tiny delicate porcelain details --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a daintycore still life, tiny porcelain teacups and fine ribbon bows arranged on lace, miniature details in pale pastels under soft window light, gilded rims and sugar-pearl textures in macro clarity, precious smallness handled with care, creamy delicate grading, 8k`

### **Delicate**

**№ 217 / 1001** — *Covenant of Gossamer, Eggshell, and Pastel Powder*

**Nível:** 🔴 Primária

**Eixo:** NUANCE ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**Gaze, casca de ovo e pó pastel** — (1001 Aesthetics, interpretação)

Delicadeza: tecidos translúcidos, pétalas e porcelana fina, tudo que pede toque leve.

**Paleta de cores** rosa-pó, casca de ovo, lavanda pálida

**Melhores usos:** beleza, produtos, editorial

**MidJourney:** `[tema], delicate aesthetic, gossamer fabrics and pale petals --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a delicate composition, translucent gossamer fabric and fine porcelain beside soft petals, eggshell and powder pastels in diffuse north light, fragile surfaces asking for the lightest touch, whisper-fine texture detail, 8k`

### **High-Classcore**

**№ 433 / 1001** — *Brummell's Grosgrain Hatband Still Tests the Trained Eye*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de microdiferenças é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**A fita de gorgurão de Brummell ainda testa o olho treinado** — (1001 Aesthetics, interpretação)

Alta classe: luxo que só iniciados percebem, detalhe discreto sobre discrição, riqueza que sussurra.

**Paleta de cores** azul-marinho, camurça, creme, dourado discreto

**Melhores usos:** branding de luxo, moda, editorial

**MidJourney:** `[tema], quiet luxury high-class aesthetic, subtle grosgrain hatband detail, understated old money elegance --v 6`

**Prompt universal (Seedream):** `Shot on Leica M6 with 50mm lens, a high-classcore image, a grosgrain hatband detail that still tests the trained eye, quiet navy and suede luxury in soft club light, wealth that whispers instead of showing, 8k`

### **Intimism**

**№ 476 / 1001** — *Vuillard's Quiet Room Makes the Table a Universe*

**Nível:** 🟣 Secundária

**Eixo:** NUANCE ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de microdiferenças é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**O quarto silencioso de Vuillard faz da mesa um universo** — (1001 Aesthetics, interpretação)

Intimismo: interior doméstico pintado com padrões densos, luz de abajur sobre cena mínima, o pequeno mundo como assunto.

**Paleta de cores** padrões de papel de parede, marrons quentes, dourado de interior

**Melhores usos:** arte, editorial doméstico, narrativa

**MidJourney:** `[tema], intimism painting, Vuillard quiet domestic interior, dense wallpaper patterns and lamp light --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an intimist painting, a quiet room making the table a universe, dense wallpaper patterns in warm browns like Vuillard and Bonnard, lamp light over a minimal domestic scene, 8k`

### **Kittencore**

**№ 505 / 1001** — *Soft paws, milk ceramics, sunlit nap*

**Nível:** ⚫ Quaternária

**Eixo:** NUANCE ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Atmosfera e mood**

**Patas macias, cerâmica de leite, soneca ao sol** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Kittencore: ternura felina como composição inteira, creme, blush e luz de janela.

**Paleta de cores** creme, blush, branco de leite

**Melhores usos:** conteúdo afetivo, ilustração, fotografia doméstica

**MidJourney:** `[tema], kittencore aesthetic, soft paws, milk ceramics, sunlit nap, tender warmth --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R8 with 85mm lens, a kittencore image, soft paws beside milk-white ceramics in a sunlit nap, cream and blush tones under warm window light, tenderness as the whole composition, 8k`

### **Languid**

**№ 516 / 1001** — *Silk robe, late hour, unhurried breath*

**Nível:** 🟣 Secundária

**Eixo:** NUANCE ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**Robe de seda, hora tardia, respiração sem pressa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lânguido: o tempo com permissão para desacelerar, champanhe e rosa sombreado à luz de abajur.

**Paleta de cores** champanhe, rosa sombreado, luz de abajur

**Melhores usos:** retrato, moda íntima, editorial

**MidJourney:** `[tema], languid aesthetic, silk robe at a late hour, unhurried breath, dim lamplight --v 6`

**Prompt universal (Seedream):** `Shot on Contax 645 with 80mm lens, a languid image, a silk robe pooling off one shoulder at a late shapeless hour, unhurried breath in dim tungsten lamplight, champagne and shadowed rose tones melting into unmade linen, Paolo Roversi breathing softness at the edge of focus, time given full permission to slow down, 8k`

### **Lingercore**

**№ 527 / 1001** — *Lace camisoles and skin-close cotton*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → DOMAIN ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Atmosfera e mood**

**Camisolas de renda e algodão rente à pele** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lingercore: intimidade mantida fora de alcance, marfim e blush desbotado sob luz de gaze.

**Paleta de cores** marfim, blush desbotado, lençol matinal

**Melhores usos:** moda íntima, editorial, retrato

**MidJourney:** `[tema], lingercore aesthetic, lace camisoles and skin-close cotton in morning sheets, gauze light --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 645N with 75mm lens, a lingercore image, lace camisoles and skin-close cotton tangled in morning sheets, ivory and faded blush under gauze-filtered window light, Deborah Turbeville grain-soft distance, a warm indentation where someone just was, intimacy photographed at the exact point where it stays out of reach, 8k`

### **Lo-fi**

**№ 528 / 1001** — *Cassette hiss under desk lamp*

**Nível:** 🟣 Secundária

**Eixo:** NUANCE ↑ → COHERENCE ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**Chiado de fita sob a luz do abajur** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lo-fi: conforto levemente fora de foco, grão quente sobre fones e setlists à mão.

**Paleta de cores** âmbar de abajur, grão quente, noite de quarto

**Melhores usos:** capa musical, conteúdo study-with-me, editorial

**MidJourney:** `[tema], lo-fi aesthetic, cassette hiss under desk lamp, warm grain, handwritten track lists --v 6`

**Prompt universal (Seedream):** `Shot on Yashica Electro 35 with 45mm lens on expired film, a lo-fi image, cassette hiss made visible under a bent desk lamp at one in the morning, warm grain settling over headphones and handwritten track lists, amber lamplight against bedroom-blue night, chillhop album-cover intimacy, comfort tuned deliberately slightly out of focus, 8k`

### **Loungecore**

**№ 531 / 1001** — *Low light, velvet banquette, martini glass*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Atmosfera e mood**

**Luz baixa, banqueta de veludo, taça de martini** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Loungecore: a noite encenada como atmosfera, brilho teal e âmbar de coquetel, exotica no toca-discos.

**Paleta de cores** teal, âmbar, veludo escuro

**Melhores usos:** bar e hospitalidade, capa musical, editorial

**MidJourney:** `[tema], loungecore aesthetic, velvet banquette and martini glass, low tungsten light, hi-fi exotica --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7C II with 40mm lens, a loungecore image, a velvet banquette and a sweating martini glass in low tungsten glow, teal and amber cocktail light pooling on walnut paneling, hi-fi exotica spinning on the turntable, Saul Bass-era bachelor-pad cool, the whole evening art-directed as atmosphere, 8k`

### **Loving**

**№ 532 / 1001** — *Handwritten note left on pillow*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de microdiferenças é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**Bilhete à mão deixado no travesseiro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Loving: o afeto registrado em gestos comuns, algodão branco e pêssego suave na primeira luz.

**Paleta de cores** branco de algodão, pêssego, luz matinal

**Melhores usos:** lifestyle, campanha afetiva, retrato

**MidJourney:** `[tema], loving aesthetic, handwritten note left on the pillow, first morning light --v 6`

**Prompt universal (Seedream):** `Shot on Minolta X-700 with 50mm lens, a loving image, a handwritten note left on the pillow in first morning light, cotton white and soft peach tones over rumpled bedding, steam rising from two mugs set close together, Nan Goldin tenderness without the ache, affection recorded in small ordinary gestures, 8k`

### **Magical Realism**

**№ 544 / 1001** — *García Márquez's rain of yellow flowers*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Atmosfera e mood**

**A chuva de flores amarelas de García Márquez** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Realismo mágico: o impossível relatado com calma, pétalas douradas sobre a rotina de Macondo.

**Paleta de cores** amarelo de flor, dourado, cotidiano latino-americano

**Melhores usos:** editorial literário, arte, campanha

**MidJourney:** `[tema], magical realism aesthetic, rain of yellow flowers on an ordinary street, the impossible reported calmly --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 800 with 35mm lens, a magical realism image, a rain of yellow flowers falling on an ordinary street in Garcia Marquez's Macondo, golden petals over everyday routine, Alex Webb layered color, the impossible reported calmly, 8k`

### **Meditative**

**№ 557 / 1001** — *Stillness Engineered Through Repetition*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**Quietude projetada pela repetição** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Meditativo: a mente desacelerada por ritmo visual, mar e horizonte reduzidos a tom sobre tom.

**Paleta de cores** cinza de névoa, prata de mar, horizonte

**Melhores usos:** bem-estar, arte contemplativa, editorial

**MidJourney:** `[tema], meditative aesthetic, sea and horizon reduced to tone on tone, stillness through repetition --v 6`

**Prompt universal (Seedream):** `Shot on Plaubel Makina 67 with 80mm lens, a meditative image, sea and horizon reduced to breathing bands of tone on tone, a long silver exposure erasing every wave into stillness, Hiroshi Sugimoto seascape discipline, mist grey graduating into pewter light, the mind slowed to the exact speed of the picture, 8k`

### **Mellow**

**№ 559 / 1001** — *Room That Asks Nothing*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**O quarto que não pede nada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mellow: o conforto sem argumento, sofá afundado e chá morno em tarde cor de mel.

**Paleta de cores** mel, bege quente, luz de fim de tarde

**Melhores usos:** lifestyle, interiores, capa musical

**MidJourney:** `[tema], mellow aesthetic, sunken couch and warm tea in honey afternoon light, a room that asks nothing --v 6`

**Prompt universal (Seedream):** `Shot on Konica Hexar AF with 35mm lens, a mellow image, a sunken corduroy couch and warm tea in honey-colored late afternoon light, dust motes drifting through amber like slow applause, a record turning quietly at the edge of hearing, William Eggleston ease without tension, a room that asks nothing of anyone, 8k`

### **Mysterious**

**№ 584 / 1001** — *Show Less Than the Eye Demands*

**Nível:** 🔴 Primária

**Eixo:** NUANCE ↑ → EDITING ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gradação é transmitida como continuidade reconhecível, preservando sua escala de diferenças.

**Atmosfera e mood**

**Mostrar menos do que o olho exige** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Misterioso: a informação retida como tensão, silhueta meio revelada atrás de vidro embactado.

**Paleta de cores** preto profundo, névoa, um recorte de luz

**Melhores usos:** retrato, cinema still, editorial

**MidJourney:** `[tema], mysterious aesthetic, half-revealed silhouette behind fogged glass, one slice of light --v 6`

**Prompt universal (Seedream):** `Shot on Leica M7 with 50mm lens on Ilford Delta 3200, a mysterious image, a half-revealed silhouette behind fogged glass with one slice of light, deep black and drifting mist, Saul Leiter obstruction, showing less than the eye demands, 8k`

### **Old Money**

**№ 643 / 1001** — *Inheritance Worn Without a Logo*

**Nível:** 🟣 Secundária

**Eixo:** NUANCE ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de microdiferenças é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**Riqueza que nunca precisa se apresentar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Old money: tweed herdado, prata de família sem polir demais e nenhum logo à vista.

**Paleta de cores** verde-caça, camel, creme antigo

**Melhores usos:** moda, lifestyle, branding

**MidJourney:** `[tema], old money aesthetic, inherited tweed no logos, wealth that never introduces itself --v 6`

**Prompt universal (Seedream):** `Shot on Leica MP with 50mm Summilux lens, an old money scene, inherited tweed and unpolished family silver on an estate lawn at golden hour, hunter green and camel with not one visible logo, wealth so old it never introduces itself, quiet grain and warmth, 8k`

### **Pastel**

**№ 670 / 1001** — *Color Learns to Whisper*

**Nível:** 🟣 Secundária

**Eixo:** NUANCE ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de microdiferenças é preservada e reinstrumentada em um novo contexto.

**Atmosfera e mood**

**Cor aprendendo a sussurrar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pastel: rosa-pó, menta e lavanda em doses homeopáticas — a paleta inteira falando baixo.

**Paleta de cores** rosa-pó, menta, lavanda, manteiga

**Melhores usos:** branding, lifestyle, produto

**MidJourney:** `[tema], pastel aesthetic, powder pink mint lavender, color learning to whisper --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GA645 with 60mm lens, a pastel composition, powder pink mint and lavender surfaces in homeopathic doses under diffused morning light, butter-soft shadows and zero saturation shouting, the entire palette speaking in a whisper, creamy medium-format tonality, 8k`

### **Quantum**

**№ 736 / 1001** — *Reality Refuses a Single Answer*

**Nível:** 🟤 Terciária

**Eixo:** NUANCE ↑ → THEME ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens distintas são recombinadas numa nova gramática de gradação.

**Nota genealógica original (EN):** Science Art's method of data-as-image, Futurism's faith in the machine, and Space Age's vacuum-dark palette were each complete systems; recombined here they produce the only aesthetic for which quantum noise itself serves as raw generative material — a synthesis none of the three parents could achieve alone.

**Atmosfera e mood**

**A recusa de uma resposta única** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Quântico: nuvens de probabilidade, partículas em superposição e a realidade decidindo só quando observada.

**Paleta de cores** azul de probabilidade, violeta, brilho de partícula

**Melhores usos:** ciência, conceito, arte digital

**MidJourney:** `[tema], quantum aesthetic, probability clouds superposition, reality deciding only when observed --v 6`

**Prompt universal (Seedream):** `Ultra-detailed scientific visualization, a quantum scene of probability clouds holding every outcome in superposition, particle glints threading violet and deep probability blue, reality politely refusing a single answer until observed, luminous precision rendering, 8k`

### **Softcore**

**№ 826 / 1001** — *Allure that stops at the hint*

**Nível:** 🟣 Secundária

**Eixo:** NUANCE ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem de microdiferenças é preservada e reinstrumentada em um novo contexto.

**Nota genealógica original (EN):** Romanticism's single transformative wager that suggestion carries more weight than statement arrives as the sole parent, and Softcore re-instruments that inheritance by pushing atmosphere all the way to its edge, so a Romantic hint becomes, one turn later, a room where the haze itself is the only thing on display.

**Atmosfera e mood**

**O fascínio que para na sugestão** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Softcore estético: foco difuso, ombro à contraluz e a imagem que insinua e se retira — tudo dito pela luz, nada mostrado.

**Paleta de cores** pêssego difuso, branco de cortina, dourado de fim de tarde

**Melhores usos:** beleza, editorial, moda

**MidJourney:** `[tema], soft-focus romantic aesthetic, backlit shoulder sheer curtain, allure that stops at the hint --v 6`

**Prompt universal (Seedream):** `Shot on Minolta with 85mm Varisoft lens, a soft-focus romantic portrait, a bare shoulder turned into late golden light behind a sheer curtain, peach diffusion blooming across the frame, allure that suggests and withdraws in the same breath, everything said by light and nothing shown, tasteful, 8k`

### **Sophisticated**

**№ 831 / 1001** — *Precision Without Visible Effort*

**Nível:** 🔴 Primária

**Eixo:** NUANCE ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova escala de distinções ao romper a leitura anterior.

**Nota genealógica original (EN):** No single movement precedes Sophisticated; refinement-as-distinction recurs across classical antiquity, the French court, and the Enlightenment without descending from any one of them, generating descendants that quote its vocabulary of restraint and gradation while it descends from none of them, so no parent can be traced upward into the room where every surface has been chosen twice.

**Atmosfera e mood**

**Precisão sem esforço visível** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sofisticado: cada escolha calibrada e nenhuma exibida — o refinamento que se percebe apenas pela ausência de erro.

**Paleta de cores** carvão, camel, pérola

**Melhores usos:** moda, branding, editorial

**MidJourney:** `[tema], sophisticated aesthetic, every choice calibrated none displayed, precision without visible effort --v 6`

**Prompt universal (Seedream):** `Shot on Leica M11 with 50mm APO lens, a sophisticated portrait, a camel coat over charcoal knit beside a single pearl detail in soft directional light, every choice calibrated and none of them displayed, refinement legible only through the total absence of error, understated flawless rendering, 8k`

## Leitura do padrão — o que as 22 estéticas confirmam

### Zero entradas suprimidas — o quarto instrumento unidirecional

Das 22, todas são NUANCE ↑ — e somadas às 45 de EDITING, a estação do Corte não tem um único caso ↓ catalogado nas 1001. O polo do estádio existe no corpus, mas só como slot secundário: nas 9 Posições, Hot carrega EXPRESSION ↑ → NUANCE ↓ — o rosa que toma o quarto antes de a porta fechar é um sinal de EXPRESSION, não uma identidade de gradação. Declarar diferenças a volume máximo é sempre trabalho de outra posição; o 濃淡 só cataloga quem faz o espectador desacelerar.

### Cinco famílias recorrentes

**1. A dose da decisão (→ INTENTIONALITY ↓) — o maior bloco.** Loving, Languid, Mellow, Kittencore, Loungecore — cinco entradas onde o segundo eixo é a decisão relaxada: o bilhete no travesseiro, o quarto que não pede nada. NUANCE ↑ com INTENTIONALITY ↓ é a fórmula fotográfica do conforto: diferença fina sem veredito. **2. O olho treinado como porteiro (→ SEMIOTICS / EDITING).** Old Money, High-Classcore, Artsy, Sophisticated, Mysterious, Bossa Nova — a distinção como teste de admissão: quem não lê o intervalo nem sabe que havia um código. **3. Cor que sussurra (→ ESTHETICS / RESONANCE).** Delicate, Pastel, Intimism, Softcore — a família tonal como mundo inteiro. **4. O intervalo como disciplina (→ TECHNIQUE / DENSITY ↓).** Daintycore, Meditative, Lo-fi — repetição, escala pequena, o ruído por baixo da lâmpada de mesa. **5. A borda dissolvida (→ SEMIOTICS ↓ / COHERENCE ↓ / DOMAIN ↓).** Blurry, Magical Realism, Quantum, Lingercore — o registro-limite: a nitidez negada de propósito, a realidade que recusa uma resposta única, o território dissolvido até a distância pele-tecido.

### Polaridades

treze XX contra nove XY, e uma única ruptura em 22 — Sophisticated, cuja ruptura é justamente não ter pai nomeável: o refinamento como raiz que os outros citam. O contraste com o vizinho de estação é cirúrgico: em EDITING as rupturas fundadoras são doze — o corte funda; a diluição herda. Gradação é herança por natureza, porque o intervalo se aprende de uma linhagem só, e ninguém funda um sistema sussurrando.

### O teste operacional

NUANCE não é "sutileza" como adjetivo — é qualquer estética cuja prova visual exige que o espectador desacelere e seja recompensado por desacelerar. O teste: se a distinção sobrevive a um thumbnail, é o polo ↓ de outra posição; se ela custa três segundos de atenção e paga esse custo, é 濃淡.

# SYNTHESIS — a Vesica Piscis

<aside>
◉

**Essência.** SYNTHESIS mede a fusão de referências heterogêneas numa nova forma. Seu ideograma é a Vesica Piscis — a amêndoa que nasce quando dois círculos atravessam o centro um do outro: uma terceira forma que não pertence a nenhum dos pais e só existe enquanto ambos permanecem comprometidos. No registro ↑, as ancestralidades se fundem além da separação; no registro ↓, permanecem apartadas, com suas junções expostas.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para SYNTHESIS, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem as ancestralidades reais de cada estética, enquanto a arquitetura preserva a lógica da Vesica Piscis — compromisso pelo centro, nunca tangência pelas bordas.

> **↑ SYNTHESIS — universal prompt.** Two [source ancestries] fused past the point of separation into a single form that belongs to neither parent, one continuous construction logic with no visible join anywhere, worn by a figure whose bearing is fluent in both traditions and quotes neither, one hand closing the garment in a movement that reads as [first ancestry's ceremony] and [second ancestry's function] at once, hair and skin finish carrying two lineages without a seam, photographed on a neutral 60mm at f/5.6 in a space whose architecture also refuses to take sides, the light blending two source temperatures into one unnameable warmth with no colour border in the frame, the settled unexplaining gaze of someone born inside the fusion rather than dressed in it, a third form with properties neither origin had alone, a form that would vanish if either parent withdrew.
> 

**Universal SYNTHESIS ↓ negative line (always pair with the ↑ prompt):**

> No split compositions, no exposed joins or centre seams, no costume quoting of either source, no colour border between light temperatures, no collage devices, no half-and-half styling, no irony toward either ancestry.
> 

**Como usar para as 41 estéticas da lista.** Substitua os slots pelas duas ancestralidades reais da estética e mantenha o resto intacto. Para Solarpunk: *the electronic spine of a wired city and the growth logic of a living vine fused past the point of separation…* — três futuros soldados numa cidade solar que nenhuma linhagem produziria sozinha. Para Biomechanical: *the anatomy of a living body and the specification of a machine fused…* — o corpo continua sendo o sujeito organizador enquanto suas partes são reespecificadas em metal. Para Tropicália, a antropofagia é o motor: as ancestralidades devoradas devem reaparecer irreconhecíveis, nunca citadas. Atenção às fusões XX de pai único (Synthetic Nature, Techno-Organic, Suzhou, Vienna Secession): o slot duplo vira herança + reinstrumentação — a linhagem mantida inteira e relida em outro material. A única entrada suprimida, Fragmented, inverte para o registro ↓: use o prompt do repertório de colagem exposta, o corte fora de registro fotografado como o próprio assunto.

## Fundamentos do elemento

### Identidade, compromisso e terceira forma

**Identity.** Fusion of heterogeneous references into new form. Its ideogram is the almond born where two circles overlap through each other's centres: a third shape that belongs to neither parent and exists only while both commit. In an image this element is proven by ancestries fused past the point of separation, or by sources kept visibly apart.

**Commitment through the centre.** Two circles that merely touch produce no almond; each must pass through the other's centre. In production terms: each ancestry must surrender its core construction logic to the shared form, not lend an accessory. A borrowed collar on an unchanged coat is tangency; one seam logic carrying both duties is the almond.

**The third form, not the average.** An average has fewer properties than either parent; a synthesis has properties neither parent had. Before the shutter, name the one property in frame that neither origin could produce alone — if it cannot be named, the fusion has not happened yet.

**The vanishing test.** Withdraw either parent mentally and the form must die. If the image survives the subtraction, the second ancestry was decoration — cut it or commit it.

## Corpo — postura, gesto e olhar

**Model posture & structure.** A bearing fluent in both traditions and quoting neither — the flat frontal calm of one lineage carried with the striding readiness of the other, resolved into one new stance; nothing in the body reads as citation. The spine holds the fusion the way the seam does: continuously.

**Gesture.** Continuous hybrid gestures — a hand closing a collar in one movement that is ceremony and utility at once; no gesture assignable to only one parent; nothing demonstrative, nothing explanatory.

**The look — how the eyes behave.** The settled gaze of a native, not a wearer: someone born inside the third culture, assured and unexplaining; eyes that have never needed to choose between the two grammars because they arrived after the choice.

## Regras de imagem — da fusão à prova de inseparabilidade

**Look & styling continuity.** One garment in which two constructions have fused into a shape that is neither — flat geometry and storm architecture sharing one continuous seam logic, one fabric carrying both duties; no visible join, no lining flashed as a wink.

**Camera.** 60mm at f/5.6 — the neutral focal length that quotes neither portrait nor reportage; framing calm and unrhetorical, letting the fusion carry the image; no angle that takes a side.

**Composition.** Unified single-read composition — no split, no diptych, no before-and-after; the figure whole in a space that also refuses to take sides; the meeting of the two grammars distributed through the whole frame, never localized into a seam.

**Lighting.** Two source temperatures blended past separation — daylight and tungsten mixed into one warmth that cannot be named, no colour border anywhere; the light itself synthesized before the subject enters it.

**Beauty detail.** A fused grammar with no seam: groomed austerity carrying one gesture of ornament absorbed into it; skin finish halfway between polish and rawness and reading as neither; hair in a shape with two ancestries and no parting line between them.

**Cenography.** Architecture that likewise fuses — traditional material in modern section, modern material in traditional proportion; a corridor where no element can be attributed to one origin alone; the set as the third culture's native ground.

**Colour.** One unnameable palette born between the parents' palettes — never one source's colour blocked against the other's; if a hue can be returned to its origin on sight, it has not yet been fused.

**Fusion proof.** Plant one verifiable evidence that the fusion is structural, not styled: a single continuous seam performing both ancestral functions, photographed sharp enough to be read — the join that does not exist as the image's quiet centre.

**Practitioner lines (from the codices).** Erwin Blumenfeld — the fusion occurring in the material itself: solarized negatives, sandwiched double exposures, distortion written in the light before the film. Man Ray — one impossible element per frame, the chemistry arguing for it; two compete and cancel. Yva (Else Ernestine Neuländer-Simon) — up to seven exposures on a single plate, product, hand, and light trace fused into an image none of the exposures contained. Nick Knight — skin texture and CGI surface interpenetrating until the seam disappears; if the manipulation reads as a layer, the synthesis failed. Cho Gi-Seok — petals growing from the figure's skin with the same physical logic as the fabric, so taxonomy and fashion cannot be told apart. Kristin-Lee Moolman — two sign systems meeting with both intact, neither colonizing the other. Camille Vivier — the mythological register: statuary, horses, and a muted palette holding the fused dream at arm's length. Norbert Schoerner — the photographic-synthetic hybrid originated before the tools existed. For the suppressed register, Jean-Paul Goude — the cut and splice performed openly on the figure itself, collage by ingestion, the join as the event.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Seamless fusion: two garment ancestries merged into a shape that is neither, continuous seam logic, no visible join, even the light blended into one unnameable temperature.

> **↑ Prompt.** A single garment in which a kimono's flat construction and a trench coat's storm flaps have fused into a shape that is neither, the seam logic continuous, no visible join between the two ancestries, worn in a corridor whose lighting likewise blends daylight and tungsten into one unnameable temperature.
> 

> **↑ Negative line.** No split compositions, no exposed joins, no costume quoting of either source, no colour border between light temperatures, no collage devices, no half-and-half styling.
> 

**↓ Suppressed — repertory.** Collage shown as collage: sources joined but unblended, each keeping its own fabric, colour, and press, the join itself exposed.

> **↓ Prompt.** A split composition, the left half of the outfit strict formal tailoring and the right half sportswear mesh, joined by an exposed zip down the centre line, the two sources refusing to blend, each keeping its own fabric, colour, and press, the collage photographed as collage.
> 

> **↓ Negative line.** No blended light temperatures, no continuous seam logic, no fused silhouettes, no gradient transitions, no hiding of the join, no unified styling.
> 

## Estéticas relacionadas a SYNTHESIS (A–Z)

As 41 estéticas classificadas sob SYNTHESIS, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Alexandrian**

**№ 038 / 1001** — *Library that outlived the empire*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → SAGA ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**A biblioteca que sobreviveu ao império** — (1001 Aesthetics, interpretação)

Erudição helenística: pergaminhos, colunas de mármore, mapas celestes — a Grande Biblioteca de Alexandria.

**Paleta de cores** mármore, papiro, dourado, azul profundo

**Melhores usos:** conhecimento, editorial, cenários históricos

**MidJourney:** `[tema], ancient Library of Alexandria, Hellenistic scholarship --v 6`

**Prompt universal (Seedream):** `Epic interior photograph shot on 24mm tilt-shift lens, the Great Library of Alexandria with towering marble columns and papyrus scrolls, celestial maps unrolled under golden oil-lamp light, dust motes drifting in volumetric beams, Hellenistic scholarly grandeur, cinematic historical reconstruction, 8k`

### **Androgynous**

**№ 047 / 1001** — *Neither code allowed to dominate*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**Nenhum código autorizado a dominar** — (1001 Aesthetics, interpretação)

Beleza andrógina: traços masculinos e femininos em equilíbrio exato, sem que nenhum vocabulário vença.

**Paleta de cores** neutros com contraste suave

**Melhores usos:** moda, retratos, editorial

**MidJourney:** `[tema], androgynous beauty editorial --v 6`

**Prompt universal (Seedream):** `High fashion portrait shot on Hasselblad with 100mm lens, androgynous model with perfectly balanced masculine and feminine features, sharp jawline and soft lips, minimal wet-look styling, neutral palette against gray seamless, single beauty dish with precise catchlights, Peter Lindbergh intensity, 8k skin texture`

### **Biomechanical**

**№ 092 / 1001** — *Wound that became the blueprint*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** One surrealist-anatomical lineage is inherited whole and re-read through machinery — the body remains the organizing subject while its parts are re-specified in metal, a reinterpretation within a single line rather than a braid of several.

**Atmosfera e mood**

**Ferida que virou planta baixa** — (1001 Aesthetics, interpretação)

Biomecânico: carne fundida a máquinas hidráulicas, precisão de pesadelo à la Giger.

**Paleta de cores** cinza-metal, osso, preto

**Melhores usos:** sci-fi, horror, tattoo

**MidJourney:** `[tema], biomechanical art, flesh and machine fusion --v 6`

**Prompt universal (Seedream):** `Ultra-detailed dark render at 8k, a biomechanical torso where pale flesh fuses seamlessly into hydraulic machinery, chrome vertebrae and translucent tubes pulsing with fluid, bone-gray and gunmetal palette under cold rim light, H.R. Giger nightmare precision with airbrushed obsidian sheen, every rivet and sinew razor-sharp`

### **Bionism**

**№ 095 / 1001** — *Bone that cuts steel weight by a third*

**Nível:** ⚫ Quaternária

**Eixo:** SYNTHESIS ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Nota genealógica original (EN):** Structural engineering, skeletal biology, and computational optimization converge several generations down; remove the biology and the lattice loses its model, remove the computation and the weight saving cannot be found — a weld of distinct lineages, not a revision of one.

**Atmosfera e mood**

**Osso que corta um terço do peso do aço** — (1001 Aesthetics, interpretação)

Biônica: estruturas generativas em treliça de osso, engenharia orgânica leve.

**Paleta de cores** branco-osso, cinza-titânio

**Melhores usos:** produto, arquitetura, 3D

**MidJourney:** `[tema], bionic generative lattice structure --v 6`

**Prompt universal (Seedream):** `Ultra-crisp render at 8k, a bionic chair of generative bone-like titanium lattice, lightweight trabecular structure glowing softly under studio gradient light, bone-white and brushed metal surfaces, 3D-printed organic engineering in the spirit of Joris Laarman, every strut and node in razor focus, architectural product-design elegance`

### **Collage**

**№ 166 / 1001** — *Torn edge that beats the clean seam*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Nota genealógica original (EN):** Cubist papier collé, mass-print material, and photomontage politics converge; remove the printed matter and there is nothing to tear, remove the montage lineage and the seam stops arguing — recombination across distinct lines.

**Atmosfera e mood**

**A borda rasgada que vence a emenda limpa** — (1001 Aesthetics; código: sref-midjourney.com)

Colagem: papel rasgado, recortes sobrepostos, fita e textura de impressão, composição feita à mão.

**Paleta de cores** mistas de papel impresso, kraft, off-white

**Melhores usos:** editorial, capas, arte

**MidJourney:** `--sref 2087220229 --sw 1000` (Whimsical Organic Surrealism, categoria collage)

**Prompt universal (Seedream):** `High-resolution scan of a mixed-media collage artwork, torn paper edges and overlapping vintage cutouts, masking tape and halftone print textures layered by hand, where the ragged edge beats the clean seam, Hannah Höch lineage with contemporary zine energy, visible glue sheen and paper fiber, 8k archival capture`

### **Contemporary**

**№ 174 / 1001** — *Now is the only material it won't abandon*

**Nível:** 🔴 Primária

**Eixo:** SYNTHESIS ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova forma ao tornar inertes as convenções de suas origens.

**Nota genealógica original (EN):** Its governing law — that only present relevance is non-negotiable and every other commitment is disposable — is a root condition rather than an inheritance, and removing it dissolves the category entirely.

**Atmosfera e mood**

**O agora é o único material que não abandona** — (1001 Aesthetics, interpretação)

Contemporâneo: linhas atuais limpas, materiais mistos, arte de agora em espaço de agora.

**Paleta de cores** neutros atuais, acentos pontuais

**Melhores usos:** interiores, arquitetura, branding

**MidJourney:** `[tema], contemporary design, current clean lines --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a contemporary interior scene, clean current lines mixing travertine glass and blackened steel, large-scale present-day art anchoring a refined neutral room, deliberate accent in ochre, floor-to-ceiling daylight, unmistakably now, Architectural Digest polish, crisp material detail, 8k`

### **Crystal Punk**

**№ 183 / 1001** — *Mohs 7 quartz against 1.0 mm hide*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Quartzo Mohs 7 contra couro de 1 mm** — (1001 Aesthetics, interpretação)

Crystal punk: cristais crescendo sobre couro e metal, armadura mineral, brutalidade facetada e brilho.

**Paleta de cores** ametista, quartzo, couro escuro, cromado

**Melhores usos:** fantasia, personagens, capas

**MidJourney:** `[tema], crystal punk, quartz armor growing over leather --v 6`

**Prompt universal (Seedream):** `Ultra-detailed character render at 8k, a crystal punk figure, amethyst and quartz clusters growing over black leather and studded metal, faceted mineral armor splintering rim light into prisms, hard gemstone brutality with punk attitude, subsurface crystal glow against matte black, razor-sharp macro facet detail, cinematic dark fantasy polish`

### **Digital Tribalism**

**№ 227 / 1001** — *Borrowed Smoke, Coded Light, Contested Lineage*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Fumaça emprestada, luz codificada, linhagem contestada** — (1001 Aesthetics, interpretação)

Tribalismo digital: padrões tribais renderizados em néon e pixel, ancestralidade remixada por interface, identidade em disputa.

**Paleta de cores** terra ancestral, néon de tela, preto digital

**Melhores usos:** arte, música, capas

**MidJourney:** `[tema], digital tribalism, neon-coded tribal patterns --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a digital tribalism composition, ancestral tribal patterns re-rendered in neon and pixel light, ritual smoke drifting through coded interfaces, earth ochres against electric cyan glow, contested lineage of symbol and circuit, volumetric light and intricate pattern detail`

### **Dissonant**

**№ 232 / 1001** — *Friction, Then Form*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → ESTHETICS ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova forma ao tornar inertes as convenções de suas origens.

**Atmosfera e mood**

**Fricção, depois forma** — (1001 Aesthetics, interpretação)

Dissonância: cores que brigam de propósito, escalas em conflito, desconforto que vira composição.

**Paleta de cores** pares em choque (verde ácido/rosa, laranja/azul)

**Melhores usos:** arte, música, experimental

**MidJourney:** `[tema], dissonant clashing colors, deliberate visual friction --v 6`

**Prompt universal (Seedream):** `Ultra-crisp graphic artwork at 8k, a dissonant composition, deliberately clashing color pairs and conflicting scales, acid green striking against hot pink, visual friction resolving into unexpected form, productive discomfort with razor-edged shapes, gallery-print precision`

### **Eclectic**

**№ 262 / 1001** — *Seven Dialects, One Sentence That Parses*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Sete dialetos, uma frase que faz sentido** — (1001 Aesthetics, interpretação)

Eclético: épocas e estilos misturados com curadoria — mid-century com barroco, artesanato com industrial, harmonia improvável.

**Paleta de cores** paleta unificadora sobre peças diversas

**Melhores usos:** interiores, editorial, branding

**MidJourney:** `[tema], eclectic curated interior, mixed eras in harmony --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 35mm lens, an eclectic interior, mid-century chair beside baroque mirror and industrial lamp in balanced daylight, seven style dialects resolved into one sentence that parses, curated harmony across eras, Architectural Digest polish, 8k`

### **Eco Algorithmic**

**№ 264 / 1001** — *Beauty Proved in Carbon, Watts, and Species*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Beleza provada em carbono, watts e espécies** — (1001 Aesthetics, interpretação)

Eco-algorítmico: design generativo otimizado por dados ambientais, estruturas orgânicas calculadas, métrica ecológica visível.

**Paleta de cores** verdes de dados, branco técnico, gradientes naturais

**Melhores usos:** tech verde, arquitetura, infografia

**MidJourney:** `[tema], algorithmic generative eco design, data-optimized organic structure --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital render at 8k, an eco-algorithmic design, generative organic structure optimized by environmental data, visible ecological metrics woven into the lattice form, biomimetic geometry glowing with soft data light, beauty proved in carbon watts and species, parametric precision`

### **Eco Futurism**

**№ 265 / 1001** — *Forest Grows Back Through the Foundation*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**A floresta volta a crescer pela fundação** — (1001 Aesthetics, interpretação)

Ecofuturismo: torres cobertas de floresta vertical, cidade e natureza fundidas, futuro verde luminoso.

**Paleta de cores** verde exuberante, vidro claro, luz solar

**Melhores usos:** sci-fi, arquitetura, capas

**MidJourney:** `[tema], eco futurism, vertical forest towers, green solarpunk city --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 32mm lens, an eco-futurist cityscape, towers wrapped in vertical forest under golden solar light, nature growing back through the foundations, luminous green future where city and canopy merge, drifting pollen catching the sun, bright utopian grading, 8k production still`

### **Fairy Grunge**

**№ 317 / 1001** — *Wings Tear and Glitter Ages*

**Nível:** ⚫ Quaternária

**Eixo:** SYNTHESIS ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**As asas rasgam e o glitter envelhece** — (1001 Aesthetics, interpretação)

Fada grunge: tule sujo e coturno, glitter desbotado sobre flanela, magia que sobreviveu ao mundo real.

**Paleta de cores** rosa desbotado, marrom terra, glitter opaco

**Melhores usos:** moda alternativa, retratos, editorial

**MidJourney:** `[tema], fairy grunge aesthetic, torn tulle wings over flannel, aged glitter --v 6`

**Prompt universal (Seedream):** `Shot on Contax T2 point-and-shoot with direct flash, a fairy grunge portrait, torn tulle wings over flannel and combat boots against a chain-link fence, faded glitter catching on scraped skin, earth browns bleeding into dulled pastels, magic that survived the real world, 90s snapshot grain, 8k scan`

### **Fragmented**

**№ 346 / 1001** — *Image Shattered and Reassembled Off-Register*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↓ → COHERENCE ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A fusão é transmitida como continuidade reconhecível, mantendo unida sua lógica ancestral.

**Atmosfera e mood**

**A imagem estilhaçada e remontada fora de registro** — (1001 Aesthetics; código: Lummi, match aproximado)

Fragmentado: imagem quebrada em cacos e recomposta com desencontro proposital, o todo legível mas nunca inteiro.

**Paleta de cores** cacos contrastantes, bordas de corte visíveis

**Melhores usos:** conceitual, colagem, editorial

**MidJourney:** `--sref 159188116 --sw 1000` (Mind Mosaic — match aproximado)

**Prompt universal (Seedream):** `Shot on Pentax 67 with 90mm lens, a fragmented composition, image shattered into shards and reassembled off-register under studio light, David Hockney joiner-photography misalignment, the whole legible but never intact, 8k fine-art collage precision`

### **Gen Y/Millennials**

**№ 370 / 1001** — *Edison Filaments Wired to a Wi-Fi Router*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**Filamentos de Edison ligados a um roteador Wi-Fi** — (1001 Aesthetics, interpretação)

Millennial: café de tijolo aparente e lâmpada de filamento, laptop e avocado toast, vintage curado com internet rápida.

**Paleta de cores** âmbar de filamento, tijolo, verde de suculenta, millennial pink

**Melhores usos:** lifestyle, branding, editorial

**MidJourney:** `[tema], millennial aesthetic, Edison bulb café with exposed brick and laptops --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X100V with 23mm lens, a millennial scene, Edison filament bulbs wired to a Wi-Fi router in an exposed-brick café, laptop and avocado toast with succulents and millennial pink, curated vintage on fast internet, 8k`

### **GISCARDPUNK**

**№ 379 / 1001** — *Minitel Beige, Pompidou Blue, and the TGV Stripe*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → NARRATIVE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Bege de Minitel, azul Pompidou e a listra do TGV** — (1001 Aesthetics, interpretação)

Giscardpunk: retrofuturismo francês dos anos 70, modernidade estatal de plástico bege, o futuro segundo a França de 1975.

**Paleta de cores** bege de terminal, azul Pompidou, laranja TGV

**Melhores usos:** retrofuturismo, editorial, design

**MidJourney:** `[tema], 1970s French state retrofuturism, Minitel beige terminals, Pompidou blue and TGV orange stripe --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Ektachrome with 35mm lens, a giscardpunk scene, 1970s French state retrofuturism with Minitel beige terminals, Pompidou blue pipework and the orange TGV stripe, flat institutional lighting, plastic modernity of France 1975, 8k`

### **Hallyu**

**№ 413 / 1001** — *Comeback Calendar Behind the Lightstick Ocean*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**O calendário de comeback atrás do oceano de lightsticks** — (1001 Aesthetics, interpretação)

Hallyu: estética K-pop de produção impecável, cores de era e palco sincronizado, fandom como paisagem luminosa.

**Paleta de cores** pastel de era, neôn de palco, oceano de lightstick

**Melhores usos:** música, editorial pop, branding jovem

**MidJourney:** `[tema], K-pop hallyu aesthetic, lightstick ocean at a concert, polished comeback era styling --v 6`

**Prompt universal (Seedream):** `Shot on Sony A1 with 200mm lens, a hallyu K-pop image, a lightstick ocean glowing before a synchronized stage, immaculate comeback-era styling and pastel concept colors, arena haze and stage beams, fandom as a luminous landscape, 8k`

### **Interlock**

**№ 475 / 1001** — *Dovetail Holds Without a Single Nail*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**O rabo-de-andorinha segura sem um único prego** — (1001 Aesthetics, interpretação)

Encaixe: marcenaria de junção perfeita, madeira que segura madeira, a inteligência visível na união.

**Paleta de cores** madeiras contrastantes, mel e nogueira, luz de oficina

**Melhores usos:** artesanato, produto, editorial de ofício

**MidJourney:** `[tema], interlocking joinery aesthetic, dovetail joint holding without a single nail, contrasting woods macro --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 645Z with 120mm macro lens, an interlock image, a dovetail joint holding without a single nail, honey and walnut woods meeting in perfect joinery, George Nakashima reverence for wood, intelligence made visible in the union, 8k`

### **Italian Renaissance**

**№ 482 / 1001** — *Brunelleschi's Dome Makes Florence Measure the World*

**Nível:** 🔴 Primária

**Eixo:** SYNTHESIS ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**A cúpula de Brunelleschi faz Florença medir o mundo** — (1001 Aesthetics; código: roms5189, match aproximado)

Renascença italiana: proporção e perspectiva recém-inventadas, terracota e afresco, o humano como medida.

**Paleta de cores** terracota de cúpula, ocre florentino, azul de afresco

**Melhores usos:** arte, arquitetura, editorial histórico

**MidJourney:** `--sref 1855712653 --sw 1000` (Renaissance Forest Fantasy — match aproximado)

**Prompt universal (Seedream):** `Shot on Hasselblad 907X with 45mm lens, an Italian Renaissance image, Brunelleschi's terracotta dome making Florence measure the world, newly invented perspective and proportion, ochre and fresco blue, the human as measure, 8k`

### **Japanese (Experimental)**

**№ 486 / 1001** — *Gutai Tears the Paper Screen and Calls It Form*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova forma ao tornar inertes as convenções de suas origens.

**Atmosfera e mood**

**Gutai rasga o biombo de papel e chama isso de forma** — (1001 Aesthetics, interpretação)

Japonês experimental: vanguarda do pós-guerra, matéria rasgada e gesto radical, a destruição como criação.

**Paleta de cores** papel rasgado, tinta crua, preto de gesto, vermelho de ação

**Melhores usos:** arte, editorial experimental, performance

**MidJourney:** `[tema], Japanese experimental avant-garde, Gutai torn paper screen called form, radical gesture and raw matter --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Fujifilm Neopan with 28mm lens, a Japanese experimental image, a torn paper screen declared as form, postwar avant-garde raw matter and radical gesture, action red on ripped white, Daido Moriyama are-bure-boke grain, destruction as creation, 8k`

### **Jugendstil**

**№ 498 / 1001** — *Olbrich's Secession Dome Turns Laurel Into Architecture*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**A cúpula da Secessão de Olbrich transforma louro em arquitetura** — (1001 Aesthetics; código: sref-midjourney.com, confirmado)

Jugendstil: art nouveau germânico, folha dourada e linha orgânica disciplinada, a natureza estilizada em ornamento estrutural.

**Paleta de cores** dourado de louro, branco de secessão, verde de folha, preto de linha

**Melhores usos:** arquitetura, ilustração, identidade

**MidJourney:** `--sref 2169827623 --sv 4 --sw 1000` (Fantasy Elegance in Art Nouveau Style)

**LoRA (Civitai):** "Mucha painting style" (SDXL, trigger: AlfMch) — civitai.com/models/193756

**Prompt universal (Seedream):** `Shot on Cambo 4x5 with 120mm lens, a Jugendstil image, a gilded laurel dome turning nature into architecture like Joseph Maria Olbrich's Secession Building, disciplined organic art nouveau lines, secession white and leaf gold, ornament as structure, 8k`

### **Manguebeat**

**№ 548 / 1001** — *Mangrove crab antennas plugged into Recife*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Antenas de caranguejo plugadas no Recife** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Manguebeat: raízes conectadas ao mundo, lama de mangue e parábolas, energia de Chico Science.

**Paleta de cores** verde úmido, marrom de rio, acentos de carnaval

**Melhores usos:** cultura BR, capa musical, editorial

**MidJourney:** `[tema], manguebeat aesthetic, crab antennas plugged into Recife mangrove mud and satellite dishes --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Gold 400 with 28mm lens, a manguebeat image, crab antennas plugged into Recife's mangrove mud and satellite dishes, humid green and river brown with carnival accents, Chico Science energy, roots wired to the world, 8k`

### **Nabis**

**№ 588 / 1001** — *Sacred Intimacy Transforms Everyday Ritual*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**Intimidade sagrada transformando o ritual cotidiano** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nabis: interiores domésticos achatados em planos decorativos, o sagrado escondido no comum.

**Paleta de cores** mostarda, vinho, verdes de tapeçaria

**Melhores usos:** arte, interiores, editorial poético

**MidJourney:** `[tema], Nabis aesthetic, flattened decorative domestic interior, sacred everyday ritual --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Nabis painting, a domestic interior flattened into decorative planes, mustard wine and tapestry greens in matte patterned harmony, Maurice Denis sacred ordinariness, lamplit ritual of the everyday, visible dry brushwork, 8k archival scan`

### **Neo-Preppy**

**№ 610 / 1001** — *Crest Without the Inheritance*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**Brasão sem a herança** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neo-preppy: blazer de brechó com brasão irônico, o código Ivy usado por quem não herdou nada.

**Paleta de cores** marinho, vinho, creme de camisa

**Melhores usos:** moda, editorial jovem, branding

**MidJourney:** `[tema], neo-preppy aesthetic, thrifted blazer with ironic crest, Ivy code without inheritance --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Ektar 100 with 50mm lens, a neo-preppy portrait, thrifted navy blazer with an ironic crest patch over a band tee, wine and cream layers styled against campus stone, the Ivy code borrowed without the inheritance, crisp film color, 8k`

### **Omniscape**

**№ 648 / 1001** — *Every View Opens Into Another Dimension*

**Nível:** 🌀 Além da Quaternária

**Eixo:** SYNTHESIS ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Cada janela abre outra dimensão** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Omnipaisagem: horizontes empilhados em escala planetária, geografia impossível costurada sem emenda.

**Paleta de cores** azuis planetários, dourado de horizonte, verde impossível

**Melhores usos:** concept art, capas, arte

**MidJourney:** `[tema], omniscape aesthetic, stacked horizons impossible geography, every view opens another world --v 6`

**Prompt universal (Seedream):** `Ultra-detailed matte painting, an omniscape where every window opens onto another dimension, stacked horizons folding at planetary scale with M.C. Escher logic, oceans flowing into skies into deserts without seam, golden horizon light across impossible geography, 8k cinematic`

### **Pastel Goth**

**№ 671 / 1001** — *Darkness Learns to Blush*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**A escuridão corando de rosa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pastel goth: cabelo lilás com renda preta, caveiras cor-de-rosa — o sombrio traduzido para tons de confeitaria.

**Paleta de cores** lilás, rosa-chiclete, preto de renda

**Melhores usos:** moda alternativa, editorial, branding jovem

**MidJourney:** `[tema], pastel goth aesthetic, lilac hair black lace pink skulls, darkness blushing --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS RP with 50mm lens, a pastel goth portrait, lilac hair and black lace choker with bubblegum-pink skull accessories, darkness translated into confectionery tones under soft window light, sweet and sinister balanced exactly, crisp gentle color, 8k`

### **Pastiche**

**№ 672 / 1001** — *Emulation, Synthesis, and the Reinterpretation of the Past*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Atmosfera e mood**

**Cinco estilos citados numa frase só** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pastiche: homenagem consciente que costura épocas e assinaturas alheias numa imagem sem costura aparente.

**Paleta de cores** mistura deliberada de paletas emprestadas

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], pastiche aesthetic, five styles quoted in one seamless image, conscious homage --v 6`

**Prompt universal (Seedream):** `Ultra-detailed artwork quoting five styles at once, a baroque sky over a cubist table beside an ukiyo-e wave framed by art deco borders with one pop-art accent, borrowed signatures stitched into a seamless conscious homage, museum-level rendering of each quotation, 8k`

### **Pont-Aven School**

**№ 696 / 1001** — *Brittany Teaches Paris to Flatten Color*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → SAGA ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Atmosfera e mood**

**Bretanha achatada em cor sintética** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Escola de Pont-Aven: campos bretões em planos chapados, contorno forte e cor decidida pela emoção.

**Paleta de cores** vermelho de campo sintético, azul de traje bretão, verde chapado

**Melhores usos:** arte, paisagens, editorial

**MidJourney:** `[tema], Pont-Aven School aesthetic, flat synthetic color planes, Breton fields with bold outlines --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Pont-Aven School painting, Breton women in white coifs crossing fields flattened into synthetic color planes, Paul Sérusier bold outlines with emotion deciding every hue, field red and flat green against costume blue, 8k archival scan`

### **Resilient Fragmentation**

**№ 755 / 1001** — *Breaking Becomes Making*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** Wabi-sabi's quiet acceptance of wear and impermanence is re-instrumented by foregrounding the break itself as the primary construction method — the crack is moved to center, run with gold, and treated not as evidence of age but as the point of departure for a new grammar of deliberate rupture.

**Atmosfera e mood**

**Inteiro justamente por estar partido** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Fragmentação resiliente: cerâmica estilhaçada suspensa no ar, cada caco mantendo o desenho do conjunto.

**Paleta de cores** porcelana quebrada, ouro de kintsugi, sombra suspensa

**Melhores usos:** conceito, arte, capas

**MidJourney:** `[tema], resilient fragmentation aesthetic, shattered ceramic suspended mid-air, whole because broken --v 6`

**Prompt universal (Seedream):** `Ultra-crisp studio photograph, resilient fragmentation, a ceramic vase shattered and suspended mid-air with every shard holding its place in the original silhouette, kintsugi gold light threading the gaps, whole precisely because it is broken, frozen high-speed clarity on black, 8k`

### **Solarpunk**

**№ 827 / 1001** — *Futures where technology grows greener*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Nota genealógica original (EN):** Cyberpunk's electronic spine, Steampunk's retro-mechanical romance, and the ecological imagination of utopian science fiction are welded into one form, no single ancestor surviving intact, so three separate futures fuse into a solar-and-vine city that none of the three lineages could produce alone.

**Atmosfera e mood**

**Futuros onde a tecnologia verdeja** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Solarpunk: torres cobertas de jardins, vitrais fotovoltaicos e bondes silenciosos — o futuro otimista movido a sol.

**Paleta de cores** verde de jardim vertical, dourado solar, branco de arcada

**Melhores usos:** conceito, sci-fi, editorial

**MidJourney:** `[tema], solarpunk aesthetic, garden-covered towers photovoltaic stained glass quiet trams, futures growing greener --v 6`

**Prompt universal (Seedream):** `Ultra-detailed concept art, a solarpunk city morning, garden-draped towers with art nouveau arcades and photovoltaic stained glass casting colored light on quiet tram lines, vertical green and solar gold under a clean bright sky, a future where technology chose to grow greener, hopeful luminous detail, 8k`

### **Sonic**

**№ 830 / 1001** — *Sound Becomes Sight*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Nota genealógica original (EN):** Musique concrète's tape-cut academic tradition, Futurist noise-art's gallery hunger for the immaterial, and visual-music film's drawn sound are welded into one form, no single ancestor surviving intact, so three separate lineages fuse into a room-as-instrument that none of the three could build alone.

**Atmosfera e mood**

**O som tornado visível** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sônico: tinta saltando do alto-falante no exato pico do grave — cimática e física transformadas em coreografia.

**Paleta de cores** tinta neon, preto de estúdio, respingo congelado

**Melhores usos:** música, arte, campanhas

**MidJourney:** `[tema], sonic aesthetic, neon paint leaping off a speaker at peak bass, sound becoming sight --v 6`

**Prompt universal (Seedream):** `Ultra-high-speed studio photograph, a sonic study, neon paint leaping off a bass speaker cone at the exact peak of the drop, liquid crowns and droplets frozen mid-air against studio black, cymatics turning physics into choreography, razor flash freeze at microsecond clarity, 8k`

### **Suzhou**

**№ 877 / 1001** — *Scholar's garden composed one framed view at a time*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → NUANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** The broader Chinese Classical Garden tradition supplies the single parent, and Suzhou's scholar garden re-instruments that inheritance by narrowing imperial grandeur into private, asymmetrical miniaturization.

**Atmosfera e mood**

**O jardim do letrado composto quadro a quadro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Suzhou: janelas-lua emoldurando pedras e bambu, corredores que editam a paisagem — o jardim clássico chinês como sequência de vistas.

**Paleta de cores** branco de muro, cinza de telha, verde de bambu

**Melhores usos:** viagem, arquitetura, editorial

**MidJourney:** `[tema], suzhou garden aesthetic, moon gate framing rock and bamboo, one composed view at a time --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 907X with 45mm lens, a Suzhou scholar's garden, a moon gate framing exactly one composition of scholar stone bamboo and still pond, whitewashed wall and gray tile editing the world view by view, the garden built as a sequence of framed poems, contemplative precision, 8k`

### **Synesthesia**

**№ 884 / 1001** — *Colors you can hear, sounds you can see*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** The Gesamtkunstwerk's total-artwork drive supplies the single parent, and Synesthesia re-instruments that inheritance by rebuilding the fusion of the senses on perceptual neuroscience instead of stagecraft.

**Atmosfera e mood**

**Cores que se ouvem, sons que se veem** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sinestesia: o acorde em amarelo, o baixo em roxo profundo — os sentidos trocando de canal no meio da frase.

**Paleta de cores** amarelo de acorde, roxo de baixo, ciano de agudo

**Melhores usos:** música, arte digital, conceito

**MidJourney:** `[tema], synesthesia aesthetic, chords in yellow bass in deep purple, senses swapping channels --v 6`

**Prompt universal (Seedream):** `Ultra-vivid abstract digital composition, synesthesia, a piano chord blooming as yellow rings while the bassline rolls beneath in deep purple waves and cymbals spark cyan at the edges, sound rendered as simultaneous color frequencies, the senses swapping channels mid-phrase, luminous flowing detail, 8k`

### **Synthetic Nature**

**№ 886 / 1001** — *Gardens grown from code and chlorophyll*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** Biomorphism supplies the single parent, and Synthetic Nature re-instruments that inheritance by applying digital fabrication and self-emitting light to organic curved forms.

**Atmosfera e mood**

**Jardins cultivados de código e clorofila** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Natureza sintética: samambaias procedurais, pétalas com malha visível e a estufa onde botânica e algoritmo se polinizam.

**Paleta de cores** verde de clorofila digital, branco de estufa, brilho de subsuperfície

**Melhores usos:** conceito, arte digital, branding

**MidJourney:** `[tema], synthetic nature aesthetic, procedural ferns petals with visible mesh, gardens of code and chlorophyll --v 6`

**Prompt universal (Seedream):** `Ultra-detailed 3D render, a synthetic nature greenhouse, procedural ferns unfurling beside orchids whose petals reveal faint wireframe mesh under subsurface glow, digital chlorophyll green in sterile greenhouse white, botany and algorithm cross-pollinating in the same bed, luminous hybrid detail, 8k`

### **Synthetism**

**№ 887 / 1001** — *Flat Color Carrying More Than Description*

**Nível:** 🟤 Terciária

**Eixo:** SYNTHESIS ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Nota genealógica original (EN):** Three lineages converge here — Cloisonism's leaded contour, Japonisme's flat color, and Symbolist idealism's pursuit of the Idea — with Impressionism supplying only the rejected wound, fixing the system as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**A cor chapada carregando mais que a descrição** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sintetismo: memória e emoção sintetizadas em planos de cor cercados de contorno — Gauguin abandonando a cópia pela síntese.

**Paleta de cores** vermelho de prado sintético, azul de contorno, amarelo de Taiti

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], synthetism aesthetic, flat color planes bound by contour memory over description, Gauguin synthesis --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a synthetist painting, figures and landscape synthesized from memory into flat color planes bound by dark contour in the Gauguin manner, synthetic meadow red and Tahitian yellow refusing mere description, emotion compressed into shape and hue, bold painted conviction, 8k scan`

### **Techno-Organic**

**№ 894 / 1001** — *Biology Wired Into Digital Growth*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** Cybernetics and Systems Art supply the single parent, and Techno-Organic re-instruments that inheritance by rewriting the feedback loop in wet biology instead of diagrams and servos.

**Atmosfera e mood**

**A biologia cabeada em crescimento digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tecno-orgânico: circuitos correndo por dentro de caules, fibra óptica florescendo em capílares — o vivo e o fabricado dividindo a mesma seiva.

**Paleta de cores** verde de seiva, cobre de circuito, azul de fibra óptica

**Melhores usos:** conceito, sci-fi, arte digital

**MidJourney:** `[tema], techno-organic aesthetic, circuits inside stems fiber optics blooming through capillaries, biology wired into digital growth --v 6`

**Prompt universal (Seedream):** `Ultra-detailed 3D render, a techno-organic hybrid, copper circuitry running inside translucent plant stems as fiber-optic capillaries bloom into a glowing flower, sap green threaded with circuit copper and optic blue, the living and the fabricated sharing one root system, luminous bio-digital detail, 8k`

### **Tropicália**

**№ 911 / 1001** — *Brazilian Counterculture in Collage and Amplification*

**Nível:** 🔴 Primária

**Eixo:** SYNTHESIS ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova forma ao tornar inertes as convenções de suas origens.

**Nota genealógica original (EN):** The antropofagia engine predates and outlives any single style it has produced; it is a procedure rather than a look, and a procedure cannot be decomposed into a parent lineage — the signature of a foundational node, not a recombination.

**Atmosfera e mood**

**A contracultura brasileira em colagem e amplificação** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tropicália: Parangolés de Oiticica em movimento, guitarra elétrica sobre batuque e 1968 engolindo tudo — antropofagia em cor máxima.

**Paleta de cores** laranja tropicalista, verde-bandeira subvertido, rosa de Parangolé

**Melhores usos:** cultura brasileira, música, editorial

**MidJourney:** `[tema], tropicalia aesthetic, Oiticica parangoles electric guitar over batuque 1968, anthropophagy at maximum color --v 6`

**Prompt universal (Seedream):** `Ultra-vivid mixed-media collage in the Tropicália spirit, Hélio Oiticica Parangolé capes swirling mid-dance over electric guitars and batuque drums in a 1968 São Paulo happening, tropicalist orange and subverted flag green cut with Parangolé pink, Brazilian counterculture devouring everything and amplifying it back, exuberant revolutionary energy, 8k`

### **Vienna Secession**

**№ 950 / 1001** — *Laurel Dome Breaks Academic Rank*

**Nível:** 🟣 Secundária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem reconhecível é preservada e reinstrumentada até produzir uma terceira forma.

**Nota genealógica original (EN):** Vienna Secession reinterprets a single parent, Jugendstil/Art Nouveau, disciplining its sinuous line into a geometric grid without fusing in a second structural lineage.

**Atmosfera e mood**

**A cúpula de louros rompendo a fila acadêmica** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Secessão de Viena: o pavilhão de Olbrich coroado de louros dourados e o lema na fachada — a cada tempo sua arte, à arte sua liberdade.

**Paleta de cores** branco de pavilhão, dourado de louro, verde de friso

**Melhores usos:** arquitetura, arte, editorial

**MidJourney:** `[tema], vienna secession aesthetic, Olbrich pavilion golden laurel dome, to every age its art to art its freedom --v 6`

**Prompt universal (Seedream):** `Shot on Cambo 4x5 with 90mm lens, the Vienna Secession pavilion at golden hour, the Olbrich dome of gilded laurel leaves blazing above the white cubic facade and its carved motto, laurel gold against pavilion white and frieze green, the young movement breaking academic rank in built form, luminous architectural rebellion, 8k`

### **Web 6.0**

**№ 971 / 1001** — *Consciousness Becomes the Network*

**Nível:** 🌀 Além da Quaternária

**Eixo:** SYNTHESIS ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Ancestralidades distintas são fundidas numa terceira gramática inseparável.

**Nota genealógica original (EN):** This retroactively gathers five formally distinct tendencies — transparent interface, generative dataflow, organic biomedia, networked noospherics, techno-numinous — under a label none of them chose, consuming transhumanist and cyberpunk substrates rather than reinterpreting a single one.

**Atmosfera e mood**

**A consciência tornando-se a rede** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Web 6.0: a fronteira entre mente e malha dissolvida, pensamentos roteados como pacotes e a rede sonhando em conjunto — especulação em escala cósmica.

**Paleta de cores** violeta neural, dourado de sinapse, negro cósmico

**Melhores usos:** conceito, sci-fi, capas

**MidJourney:** `[tema], web 6.0 aesthetic, mind and mesh dissolved thoughts routed as packets, consciousness becomes the network --v 6`

**Prompt universal (Seedream):** `Ultra-detailed cosmic render, a Web 6.0 speculation, a human silhouette dissolving into a galaxy-scale neural mesh where thoughts route as pulses of synapse gold through neural violet, the border between mind and network fully negotiated away, the system dreaming collectively against cosmic black, transcendent visionary scale, 8k`

### **Weimar**

**№ 972 / 1001** — *Cabaret Smoke, Bauhaus Steel, and the Brilliant Decade Between Two Catastrophes*

**Nível:** 🔴 Primária

**Eixo:** SYNTHESIS ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova forma ao tornar inertes as convenções de suas origens.

**Nota genealógica original (EN):** The currents that fed the moment are absorbed and rendered inert: the preliminary course cuts the definition of ornament out of design — material before style, hand before theory — and what came before does not survive as ancestry.

**Atmosfera e mood**

**Fumaça de cabaré, aço Bauhaus e a década brilhante entre duas catástrofes** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Weimar: Berlim 1928 — o cabaré esfumaçado onde Otto Dix encontra a cadeira de aço tubular, glória e presságio dividindo a mesma mesa.

**Paleta de cores** fumaça de cabaré, dourado de palco, aço tubular

**Melhores usos:** histórico, editorial, cinema

**MidJourney:** `[tema], weimar aesthetic, berlin 1928 smoky cabaret Otto Dix faces tubular steel, brilliance between two catastrophes --v 6`

**Prompt universal (Seedream):** `Shot on an Ernemann Ermanox in available light, a Weimar cabaret in 1928 Berlin, a singer under one gold spot as Otto Dix faces lean through smoke around tubular steel chairs, stage gilt and cigarette haze over Bauhaus lines, the brilliant decade burning between two catastrophes and knowing it, intoxicating doomed glamour, 8k scan`

### **Worldly**

**№ 983 / 1001** — *Nomadic Taste Without the Souvenir Shelf*

**Nível:** 🔴 Primária

**Eixo:** SYNTHESIS ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova forma ao tornar inertes as convenções de suas origens.

**Nota genealógica original (EN):** No single school hands the Worldly form down; Branded and Vernacular Cosmopolitanism both descend from this root rather than feeding into it, and removing the parent tradition of cosmopolitanism itself leaves no substrate movement to trace back to.

**Atmosfera e mood**

**O gosto nômade sem a prateleira de suvenires** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Worldly: o têxtil comprado do próprio tecelão, o livro anotado em três idiomas e a casa que absorveu as viagens em vez de exibi-las.

**Paleta de cores** terracota de mundo, índigo artesanal, neutro de fundo culto

**Melhores usos:** interiores, lifestyle, editorial

**MidJourney:** `[tema], worldly aesthetic, textile bought from its weaver book annotated in three languages, travel absorbed not displayed --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 24mm lens, a worldly living room, a handwoven textile draped where its weaver's name is still remembered beside books annotated in three languages and one worn brass teapot in daily use, world terracotta and artisan indigo against cultured neutrals, travel absorbed into the household rather than shelved as souvenirs, quiet cosmopolitan depth, 8k`

## Leitura do padrão — o que as 41 estéticas confirmam

### O caso suprimido e seu fato estrutural

Fragmented (№ 346) é a única estética do corpus inteiro que suprime SYNTHESIS — e o faz como identidade primária, arrastando junto COHERENCE ↓: os dois abridores da Station SCÈNE caem juntos numa única entrada, e a polaridade é XX — continuity by transmission: a imagem estilhaçada e remontada fora de registro não rompe uma herança, ela transmite a quebra como herança. O fato estrutural: SYNTHESIS ↓ não aparece como slot secundário em nenhuma outra entrada das 14 Ações. Nenhuma estética perde a síntese como efeito colateral de outra amplificação — quando a fusão falha, falha como evento principal.

### Quatro famílias recorrentes

→ EMANATION ↑ reúne 7 (Synthetic Nature, Synesthesia, Vienna Secession, Solarpunk, Web 6.0, Hallyu, Nabis) — a fusão que irradia, a amêndoa que reorganiza o ambiente; → MATTER reúne 7 (Techno-Organic, Biomechanical, Resilient Fragmentation, Bionism, Crystal Punk, Eco Futurism, e Synthetism com MATTER ↓) — a fusão que encarna em material e resistência; → SEMIOTICS ↑ reúne 3 (Worldly, Eclectic, Pastel Goth) — a fusão que vira código legível para iniciados; → COHERENCE ↑ reúne 3 (Collage, Neo-Preppy, Interlock) — a fusão disciplinada em lógica interna, o encaixe que dispensa prego.

### Polaridades

25 XY contra 16 XX — a lista pende para a disrupção: fundir linhagens produz, na maioria dos casos, uma forma que nenhum ancestral reconhece (rearticulação) ou que torna os ancestrais inertes (ruptura: Tropicália, Weimar, Worldly, Contemporary, Dissonant, Japanese Experimental). As 16 XX são as fusões de pai único — uma herança mantida inteira e reinstrumentada. Cinco Primárias ancoram a lista: Tropicália, Weimar, Italian Renaissance, Worldly e Contemporary — procedimentos fundadores, não recombinações.

### O teste operacional

a lei do glifo é verificável no corpus pelo avesso. A amêndoa existe apenas enquanto os dois círculos se comprometem — e de fato nenhuma entrada perde SYNTHESIS por acidente: ou a fusão é o sujeito da imagem, ou ela nem entra em cena. Compromisso pelo centro, nunca tangência pelas bordas.

# COHERENCE — o Nó Sem Fim

<aside>
♾️

**Essência.** COHERENCE mede a consistência da lógica interna através de suas manifestações. Seu ideograma é o Nó Sem Fim — uma única linha sem começo nem término, cruzando-se sem se romper: cada ponto depende dos demais, e o todo responde quando qualquer trecho é tensionado. No registro ↑, a mesma lógica sobrevive em todas as escalas e recortes; no registro ↓, a leitura se altera conforme a distância.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para COHERENCE, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem a lógica construtiva própria de cada estética, enquanto a arquitetura preserva a lei do Nó Sem Fim — o todo deve ser recuperável a partir de qualquer fragmento.

> **↑ COHERENCE — universal prompt.** One [construction logic] legible at every scale of the same look — cuff, closure, hem, and silhouette carrying a single continuous line of design from the smallest fastening to the full figure, the model's fingers crossing in the seam's own over-under rhythm, the hair repeating the construction the garment states, the same even temperature of expression held identically in close detail and at full length, photographed as a matched pair under one identical light — a tight 100mm detail at f/8 beside an 85mm full-length at f/8 with matching exposure — [surrounding structure] behind obeying the same construction grammar without literalizing it, any crop of the frame keeping the logic, the pattern of the whole recoverable from the fragment alone.
> 

**Universal COHERENCE ↓ negative line (always pair with the ↑ prompt):**

> No stylistic drift between scales, no detail that contradicts the silhouette, no mixed lighting logics, no off-programme accessory, no reading that changes with distance, no crop that breaks the pattern.
> 

**Como usar para as 19 estéticas da lista.** Substitua o slot pela lógica construtiva real da estética e mantenha o resto intacto. Para Geometric: *one tessellation logic legible at every scale…* — o azulejo de Alhambra que prevê sua próxima linha é a definição operacional deste prompt. Para Labyrinth: a linha unicursal — um único caminho sem bifurcação, do piso ao bordado. Para Casual: o uniforme democrático — índigo, jersey e lona carregando a mesma gramática do calçado ao colarinho. Nas três de EXPRESSION ↓ (Biedermeier, Copencore, Uniformed), acrescente a redução: a lógica contínua com a ambição individual visivelmente rebaixada. A única suprimida, Deconstructivism, inverte para o registro ↓: use o prompt do repertório de dupla identidade — severa à distância, caótica de perto.

## Fundamentos do elemento

### Identidade, continuidade e teste do recorte

**Identity.** Consistency of internal logic across manifestations. Its ideogram is the knot with no beginning and no end: one line crossing itself again and again without breaking, every point dependent on every other, pull anywhere and the whole answers. In an image this element is proven when the same logic survives every crop, or when the reading changes with distance. Its land is repeated by design: Tibet appears twice on the table and only twice — the Vajra gives the sequence its decision, this knot gives it its continuity — a deliberate rhyme, not an oversight.

**The line through contradictions.** Coherence is not the absence of contradiction — it is the continuity of the line through them. A programme that admits no tension is not coherent, only thin; the knot crosses itself and does not break.

**Pull anywhere.** Every point depends on every other: the cuff must be able to testify for the silhouette, the buttonhole for the whole garment. If one detail cannot predict the rest, it is not a detail — it is a leak.

**The crop test.** The logic must survive every crop. Before release, excerpt the frame at three scales; if any excerpt could belong to another look, the line has a beginning and an end — and the knot is counterfeit.

## Corpo — postura, gesto e olhar

**Model posture & structure.** The same postural signature legible at every scale — the spinal line of the full-length view repeated in the set of a wrist in close-up; the body consistent from silhouette to fingertip, nothing performed for one framing that the other would contradict.

**Gesture.** Gestures that repeat the garment's logic — fingers crossing in the same over-under rhythm as the seam; the hand a small edition of the whole; no gesture off-programme.

**The look — how the eyes behave.** An even, continuous presence held identically at both distances — the same temperature of expression in macro and at full figure; eyes that do not renegotiate the contract when the camera moves.

## Regras de imagem — do fragmento à prova do todo

**Look & styling continuity.** One continuous line of design from the buttonhole outward — the same braided logic in cuff, closure, hem, and overall cut; a garment whose fragment predicts its whole; every accessory inside the programme or absent.

**Camera.** Matched-pair discipline — a 100mm macro detail at f/8 beside an 85mm full-length at f/8, identical exposure, identical light, identical processing; the camera as the system's notary.

**Composition.** Constructed so any crop keeps the logic — repeating structural motifs planted at multiple scales within one frame; diptych or single view, the pattern survives every excerpt.

**Lighting.** One lighting logic applied across scales — same key direction and quality in detail and full view; light as the system's constant, never a second author.

**Beauty detail.** System beauty — the braid in the hair repeating the braid in the seam repeating the braid in the bracelet; skin finish identical in close-up and at distance; not one element off-programme anywhere on the head.

**Cenography.** A set obeying the same construction grammar — woven screens, knotted cords, coiled architecture repeating the garment's over-under logic without literalizing it; the room as one more scale of the same line.

**Colour.** One palette declined at every scale — the accent in the detail shot already present in the full view; no hue that appears only once, because a colour without an echo is a leak in the knot.

**Knot proof.** Plant one verifiable evidence that the logic is continuous: a detail crop pinned beside the full look under the same light, the fragment predicting the whole on sight — recoverability photographed, not claimed.

**Practitioner lines (from the codices).** John Rawlings — two hundred covers with no dramatic device, the connective tissue that makes a cover recognizable regardless of decade: direct clarity, the garment legible first, the throughline extended into new territory without breaking. Aldo Fallai — three decades of one unbroken visual identity fed campaign after campaign, until photographer and house became indistinguishable: the knot as a career. Clifford Coffin — one uncluttered silhouette-first language held steady across London, Paris, and New York, a single dominant curve doing the work of a dozen props. Giampaolo Sgura — the commercial register: fiercely sharp, graphic, culturally coherent, the programme executed at editorial speed without one frame drifting.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** One line of design from buttonhole to silhouette: detail and full-length views carrying the same construction logic, the pattern of the whole recoverable from any fragment.

> **↑ Prompt.** A diptych of the same look, a tight detail of a cuff beside a full-length view, the same braided seam logic legible in both, the pattern of the whole recoverable from the fragment alone, one continuous line of design running from buttonhole to silhouette without a break.
> 

> **↑ Negative line.** No stylistic drift between frames, no detail that contradicts the silhouette, no mixed lighting logics, no off-programme accessory, no crop that breaks the pattern.
> 

**↓ Suppressed — repertory.** Logic that shifts by framing: strict from afar, chaotic up close, the garment keeping two identities depending on where the viewer stands.

> **↓ Prompt.** From across the room a strict black column of a dress, and in close-up the same garment dissolving into hundreds of mismatched found fabrics, the reading changing completely at each distance, a photographic pair proving the garment holds two irreconcilable identities depending on where you stand.
> 

> **↓ Negative line.** No consistent seam logic across scales, no matching detail-to-whole grammar, no dramatic lighting taking sides, no digital blending of the two readings.
> 

## Estéticas relacionadas a COHERENCE (A–Z)

As 19 estéticas classificadas sob COHERENCE, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Amazonian Lowland**

**№ 043 / 1001** — *Cosmology built from vines and mud*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

**Atmosfera e mood**

**Cosmologia construída de cipós e barro** — (1001 Aesthetics, interpretação)

Povos da várzea amazônica: grafismos indígenas, cerâmica marajoara, a floresta como cosmologia viva.

**Paleta de cores** terracota, vermelho de urucum, preto-azulado de jenipapo, verdes de mata

**Melhores usos:** cultura, padronagem, ilustração

**MidJourney:** `[tema], Amazonian indigenous art, marajoara pottery patterns --v 6`

**Prompt universal (Seedream):** `Documentary art photograph shot on 50mm lens, Amazonian indigenous graphics — geometric urucum-red body paint and marajoara pottery patterns, terracotta and genipap black on warm skin and clay, dappled rainforest light through the canopy, living cosmology in tactile detail, respectful editorial realism, 8k`

### **Biedermeier**

**№ 087 / 1001** — *Chair sized for the hand that dusts it*

**Nível:** 🟣 Secundária

**Eixo:** COHERENCE ↑ → EXPRESSION ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma gramática coerente é preservada e reinstrumentada sem romper sua linha interna.

**Nota genealógica original (EN):** One inherited line — Empire-era neoclassical furniture — is kept whole and scaled down to domestic use; the proportions, woods and joinery survive intact while only ambition is reduced, a reinterpretation within a single lineage rather than a fusion.

**Atmosfera e mood**

**Cadeira do tamanho da mão que tira o pó** — (1001 Aesthetics, interpretação)

Biedermeier: interior burguês modesto e polido de 1830, madeira clara, ordem doméstica.

**Paleta de cores** madeira-mel, azul suave, listras discretas

**Melhores usos:** interiores, still life, histórico

**MidJourney:** `[tema], Biedermeier interior, polished domestic simplicity --v 6`

**Prompt universal (Seedream):** `Shot on medium format with 55mm lens, a Biedermeier drawing room around 1830, light polished cherry wood furniture with clean curved lines, soft daylight filtering through muslin curtains onto an embroidery hoop and porcelain cup, quiet bourgeois order, honeyed wood grain detail, painterly domestic stillness, museum-catalog quality, 8k`

### **Casual**

**№ 143 / 1001** — *Indigo, jersey, and the canvas sneaker as democratic uniform*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova lógica ao romper a continuidade do programa anterior.

**Nota genealógica original (EN):** No earlier aesthetic supplies this — the claim that ordinary workwear can serve as a universal civilian uniform is asserted at the root, and removing that democratic premise collapses the whole rather than pruning one of its branches.

**Atmosfera e mood**

**Índigo, malha e o tênis de lona como uniforme democrático** — (1001 Aesthetics, interpretação)

Casual: jeans, camiseta e tênis de lona, conforto sem esforço em luz natural de rua.

**Paleta de cores** índigo, branco, tons neutros

**Melhores usos:** moda, lifestyle, e-commerce

**MidJourney:** `[tema], casual streetwear editorial, denim and canvas sneakers --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.4, a casual fashion editorial, indigo selvedge denim and crisp white jersey tee with canvas sneakers, relaxed pose in warm afternoon street light, honest fabric texture and denim fade detail, effortless democratic style in the spirit of Peter Lindbergh, natural grading, 8k`

### **Copencore**

**№ 175 / 1001** — *Build for two centuries, light a candle anyway*

**Nível:** 🟤 Terciária

**Eixo:** COHERENCE ↑ → EXPRESSION ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Lógicas distintas são reorganizadas num sistema cuja continuidade atravessa as diferenças.

**Nota genealógica original (EN):** Danish functionalist design, hygge's domestic ritual, and social-democratic building standards converge; strip the ritual and the candle disappears, strip the building culture and the two-century horizon does — fusion of several lines.

**Atmosfera e mood**

**Constrói para dois séculos, acende uma vela mesmo assim** — (1001 Aesthetics, interpretação)

Copenhague: design escandinavo sólido, bicicletas, fachadas coloridas de Nyhavn, hygge com rigor.

**Paleta de cores** neutros nórdicos, fachadas coloridas, luz de vela

**Melhores usos:** lifestyle, interiores, cidades

**MidJourney:** `[tema], Copenhagen aesthetic, Scandinavian design and hygge --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 35mm lens, a Copenhagen lifestyle scene, bicycles leaning against colorful Nyhavn facades under soft northern light, solid Scandinavian design built to last centuries, a single candle lit in a café window against the gray, rigorous hygge, muted Nordic grading, quiet documentary warmth, 8k`

### **Day-to-Night**

**№ 204 / 1001** — *One cut that holds from boardroom to table*

**Nível:** 🟤 Terciária

**Eixo:** COHERENCE ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma gramática coerente é preservada e reinstrumentada sem romper sua linha interna.

**Atmosfera e mood**

**Um corte só que aguenta da sala de reunião à mesa do jantar** — (1001 Aesthetics, interpretação)

Dia-para-noite: look versátil em transição, blazer que vira elegância noturna, cidade mudando de luz ao fundo.

**Paleta de cores** neutros de dia, preto e dourado de noite

**Melhores usos:** moda, editorial, branding

**MidJourney:** `[tema], day-to-night versatile fashion editorial --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 50mm f/1.2, a day-to-night fashion editorial, one versatile tailored look transitioning from boardroom daylight to candlelit dinner, city shifting from blue hour to golden lamps behind glass, effortless duality with Vogue polish, split-toned cinematic grading, 8k`

### **DECONSTRUCTIVISM**

**№ 213 / 1001** — *Architecture that argues with itself*

**Nível:** 🟣 Secundária

**Eixo:** COHERENCE ↓ → INTEGRITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova lógica ao romper a continuidade do programa anterior.

**Atmosfera e mood**

**Arquitetura que discute consigo mesma** — (1001 Aesthetics, interpretação)

Desconstrutivismo: volumes fraturados e inclinados, fachadas que colidem, ordem rompida com intenção (Gehry, Hadid, Libeskind).

**Paleta de cores** titânio, concreto, vidro anguloso

**Melhores usos:** arquitetura, abstrato, capas

**MidJourney:** `[tema], deconstructivist architecture, fractured colliding volumes --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm tilt-shift lens, deconstructivist architecture, fractured tilted volumes colliding mid-air, titanium and angular glass breaking every expected line under a dramatic sky, buildings arguing with themselves, Gehry and Hadid energy, razor-sharp architectural detail, 8k`

### **Designtopia**

**№ 221 / 1001** — *Anticipatory Covenant of Sensor, Surface, and Self*

**Nível:** 🟤 Terciária

**Eixo:** COHERENCE ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Lógicas distintas são reorganizadas num sistema cuja continuidade atravessa as diferenças.

**Atmosfera e mood**

**Sensor, superfície e o eu antecipado** — (1001 Aesthetics, interpretação)

Utopia de design: ambiente que antecipa o usuário — superfícies responsivas, luz adaptativa, tecnologia invisível e gentil.

**Paleta de cores** branco quente, luz adaptativa, acentos suaves

**Melhores usos:** tech, futurismo, produto

**MidJourney:** `[tema], seamless smart design utopia, responsive surfaces --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 32mm lens, a design utopia interior, responsive surfaces and adaptive ambient light anticipating the inhabitant, invisible gentle technology in warm white minimalism, dawn-simulation glow along seamless walls, the room thinking ahead, serene sci-fi editorial polish, 8k`

### **Drifting**

**№ 244 / 1001** — *Discipline of surrendered motion*

**Nível:** 🟤 Terciária

**Eixo:** COHERENCE ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Lógicas distintas são reorganizadas num sistema cuja continuidade atravessa as diferenças.

**Atmosfera e mood**

**A disciplina do movimento entregue** — (1001 Aesthetics, interpretação)

À deriva: figura levada pela corrente ou pelo vento, cabelo e tecido em suspensão, controle rendido com graça.

**Paleta de cores** azuis de água, brancos de vento, luz suave

**Melhores usos:** artístico, dança, editorial

**MidJourney:** `[tema], drifting figure, hair and fabric suspended in current --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 50mm lens, a drifting figure, body carried by water current or wind, hair and fabric in weightless suspension, soft blues and wind whites in slow-shutter grace, control gracefully surrendered to motion, cinematic underwater-light poetry, 8k`

### **ENDURING MODERNISM**

**№ 287 / 1001** — *Doctrine That Refused to Age*

**Nível:** 🟣 Secundária

**Eixo:** COHERENCE ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma gramática coerente é preservada e reinstrumentada sem romper sua linha interna.

**Atmosfera e mood**

**A doutrina que se recusou a envelhecer** — (1001 Aesthetics, interpretação)

Modernismo duradouro: linhas limpas de meio de século ainda atuais, móvel de 1950 em casa de 2020, atemporalidade projetada.

**Paleta de cores** branco, madeira clara, preto, um acento primário

**Melhores usos:** arquitetura, design, interiores

**MidJourney:** `[tema], enduring mid-century modernism, timeless clean-lined design --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q2 with 28mm lens, an enduring modernism interior, mid-century clean lines still current, 1950s furniture in a contemporary home under soft north light, white light wood and black with one primary accent, designed timelessness, Case Study House editorial clarity, 8k`

### **06 EQUILIBRIUM**

**№ 006 / 1001** — *Six forces, one stillness*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

### **Gaúcho**

**№ 364 / 1001** — *Cuia Passed Counterclockwise by the Fire*

**Nível:** 🟤 Terciária

**Eixo:** COHERENCE ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

**Atmosfera e mood**

**A cuia passada em sentido anti-horário ao pé do fogo** — (1001 Aesthetics, interpretação)

Gaúcho: pampa aberto e chimarrão, bombacha e lenço, tradição sulina em roda de galpão.

**Paleta de cores** verde do pampa, couro, vermelho de lenço, fogo de chão

**Melhores usos:** cultura brasileira, editorial, lifestyle rural

**MidJourney:** `[tema], gaúcho tradition, mate gourd passed by the campfire, pampas horseman culture --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 7 with 80mm lens, a gaúcho scene, mate gourd passed counterclockwise by the fire in a galpão, bombacha trousers and red neckerchief against the open pampa, leather and firelight warmth, documentary dignity, southern tradition in a circle, 8k`

### **Geometric**

**№ 375 / 1001** — *Alhambra Tile That Predicts Its Next Line*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

**Atmosfera e mood**

**O azulejo de Alhambra que prevê sua próxima linha** — (1001 Aesthetics; código: Lummi, match aproximado)

Geométrico: padrão que se autogera, tesselacao perfeita, ordem matemática como ornamento.

**Paleta de cores** cores planas em lógica de padrão

**Melhores usos:** padrões, design, arquitetura

**MidJourney:** `--sref 966835107 --sw 1000` (Geo Fusion — match aproximado)

**Prompt universal (Seedream):** `High-resolution scan of an Islamic tile tessellation, a geometric pattern, Alhambra-like interlocking where each tile predicts its next line, perfect self-generating symmetry admired by M.C. Escher, flat colors in mathematical order as ornament, 8k`

### **Harmonic**

**№ 418 / 1001** — *Palladio's Villa Rotonda Turns Rooms Into Musical Ratios*

**Nível:** 🟣 Secundária

**Eixo:** COHERENCE ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

**Atmosfera e mood**

**A Villa Rotonda de Palladio transforma salas em razões musicais** — (1001 Aesthetics, interpretação)

Harmônico: proporção como música congelada, simetria palladiana, espaços afinados em razões perfeitas.

**Paleta de cores** branco palladiano, pedra clara, verde de paisagem enquadrada

**Melhores usos:** arquitetura, editorial, institucional

**MidJourney:** `[tema], harmonic Palladian architecture, Villa Rotonda symmetry, rooms as musical ratios --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm tilt-shift lens, a harmonic image, Palladio's Villa Rotonda turning rooms into musical ratios, perfect symmetry framing the landscape, proportion as frozen music in pale stone under even daylight, 8k`

### **Labyrinth**

**№ 508 / 1001** — *Chartres’ unicursal lesson underfoot*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → DOMAIN ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

**Atmosfera e mood**

**A lição unicursal de Chartres sob os pés** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Labirinto: o caminho único gravado na pedra da catedral, espiral de calcário e peregrinação interior.

**Paleta de cores** calcário, sombra de nave, cinza de pedra

**Melhores usos:** editorial espiritual, arquitetura, arte

**MidJourney:** `[tema], labyrinth aesthetic, Chartres unicursal stone path, cathedral nave light --v 6`

**Prompt universal (Seedream):** `Shot on Canon 5D Mark IV with 24mm tilt-shift lens, a labyrinth image, the Chartres unicursal path worn smooth into cathedral flagstones, limestone spirals raked by high nave light through stained glass, a pilgrim shadow tracing one turn at a time, stone grey and candle gold, an architecture that teaches patience by geometry, 8k`

### **Neoclassical Revival**

**№ 605 / 1001** — *Antiquity Recast for Modern Longing*

**Nível:** 🟣 Secundária

**Eixo:** COHERENCE ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma gramática coerente é preservada e reinstrumentada sem romper sua linha interna.

**Atmosfera e mood**

**Antiguidade refundida para a saudade moderna** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Revival neoclássico: colunas e frisos reconstruídos por um século que sentia falta de ordem.

**Paleta de cores** calcário, bronze, verde institucional

**Melhores usos:** arquitetura, institucional, histórico

**MidJourney:** `[tema], neoclassical revival aesthetic, columned facade recast for modern longing --v 6`

**Prompt universal (Seedream):** `Shot on ALPA 12 with 36mm lens, a neoclassical revival facade at blue hour, limestone columns and bronze doors recast for modern longing, institutional symmetry glowing with warm interior light, antiquity rebuilt by a century that missed order, architectural print clarity, 8k`

**Atmosfera e mood**

**Antiguidade refundida para a saudade moderna** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Revival neoclássico: colunas e frisos reconstruídos por um século que sentia falta de ordem.

**Paleta de cores** calcário, bronze, verde institucional

**Melhores usos:** arquitetura, institucional, histórico

**MidJourney:** `[tema], neoclassical revival aesthetic, columned facade recast for modern longing --v 6`

**Prompt universal (Seedream):** `Shot on ALPA 12 with 36mm lens, a neoclassical revival facade at blue hour, limestone columns and bronze doors recast for modern longing, institutional symmetry glowing with warm interior light, antiquity rebuilt by a century that missed order, architectural print clarity, 8k`

### **Nomadism**

**№ 631 / 1001** — *Identity Packed to Carry*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → MATTER ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A lógica interna é transmitida como continuidade reconhecível em todas as escalas.

**Atmosfera e mood**

**Identidade que cabe na bagagem** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nomadismo: yurt na estepe, alforjes e pó de estrada, a casa definida pelo movimento.

**Paleta de cores** pó de estepe, lã tingida, céu aberto

**Melhores usos:** viagem, documental, editorial

**MidJourney:** `[tema], nomadism aesthetic, yurt on the steppe, identity packed into saddlebags --v 6`

**Prompt universal (Seedream):** `Shot on Leica M4 with 35mm lens, a nomad scene on the open steppe, a felt yurt and loaded saddlebags in road dust, dyed wool textiles against an enormous sky, home defined by movement rather than address, warm documentary honesty, 8k`

### **Post-War Suburbia**

**№ 710 / 1001** — *Nightmare That Looked Like Paradise*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → NUANCE ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova lógica ao romper a continuidade do programa anterior.

**Nota genealógica original (EN):** Levitt and Sons' 1947–1951 Levittown stamped a single house design across four thousand lots, introducing mass-production logic into domestic architecture in a move that severed the garden-city tradition and made the standardized lawn-policed mortgage unit the irreducible grammar of American belonging.

**Atmosfera e mood**

**Gramados idênticos, sonhos padronizados** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Subúrbio pós-guerra: casas em série de 1955, carro na garagem e o paraíso em formato de nightmare educada.

**Paleta de cores** verde de gramado, pastel de fachada, cromo de sedã

**Melhores usos:** histórico, conceito, editorial

**MidJourney:** `[tema], post-war suburbia 1955 aesthetic, identical lawns tract houses, paradise-shaped conformity --v 6`

**Prompt universal (Seedream):** `Shot on Kodachrome 25 with 50mm lens, a post-war suburbia scene, identical 1955 tract houses with matching lawns and one chrome sedan per driveway, facade pastels under an optimistic sky, Bill Owens deadpan on a paradise-shaped nightmare, saturated period color, 8k scan`

### **Suburban**

**№ 859 / 1001** — *Lawns, cul-de-sacs, and the comfort contract*

**Nível:** 🔴 Primária

**Eixo:** COHERENCE ↑ → DENSITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova lógica ao romper a continuidade do programa anterior.

**Nota genealógica original (EN):** No single prior movement precedes Suburban; the kept lawn, the looping street, and the open kitchen are borrowed fragments no ancestor assembles whole, so the grammar of repeated low houses generates descendants — New Urbanism, the gated subdivision — far more than it derives from any one of them.

**Atmosfera e mood**

**Gramados, cul-de-sacs e o contrato do conforto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Suburbano: aspersor no horário, caixa de correio idêntica à do vizinho e a promessa de que nada de inesperado vai acontecer.

**Paleta de cores** verde de gramado, bege de fachada, azul de piscina

**Melhores usos:** documental, editorial, conceito

**MidJourney:** `[tema], suburban aesthetic, scheduled sprinklers identical mailboxes cul-de-sac, the comfort contract --v 6`

**Prompt universal (Seedream):** `Shot on a Canon Sure Shot with Kodak Gold 200, a suburban afternoon, a sprinkler ticking across a perfect lawn in a cul-de-sac of identical mailboxes and beige facades, pool blue winking behind a fence, the quiet contract that nothing unexpected will ever happen here, warm consumer-film calm, 8k scan`

### **Uniformed**

**№ 927 / 1001** — *Discipline Made Readable at a Distance*

**Nível:** 🟤 Terciária

**Eixo:** COHERENCE ↑ → EXPRESSION ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Lógicas distintas são reorganizadas num sistema cuja continuidade atravessa as diferenças.

**Nota genealógica original (EN):** Military dress standardization, institutional and clerical vestment, and industrial ready-to-wear converge here, each supplying a load-bearing layer nothing else replaces, fixing Uniformed as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**A disciplina legível à distância** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Uniformizado: fileiras idênticas, vincos alinhados ao milímetro e a hierarquia inteira comunicada antes de qualquer palavra.

**Paleta de cores** azul-marinho de farda, dourado de botão, branco de luva

**Melhores usos:** editorial, conceito, histórico

**MidJourney:** `[tema], uniformed aesthetic, identical ranks millimeter-aligned creases, discipline readable at a distance --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F3 with 105mm lens, a uniformed formation, identical navy ranks compressed by the telephoto into one repeating geometry of millimeter-aligned creases and button gold, white gloves snapping to the same angle at the same instant, hierarchy communicated before any word is spoken, rigorous ordered precision, 8k scan`

## Leitura do padrão — o que as 19 estéticas confirmam

### O caso suprimido e a rima da Station

Deconstructivism (№ 213, COHERENCE ↓ → INTEGRITY ↓, XY — ruptura) é a arquitetura que discute consigo mesma: quando o nó se desata como identidade, o que cai junto é a primeira posição do sistema — a Integridade. E a rima interna da SCÈNE: Fragmented (SYNTHESIS ↓ → COHERENCE ↓) é a única entrada do corpus em que os dois abridores da Station caem juntos — a fusão que falha desamarra o nó no mesmo gesto.

### Onde o nó se desata fora desta lista

COHERENCE ↓ aparece 12 vezes como slot secundário nas 14 Ações — 4 sob EMANATION ↑ (Dream, Latinx, Omnireflect, Feminine Mystique), 3 sob SEMIOTICS ↑ (Post-Modernism, Magic, Memecore), 2 sob DENSITY ↑ (Maximalism, Overloaded), 2 sob NUANCE ↑ (Lo-fi, Magical Realism), 1 sob ESTHETICS ↑ (McBling). A leitura: o que mais frequentemente desamarra a lógica interna é a irradiação — a presença que reorganiza o ambiente tende a dissolver o programa; a citação que se multiplica vem logo atrás.

### Famílias recorrentes

→ ETERNITY ↑ reúne 3 (Enduring Modernism, Neoclassical Revival, Gaúcho) — a lógica que sobrevive ao tempo, o nó que as décadas não desatam; → EXPRESSION ↓ reúne 3 (Biedermeier, Copencore, Uniformed) — a lógica que rebaixa o gesto individual para manter o programa; → MATTER divide 2 (Amazonian Lowland ↑, Nomadism ↓ — a identidade coerente que carrega tudo ou abre mão de tudo); → INTENTIONALITY divide 2 (Designtopia ↑, Drifting ↓ — o programa que decide e a disciplina do movimento rendido).

### Polaridade e Primárias

11 XX contra 8 XY — o nó pende para a continuidade, como convém a quem transmite. E 7 Primárias em 19 (Suburban, Labyrinth, Casual, Amazonian Lowland, Nomadism, Equilibrium, Geometric) — mais de um terço da lista é fundadora, uma das maiores densidades de gramáticas-raiz do glossário: coerência é onde os sistemas que geram descendência moram.

### O teste operacional

puxe em qualquer ponto e o todo responde — e a tábua repete a terra do glifo por desenho: o Tibete aparece duas vezes e apenas duas, o Vajra abrindo a sequência com a decisão e o Nó amarrando-a com a continuidade. O corpus confirma o resto pelo avesso: o nó quase nunca se desata sozinho — ele é desatado por outra força em amplificação.

# EMANATION — a Placa Cimática

<aside>
◎

**Essência.** EMANATION mede a capacidade de irradiar presença para além dos sinais explícitos. Seu ideograma é a Placa Cimática — areia sobre uma superfície vibrante organiza-se numa geometria que nenhuma mão desenhou; quando o som cessa, o padrão ainda pode ser copiado, mas já está morto. No registro ↑, o cenário reorganiza-se visivelmente ao redor da figura; no registro ↓, a estética permanece selada na própria bainha.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para EMANATION, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem o tom-assinatura e os ecos ambientais próprios de cada estética, enquanto a arquitetura preserva a lei da Placa Cimática — presença testemunhada, nunca instalada por direção de arte.

> **↑ EMANATION — universal prompt.** A figure in [signature garment tone] standing in unforced settled stillness at the gravitational centre of an ordinary room with its own life, the garment's tone found again at three depths without a single prop placed as explanation — near in [small worn accent on another body], mid in [sheen of a used surface], far in [light passing beyond the glass] — each echo reading as coincidence turned agreement, skin reading as lit from within rather than lit at and a lip tone the room echoes rather than quotes, hair with live unarranged authority, a self-sufficient interior gaze that seeks no one, photographed at observational distance on a 50mm at f/2.8 as a witness rather than a director, warm ambient found sources converging on the figure with no visible dedicated key, the whole setting visibly reorganized around a presence that never asks for it.
> 

**Universal EMANATION ↓ negative line (always pair with the ↑ prompt):**

> No art-directed prop echoes, no styling coincidence that reads as installed, no dedicated beauty light, no posing, no gesture asking the camera for attention, no costume sealed at its own hem, no room that has not noticed, no explanation anywhere in the frame.
> 

**Como usar para as 84 estéticas da lista.** Escolha o tom-assinatura da estética e deixe a sala devolvê-lo em três profundidades, sem instalar nada. Baroque: o dourado da talha reencontrado no verniz do piso, no latão de uma maçaneta, na luz de vela além da porta — ornament staged until it becomes proof. Brazilian Carnival: trinta quilos de plumas movidos por um corpo — o eco é cinético: confete no asfalto molhado, purpurina alheia, um refletor que passa. Poolcore: o azul clorado devolvido no gelo do copo, no toldo, no reflexo que treme no teto — a melancolia do paraíso artificial irradiando de fora para dentro. Sedona: terracota respondida pela poeira no para-brisa e pelo último sol na rocha. Para Voidcore — a única supressão da lista — inverta para o registro ↓: o traje selado na própria bainha, a sala que não percebeu; o eco negado é o assunto.

## Fundamentos do elemento

### Identidade, vibração e reorganização do ambiente

**Identity.** Capacity to radiate presence beyond explicit signals. Its ideogram is sand on a vibrating plate: when the frequency is real, the grains organize themselves into geometry no hand arranged; when the sound stops, the pattern can be copied but it is dead. It is the table's declared exception — the one glyph whose form no hand draws: Vedic in its sound, proven on Chladni's plate of 1787, produced only by live vibration. In an image this element is proven when the setting visibly reorganizes around the figure, or when the aesthetic stays sealed at the garment's hem.

**The pattern no hand arranged.** Sand on the plate organizes itself; the moment an echo is installed, it dies. Production law: every repetition of the figure's tone must be findable in the room's own life — witnessed, not arranged. If any echo reads as art-directed, rebuild it from the identity's frequency or cut it: copied pattern is dead sand.

**The witness camera.** The camera converts nothing — it arrives after the room has already agreed. Observational distance, no rhetorical angle, no dedicated key: the frame discovers the reorganization, never constructs it. A prop placed as explanation is the confession that the vibration failed.

**The gate the whole codex ends on.** This action is the exact antipole of the Vale, and its test closes every prompt on this page, last, always: does each element trace to a live decision of this identity, or is something decorating from memory?

## Corpo — postura, gesto e olhar

**Model posture & structure.** Unforced settled stillness at the frame's gravitational centre — weight fully arrived, nothing performed toward the lens; the posture of a person the room has already agreed with.

**Gesture.** Almost none directed at the camera — at most a slow turn the light seems to follow; gestures the environment answers rather than gestures that ask.

**The look — how the eyes behave.** Interior and self-sufficient — not seeking the camera, not seeking anyone; the face of the source of the sound, never of its echo.

## Regras de imagem — da vibração à prova do eco

**Look & styling continuity.** One deep signature tone carried as the driving frequency; every beauty and wardrobe tone harmonized to it, so the room's echoes agree with the garment instead of quoting it.

**Camera.** 50mm at f/2.8 at observational distance, handheld steadiness, no rhetorical angle; framing that discovers the echoes at three depths rather than constructing them.

**Composition.** The figure as organizing node — the tone recurring near, mid, and far, each recurrence reading as coincidence turned agreement; the frame arranged by the figure, never around a prop.

**Lighting.** Ambient found sources that appear tuned to the figure — sconces, passing headlights, window spill — warm and convergent, with no visible dedicated key; light behaving as if it, too, has been converted.

**Beauty detail.** Skin reading as lit from within rather than lit at; hair with live unarranged authority; a lip tone the set echoes — nothing that looks placed for the picture.

**Cenography.** An ordinary room with its own life — a doorman, wet floor wax, traffic beyond the glass; nothing dressed, nothing explained; the echoes findable, not installed.

**Colour.** One deep signature register recurring at three depths against a neutral living ground — no colour border, no installed palette; the tone must be found, never laid.

**Vibration proof.** Plant one verifiable evidence that the room answered: the garment's tone found in a surface that could not have been styled — wet floor wax, a passing taillight — sharp enough to read as agreement, never as prop.

**Practitioner lines (from the codices).**

**Corinne Day** (Expression × Emanation; Despojar) — grunge stripped of jewelry, makeup, and pretense: the model's unrepeatable state in an unstyled flat — radiance with everything removable removed.

**Cass Bird** (Expression × Emanation; Encantar) — sets that feel like summer camps and road trips: laughter and camaraderie reorganizing the room with no direction visible.

**Giovanni Corabi** (Esthetics × Emanation; Vislumbrar) — poetic, fleeting campaigns between fine art and luxury; a transient elegance that converts the frame before anyone can arrange it.

**Rala Choi** (Illumination × Emanation; Vislumbrar) — medium-format figures turned away from the lens into saturated colour fields; the image glowing from within, a Rothko with a body in it.

**Lea Colombo** (Illumination × Emanation; Transmutar) — shoots light itself: refractions, crystals, and colour across skin; the studio a prism, the body its screen.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** The room converted: the garment's tone found again in floor wax, passing lights, a stranger's cravat; setting and light vibrating at the figure's frequency with no prop placed as explanation.

> **↑ Prompt.** A gown's oxblood tone found again in the corridor's floor wax, in the doorman's cravat, in the taillights through the window, one figure whose colour and bearing have visibly reorganized the whole room around them, light and setting vibrating at the garment's frequency without a single prop placed as explanation.
> 

> **↑ Negative line.** No art-directed echoes, no installed coincidences, no dedicated key light, no posing, no gesture asking the camera for attention, no fluorescent institutional evenness, no costume sealed at its own hem, no room that carries on unconverted.
> 

**↓ Suppressed — repertory.** Containment: a brilliant costume in a room that has not noticed, no bleed, no echo, the world around it entirely unconverted.

> **↓ Prompt.** An ornate, brilliant costume worn in a room that has not noticed, grey office carpet, filing cabinets, fluorescent ceiling panels, the aesthetic sealed at the garment's hem, no colour bleed, no echo, the world around it entirely unconverted.
> 

> **↓ Negative line.** No environmental echoes, no answering tones anywhere in the set, no warm converging ambient sources, no compositional privilege for the figure, no skin lit from within, no reorganized space, no witnesses reacting.
> 

## Estéticas relacionadas a EMANATION (A–Z)

As 84 estéticas classificadas sob EMANATION, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Almighty**

**№ 041 / 1001** — *Power that radiates, not roars*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Poder que irradia, não ruge** — (1001 Aesthetics, interpretação)

Divindade serena: figuras monumentais, luz que emana de dentro, ouro e silêncio sagrado.

**Paleta de cores** dourado radiante, branco, azul cósmico profundo

**Melhores usos:** espiritual, capas, arte sacra

**MidJourney:** `[tema], divine radiant majesty, sacred golden light --v 6`

**Prompt universal (Seedream):** `Monumental sacred image shot on medium format with 50mm lens, a divine figure radiating serene golden light against a deep blue cosmos, glowing halo and floating gilded particles, volumetric god rays, Renaissance-meets-cosmic composition, quiet overwhelming power, ultra-detailed fine art quality, 8k`

### **Astrological**

**№ 068 / 1001** — *Sky read like a ledger*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Observational sky-charting, symbolic glyph systems, and esoteric print illustration braid into one visual grammar; remove the charting and the glyphs float free of any structure, remove the glyphs and only astronomy remains — recombination, not revision.

**Atmosfera e mood**

**Céu lido como um livro-caixa** — (1001 Aesthetics, interpretação)

Astrologia visual: cartas celestes, roda do zodíaco, ouro sobre azul-noite.

**Paleta de cores** azul-noite, dourado, prata

**Melhores usos:** espiritual, ilustração, branding místico

**MidJourney:** `[tema], astrological celestial chart, zodiac gold on navy --v 6`

**Prompt universal (Seedream):** `Ornate celestial artwork captured in ultra-high resolution, a zodiac wheel and constellation charts inked in gold on midnight blue, hand-gilded stars and planetary sigils, aged vellum texture with a candlelit glow, mystical astronomy ledger detail, esoteric atlas plate reproduction, 8k`

### **Atmospheric**

**№ 072 / 1001** — *Mist thinning across plaster*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → NUANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** A single inherited lineage of tonal landscape painting is kept whole and shifted in emphasis — air and light are promoted over subject — so the change is one of priority within a tradition rather than a new root or a fusion.

**Atmosfera e mood**

**Névoa afinando sobre o reboco** — (1001 Aesthetics, interpretação)

Atmosfera acima do objeto: névoa, luz difusa, silêncio visual contemplativo.

**Paleta de cores** cinzas quentes, brancos, tons apagados

**Melhores usos:** fine art, cenários, meditativo

**MidJourney:** `[tema], atmospheric mist, quiet tonal painting --v 6`

**Prompt universal (Seedream):** `Contemplative photograph shot on medium format with 80mm lens, thin mist hanging over aged plaster walls, diffused pale light with no hard shadows, muted warm grays and off-whites, more air than object, meditative negative space, Michael Kenna quietness in soft color, 8k tonal subtlety`

### **Baroque**

**№ 080 / 1001** — *Ornament staged until it becomes proof*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** The governing principle — that overwhelming the senses is itself the argument — arrives as a root demand rather than as an inheritance, and every device serves it, so removing the staging of excess collapses the whole rather than a single line.

**Atmosfera e mood**

**Ornamento encenado até virar prova** — (1001 Aesthetics, interpretação)

Barroco: drama teatral, dourado, claro-escuro de Caravaggio, excesso como argumento.

**Paleta de cores** dourado, bordô, sombras profundas

**Melhores usos:** retratos dramáticos, cenários, luxo

**MidJourney:** `[tema], baroque painting, dramatic chiaroscuro --v 6`

**Prompt universal (Seedream):** `Shot on Phase One 150MP with 80mm lens, a baroque-inspired haute couture portrait lit by single-candle chiaroscuro, model draped in swirling crimson velvet and gilded brocade, pearls glinting in deep shadow, Caravaggio tenebrism meets modern Vogue Italia editorial, oil-painting richness, ultra-detailed fabric texture, museum-dark grading, 8k`

### **Biomorphic**

**№ 094 / 1001** — *Curve coral grows without knowing why*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** One abstract-form lineage is kept and re-grounded in organic growth — the same vocabulary of shape persists while its justification shifts from geometry to biology, a reinterpretation within a single line rather than a hybrid.

**Atmosfera e mood**

**Curva que o coral cresce sem saber por quê** — (1001 Aesthetics, interpretação)

Biomorfismo: formas orgânicas abstratas de células e corais (Arp, Miró).

**Paleta de cores** suaves naturais ou vivas chapadas

**Melhores usos:** design, escultura, padrões

**MidJourney:** `[tema], biomorphic organic abstract forms --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a biomorphic sculptural composition, soft organic curves like coral cells and river stones in matte ivory and terracotta, flowing amoeba silhouettes influenced by Arp and Miró, gentle raking gallery light revealing velvety surface grain, natural asymmetric harmony, minimalist pedestal staging, 8k fine-art clarity`

### **Brazilian Carnival**

**№ 120 / 1001** — *Thirty kilos of feathers moved by one body*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** Nothing earlier produces this — the demand that one body carry and move an impossible mass of ornament is a founding law of the form itself, and removing that load-bearing body dissolves the system rather than pruning a branch.

**Atmosfera e mood**

**Trinta quilos de plumas movidos por um corpo** — (1001 Aesthetics, interpretação)

Carnaval: plumas gigantes, lantejoulas, carros alegóricos e o sambódromo aceso na madrugada.

**Paleta de cores** plumas vibrantes, dourado, brilho de lantejoula

**Melhores usos:** festa, cultura, campanhas

**MidJourney:** `[tema], Rio Carnival parade, feathers and sequins --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 with 70-200mm f/2.8, a Rio Carnival dancer mid-spin in a massive feather headdress and crystal-sequined costume, sambadrome float lights exploding into bokeh behind, glitter and sweat catching strobe flash, motion-frozen feathers in electric magenta and gold, explosive night energy, editorial sharpness, 8k`

### **Byzantine**

**№ 136 / 1001** — *Covenant held in dome, icon, and gold tesserae*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** No prior style can be named as its maker — dome, icon and gold ground are generated at the root by a theology of divine presence, and each bears load, so removing any one collapses the whole system rather than a branch of it.

**Atmosfera e mood**

**Pacto guardado em cúpula, ícone e tessela de ouro** — (1001 Aesthetics; código: MidLibrary)

Arte bizantina: fundos de mosaico dourado, figuras frontais alongadas com auréolas, devoção solene que cintila.

**Paleta de cores** ouro de tessela, azul profundo, carmim

**Melhores usos:** arte sacra, simbolismo, ilustração histórica

**MidJourney:** `--sref 3704504360 --sw 1000` (Byzantine Mosaic Collision) — alternativa por nome: `[tema], Byzantine icon style --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a Byzantine apse mosaic, shimmering gold tesserae background around frontal elongated sacred figures with jeweled halos, deep lapis and crimson robes rendered in tiny glass fragments, candlelight flickering across the dome's curvature, Ravenna solemnity, each tessera in razor focus, 8k archival documentation`

### **Colonial**

**№ 167 / 1001** — *Azulejo, stone, and the long reach of empire*

**Nível:** ⚫ Quaternária

**Eixo:** EMANATIO ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Metropolitan building convention, local material and labour, and imported ornament traditions fuse generations downstream; strip the local craft and the azulejo loses its hand, strip the imperial line and the plan disappears — hybridization, not single-parent revision.

**Atmosfera e mood**

**Azulejo, pedra e o longo alcance do império** — (1001 Aesthetics, interpretação)

Colonial: casarões caiados com janelas coloridas, azulejaria portuguesa, pedra de calçamento e igreja barroca.

**Paleta de cores** branco de cal, azul de azulejo, ocres coloniais

**Melhores usos:** arquitetura, cultura, turismo

**MidJourney:** `[tema], Portuguese colonial architecture, azulejo tiles --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm f/2.8, a colonial town scene at golden hour, whitewashed mansions with cobalt and mustard window frames, Portuguese azulejo tiles and cobblestone streets climbing to a baroque church tower, layered imperial history in warm raking light, Ouro Preto atmosphere, rich architectural detail, 8k`

### **Communism**

**№ 169 / 1001** — *Argument that refuses adaptation*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → THEME ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Revolutionary graphics, monumental figuration, and state propaganda apparatus converge; strip the avant-garde graphics and the poster loses its force, strip the state machinery and the argument never reaches scale — several lineages welded into one.

**Atmosfera e mood**

**O argumento que recusa adaptação** — (1001 Aesthetics, interpretação)

Realismo socialista: trabalhadores heróicos em pôster, punho e foice, tipografia de propaganda em vermelho e preto.

**Paleta de cores** vermelho, preto, creme de papel envelhecido

**Melhores usos:** pôsteres, sátira, história

**MidJourney:** `[tema], soviet socialist realism propaganda poster --v 6`

**LoRA (Civitai):** "Soviet Propaganda" (SD 1.5) — civitai.com/models/71635; "Soviet-poster XL" (SDXL) — civitai.com/models/183892

**Prompt universal (Seedream):** `High-resolution scan of a Soviet propaganda poster, heroic workers gazing toward the horizon in bold red and black on aged cream paper, constructivist diagonal typography and coarse lithograph grain, unyielding ideological argument, misregistered ink and fold creases, 1930s state-print urgency, 8k archival quality`

### **COSMIC**

**№ 177 / 1001** — *Nine parts darkness to one part light*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Astronomical imaging, mystical symbolism, and science-fiction illustration converge; remove the observational lineage and the darkness loses its accuracy, remove the mystical strand and the scale loses its meaning — recombination across several lines.

**Atmosfera e mood**

**Nove partes de escuridão para uma de luz** — (1001 Aesthetics, interpretação)

Cósmico: nebulosas e campos de estrelas, escala esmagadora, poeira estelar em véus luminosos.

**Paleta de cores** preto profundo, violeta e azul de nebulosa, pontos de luz

**Melhores usos:** sci-fi, espiritual, capas

**MidJourney:** `[tema], cosmic deep space, nebula and starfield --v 6`

**Prompt universal (Seedream):** `Ultra-detailed space vista at 8k, cosmic nebula veils and dense starfields in overwhelming scale, nine parts darkness to one part light, violet and blue stardust pillars against the void, James Webb telescope clarity with cinematic depth, volumetric star glow, awe-inducing archival precision`

### **Cyberdelic**

**№ 188 / 1001** — *Vision quest run on hardware*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Busca visionária rodando em hardware** — (1001 Aesthetics, interpretação)

Cyberdelia: fractais psicodélicos digitais, túnel de realidade virtual, cores ácidas em fluxo de dados.

**Paleta de cores** arco-íris ácido digital, magenta, ciano

**Melhores usos:** música eletrônica, visuais, capas

**MidJourney:** `[tema], cyberdelic psychedelic digital fractals, VR trip --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a cyberdelic vision, psychedelic fractals flowing through a virtual-reality tunnel, acid-rainbow data streams in magenta and cyan spiraling toward an event horizon, consciousness expansion rendered on hardware, Alex Grey meets TRON, volumetric neon glow, razor-sharp infinite recursion`

### **Dazecore**

**№ 206 / 1001** — *Second look fails too*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**O segundo olhar também falha** — (1001 Aesthetics, interpretação)

Torpor onírico: desfoque suave, halos de luz, realidade meio dissolvida como memória de sonho.

**Paleta de cores** pastel dessaturado, brancos estourados, halos

**Melhores usos:** artístico, música, editorial

**MidJourney:** `[tema], dazecore, soft blur and dream haze --v 6`

**Prompt universal (Seedream):** `Shot on expired 35mm film with 50mm lens, a dazecore image, softly blurred figures and glowing light halos, half-dissolved dreamlike reality in desaturated pastels and overexposed whites, lens bloom swallowing the edges, the second look failing too, hazy analog grain, poetic drift`

### **Democratic**

**№ 218 / 1001** — *Ramp, the Plaza Stone, and the Open Source File*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**A rampa, a pedra da praça e o arquivo de código aberto** — (1001 Aesthetics, interpretação)

Design democrático: espaços públicos acessíveis, mobiliário para todos, praça aberta e design sem barreiras.

**Paleta de cores** concreto claro, madeira pública, sinalização primal

**Melhores usos:** urbanismo, design social, editorial

**MidJourney:** `[tema], democratic design, accessible public plaza --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm f/2.8, a democratic design scene, accessible public plaza with ramps and shared benches, open-source simplicity built for everyone, pale concrete and communal wood under even daylight, dignity without exclusivity, clean documentary clarity, 8k`

### **Disco**

**№ 229 / 1001** — *Cathedral Built from Mirror Ball, Bass Bin, and 120 BPM*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Catedral de globo espelhado, caixa de grave e 120 BPM** — (1001 Aesthetics; código: match aproximado)

Disco: pista iluminada em quadrados, globo espelhado espalhando estrelas, cetim, brilho e 1977 eterno.

**Paleta de cores** dourado, roxo e rosa de pista, prata espelhada

**Melhores usos:** música, festas, editorial retrô

**MidJourney:** `--sref 561264478 --sw 1000` (catalogado como 1970s style — match aproximado)

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 32mm lens, a 1977 disco scene, mirror ball scattering stars over a lit dance floor, satin and sequins flashing under purple pink and gold lights, haze catching every beam, nightclub cathedral pulsing at 120 BPM, Saturday Night Fever grading, 8k production still`

### **Disruptive**

**№ 231 / 1001** — *Covenant of Calculated Rupture and Forced Replacement*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Atmosfera e mood**

**Ruptura calculada e substituição forçada** — (1001 Aesthetics, interpretação)

Disruptivo: o novo atravessando o antigo — formas que quebram a grade de propósito, tensão entre sistemas.

**Paleta de cores** contraste máximo, acento elétrico invasor

**Melhores usos:** branding, tech, editorial

**MidJourney:** `[tema], disruptive design, new form breaking through the old grid --v 6`

**Prompt universal (Seedream):** `Ultra-crisp graphic composition at 8k, a disruptive design piece, one new electric form deliberately breaking through an established monochrome grid, calculated rupture and forced replacement, maximum contrast between old order and invading neon accent, flawless flat rendering, poster-grade impact`

### **Dominance**

**№ 238 / 1001** — *Marble outlasts the body that walked it*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**O mármore sobrevive ao corpo que o pisou** — (1001 Aesthetics, interpretação)

Dominância: escadarias monumentais, colunas que diminuem o humano, poder gravado em pedra.

**Paleta de cores** mármore branco, sombra dura, dourado imperial

**Melhores usos:** arquitetura, poder, editorial

**MidJourney:** `[tema], monumental marble architecture dwarfing the human figure --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm lens, a monumental scene of dominance, vast marble staircases and columns dwarfing a lone human figure, imperial gold accents and hard raking shadow, power carved to outlast the body, cinematic scale with architectural precision, 8k`

### **Dream**

**№ 243 / 1001** — *Nothing is permitted to resolve*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Nada tem permissão de se resolver** — (1001 Aesthetics; código: Kinomoto, match aproximado)

Sonho: lógica flutuante, objetos deslocados em névoa pastel, transições que nunca se explicam.

**Paleta de cores** pastel de névoa, lilás, luz difusa

**Melhores usos:** arte, espiritual, capas

**MidJourney:** `--sref 3943333032 --sw 1000` (New Dreamlike Pastel Color — match aproximado)

**LoRA (Civitai):** "Dreamcore PRO" (Flux/Krea) — civitai.com/models/1986271

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens through soft diffusion, dream imagery, floating dream logic with displaced objects in pastel mist, diffuse sourceless light and transitions that never explain themselves, nothing permitted to resolve, ethereal grain and glow, fine-art surrealism, 8k`

### **Elemental Air**

**№ 274 / 1001** — *Incense Thread That Breaks the Line*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → MATTER ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**O fio de incenso que quebra a linha** — (1001 Aesthetics, interpretação)

Ar: fumaça de incenso desenhando no vácuo, tecidos ao vento, leveza visível e respirável.

**Paleta de cores** branco, azul-céu pálido, translúcidos

**Melhores usos:** espiritual, abstrato, editorial

**MidJourney:** `[tema], elemental air, incense smoke threads and wind-blown fabric --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, an elemental air study, incense smoke thread breaking its own line in a still shaft of light, translucent fabric lifted by wind, pale sky blues and whites, weightlessness made visible, high-speed capture of drifting form, 8k`

### **Enchantment**

**№ 284 / 1001** — *Gold Leaf That Catches a Breath*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**Folha de ouro que captura um sopro** — (1001 Aesthetics, interpretação)

Encantamento: brilho dourado suspenso no ar, magia delicada e silenciosa, o maravilhoso em escala íntima.

**Paleta de cores** ouro em folha, âmbar, penumbra quente

**Melhores usos:** fantasia, poético, editorial

**MidJourney:** `[tema], enchantment, gold leaf catching the light in warm dusk, delicate quiet magic --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 50mm lens at f/1.4, an enchantment scene, gold leaf suspended in the air catching a breath, delicate silent magic in warm dusk, amber glow and floating bokeh, wonder at intimate scale, fairy-tale cinematography, 8k still`

### **Enthralling**

**№ 291 / 1001** — *Harmonica Hums Before the Room Speaks*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**A harmônica soa antes de a sala falar** — (1001 Aesthetics, interpretação)

Cativante: plateia suspensa, um ponto de luz no palco, atenção total capturada num instante.

**Paleta de cores** escuro de plateia, dourado de holofote

**Melhores usos:** performance, narrativa, dramático

**MidJourney:** `[tema], enthralling stage moment, suspended audience, single spotlight --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 85mm lens, an enthralling performance, a harmonica humming before the room dares to speak, audience faces suspended in darkness under one golden spotlight, dust motes in the beam, total captured attention, cinematic concert still, 8k`

### **Ephemeral**

**№ 295 / 1001** — *Mandala Swept Into the River*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → ETERNITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**A mandala varrida para o rio** — (1001 Aesthetics, interpretação)

Efêmero: areia colorida, pétala e neblina, beleza feita para durar um instante e ser entregue.

**Paleta de cores** pós coloridos, pétalas, névoa

**Melhores usos:** espiritual, poético, arte

**MidJourney:** `[tema], ephemeral beauty, sand mandala being swept away, petals and mist --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 7 with 80mm lens, an ephemeral scene, colored sand mandala being swept into the river, petals and mist drifting through morning light, beauty made to last one instant and be surrendered, luminous impermanence, contemplative cinematic grading, 8k`

### **Expansive**

**№ 312 / 1001** — *Horizon Pushed Past the Frame's Edge*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**O horizonte empurrado para além da borda do quadro** — (1001 Aesthetics, interpretação)

Expansivo: panorama que não cabe, céu dominante e terra infinita, amplidão como sentimento.

**Paleta de cores** azuis de distância, dourado de horizonte

**Melhores usos:** paisagem, cinematográfico, contemplativo

**MidJourney:** `[tema], expansive panorama, horizon pushed past the frame edge, dominant sky --v 6`

**Prompt universal (Seedream):** `Shot on a Hasselblad XPan panoramic with 45mm lens, an expansive panorama, horizon pushed past the frame's edge, dominant sky over infinite land at golden hour, distance blues and horizon gold in perfect atmospheric gradient, vastness as feeling, Ansel Adams clarity, 8k`

### **Extravagance**

**№ 314 / 1001** — *Gilding Applied Until the Surface Disappears*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**Douramento aplicado até a superfície desaparecer** — (1001 Aesthetics, interpretação)

Extravagância: excesso como declaração, ouro sobre ouro, luxo que não conhece freio.

**Paleta de cores** ouro total, cristal, veludo profundo

**Melhores usos:** luxo, editorial, dramático

**MidJourney:** `[tema], extravagance, gold upon gold, gilding until the surface disappears --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 50mm lens, an extravagant interior, gilding applied until the surface disappears, gold on gold with crystal chandeliers and deep velvet under warm candela light, excess as declaration, luxury without restraint, opulent editorial grading, 8k`

### **FEMININE MYSTIQUE**

**№ 326 / 1001** — *Polished Surface That Cannot Hold*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Atmosfera e mood**

**A superfície polida que não consegue se sustentar** — (1001 Aesthetics, interpretação)

Mística feminina: perfeição doméstica dos anos 1950 com fissura visível, sorriso de anúncio e tensão por baixo.

**Paleta de cores** pastel de anúncio, batom vermelho, luz de estúdio fria

**Melhores usos:** conceitual, editorial, crítica visual

**MidJourney:** `[tema], 1950s domestic perfection with a visible crack, advertising smile and unease beneath --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Ektachrome with 50mm lens, a feminine mystique scene, 1950s advertising-perfect housewife tableau with one visible crack in the polished surface, pastel kitchen and red lipstick under cold studio light, Douglas Sirk melodrama beneath the smile, saturated vintage-ad grading, 8k`

### **FIZZYCORE**

**№ 332 / 1001** — *Soda-Pop Bubbles in Candy-Bright Y2K Color*

**Nível:** ⚫ Quaternária

**Eixo:** EMANATIO ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Bolhas de refrigerante em cor doce e brilhante de Y2K** — (1001 Aesthetics, interpretação)

Efervescente: bolhas e plástico translúcido, cores de bala dos anos 2000, alegria gaseificada.

**Paleta de cores** rosa chiclete, azul de refrigerante, translúcidos brilhantes

**Melhores usos:** branding jovem, editorial pop, produto

**MidJourney:** `[tema], fizzycore, soda-pop bubbles in candy-bright Y2K colors, translucent plastic shine --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 105mm macro lens, a fizzycore image, soda-pop bubbles rising through candy-bright Y2K color, bubblegum pink and soda blue with glossy translucent plastic, condensation droplets sharp against studio light, carbonated joy, 8k product clarity`

### **Flowy**

**№ 339 / 1001** — *Bias-Cut Chiffon That Never Holds a Crease*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**Chiffon em corte enviesado que nunca guarda um vinco** — (1001 Aesthetics, interpretação)

Fluido: tecido em movimento perpétuo, drapeado que responde ao ar, corpo e pano em dança contínua.

**Paleta de cores** tons suaves, translúcidos, luz que atravessa tecido

**Melhores usos:** moda, dança, editorial

**MidJourney:** `[tema], flowy bias-cut chiffon in perpetual motion, fabric responding to air --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.2, a flowy fashion image, bias-cut chiffon that never holds a crease, drape in perpetual motion responding to air, soft translucent tones with light passing through fabric, Nick Knight wind-machine movement, 8k`

### **Fractalism**

**№ 345 / 1001** — *Mandelbrot Set Repeating at Every Zoom*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**O conjunto de Mandelbrot repetindo em cada zoom** — (1001 Aesthetics, interpretação)

Fractal: autossimilaridade infinita, espirais dentro de espirais, matemática visível como ornamento cósmico.

**Paleta de cores** gradientes espectrais profundos, luz eletrônica

**Melhores usos:** arte digital, abstrato, psicodélico

**MidJourney:** `[tema], fractal art, Mandelbrot set self-similarity repeating at every zoom --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a fractalism artwork, Mandelbrot-like self-similar spirals within spirals repeating at every zoom, deep spectral gradients and electronic light, mathematics visible as cosmic ornament, hypnotic infinite recursion`

### **Gen Alpha**

**№ 368 / 1001** — *Solar Cell Beside the Voice Assistant*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**A célula solar ao lado do assistente de voz** — (1001 Aesthetics, interpretação)

Geração Alpha: infância nativa de tela e sustentabilidade, tablet e horta escolar, futuro doméstico já instalado.

**Paleta de cores** cores de app arredondado, verde solar, branco de dispositivo

**Melhores usos:** tech, educação, editorial

**MidJourney:** `[tema], Gen Alpha childhood, solar cell beside the voice assistant, native digital sustainability --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm lens, a Gen Alpha scene, a solar cell beside the voice assistant in a rounded-app-colored playroom, tablet and school garden, device white and solar green, bright even daylight, the future already installed at home, 8k`

### **Generative Art**

**№ 372 / 1001** — *Eighteen Lines of Code, One Mandelbrot Universe*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**Dezoito linhas de código, um universo de Mandelbrot** — (1001 Aesthetics, interpretação)

Arte generativa: algoritmo como pincel, regra simples gerando complexidade infinita, beleza emergente de sistemas.

**Paleta de cores** gradientes matemáticos, cores paramétricas

**Melhores usos:** arte digital, capas tech, identidades dinâmicas

**MidJourney:** `[tema], generative algorithmic art, emergent complexity from simple code rules, plotter and particle systems --v 6`

**Prompt universal (Seedream):** `Ultra-crisp algorithmic composition, a generative art piece, emergent complexity from a few lines of code, particle flows and parametric gradients in the lineage of Vera Molnár and Casey Reas, mathematical beauty born from simple rules, 8k`

### **Gothic I Medieval Gothic**

**№ 389 / 1001** — *Chartres Blue Through a Flying Buttress*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Atmosfera e mood**

**O azul de Chartres através de um arcobotante** — (1001 Aesthetics; código: sref-midjourney.com, match aproximado)

Gótico medieval: catedral apontando para cima, vitral azul e pedra nervurada, luz divina projetada no chão.

**Paleta de cores** azul de vitral, pedra cinzenta, dourado de vela

**Melhores usos:** arquitetura, histórico, sacro

**MidJourney:** `--sref 603402874 --sw 1000` (Mystical Fortress at Sea — match aproximado)

**Prompt universal (Seedream):** `Shot on Arca-Swiss 4x5 view camera with 90mm lens, a medieval gothic scene, Chartres blue stained glass seen through a flying buttress, ribbed stone vaults pointing upward, divine light cast on the cathedral floor, candle gold on grey stone, 8k`

### **Heavenly**

**№ 424 / 1001** — *Gold Smalti Turns the Hagia Sophia Dome Into Light*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**O smalti dourado transforma a cúpula de Hagia Sophia em luz** — (1001 Aesthetics, interpretação)

Celestial: mosaico bizantino de ouro, cúpula que dissolve em brilho, o sagrado construído com milhões de tesselas.

**Paleta de cores** ouro de mosaico, azul bizantino, luz de cúpula

**Melhores usos:** sacro, arte, editorial espiritual

**MidJourney:** `[tema], heavenly Byzantine gold mosaic, Hagia Sophia dome dissolving into light, golden smalti tesserae --v 6`

**Prompt universal (Seedream):** `Shot on Phase One IQ4 with 35mm lens, a heavenly image, gold smalti mosaic turning a Byzantine dome into pure light, millions of tesserae dissolving architecture into glow, sacred gold with deep blue accents, 8k`

### **Infrared**

**№ 470 / 1001** — *Chlorophyll Turns White Beyond the Visible Spectrum*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**A clorofila fica branca além do espectro visível** — (1001 Aesthetics, interpretação)

Infravermelho: fotografia IR onde folhas viram neve, céu escurece e o mundo revela sua outra frequência.

**Paleta de cores** branco de folhagem IR, céu quase negro, rosa de Aerochrome

**Melhores usos:** fotografia experimental, paisagem, editorial

**MidJourney:** `[tema], infrared photography, chlorophyll turned white beyond the visible spectrum, dark sky and snow-white foliage --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Aerochrome infrared film with 50mm lens, an infrared photograph, chlorophyll turning white beyond the visible spectrum, snow-white foliage under a near-black sky, Richard Mosse infrared surrealism, the world at its other frequency, 8k`

### **It Aesthetic**

**№ 480 / 1001** — *Clara Bow's 1927 Close-Up Names the Unnameable*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**O close de Clara Bow em 1927 nomeia o inominável** — (1001 Aesthetics, interpretação)

It: carisma de cinema mudo, olhar que atravessa a lente, o magnetismo que não se explica, só se reconhece.

**Paleta de cores** prata de nitrato, preto de cinema mudo, brilho de estúdio

**Melhores usos:** retrato, editorial vintage, moda

**MidJourney:** `[tema], 1927 silent film it-girl close-up, nitrate silver glamour, magnetic gaze through the lens --v 6`

**Prompt universal (Seedream):** `Vintage nitrate film still, an it aesthetic image, a 1927 silent-film close-up naming the unnameable, nitrate silver and studio glow, Clara Bow-era magnetism, a magnetic gaze that cannot be explained only recognized, 8k`

### **Italian Baroque**

**№ 481 / 1001** — *Bernini's Ecstasy Turns Marble Into Breath*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → EXPRESSION ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**O êxtase de Bernini transforma mármore em respiração** — (1001 Aesthetics, interpretação)

Barroco italiano: drama esculpido, dobra de tecido em pedra, luz teatral caindo sobre o momento de arrebatamento.

**Paleta de cores** mármore quente, dourado de igreja, sombra de capela, raio de luz

**Melhores usos:** arte, sacro, editorial dramático

**MidJourney:** `[tema], Italian Baroque, Bernini ecstasy marble turned into breath, theatrical chapel light, dramatic drapery --v 6`

**LoRA (Civitai):** "Rubens Baroque" — civitai.com/models/1564271

**Prompt universal (Seedream):** `Shot on Canon EOS R3 with 50mm lens, an Italian Baroque image, marble turned into breath at the moment of ecstasy like Bernini's Saint Teresa, theatrical Caravaggio light falling through a dark chapel, stone drapery folding like fabric, church gold in shadow, 8k`

### **Japanese (Kawaii)**

**№ 488 / 1001** — *Hello Kitty's Missing Mouth Holds the Pastel Field*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**A boca ausente da Hello Kitty sustenta o campo pastel** — (1001 Aesthetics; código: kajimelo, confirmado)

Kawaii: fofura gráfica máxima, mascote de traço simples em mar de pastel, a simplicidade como afeto.

**Paleta de cores** rosa bebê, lilás, amarelo pastel, branco de mascote

**Melhores usos:** infantil, branding fofo, ilustração

**MidJourney:** `--sref 674875765 --sw 1000` (Kawaii Digital Mascot & Flat Cartoon); alternativa: `--sref 3065572110` (Cute Pastel Anime)

**Prompt universal (Seedream):** `Ultra-clean flat vector illustration, a Japanese kawaii image, a simple-lined mascot with a missing mouth holding the pastel field, baby pink and lilac flat cartoon cuteness, Sanrio character design minimalism, simplicity as affection, 8k`

### **Japanese (Nature & Fantasy)**

**№ 489 / 1001** — *Miyazaki's Kodama Blink Inside the Cedar Forest*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**Os kodama de Miyazaki piscam dentro da floresta de cedros** — (1001 Aesthetics, interpretação)

Japonês natureza e fantasia: floresta animada de Ghibli, espíritos entre musgos e luz filtrada, o encantado dentro do natural.

**Paleta de cores** verde de cedro, luz de sub-bosque, branco de espírito, azul de riacho

**Melhores usos:** animação, fantasia, editorial

**MidJourney:** `[tema], Ghibli-inspired Japanese nature fantasy, kodama spirits blinking inside the cedar forest, filtered light --v 6`

**Prompt universal (Seedream):** `Ultra-detailed anime background art, a Japanese nature fantasy image, forest spirits blinking inside a cedar forest, Studio Ghibli filtered light through moss and canopy, Kazuo Oga hand-painted foliage, the enchanted living inside the natural, 8k`

### **Jetsetter**

**№ 492 / 1001** — *Pan Am's Blue Globe Turns the Passport Into Status*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**O globo azul da Pan Am transforma o passaporte em status** — (1001 Aesthetics, interpretação)

Jetsetter: era dourada da aviação, mala rígida e óculos escuros na escada do jato, viajar como assinatura de classe.

**Paleta de cores** azul Pan Am, branco de fuselagem, caramelo de couro, dourado de sol

**Melhores usos:** viagem, branding premium, editorial retrô

**MidJourney:** `[tema], 1960s jetsetter aesthetic, Pan Am blue globe era, hard-shell luggage on the jet stairway --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex 3.5F with 75mm lens, a jetsetter image, the Pan Am blue globe turning the passport into status, hard-shell luggage and sunglasses on the jet stairway, Slim Aarons leisure-class sheen, golden age of aviation in caramel leather and fuselage white, 8k`

### **Jubilant**

**№ 497 / 1001** — *Victory Parade Throws Gold Confetti Into the Street*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**O desfile da vitória joga confete dourado na rua** — (1001 Aesthetics, interpretação)

Jubiloso: celebração em escala de cidade, confete no ar e braços erguidos, a alegria coletiva no seu pico.

**Paleta de cores** dourado de confete, azul de céu aberto, cores de bandeirola

**Melhores usos:** celebração, campanha, editorial

**MidJourney:** `[tema], jubilant aesthetic, victory parade throwing gold confetti into the street, raised arms and city-scale joy --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F5 with 24mm lens, a jubilant image, a victory parade throwing gold confetti into the street, raised arms under open blue sky, Alfred Eisenstaedt V-J Day energy, collective joy at its peak with banner colors everywhere, 8k`

### **Kaleidoscopic**

**№ 499 / 1001** — *Brewster's Mirrors Multiply One Shard Into a Field*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**Os espelhos de Brewster multiplicam um caco em um campo** — (1001 Aesthetics; código: sref-midjourney.com, categoria Psychedelic, match aproximado)

Caleidoscópico: simetria radial infinita, fragmento espelhado em mandala, a cor girando em padrão vivo.

**Paleta de cores** fragmentos multicoloridos, simetria de vitral, espelho

**Melhores usos:** padrão, editorial psicodélico, arte

**MidJourney:** `--sref 2421650338 --sw 1000` (categoria Psychedelic — match aproximado)

**Prompt universal (Seedream):** `Ultra-vivid prism-lens macro photograph, a kaleidoscopic image, mirrors multiplying one shard into a whole field, infinite radial symmetry like a living mandala, multicolored fragments turning in stained-glass pattern, 8k`

### **Latinx**

**№ 518 / 1001** — *Folklórico braid in motion*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Trança folklórica em movimento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Latinx: herança dançada no presente, saia de folklórico girando, fitas de calêndula e cobalto.

**Paleta de cores** laranja de calêndula, cobalto, festa em movimento

**Melhores usos:** cultura, editorial, dança

**MidJourney:** `[tema], Latinx aesthetic, folklorico braid and skirt mid-spin, marigold and cobalt ribbons, stage light --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z6 III with 85mm lens, a Latinx image, a folklorico braid and skirt caught mid-spin under stage light, marigold and cobalt ribbons in motion, Graciela Iturbide depth of gaze, heritage danced into the present, 8k`

### **Ludofuturism**

**№ 537 / 1001** — *HUD glow and neon controller logic*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Brilho de HUD e lógica neon de controle** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ludofuturismo: a vida renderizada como fase jogável, camadas de interface ciano sobre a rua real.

**Paleta de cores** ciano de interface, neon, noite urbana

**Melhores usos:** games, UI conceitual, editorial tech

**MidJourney:** `[tema], ludofuturism aesthetic, HUD glow and neon controller logic over the real street --v 6`

**Prompt universal (Seedream):** `Ultra-crisp digital game concept art, a ludofuturism image, HUD glow and neon controller logic wrapped around a real rain-slick street, cyan interface layers and floating quest markers over night architecture, Syd Mead surfaces gamified with arcade magenta accents, a pedestrian pausing exactly where the tutorial arrow points, life rendered as a playable level, 8k`

### **Majestic**

**№ 546 / 1001** — *Versailles ceilings and gold leaf scale*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Atmosfera e mood**

**Tetos de Versalhes e escala de folha de ouro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Majestoso: a grandeza como argumento de Estado, céus de afresco sobre luz de lustre.

**Paleta de cores** folha de ouro, afresco, cristal de lustre

**Melhores usos:** arquitetura, editorial de luxo, histórico

**MidJourney:** `[tema], majestic aesthetic, Versailles ceilings and gold leaf at overwhelming scale, chandelier light --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z7 II with 14mm lens, a majestic image, Versailles ceiling frescoes and gold leaf carrying scale far beyond the human, painted skies swimming above crystal chandelier light, Charles Le Brun ceiling theatre in full voice, marble pilasters marching toward the Hall of Mirrors, grandeur deployed as an argument of state, 8k`

### **Napoleonic (1799–1815)**

**№ 590 / 1001** — *Empire Tailored to the Inch*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**Império alfaiatado ao milímetro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Estilo Império: águias douradas, veludo carmesim e a coroação encenada como propaganda.

**Paleta de cores** carmesim imperial, dourado de abelha, verde Empire

**Melhores usos:** histórico, luxo, cenografia

**MidJourney:** `[tema], Napoleonic Empire aesthetic, gilded eagles crimson velvet, coronation grandeur --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Napoleonic Empire painting, coronation grandeur staged as propaganda, crimson velvet and golden bees under candelabra light, Jacques-Louis David precision tailored to the inch, imperial eagles and laurel, 8k archival detail`

### **New Age**

**№ 617 / 1001** — *Quartz, Aura, and Consumer Transcendence*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Quartzo, aura e transcendência de consumo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

New age: cristais na vitrine, gradientes de aura e o infinito vendido em incenso e pôster de golfinho.

**Paleta de cores** lilás de aura, turquesa, arco-íris difuso

**Melhores usos:** editorial, nostalgia, conceito

**MidJourney:** `[tema], new age aesthetic, quartz crystals aura gradients, 1990 bookstore transcendence --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm Provia 100F with 50mm lens, a new age still life, quartz crystals and amethyst on a velvet cloth under aura-gradient light, incense smoke drifting past a dolphin poster, 1990 bookstore transcendence sold by the shelf, soft lilac and turquoise glow, 8k`

### **Omnireflect**

**№ 647 / 1001** — *Consciousness Trapped in Infinite Mirrors*

**Nível:** 🌀 Além da Quaternária

**Eixo:** EMANATIO ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Tudo espelhando tudo, sem saída** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Omnireflexo: corredores de cromo recursivo onde cada superfície devolve outra versão da cena.

**Paleta de cores** cromo, prata líquida, reflexo espectral

**Melhores usos:** arte digital, capas, conceito

**MidJourney:** `[tema], omnireflect aesthetic, recursive chrome corridors, every surface mirroring the scene --v 6`

**Prompt universal (Seedream):** `Ultra-crisp 3D render, an omnireflective corridor of recursive chrome, every curved surface returning another version of the same figure into infinity, liquid silver with spectral highlight fringes, geometry dissolving into pure reflection, flawless raytracing, 8k`

### **Optimistic**

**№ 651 / 1001** — *Yellow Door Left Open*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**A manhã como argumento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Otimista: porta amarela aberta, luz nova e a convicção visual de que hoje pode dar certo.

**Paleta de cores** amarelo claro, branco de manhã, azul limpo

**Melhores usos:** campanhas, lifestyle, editorial

**MidJourney:** `[tema], optimistic aesthetic, yellow door left open, morning light as an argument --v 6`

**Prompt universal (Seedream):** `Shot on Nikon FE2 with 50mm lens, an optimistic scene, a bright yellow door left open to clean morning light, fresh white walls and a clear blue sky making the visual argument that today might work out, warm honest film color, 8k`

### **Palmette**

**№ 663 / 1001** — *Fan-Leaf Travels Three Thousand Years and Still Reads as Crown*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**Um motivo viajando por impérios** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Palmeta: o leque estilizado que saiu de Persépolis, atravessou a Grécia e pousou no móvel Império.

**Paleta de cores** dourado de friso, terracota, negro de ceramica

**Melhores usos:** ornamento, design, editorial

**MidJourney:** `[tema], palmette ornament aesthetic, stylized fan motif traveling from Persepolis to Empire furniture --v 6`

**Prompt universal (Seedream):** `Ultra-detailed ornament study, the palmette motif traced across empires, a stylized fan repeating from Persepolis stone friezes through Greek vase borders to gilt Empire furniture, frieze gold terracotta and ceramic black, one form carrying three thousand years, 8k`

### **Phoenician**

**№ 682 / 1001** — *Purple Dye Financing the Mediterranean*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Atmosfera e mood**

**Púrpura, cedro e rotas de mar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Fenício: conchas de múrex, tinturarias de púrpura real e navios de cedro cruzando o Mediterrâneo.

**Paleta de cores** púrpura de Tiro, cedro, azul de rota

**Melhores usos:** histórico, cultura, editorial

**MidJourney:** `[tema], Phoenician aesthetic, Tyrian purple murex shells cedar ships, Mediterranean trade routes --v 6`

**Prompt universal (Seedream):** `Museum-grade artifact photograph, a Phoenician still life of crushed murex shells beside cloth dyed deep Tyrian purple, cedar ship fragments and glass beads from Mediterranean routes, royal purple against warm cedar and sea blue, trade-empire history in raking light, 8k`

### **Poolcore**

**№ 697 / 1001** — *Melancholy of Artificial Paradise*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Atmosfera e mood**

**Azul de piscina como estado de espírito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Poolcore: azulejos, silhêuetas suspensas e o silêncio clorado das piscinas quase vazias.

**Paleta de cores** azul clorado, branco de azulejo, pele ao sol

**Melhores usos:** editorial, arte, moda

**MidJourney:** `[tema], poolcore aesthetic, tiled pool geometry chlorinated silence, suspended swimmers --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Ektachrome E100 in 120 format, a poolcore composition, a lone swimmer suspended in tiled turquoise geometry with chlorinated silence all around, Maria Svarbova stillness in pool blue and tile white, sun-warmed skin the only warm note, dreamlike symmetry, 8k`

### **Popstar**

**№ 702 / 1001** — *Love Metered by the Like*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → INTEGRITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A irradiação é transmitida como continuidade reconhecível, mantendo vivo seu campo de presença.

**Nota genealógica original (EN):** K-pop training academies of the 1990s and Hatsune Miku's 2007 virtual design both reproduced the parasocial bond mechanism without modification, confirming that industrial charisma survives format changes by passing its grammar intact to each new delivery system.

**Atmosfera e mood**

**Amor medido em curtidas por segundo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Popstar: parede de LED, brilho de palco e a persona construída para caber em todas as telas ao mesmo tempo.

**Paleta de cores** LED magenta, prata de palco, spotlight branco

**Melhores usos:** música, capas, editorial

**MidJourney:** `[tema], popstar aesthetic, LED wall stage glitter, persona built for every screen at once --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa Mini with 75mm lens, a popstar mid-performance before a towering LED wall, glitter catching magenta panels and white spotlight, a persona engineered to fit every screen simultaneously, love metered in likes per second, cinematic stage sheen, 8k`

### **Ravecore**

**№ 742 / 1001** — *Bass Turns the Crowd Into One Body*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Chicago house's four-to-the-floor drive, Detroit techno's machine precision, psychedelic counterculture's entheogenic ritual frame, and industrial music's raw stripped aesthetic were each complete systems; recombined here they produce the only aesthetic for which a warehouse becomes a temple and the kick drum functions as sacrament — a synthesis none of the four parents could achieve alone.

**Atmosfera e mood**

**A noite inteira em um único flash** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ravecore: lasers verdes cortando fumaça, pulseiras neon e o êxtase coletivo da pista às 4h da manhã.

**Paleta de cores** verde laser, rosa UV, preto de galpão

**Melhores usos:** música, editorial, moda jovem

**MidJourney:** `[tema], ravecore aesthetic, green lasers through smoke neon bracelets, 4am collective ecstasy --v 6`

**Prompt universal (Seedream):** `Slow-shutter compact camera photo with rear-curtain flash, a ravecore scene at 4am, green lasers slicing smoke above a crowd wearing UV-pink glow bracelets, motion trails smearing into one sharp flash-frozen face, warehouse black swallowing the edges, sweaty euphoric grain, 8k`

### **Regal**

**№ 749 / 1001** — *Divine Right Staged in Scale and Gold*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** No prior aesthetic exists to inherit; sovereign display surfaced independently across Mesopotamia, Egypt, China, and Mesoamerica, each arriving at gold, the axial approach, and the raised throne by the same structural necessity — that centralized authority requires legitimation the eye can read.

**Atmosfera e mood**

**Direito divino encenado em escala e ouro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Régio: sala do trono, veludo carmesim e a distância cerimonial entre a coroa e todo o resto.

**Paleta de cores** ouro de trono, carmesim, arminho branco

**Melhores usos:** histórico, luxo, capas

**MidJourney:** `[tema], regal aesthetic, throne room crimson velvet, divine right staged in scale and gold --v 6`

**Prompt universal (Seedream):** `Shot on an 8x10 camera with 480mm lens, a regal throne room, crimson velvet and ermine beneath a canopy of gold, ceremonial distance measured between the crown and everything else, divine right staged in sheer scale and gilding, candelabra glow on marble, 8k`

### **Regenerative**

**№ 751 / 1001** — *Design That Gives Back*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Sustainable design's mandate to reduce harm is re-instrumented by inverting its target from neutral balance to net-positive contribution, so every surface is specified not to minimize damage but to feed the living system it stands inside.

**Atmosfera e mood**

**Design que devolve mais do que tira** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Regenerativo: mandalas de permacultura, solo vivo e sistemas desenhados para deixar o lugar melhor.

**Paleta de cores** verde de policultura, marrom de solo vivo, dourado de colheita

**Melhores usos:** sustentabilidade, branding, editorial

**MidJourney:** `[tema], regenerative aesthetic, permaculture mandala beds living soil, design that gives back more --v 6`

**Prompt universal (Seedream):** `Aerial drone photograph over a regenerative farm, permaculture mandala beds spiraling in polyculture greens around living compost-brown soil, harvest gold edging each ring, a system designed to return more than it takes, morning light across patterned abundance, 8k`

### **Sacred Geometry**

**№ 779 / 1001** — *Math's Mystical Side*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Classical construction geometry — compass, straightedge, circle, and square — arrives as the single parent, and Sacred Geometry re-instruments it by declaring the same constructions holy, rereading the radius as emanation and the proportion as divine law without adding one new form — so a toolkit that could stand without theology gains, one interpretive turn later, a cosmology it cannot stand without.

**Atmosfera e mood**

**O lado místico da matemática** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Geometria sagrada: flor da vida, proporção áurea e mandalas de precisão — o universo desenhado com compasso.

**Paleta de cores** dourado de linha, azul profundo, branco de pergaminho

**Melhores usos:** espiritual, arte, branding

**MidJourney:** `[tema], sacred geometry aesthetic, flower of life golden ratio mandala, math's mystical side --v 6`

**Prompt universal (Seedream):** `Ultra-precise geometric illustration, sacred geometry unfolding as a flower of life within a golden-ratio spiral, hairline gold construction lines over deep indigo with parchment-white intersections, the universe drafted with compass and reverence, flawless symmetrical detail, 8k`

### **Scented Bloom**

**№ 786 / 1001** — *Petals and Perfume*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Romanticism's reverence for transient natural beauty arrives as the single parent, and Scented Bloom re-instruments that premise through one narrowed organ of perception — extraction, drying, diffusion of the bloom's volatile essence — so a philosophy of feeling nature before reasoning it becomes, one distillation later, a discipline of capturing scent before it is lost.

**Atmosfera e mood**

**Pétalas e perfume na mesma imagem** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Flor perfumada: rosas abertas, vidro de perfume e névoa de fragrância visível — o olfato traduzido em luz.

**Paleta de cores** rosa de pétala, âmbar de perfume, branco de vapor

**Melhores usos:** beleza, perfumaria, produto

**MidJourney:** `[tema], scented bloom aesthetic, open roses perfume bottle visible fragrance mist, scent translated to light --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R5 with 100mm macro lens, a scented bloom still life, full-blown roses beside a faceted amber perfume bottle with a fine mist hanging visible in backlight, petal pink and vapor white translating fragrance into light, dewy luxurious macro detail, 8k`

### **Sci-Fi**

**№ 788 / 1001** — *Electric Dreams*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → THEME ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** Strip away Gothic shadow and Romantic sublime and the genre still stands, because the speculative operation — present technology extrapolated into an imagined future — answers to no parent aesthetic, only to the raw act of cognitive estrangement; cyberpunk, steampunk, solarpunk, and biopunk all decompose into this root, and none can be traced upward past it.

**Atmosfera e mood**

**Sonhos elétricos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sci-fi: corredores de nave em neon, cidades verticais e a pergunta sobre o humano feita em luz artificial.

**Paleta de cores** azul elétrico, neon magenta, preto de espaço

**Melhores usos:** conceito, capas, entretenimento

**MidJourney:** `[tema], sci-fi aesthetic, neon spaceship corridor vertical city, electric dreams --v 6`

**Prompt universal (Seedream):** `Ultra-detailed cinematic concept art, a sci-fi corridor aboard a deep-space vessel, electric blue panel light and magenta holograms reflecting off brushed hull plating toward a viewport of vertical city lights below, electric dreams asking what remains human, filmic atmosphere, 8k`

### **Sedona**

**№ 794 / 1001** — *Earth's Whisper*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** American Transcendentalism's landscape-as-spiritual-instrument arrives as the single parent, and Sedona re-instruments that inheritance through one geological subject — iron-stained sandstone reaching three hundred metres into a dry sky — so a philosophy of wilderness refining the self becomes, one turn later, a vortex-and-crystal practice of listening to a specific red rock.

**Atmosfera e mood**

**O sussurro da terra em rocha vermelha** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sedona: mesas de arenito ao amanhecer, juníperos retorcidos e o silêncio minéral que atrai peregrinos do espírito.

**Paleta de cores** vermelho de arenito, sage, azul de amanhecer

**Melhores usos:** paisagens, espiritual, viagem

**MidJourney:** `[tema], Sedona aesthetic, red rock mesas at dawn twisted junipers, earth's whisper --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 645N with 45mm lens, a Sedona dawn, red sandstone mesas igniting layer by layer above twisted junipers and pale sage, mineral silence that pulls pilgrims of the spirit, sandstone crimson against cool dawn blue, vast quiet medium-format depth, 8k`

### **Social Media I Vlogger & Tumblr**

**№ 817 / 1001** — *Digital Diaries*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** The confessional webcam diary, the dated first-person blog, and Tumblr's curatorial reblog dashboard are welded into one form, no single ancestor surviving intact, so a private diary entry and a stranger's borrowed photograph fuse into a platform-native self that none of the three lineages could produce alone.

**Atmosfera e mood**

**Diários digitais em luz de pisca-pisca** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tumblr/vlog 2011: luzinhas de fada, polaroides na parede e a webcam como confessionário de quarto.

**Paleta de cores** rosa de filtro, luz de fada, branco de pôster

**Melhores usos:** nostalgia digital, editorial, conceito

**MidJourney:** `[tema], 2011 tumblr vlogger aesthetic, fairy lights polaroid wall webcam confessional, digital diaries --v 6`

**Prompt universal (Seedream):** `Shot on Canon T2i at desk height, a 2011 vlogger bedroom framed like a paused video, fairy lights and a polaroid wall behind a hand mid-gesture toward the lens, faded pink filter over soft lamp glow, the webcam as diary confessional, nostalgic early-YouTube softness, 8k upscale`

### **Social Media III TikTok**

**№ 819 / 1001** — *Attention compressed into fifteen seconds*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Looped Vine comedy and the Instagram grid's social-graph feed arrive as the single parent, and TikTok re-instruments that inheritance by detaching distribution from the follower count and handing every clip to a recommendation engine instead, so a video shown to people who chose to follow becomes, one turn later, a video thrown to a million strangers who never asked for it.

**Atmosfera e mood**

**A atenção comprimida em quinze segundos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

TikTok: enquadramento vertical, ring light nos olhos e a transição congelada no meio do gesto — o corte como linguagem.

**Paleta de cores** luz de ring light, ciano e rosa de app, LED de quarto

**Melhores usos:** conceito, marketing, editorial

**MidJourney:** `[tema], tiktok aesthetic, vertical frame ring light mid-transition freeze, attention compressed to fifteen seconds --v 6`

**Prompt universal (Seedream):** `Ultra-sharp vertical photograph, a TikTok moment frozen mid-transition, ring-light circles in the eyes as an outfit changes between frames, cyan and pink app glow over bedroom LED strips, choreography built for the fifteenth second, kinetic pause full of implied motion, 8k`

### **Social Media IV Algorithmic Realism**

**№ 820 / 1001** — *Your feed, trained to mirror you*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Post-Internet Art's practice of making work about being online arrives as the single parent, and Algorithmic Realism re-instruments that inheritance by collapsing the distance between artwork and network, so the algorithm that once stood as backdrop becomes, one turn later, the working material itself.

**Atmosfera e mood**

**O feed treinado para espelhar você** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Realismo algorítmico: a grade infinita devolvendo variantes de um mesmo rosto — o gosto pessoal como profecia autorrealizada.

**Paleta de cores** azul de tela, cinza de interface, brilho de recomendação

**Melhores usos:** conceito, arte digital, editorial

**MidJourney:** `[tema], algorithmic realism aesthetic, infinite feed mirroring one face in variants, taste as self-fulfilling prophecy --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital composition, algorithmic realism, an infinite scrolling grid where every recommended tile is a slight variant of the same viewer's face and taste, interface gray and screen blue lit by recommendation glow, the feed trained into a mirror, unsettling seamless repetition, 8k`

### **Socialite**

**№ 822 / 1001** — *Life as a Red Carpet*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Hollywood Glamour's posed front-facing portrait and choreographed entrance arrive as the single parent, and Socialite re-instruments that inheritance by extending the studio's one-night premiere into a permanent condition, so a movie star's red carpet becomes, one turn later, an airport, a courtroom, and a feed that never stops rolling.

**Atmosfera e mood**

**A vida como tapete vermelho permanente** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Socialite: flash no step-and-repeat, taça erguida para as câmeras e a agenda social como carreira em tempo integral.

**Paleta de cores** preto de gala, champanhe, flash branco

**Melhores usos:** editorial, moda, eventos

**MidJourney:** `[tema], socialite aesthetic, flash on the step-and-repeat raised champagne, life as permanent red carpet --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D5 with direct flash, a socialite mid-arrival on the step-and-repeat, gala black sequins and a champagne flute raised precisely toward the cameras, flash white flattening the night into publicity, the social calendar practiced as a full-time career, tabloid-sharp glamour, 8k`

### **Sonarcore**

**№ 829 / 1001** — *Echoes Draw the Room in Darkness*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** The oceanic soundscape tradition's conviction that the ocean is known by ear arrives as the single parent, and Sonarcore re-instruments that inheritance by routing every perception through sonar instead of the hydrophone's passive record, so a recorded undersea hum becomes, one turn later, a green sweep-line reading distance out of the dark.

**Atmosfera e mood**

**Ecos desenhando o espaço no escuro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sonarcore: anéis de pulso verde varrendo o breu, o ambiente revelado só pelo retorno do som — ver com os ouvidos.

**Paleta de cores** verde de sonar, preto abissal, fosforescência

**Melhores usos:** conceito, arte digital, capas

**MidJourney:** `[tema], sonarcore aesthetic, green pulse rings sweeping darkness, the room drawn only by echoes --v 6`

**Prompt universal (Seedream):** `Ultra-crisp digital composition, sonarcore, concentric green pulse rings sweeping through abyssal black to reveal a room only where echoes return, phosphorescent traces sketching walls and a lone figure in outline, space drawn entirely by sound, deep-sea instrument glow, 8k`

### **Spring**

**№ 842 / 1001** — *First green after the long gray*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** No single movement precedes Spring; Han solar terms, Heian dawn-poetics, and Western pastoral each arrive independently at the same renewal-grammar with no shared ancestor, so the aesthetic generates descendants across every later season-code while descending from none of them, and no prior tradition can be traced upward into it.

**Atmosfera e mood**

**O primeiro verde depois do longo cinza** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Primavera: botões rompendo o galho, poças refletindo céu novo e a estação inteira pedindo licença para começar.

**Paleta de cores** verde de broto, rosa de flor de cerejeira, azul lavado

**Melhores usos:** natureza, lifestyle, editorial

**MidJourney:** `[tema], spring aesthetic, buds breaking the branch puddles reflecting new sky, first green after the long gray --v 6`

**Prompt universal (Seedream):** `Shot on Fuji GA645Zi with 55mm lens, a spring morning, cherry buds breaking open along a wet branch above puddles reflecting freshly washed blue, sprout green arriving shy against the last of winter gray, the whole season politely asking permission to begin, tender bright film color, 8k`

### **Stile Liberty**

**№ 849 / 1001** — *Italian Sophistication Blossoms into Art Nouveau*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Belgian and French Art Nouveau's curvilinear line, British Arts and Crafts' doctrine of handwork, and Celtic interlace's inherited geometric fill are welded into one form, no single ancestor surviving intact, so three lineages fuse into an Italian ornamental grammar that none of the three could produce alone.

**Atmosfera e mood**

**A sofisticação italiana florescendo em art nouveau** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Stile Liberty: fachadas milanesas com ferro em ramos, cerâmica floral e o art nouveau falando italiano com sotaque aristocrático.

**Paleta de cores** verde de ferro forjado, creme de fachada, rosa de cerâmica

**Melhores usos:** arquitetura, histórico, editorial

**MidJourney:** `[tema], stile liberty aesthetic, milanese facade wrought iron vines floral ceramics, italian art nouveau --v 6`

**Prompt universal (Seedream):** `Shot on Arca-Swiss 4x5 with 90mm lens, a Stile Liberty facade in Milan, wrought iron curling into branches over balconies of floral ceramic in the Casa Galimberti manner, forged green and ceramic rose against cream stucco, art nouveau spoken in aristocratic Italian, refined architectural detail, 8k`

### **Sunset**

**№ 864 / 1001** — *Sky burning through its final palette*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Romanticism's sublime landscape is inherited whole, then refined: Romantic vastness narrowed to a single recurring event and the slim band of minutes that holds it.

**Atmosfera e mood**

**O céu queimando sua paleta final** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pôr do sol: o horizonte gastando laranja, rosa e violeta na mesma dúzia de minutos — o espetáculo diário que ninguém cansa de fotografar.

**Paleta de cores** laranja de brasa, rosa incendiado, violeta de despedida

**Melhores usos:** paisagens, lifestyle, capas

**MidJourney:** `[tema], sunset aesthetic, horizon spending orange pink and violet in twelve minutes, the sky's final palette --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 70-200mm lens, a sunset compression, the horizon spending ember orange blazing pink and farewell violet in the same twelve minutes over silhouetted ridgelines, clouds igniting layer by layer as the palette burns down, the daily spectacle no one tires of, saturated telephoto drama, 8k`

### **Supergraphic Ultramodern**

**№ 867 / 1001** — *Futurist Space Directed by Giant Graphics*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Space Age Mid-Century Modernism supplies the single parent, and Supergraphic Ultramodern re-instruments that inheritance by painting the optimism directly onto the total room surface, with Pop color and Swiss type pressing in as influence rather than a second lineage.

**Atmosfera e mood**

**O espaço futurista dirigido por gráficos gigantes** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Supergráficos: setas e números em escala de parede inteira, corredores de 1972 transformados em sinalização habitável.

**Paleta de cores** laranja de supergráfico, branco de corredor, preto de numeral

**Melhores usos:** design, interiores, editorial

**MidJourney:** `[tema], supergraphic ultramodern aesthetic, wall-scale arrows and numerals 1972 corridor, inhabitable signage --v 6`

**Prompt universal (Seedream):** `Ultra-clean architectural photograph, a supergraphic ultramodern corridor, a wall-scale orange arrow and ten-foot numeral sweeping across white walls and around the ceiling in 1972 confidence, graphics directing the space instead of decorating it, signage grown large enough to live inside, crisp geometric power, 8k`

### **Surfercore**

**№ 871 / 1001** — *Salt, swell, and a schedule set by tides*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Polynesian/Hawaiian oceanic wave-riding supplies the single parent, and Surfercore re-instruments that inheritance as a consumer coastal-leisure lifestyle, swapping koa-wood boards and ritual for foam blanks and the dawn-patrol routine.

**Atmosfera e mood**

**Sal, ondulação e a agenda ditada pelas marés** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Surfercore: parafina na prancha ao amanhecer, cabelo endurecido de sal e o dia inteiro organizado em torno do swell.

**Paleta de cores** turquesa de onda, branco de espuma, dourado de sal

**Melhores usos:** esporte, lifestyle, editorial

**MidJourney:** `[tema], surfercore aesthetic, dawn wax salt-stiff hair schedule set by tides, salt and swell --v 6`

**Prompt universal (Seedream):** `Shot on Nikonos V with 35mm lens, a surfercore morning half in the water, a surfer duck-diving through turquoise glass as foam explodes overhead, salt gold burning in the backlit spray, the whole day already surrendered to the tide chart, water-level film immediacy, 8k scan`

### **Surrealism**

**№ 872 / 1001** — *Melting clocks and the logic of dreams*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** No single ancestor can be removed to collapse the system — strip Dada, Symbolism, or Freud individually and the marvelous survives intact, which is the structural signature of a root node rather than a derivative.

**Atmosfera e mood**

**Relógios derretendo e a lógica dos sonhos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Surrealismo: o deserto onde relógios escorrem de galhos secos e a razão tira férias — Dalí e Magritte como cartógrafos do inconsciente.

**Paleta de cores** dourado de deserto onírico, azul de céu impossível, âmbar derretido

**Melhores usos:** arte, conceito, capas

**MidJourney:** `[tema], surrealism aesthetic, clocks melting over dry branches dream logic desert, Dalí unconscious cartography --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a surrealist painting, soft watches melting over a dry branch and a sleeping form in an endless amber desert, Dalí precision rendering the impossible under Magritte's too-blue sky, dream logic administered with academic technique, hallucinatory clarity, 8k scan`

### **Surrealist Automatism**

**№ 873 / 1001** — *Hand drawing before the mind can censor*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Dada supplies the single parent — chance operations and the refusal to compose — and Surrealist Automatism re-instruments that inheritance by narrowing chance into a disciplined channel for the unconscious mark.

**Atmosfera e mood**

**A mão desenhando antes que a mente censure** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Automatismo surrealista: a linha solta correndo o papel sem plano, figuras emergindo do rabisco — André Masson ditando pelo pulso.

**Paleta de cores** nanquim, papel cru, sangria de aquarela

**Melhores usos:** arte, conceito, editorial

**MidJourney:** `[tema], surrealist automatism aesthetic, unplanned ink line figures emerging from the scrawl, hand before censor --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a surrealist automatic drawing, an unbroken ink line wandering the raw paper faster than intention, half-figures and wings surfacing from the scrawl in the André Masson manner, watercolor bleeding where the wrist hesitated, the hand outrunning the censor, 8k`

### **Suzani**

**№ 876 / 1001** — *Silk Suns Hand-Stitched Across the Dowry Cloth*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** The ornamental tradition of Islamic decorative art supplies the single parent, and Suzani re-instruments that inheritance by rerouting floral abstraction from architecture and manuscript into hand-stitched dowry cloth.

**Atmosfera e mood**

**Sóis de seda bordados no enxoval** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Suzani: medalhões solares em ponto de cadeia, romãs e vinhas cobrindo o pano de dote uzbeque — gerações costuradas em vermelho.

**Paleta de cores** carmesim de seda, dourado de sol bordado, índigo de fundo

**Melhores usos:** têxtil, interiores, editorial

**MidJourney:** `[tema], suzani aesthetic, chain-stitched silk suns pomegranates on uzbek dowry cloth, generations sewn in red --v 6`

**Prompt universal (Seedream):** `High-resolution textile scan of an Uzbek suzani, chain-stitched silk suns and pomegranate vines blazing across the dowry cloth, crimson and embroidered gold over deep indigo ground, a grandmother's hand legible in every slightly irregular stitch, generations sewn into one cloth, 8k`

### **Swampcore**

**№ 878 / 1001** — *Murky water guarding a lush living archive*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** The nature-appreciation tradition (Naturecore) supplies the single parent, and Swampcore re-instruments that inheritance by inverting its celebration of growth toward decay, moisture, and unsanitized ecological complexity.

**Atmosfera e mood**

**A água turva guardando um arquivo vivo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Swampcore: joelhos de cipreste saindo da água de tanino, musgo espanhol pendurado e a biodiversidade prosperando onde ninguém limpa.

**Paleta de cores** verde de lentilha d'água, castanho de tanino, cinza de musgo

**Melhores usos:** natureza, conceito, editorial

**MidJourney:** `[tema], swampcore aesthetic, cypress knees tannin water spanish moss, murky water guarding a living archive --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z6 III with 24mm lens, a swampcore scene at first light, cypress knees rising from tannin-brown water under curtains of Spanish moss, duckweed green scumming the mirror surface as an egret freezes mid-step, the murk guarding a lush living archive, humid primordial atmosphere, 8k`

### **Synthetic Dreamscape**

**№ 885 / 1001** — *Dreamworlds rendered sharper than waking life*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Surrealism supplies the single parent, and Synthetic Dreamscape re-instruments that inheritance by executing dream-logic through ray-traced computational rendering instead of the hand-painted canvas.

**Atmosfera e mood**

**Mundos de sonho renderizados mais nítidos que a vigília** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Paisagem onírica sintética: arquipélagos flutuando em gradiente impossível, física opcional e resolução acima do real.

**Paleta de cores** rosa de nuvem renderizada, azul de água impossível, branco de vazio

**Melhores usos:** arte digital, capas, conceito

**MidJourney:** `[tema], synthetic dreamscape aesthetic, floating archipelagos optional physics, dreams sharper than waking --v 6`

**Prompt universal (Seedream):** `Ultra-detailed 3D dreamscape render, floating stone archipelagos trailing waterfalls into an impossible gradient sky, rendered-cloud pink and unreal water blue at a resolution waking life never reaches, physics left politely optional, a dream sharper than the morning after it, 8k`

### **Taoist**

**№ 893 / 1001** — *Garden Finds Order by Refusing Force*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** The system reduces no further — its philosophy of non-action and complementary opposites is a root worldview, not a decomposable style, the signature of a foundational node that seeds descendants rather than inheriting from any parent.

**Atmosfera e mood**

**O jardim que encontra ordem recusando a força** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Taoísta: água contornando a pedra em vez de vencê-la, névoa entre pinheiros e o wu wei praticado como paisagismo.

**Paleta de cores** verde de pinheiro na névoa, cinza de pedra, branco de vazio

**Melhores usos:** espiritual, paisagens, editorial

**MidJourney:** `[tema], taoist aesthetic, water rounding the stone mist between pines, order found by refusing force --v 6`

**Prompt universal (Seedream):** `Shot on Linhof 617 panoramic with 90mm lens, a Taoist garden dawn, a stream choosing to round the stone rather than defeat it while mist drifts between pines, stone gray and pine green dissolving into deliberate empty white, wu wei practiced as landscape design, serene unforced order, 8k`

### **Transcendentalism**

**№ 905 / 1001** — *Truth Found Beyond the Built World*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** Romanticism supplies the single parent, and Transcendentalism re-instruments that inheritance by narrowing reverence for landscape into one American claim: the soul reads truth directly from nature.

**Atmosfera e mood**

**A verdade encontrada além do mundo construído** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Transcendentalismo: a cabana à beira do lago, a névoa levantando de Walden e a certeza de Emerson e Thoreau de que a natureza é o texto original.

**Paleta de cores** verde de mata matinal, névoa de lago, castanho de cabana

**Melhores usos:** natureza, espiritual, editorial

**MidJourney:** `[tema], transcendentalism aesthetic, cabin by the pond mist rising off Walden, nature as the original text --v 6`

**Prompt universal (Seedream):** `Shot on Chamonix 4x5 with 150mm lens, a transcendentalist dawn, mist lifting off a Walden-still pond before a hand-built cabin at the treeline, morning forest green dissolving into lake fog, the Emerson and Thoreau conviction that truth waits beyond the built world, contemplative large-format serenity, 8k`

### **Twilightcore**

**№ 918 / 1001** — *Gothic Romance Under Suburban Fluorescence*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Gothic Romance, Emo, and 2000s Teen Culture converge here, each supplying a load-bearing layer nothing else replaces, fixing Twilightcore as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Romance gótico sob fluorescência suburbana** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Twilightcore: floresta do Pacific Northwest em azul dessaturado, caminhonete antiga na garoa e o sobrenatural matriculado no colégio público.

**Paleta de cores** azul-petróleo de floresta, cinza de garoa, verde dessaturado

**Melhores usos:** capas, editorial, conceito

**MidJourney:** `[tema], twilightcore aesthetic, pacific northwest forest desaturated teal old truck in drizzle, the supernatural enrolled in public school --v 6`

**Prompt universal (Seedream):** `Cinematic still graded in desaturated teal, a twilightcore scene, a rusted pickup parked in Pacific Northwest drizzle where hemlock forest presses against a high school parking lot, drizzle gray and forest blue-green swallowing the fluorescent glow, gothic romance enrolled quietly in public school, moody overcast atmosphere, 8k`

### **Unicorn**

**№ 926 / 1001** — *Pastel Mythology With a Glitter Horn*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Kawaii cute-commodity grammar, 2010s digital pastel femininity, and the mythological single-horned beast converge here, each supplying a load-bearing layer nothing else replaces, fixing Unicorn as a multi-lineage hybrid rather than a single-parent revision.

**Atmosfera e mood**

**Mitologia pastel com chifre de glitter** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Unicórnio: crina em arco-íris pastel, chifre dourado e a fé de que magia e açúcar são a mesma substância.

**Paleta de cores** rosa pastel, lilás de crina, dourado de chifre

**Melhores usos:** infantil, branding, conteúdo

**MidJourney:** `[tema], unicorn aesthetic, pastel rainbow mane golden glitter horn, magic and sugar as one substance --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R6 Mark II with 50mm lens, a unicorn styled tableau, a white pony with a pastel rainbow-braided mane and gilded glitter horn standing in soft cloud-machine mist, lilac and pastel pink shimmering under candy light, the firm belief that magic and sugar are one substance, sparkling dreamy sweetness, 8k`

### **Virtual**

**№ 954 / 1001** — *Reality Built Without Physical Permission*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Virtual recombines three derived lineages — Digital Art's rendered surface, Cyberpunk's human-machine interface, and Post-Digital's self-aware glitch — two generations deep, the signature of multi-lineage hybridization rather than single-parent reinterpretation.

**Atmosfera e mood**

**A realidade construída sem permissão física** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Virtual: a arquitetura que ignora gravidade, o pôr do sol editável e o mundo renderizado onde a física é só uma sugestão de estilo.

**Paleta de cores** azul de wireframe, magenta de horizonte digital, preto de void

**Melhores usos:** conceito, arte digital, capas

**MidJourney:** `[tema], virtual aesthetic, gravity-ignoring architecture editable sunset, physics as a style suggestion --v 6`

**Prompt universal (Seedream):** `Ultra-detailed VR world render, a virtual environment, impossible architecture spiraling free of gravity above an editable magenta sunset while wireframe blue seams flicker at the horizon of the void, reality assembled without physical permission, physics demoted to a style suggestion, limitless synthetic wonder, 8k`

### **Visual Propaganda**

**№ 957 / 1001** — *Persuasion Compressed Into One Image*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** Socialist Realism, Constructivism, and Art Deco all consume the persuasive-instrumental image as a style choice; none generates the underlying grammar of legibility-at-distance and directed composition, which remains a root operation other movements borrow from rather than descend into.

**Atmosfera e mood**

**A persuasão comprimida numa única imagem** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Propaganda visual: o braço em diagonal heróica, três cores e uma palavra de ordem — o cartaz desenhado para decidir antes do pensamento.

**Paleta de cores** vermelho de comando, creme de cartaz, preto de slogan

**Melhores usos:** histórico, design, conceito

**MidJourney:** `[tema], visual propaganda aesthetic, heroic diagonal arm three colors one slogan, persuasion before thought --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a lithographic propaganda poster, a heroic figure thrust along the diagonal with one arm pointing the only permitted direction, command red and slogan black on aged cream, persuasion compressed into a single image built to decide before thought arrives, bold graphic force, 8k`

### **Voidcore**

**№ 959 / 1001** — *Emptiness Given an Edge and an Echo*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↓ → DENSITY ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** No prior aesthetic can be stripped from Voidcore without leaving a simpler Voidcore behind — every candidate parent, including Minimalism, still keeps an object in the frame — so the terminal reduction to structured absence stands as an irreducible root rather than a derivative branch.

**Atmosfera e mood**

**O vazio ganhando aresta e eco** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Voidcore: a porta aberta para o preto absoluto, a escada que desce sem fundo visível e o silêncio com textura — o nada como presença ativa.

**Paleta de cores** preto absoluto, cinza de limiar, branco de única luz

**Melhores usos:** conceito, capas, arte digital

**MidJourney:** `[tema], voidcore aesthetic, door opening onto absolute black bottomless stair, emptiness with an edge and an echo --v 6`

**Prompt universal (Seedream):** `Ultra-minimal dark render, a voidcore threshold, a single lit doorway opening onto absolute black where a stair descends past any visible bottom, threshold gray dissolving at the edge of one cold light, silence given texture and emptiness given an echo, immense quiet dread, 8k`

### **Vorticism**

**№ 960 / 1001** — *Machine Energy Cut Into Angular Force*

**Nível:** 🟤 Terciária

**Eixo:** EMANATIO ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** Vorticism fuses Cubism's angular fracture with Futurism's machine charge into a third grammar, the frozen vortex, that survives in neither parent alone and cannot be reduced back to a single source.

**Atmosfera e mood**

**A energia da máquina cortada em força angular** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vorticismo: diagonais de aço convergindo no vórtice, a cidade industrial fatiada em planos duros — Wyndham Lewis e o BLAST contra o sentimentalismo.

**Paleta de cores** aço anguloso, vermelho de BLAST, preto de diagonal

**Melhores usos:** arte, design, editorial

**MidJourney:** `[tema], vorticism aesthetic, steel diagonals converging on the vortex hard sliced planes, BLAST against sentiment --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a vorticist painting in the Wyndham Lewis manner, steel diagonals and fractured machine planes converging violently on a central vortex, angular gray and BLAST red slicing through black, the industrial city cut into pure directional force, hard abstract dynamism, 8k scan`

### **Wanderlust**

**№ 965 / 1001** — *Horizons Sold as Vintage Postcards*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** The ache to be elsewhere predates every style that dresses it — Grand Tour travel, Romantic wandering, and Instagram photography are all expressions of the same irreducible drive, not sources for it — so removing any one expression leaves the generative desire intact.

**Atmosfera e mood**

**Horizontes vendidos como cartões-postais vintage** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Wanderlust: a mala coberta de decalques de hotéis, o postal de 1962 prometendo o paraíso a três selos de distância e o mapa dobrado no bolso do coração.

**Paleta de cores** turquesa de postal, creme de selo, vermelho de carimbo

**Melhores usos:** viagem, nostalgia, editorial

**MidJourney:** `[tema], wanderlust aesthetic, hotel decal suitcase 1962 postcard paradise three stamps away, horizons as vintage postcards --v 6`

**Prompt universal (Seedream):** `High-resolution flat lay photograph, a wanderlust collection, a leather suitcase covered in hotel decals beneath fanned 1962 postcards promising turquoise coasts three stamps away, postcard teal and stamp red on cream, folded maps softened at every crease by rereading, the horizon merchandised as longing, nostalgic saturated charm, 8k`

### **Web 5.0**

**№ 970 / 1001** — *Emotion Enters the Protocol*

**Nível:** 🌀 Além da Quaternária

**Eixo:** EMANATIO ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Frequências de linhagens distintas são reorganizadas num novo campo de irradiação.

**Nota genealógica original (EN):** No single parent lends this system its skeleton — Web 4.0's synergy, affective computing's emotion-detection, speculative design's not-yet-built horizon, and cyberpunk's body-machine seam arrive from different decades and refuse to resolve into one dominant strain.

**Atmosfera e mood**

**A emoção entrando no protocolo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Web 5.0: a rede lendo o tom antes do texto, cores da interface mudando com o humor e a empatia compilada como camada do sistema.

**Paleta de cores** gradiente emocional, rosa de afeto, azul de escuta

**Melhores usos:** tech, conceito, arte digital

**MidJourney:** `[tema], web 5.0 aesthetic, network reading tone before text interface shifting with mood, emotion enters the protocol --v 6`

**Prompt universal (Seedream):** `Ultra-soft futuristic render, a Web 5.0 interface, translucent layers shifting from listening blue to affection pink as they read the user's tone before the words arrive, an emotional gradient breathing across the room like weather, empathy compiled as a native layer of the protocol, tender responsive luminosity, 8k`

### **Whimsigothic**

**№ 977 / 1001** — *Celestial Light Behind Black Velvet*

**Nível:** 🟣 Secundária

**Eixo:** EMANATIO ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma frequência reconhecível é preservada e reinstrumentada até reorganizar um novo ambiente.

**Nota genealógica original (EN):** The Gothic tradition supplies the structural skeleton entire — strip that parent and nothing survives; strip only the whimsical modifier and the result reverts to ordinary goth, confirming a single lineage reinterpreted rather than several fused.

**Atmosfera e mood**

**A luz celestial atrás do veludo negro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Whimsigoth: luas e estrelas estampadas no veludo, vitral roxo sobre a poltrona de leitura e o místico doméstico dos anos 90 — gótico com chá de jasmim.

**Paleta de cores** roxo profundo, dourado celestial, verde de vitral

**Melhores usos:** interiores, moda, editorial

**MidJourney:** `[tema], whimsigothic aesthetic, moons and stars on velvet purple stained glass reading chair, nineties domestic mysticism --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Df with 28mm lens, a whimsigothic interior, celestial suns and moons printed gold on black velvet drapes around a reading chair lit through purple stained glass, deep violet and star gold glowing like a benevolent tarot parlor, nineties domestic mysticism serving jasmine tea, enchanted cozy shadow, 8k`

### **Youth**

**№ 992 / 1001** — *Rebellion Codes Tomorrow's Look*

**Nível:** 🔴 Primária

**Eixo:** EMANATIO ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova frequência ao romper o campo de presença anterior.

**Nota genealógica original (EN):** No single movement authored this grammar; each generation regenerates it independently — the Wandervögel break of 1900, the 1960s civil-rights placard system, and Fridays for Future's 2018 smartphone mobilization are three separate originations rather than one relayed inheritance, and removing any one leaves the irreducible core, an unsanctioned young body marking public space, fully intact.

**Atmosfera e mood**

**A rebeldia codificando o visual de amanhã** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Juventude: o corte de cabelo que os pais odeiam hoje e a passarela copia em cinco anos — a rua adolescente como laboratório não remunerado da moda.

**Paleta de cores** cor de fase, preto de jaqueta emprestada, neón de fim de semana

**Melhores usos:** moda, cultura, editorial

**MidJourney:** `[tema], youth aesthetic, the haircut parents hate and runways copy in five years, the street as fashion's unpaid lab --v 6`

**Prompt universal (Seedream):** `Shot on Contax G1 with 45mm lens, a youth portrait at dusk, a teenager in a borrowed jacket and a haircut their parents hate leaning against the corner shop under weekend neon, phase color and defiant black worn like a thesis, the exact look runways will invoice for in five years, electric unbothered cool, 8k scan`

## Leitura do padrão — o que as 84 estéticas confirmam

### O caso Voidcore

Uma única supressão como primária em 84 entradas — e é dupla: № 959 Voidcore, EMANATIO ↓ → DENSITY ↓ · XY, ruptura. O vazio com borda e eco: nenhum pai pode ser removido de Voidcore sem deixar um Voidcore mais simples para trás. E o corpus confirma a raridade por fora: EMANATION ↓ aparece uma única vez como slot secundário em toda a página — № 626 Nihilism (MATTER ↑ → EMANATIO ↓, "Nothing Matters, Carefully"). Suprimir a irradiação, neste sistema, nunca é acidente de estilo: é ausência construída de propósito, e acontece só duas vezes em todo o corpus da página.

### Cinco famílias recorrentes

→ SEMIOTICS ↑ reúne 14 (Regal, Surrealism, Visual Propaganda, Wanderlust, Socialite, Whimsigothic, Astrological…) — a radiância que quer ser lida como signo; → ETERNITY soma 14 no total, mas partida: 10 ↑ (Sedona, Sacred Geometry, Transcendentalism, Spring, Expansive, Gothic Medieval…) contra 4 ↓ (Social Media III TikTok, Scented Bloom, Ephemeral, Dazecore) — a radiância que dura contra a que se recusa a durar; → DENSITY ↑ leva 9 (Baroque, Brazilian Carnival, Extravagance, Kaleidoscopic, Fractalism…) — irradiar enchendo; → RESONANCE ↑ leva 7 (Majestic, Ravecore, Jubilant, Poolcore…) — irradiar tocando; → COHERENCE leva 7 (3 ↑, 4 ↓ — Dream, Latinx, Omnireflect, Feminine Mystique), o cluster já sinalizado na análise de COHERENCE: a irradiação é o que mais dissolve o programa.

### Polaridades

41 XX / 43 XY — a lista mais equilibrada de todas as ações até aqui. A placa não distingue som herdado de som novo: vibração é vibração; o que decide a polaridade é o que o eco faz com a linhagem, não a intensidade da irradiação.

### O teste operacional

EMANATION é a segunda maior lista das 14 Ações (84 entradas, atrás apenas de SEMIOTICS) e a mais recebida como modificador: 32 entradas de outras ações terminam em → EMANATIO ↑, de Pop a Vampire — quase tudo quer irradiar; quase nada aceita ser selado. E 18 Primárias sustentam a lista, de Baroque e Byzantine a Sci-Fi e Youth: a irradiação é gramática fundadora em todos os séculos que a página cobre.

# NARRATIVE — o Quipu

<aside>
🪢

**Essência.** NARRATIVE mede a estrutura da história e sua difusão através do tempo. Seu ideograma é o Quipu — o arquivo andino de cordas: tempo atado em ordem transmissível, com cada nó registrando uma decisão de posição, espessura e cor. No registro ↑, o quadro carrega seu próprio antes e depois; no registro ↓, o momento permanece selado por todos os lados. O quipu é honrado como sistema de registro, nunca como ornamento: ninguém narra sozinho.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para NARRATIVE, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem os três tempos próprios de cada estética, enquanto a arquitetura preserva a lógica do Quipu — cada objeto precisa declarar se pertence ao antes, ao durante ou ao depois.

> **↑ NARRATIVE — universal prompt.** One frame carrying three tenses in [time-of-day directional light with weather in it], a [garment mid-work] being worked by the same hands that made it, the trace of what happened still on the cloth — [mark of the earlier hours] — the evidence of what is happening held mid-gesture, and [prepared object by the door] waiting as what comes next, the figure bent to real work with eyes down and grooming legible as elapsed hours, a second pair of hands entering at the frame's edge, photographed slightly elevated on a 40mm at f/8 so every object stays legible in order, long shadows with history in them, each object placed so the viewer reconstructs the story in sequence, the image carrying its own before and after.
> 

**Universal NARRATIVE ↓ negative line (always pair with the ↑ prompt):**

> No sealed symmetrical stasis, no hour-less grooming, no garment without creases of use, no prop without a tense, no shadowless light with no time of day in it, no moment self-contained on all sides, no direct-to-camera address, no story told by caption.
> 

**Como usar para as 19 estéticas da lista.** Preencha os slots com os três tempos da própria estética. Pantanal: a marca d'água da última cheia na parede é o passado, a rede sendo remendada é o presente, o barco carregado é o que vem — water rewrites the landscape each season. Wanderer: a mala junto à porta é literal — path becomes home, stillness a trap; a bota gasta narra as horas anteriores. Baby Boomers: o denim que se data pelo desbotamento é o relógio usado no próprio tecido. Ashcan School: [time-of-day light] = a luz de gás do bar na hora de fechar — o horário é o narrador. Cinematic: o corte, não o quadro, carrega o sentido — disponha os objetos como uma decupagem que se lê em ordem. A lista não tem nenhuma supressão: quando precisar do momento selado, o registro ↓ do repertório existe como guarda contra o adereço sem tempo, não como destino.

## Fundamentos do elemento

### Identidade, registro e tempo transmissível

**Identity.** Story structure and diffusion across time. Its ideogram is the Andean cord archive: time knotted into transmissible order, each knot a decision of position, thickness, and colour that a trained hand can read back centuries later. The glyph is carried with citation, like the Sankofa: quipus were systematically burned under colonial rule and remain largely undeciphered — a suppressed archive honoured, never a decorative motif. And the quipu has many hands: nobody narrates alone. In an image this element is proven by a frame carrying its own before and after, or by a moment sealed on all sides.

**The knot, not the caption.** Story is proven by position — every object a decision of place, thickness, and colour that the viewer reads back in order. No prop without a tense: whatever cannot answer "before, during, or after?" leaves the frame.

**Many hands.** Nobody narrates alone: a second pair of hands is licensed at the frame's edge, because transmission belongs to the story's structure. The cord is held at both ends or it is not a record.

**The archive that survived by being held.** The glyph carries its citation into production: a suppressed, still-undeciphered archive is honoured as a system of record — position and sequence doing the work — never worn as costume, never quoted as decorative motif.

## Corpo — postura, gesto e olhar

**Model posture & structure.** A body mid-act — bent to real work, spine engaged in the present tense of the story; a posture that could not be held for a picture, only interrupted by one.

**Gesture.** Hands doing the narrative — unpicking, winding back, packing; each gesture legible as a verb with a tense; the pass of a tool between two hands permitted at the edge.

**The look — how the eyes behave.** Absorbed, eyes down on the work — or lifted for one beat between tenses; nothing addressed to the camera; the look of someone mid-sentence in their own story.

## Regras de imagem — do vestígio à prova de sequência

**Look & styling continuity.** Elapsed-time grooming: hair still carrying the earlier walk's wind, a lip worn to its afternoon state, thread-marks on the hands; the wardrobe simultaneously artifact, action, and aftermath.

**Camera.** 40mm at f/5.6–f/8, slightly elevated — positioned like a reader moving along the cord; depth held so all three tenses stay legible in order.

**Composition.** Objects staged in readable sequence — past, present, and future placed on one leading line; the position of each object meaning as much as the object itself.

**Lighting.** Late-afternoon directional window light with weather in it — a light that states the hour and implies the hours before it; shadows long enough to have history.

**Beauty detail.** The clock worn on the skin: a worn lip, wind still in the hair, honest working hands — evidence of hours passed, never of neglect.

**Cenography.** A lived room with a door in frame — the spool on the table, mud tracked in an honest line, the suitcase waiting; no prop without a tense.

**Colour.** A palette that states time — late-gold key against interiors holding the day's fatigue; colour as hour, never as mood board.

**Sequence proof.** Plant one verifiable evidence that time passed through the frame: the same thread present in three states — sewn, being unpicked, rewound on its spool — readable in order at a glance.

**Practitioner lines (from the codices).**

**Eugenio Recuenco** (Narrative × Density; Reger) — fashion staged as history painting: candlelit tableaux with cinematic plots, every frame a still from an unmade epic film.

**Kourtney Roy** (Narrative × Semiotics; Inverter) — self-portrait as the recurring heroine of candy-coloured, vaguely sinister Americana, lost in motels and diners.

**Emma Summerton** (Density × Narrative; Encantar) — saturated theatrical dreamscapes with storybook logic, the model a willing protagonist of an overripe fable.

**Frances McLaughlin-Gill** (Expression × Narrative; Encantar) — first woman under contract at Vogue (1943): genuine motion in real city situations, casual realism a decade early.

**Guy Bourdin** (Effect × Narrative; Inverter) — the narrative event entirely off-camera, reconstructed by the viewer from a colour chord, a crop, a posture.

**Scandebergs** (Effect × Narrative; Transgredir) — the cinematic uncanny at thresholds: everyday life slipping out of place under sharp light.

**Theo Wenner** (Expression × Narrative; Fazer) — relaxed, off-guard candid documentary; the story caught rather than staged.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Three tenses in one frame: traces of what happened, evidence of what is happening, preparation for what comes next, every object a knot the viewer reconstructs in order.

> **↑ Prompt.** One frame carrying three tenses, a wedding dress being unpicked at the hem by the same hands that embroidered it, the thread wound back onto its original spool, mud from an earlier walk still on the train, a packed suitcase waiting by the door, every object a knot in a story the viewer reconstructs in order.
> 

> **↑ Negative line.** No sealed stasis, no hour-less grooming, no prop without a tense, no shadowless clockless light, no centred symmetrical rest, no direct-to-camera address, no garment without creases of use, no single unaccompanied author.
> 

**↓ Suppressed — repertory.** Sealed stasis: no props implying arrival or departure, no weather, no clock, the moment self-contained.

> **↓ Prompt.** A figure seated exactly centred, garment at rest, hands still, no props implying arrival or departure, no weather, no clock, the moment sealed on all sides, an image with no before and no after.
> 

> **↓ Negative line.** No narrative props, no doors or suitcases or spools, no directional time-of-day light, no weather, no mid-action gestures, no elapsed grooming, no second pair of hands, no leading line out of the frame.
> 

## Estéticas relacionadas a NARRATIVE (A–Z)

As 19 estéticas classificadas sob NARRATIVE, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **Acadian**

**№ 016 / 1001** — *Exiled Maritime French*

**Nível:** 🟣 Secundária

**Eixo:** NARRATIVE ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem narrativa é preservada e reinstrumentada numa nova sequência temporal.

**Atmosfera e mood**

**Francês marítimo exilado** — (1001 Aesthetics, interpretação)

Cultura acadiana das províncias marítimas do Canadá: casas de madeira à beira-mar, tecidos artesanais, vilas de pesca e memória do exílio.

**Paleta de cores** azul, branco e vermelho com estrela amarela; tons marítimos desbotados

**Melhores usos:** cenas costeiras, folclore, ilustração histórica

**MidJourney:** `[tema], Acadian maritime folk culture, coastal Canada --v 6`

**Prompt universal (Seedream):** `Editorial photograph shot on medium format film with 50mm lens, weathered wooden coastal houses of an Acadian fishing village, handwoven textiles drying in the salt wind, overcast maritime light with a muted seaside palette, fine film grain and documentary warmth, quiet exiled heritage`

### **Ashcan School**

**№ 066 / 1001** — *Gaslit bar at closing time*

**Nível:** 🔴 Primária

**Eixo:** NARRATIVE ↑ → THEME ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova temporalidade ao romper a sequência narrativa anterior.

**Nota genealógica original (EN):** No aesthetic parent supplies this subject — the tenement, the bar at closing, the unposed street are taken directly from lived urban fact rather than from an inherited style, and stripping the ordinary subject leaves nothing standing.

**Atmosfera e mood**

**Bar a gás na hora de fechar** — (1001 Aesthetics, interpretação)

Escola Ashcan: realismo urbano cru de Nova York de 1900, bares, becos, vida operária.

**Paleta de cores** marrons, cinzas, amarelo de luz a gás

**Melhores usos:** cenas urbanas, narrativa, editorial

**MidJourney:** `[tema], Ashcan School urban realism painting --v 6`

**Prompt universal (Seedream):** `Painterly urban scene in Ashcan School style, a gritty New York bar at closing time around 1908, gaslight yellow pooling on wet cobblestones, loose realist brushwork with heavy impasto shadows, working-class figures in worn wool coats, warm browns and smoky grays, museum-grade reproduction, 8k`

### **Baby Boomers**

**№ 077 / 1001** — *Denim that dates itself by fading*

**Nível:** 🔴 Primária

**Eixo:** NARRATIVE ↑ → SAGA ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova temporalidade ao romper a sequência narrativa anterior.

**Nota genealógica original (EN):** No earlier aesthetic can be named as its maker — the cohort's material world is generated directly by postwar demographic and economic conditions rather than inherited from a prior style, and removing that generational ground collapses the whole system rather than one branch.

**Atmosfera e mood**

**Jeans que se data pelo desbotamento** — (1001 Aesthetics, interpretação)

Estética boomer: kodachrome de família, jeans desbotado, subúrbio dos anos 60–70.

**Paleta de cores** kodachrome quente, jeans, madeira

**Melhores usos:** nostalgia, editorial, retratos

**MidJourney:** `[tema], 1960s-70s family kodachrome nostalgia --v 6`

**Prompt universal (Seedream):** `Shot on Kodachrome 64 with a Canon AE-1 50mm f/1.8, a stylish baby boomer couple leans against a wood-paneled station wagon in a suburban backyard at golden hour, faded denim and floral sundress, lawn chairs and sprinkler mist catching low sun, authentic 1970s film grain and warm nostalgic halation, magazine-archive quality`

### **Chrono-Distortion**

**№ 154 / 1001** — *Frame that remembers and prophesies at once*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Nota genealógica original (EN):** Retro-futurist imagery, archival nostalgia, and speculative fiction converge in one frame; strip the archival strand and the memory disappears, strip the speculative strand and the prophecy does — recombination rather than reinterpretation of a single parent.

**Atmosfera e mood**

**O quadro que lembra e profetiza ao mesmo tempo** — (1001 Aesthetics, interpretação)

Distorção temporal: épocas sobrepostas num só quadro, eco de movimento, relógios e camadas de tempo derretendo.

**Paleta de cores** sépia sob néon, transições cromáticas

**Melhores usos:** conceitual, capas, sci-fi

**MidJourney:** `[tema], chrono distortion, overlapping time layers, motion echo --v 6`

**Prompt universal (Seedream):** `Ultra-detailed surreal artwork at 8k, a chrono-distortion composition where multiple eras overlap in one frame, ghosted motion echoes and melting clock layers, sepia past bleeding into neon future along torn temporal seams, Dalí meets Blade Runner, volumetric light through time-dust, museum-grade digital finish`

### **Cinematic**

**№ 156 / 1001** — *Cut, not the frame, carries the meaning*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Nota genealógica original (EN):** Theatrical staging, photographic lighting, and montage theory converge; remove montage and the cut stops carrying meaning, remove the lighting lineage and the frame loses its depth — several traditions welded into a grammar none supplies alone.

**Atmosfera e mood**

**É o corte, não o quadro, que carrega o sentido** — (1001 Aesthetics; códigos: MidLibrary)

Cinematográfico: composição anamórfica, color grading teal-orange, luz motivada e narrativa implícita no enquadramento.

**Paleta de cores** teal e laranja, pretos profundos

**Melhores usos:** narrativa, capas, thumbnails

**MidJourney:** `--sref 3769261565 --sw 1000` — veja também a seção “10 códigos cinematográficos” já nesta página

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a cinematic film still, teal-orange grading over motivated practical lighting, shallow depth isolating a figure in a rain-lit doorway, atmospheric haze and horizontal lens flare, implied story in a single frame in the manner of Roger Deakins, 35mm movie texture, 8k production still`

### **Fairycore**

**№ 318 / 1001** — *Pressed Flowers and Mushroom Rings in Dawn Mist*

**Nível:** ⚫ Quaternária

**Eixo:** NARRATIVE ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A estrutura narrativa é transmitida como continuidade reconhecível através do tempo.

**Atmosfera e mood**

**Flores prensadas e círculos de cogumelo na névoa do amanhecer** — (1001 Aesthetics; código: sref-midjourney.com, match aproximado)

Fairycore: floresta encantada em luz suave, cogumelos e orvalho, delicadeza de conto de fadas.

**Paleta de cores** verde musgo, rosa pétala, dourado de amanhecer

**Melhores usos:** fantasia, retratos, editorial delicado

**MidJourney:** `--sref 3482194348 --sw 1000` (Fairy Tale Portrait — match aproximado)

**LoRA (Civitai):** "Fairycore (World Morph)" (Anima/Illustrious/Z-Image) — civitai.com/models/1840174

**Prompt universal (Seedream):** `Shot on Mamiya RZ67 with 110mm lens, a fairycore scene, pressed flowers and mushroom rings in dawn mist, enchanted forest in soft diffused light with dew catching every petal, moss green and petal pink with dawn gold, Tim Walker whimsy, fairy-tale delicacy, 8k medium-format detail`

### **Frasurbane**

**№ 347 / 1001** — *'Frasier' Apartment: Jazz, Wine, and Eames*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Atmosfera e mood**

**O apartamento do 'Frasier': jazz, vinho e Eames** — (1001 Aesthetics, interpretação)

Urbano sofisticado anos 90: cobertura com poltrona Eames e vista da cidade, jazz e vinho tinto, bom gosto confortável e levemente esnobe.

**Paleta de cores** creme, caramelo de couro, cinza de skyline

**Melhores usos:** interiores, lifestyle, editorial

**MidJourney:** `[tema], 90s upscale apartment, Eames lounge chair, jazz and wine, city view --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R with 35mm lens, a frasurbane interior, 1990s upscale apartment with an Eames lounge chair and skyline view at dusk, red wine and jazz records, cream and leather caramel, Wallpaper* magazine polish, comfortable slightly snobbish good taste, 8k`

### **FuturAntérieur**

**№ 355 / 1001** — *Bohr-Atom Clock of a Tomorrow That Expired*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Atmosfera e mood**

**O relógio de átomo de Bohr de um amanhã que expirou** — (1001 Aesthetics, interpretação)

Futuro anterior: o amanhã imaginado pelos anos 1950–60 e nunca chegado, átomos e foguetes cromados, nostalgia de um futuro vencido.

**Paleta de cores** cromado, turquesa atômica, laranja retrô

**Melhores usos:** retrofuturismo, editorial, ilustração

**MidJourney:** `[tema], retro-futurism, atomic-age chrome and Bohr-atom clocks, a tomorrow that expired --v 6`

**Prompt universal (Seedream):** `Shot on a vintage Polaroid SX-70, a futur antérieur scene, atomic-age retro-futurism with Bohr-atom clocks and chrome rockets, turquoise and retro orange under saturated studio light, nostalgia for a tomorrow that never arrived, 1960s World's Fair gloss, 8k`

### **Hip Hop**

**№ 436 / 1001** — *Kool Herc Extends the Break at 1520 Sedgwick*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Atmosfera e mood**

**Kool Herc estende o break na 1520 Sedgwick** — (1001 Aesthetics, interpretação)

Hip hop: toca-discos duplos e graffiti no Bronx de 1973, boombox e adidas no asfalto, cultura nascendo de um breakbeat.

**Paleta de cores** spray vibrante, preto de vinil, dourado de corrente, tijolo do Bronx

**Melhores usos:** música, streetwear, editorial urbano

**MidJourney:** `[tema], old school hip hop aesthetic, twin turntables and graffiti in the 1973 Bronx, boombox and b-boy energy --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Tri-X with 35mm lens, a hip hop image, twin turntables extending the break at a 1973 Bronx block party, graffiti spray colors on brick, boombox and shell-toe sneakers, Jamel Shabazz street portraiture energy, a culture born from a breakbeat, 8k`

### **Hudson River School**

**№ 442 / 1001** — *Cole's Catskill Light Edits the Railroad Out*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem narrativa é preservada e reinstrumentada numa nova sequência temporal.

**Atmosfera e mood**

**A luz de Catskill de Cole edita a ferrovia para fora** — (1001 Aesthetics, interpretação)

Escola do Rio Hudson: paisagem americana sublime, luz dourada sobre vales intocados, a natureza pintada maior que a história.

**Paleta de cores** dourado de entardecer, verde de vale, azul de montanha distante

**Melhores usos:** paisagem, arte, editorial contemplativo

**MidJourney:** `[tema], Hudson River School painting, sublime Catskill golden light over untouched valley, luminist landscape --v 6`

**Prompt universal (Seedream):** `Museum-grade landscape painting reproduction, a Hudson River School painting, Catskill golden light editing the railroad out of the valley, sublime untouched American landscape in the manner of Bierstadt and Church, distant blue mountains under luminous sky, 8k`

### **Illustrationcore**

**№ 458 / 1001** — *Ink Margins Open a Door to a Drawn World*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A estrutura narrativa é transmitida como continuidade reconhecível através do tempo.

**Atmosfera e mood**

**As margens de tinta abrem uma porta para um mundo desenhado** — (1001 Aesthetics; código: Lummi, match aproximado)

Illustrationcore: livro ilustrado vivo, traço de tinta e cor de história, o desenhado como lugar habitável.

**Paleta de cores** cores de livro ilustrado, tinta quente, papel creme

**Melhores usos:** ilustração, infantil, editorial

**MidJourney:** `--sref 959307530 --sw 1000` (Storybook Hues — match aproximado)

**Prompt universal (Seedream):** `Warm storybook illustration, an illustrationcore image, ink margins opening a door to a drawn world, storybook hues and warm linework on cream paper with Beatrix Potter charm, the illustrated as a place you can live in, 8k`

### **Lanecore**

**№ 515 / 1001** — *Sodium lamp, wet asphalt, vanishing point*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Atmosfera e mood**

**Lâmpada de sódio, asfalto molhado, ponto de fuga** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lanecore: a rua vazia à noite, halação âmbar sobre asfalto molhado rumo ao ponto de fuga.

**Paleta de cores** âmbar de sódio, asfalto molhado, noite azulada

**Melhores usos:** fotografia noturna, editorial, cinema

**MidJourney:** `[tema], lanecore aesthetic, sodium lamp halo on wet asphalt, empty night lane, vanishing point --v 6`

**Prompt universal (Seedream):** `Shot on CineStill 800T with 50mm lens, a lanecore image, a lone sodium lamp haloing over wet asphalt toward a dissolving vanishing point, amber halation bleeding into bluish night, Todd Hido suburban loneliness seen through a fogged windshield, puddles doubling every light, an empty lane holding the feeling of almost home, 8k`

### **Mexican Muralism**

**№ 567 / 1001** — *Revolution Painted at Building Scale*

**Nível:** 🟣 Secundária

**Eixo:** NARRATIVE ↑ → DOMAIN ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem narrativa é preservada e reinstrumentada numa nova sequência temporal.

**Atmosfera e mood**

**Revolução pintada em escala de edifício** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Muralismo mexicano: história do povo em braços monumentais, terracota e vermelho revolucionário.

**Paleta de cores** terracota, vermelho revolucionário, ocre de parede

**Melhores usos:** arte pública, editorial, cultura

**MidJourney:** `[tema], Mexican muralism aesthetic, monumental workers painted at building scale, Diego Rivera fresco --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Mexican muralist fresco, a Mexican muralism image, monumental workers and campesinos painted at full building scale, terracotta and revolutionary red ground into wet plaster, Diego Rivera bodies with Siqueiros diagonal momentum and Orozco fire, history handed directly to the street that walks past it daily, 8k archival scan`

### **Narrative**

**№ 591 / 1001** — *Every Object Owes the Plot a Secret*

**Nível:** 🟣 Secundária

**Eixo:** NARRATIVE ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem narrativa é preservada e reinstrumentada numa nova sequência temporal.

**Atmosfera e mood**

**Cada objeto deve um segredo ao enredo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Narrativo: cena encenada onde tudo significa, uma história congelada um segundo antes da revelação.

**Paleta de cores** tons cinematográficos controlados

**Melhores usos:** fotografia conceitual, capas, storytelling

**MidJourney:** `[tema], narrative staged tableau, every object hiding a plot secret, cinematic frozen story --v 6`

**Prompt universal (Seedream):** `Shot on an 8x10 Deardorff with 210mm lens, a meticulously staged narrative tableau, every object placed to owe the plot a secret, a room frozen one second before revelation, Jeff Wall lightbox clarity, controlled cinematic color, 8k`

### **Neo Realism**

**№ 601 / 1001** — *Raw Truth Under Digital Compression*

**Nível:** 🟣 Secundária

**Eixo:** NARRATIVE ↑ → ESTHETICS ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem narrativa é preservada e reinstrumentada numa nova sequência temporal.

**Atmosfera e mood**

**Verdade crua sob compressão digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neorrealismo: a rua sem encenação, dignidade cotidiana capturada com artefatos honestos.

**Paleta de cores** tons de rua sem correção, cinzas reais

**Melhores usos:** documental, editorial, narrativa

**MidJourney:** `[tema], neo realism aesthetic, unstaged street truth, everyday dignity, honest compression --v 6`

**Prompt universal (Seedream):** `Low-fi digital photograph with honest compression artifacts, an unstaged street scene of everyday dignity, uncorrected real-world grays and worn facades, De Sica neorealist compassion carried into the phone-camera age, raw truth over polish, 8k upscale`

### **Oceanpunk**

**№ 639 / 1001** — *Survival Hardware Below the Waterline*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Tempos e linhagens distintas são reorganizados numa nova estrutura de história.

**Atmosfera e mood**

**Civilização reconstruída na linha d'água** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Oceanpunk: cidades flutuantes de ferrugem e kelp, escafandros remendados e tecnologia de sobrevivência marinha.

**Paleta de cores** verde-kelp, ferrugem, azul de tempestade

**Melhores usos:** concept art, games, capas

**MidJourney:** `[tema], oceanpunk aesthetic, floating rust cities kelp survival hardware, civilization at the waterline --v 6`

**Prompt universal (Seedream):** `Cinematic concept art, an oceanpunk floating city rebuilt at the waterline, rust towers lashed with kelp and patched diving suits drying on lines, survival hardware humming under a storm-blue sky, salt-corroded detail and dramatic scale, 8k production quality`

### **Pantanal**

**№ 665 / 1001** — *Water Rewrites the Landscape Each Season*

**Nível:** 🔴 Primária

**Eixo:** NARRATIVE ↑ → DENSITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A estrutura narrativa é transmitida como continuidade reconhecível através do tempo.

**Atmosfera e mood**

**Planície alagada em ouro e vida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pantanal: tuiuiús, capivaras e espelhos d'água ao amanhecer — a maior planície alagável do mundo em plena pulsação.

**Paleta de cores** dourado de amanhecer, verde de várzea, azul de arara

**Melhores usos:** natureza, documental, editorial brasileiro

**MidJourney:** `[tema], Pantanal aesthetic, flooded golden plains, jabiru storks and caiman mirrors --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 Mark II with 500mm lens, a Pantanal dawn, a jabiru stork lifting from mirror-still floodwater in molten gold light, caiman eyes and capybara silhouettes along the marsh grass, the world's largest wetland breathing in green and amber, wildlife-documentary sharpness, 8k`

### **Pre-Raphaelite**

**№ 718 / 1001** — *Victorian England Dreams in Medieval Color*

**Nível:** 🟤 Terciária

**Eixo:** NARRATIVE ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova temporalidade ao romper a sequência narrativa anterior.

**Nota genealógica original (EN):** When Rossetti, Hunt, and Millais signed their canvases PRB in 1848 and painted into a wet white ground rather than the studio brown the Academy required, they made the break legally binding — atmospheric recession, modelled shadow, and academic finish were named and refused as the founding act, not revised or absorbed.

**Atmosfera e mood**

**Cores de joia e trágicas donzelas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pré-rafaelita: cabelo cobre solto na correnteza, flores botânicamente exatas e o mito pintado fio a fio.

**Paleta de cores** verde de joia, cobre de cabelo, azul medieval

**Melhores usos:** arte, moda, editorial

**MidJourney:** `[tema], pre-raphaelite aesthetic, copper hair in the stream jewel colors, myth painted thread by thread --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Pre-Raphaelite painting, a tragic maiden with loose copper hair drifting among botanically exact flowers in a glassy stream, Millais Ophelia devotion with Rossetti jewel color, medieval blue and emerald rendered thread by thread, 8k archival scan`

### **Wanderer**

**№ 964 / 1001** — *Path Becomes Home, Stillness a Trap*

**Nível:** 🔴 Primária

**Eixo:** NARRATIVE ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova temporalidade ao romper a sequência narrativa anterior.

**Nota genealógica original (EN):** Three traditions that never touched converge independently on the same figure — the solitary body against enormous ground — which is the signature of convergent irreducibility, not hybrid fusion: no aesthetic can be decomposed out of the walking figure, because every candidate ancestor already presupposes it.

**Atmosfera e mood**

**O caminho virando casa, a quietude virando armadilha** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Andarilho: a mochila com poeira de três países, botas remendadas e o horizonte tratado como endereço fixo — partir como única direção estável.

**Paleta de cores** poeira de estrada, verde de lona gasta, azul de distância

**Melhores usos:** viagem, editorial, retratos

**MidJourney:** `[tema], wanderer aesthetic, three countries of dust patched boots horizon as fixed address, stillness a trap --v 6`

**Prompt universal (Seedream):** `Shot on Leica M4 with 35mm lens, a wanderer at first light, a lone figure with a dust-caked pack and patched boots walking the crown of an empty road toward mountains still in shadow, road dust and worn canvas green against distance blue, the path chosen as home and stillness as the only trap, restless open-ended grain, 8k scan`

## Leitura do padrão — o que as 19 estéticas confirmam

### O caso do zero absoluto

NARRATIVE ↓ não aparece em nenhum slot de nenhuma entrada da página — nem como primária (as 19 são todas ↑) nem como secundária (as 8 recepções são todas ↑). Na Station SCÈNE, é a única ação jamais suprimida: SYNTHESIS tem Fragmented, COHERENCE tem Deconstructivism e doze quedas secundárias, EMANATION tem Voidcore e Nihilism, ETERNITY tem Atlantis. O corpus não sabe calar uma história — pode selá-la no repertório como exercício, mas nenhuma estética viva paga esse preço.

### Atlantis — a recepção mais eloquente

NARRATIVE ↑ é recebida 8 vezes como slot secundário (Rough, Steampunk, Mythopoeic, New Hollywood, GISCARDPUNK, Grandmacore, Pathcore, Atlantis) — e a rima decisiva é № 071 Atlantis: ETERNITY ↓ → NARRATIVE ↑ · XY. Quando a permanência afunda, é a narrativa que a segura: "throne still ruling from the ocean floor". A única supressão de ETERNITY do corpus cai exatamente nos braços da única ação que nunca cai.

### Famílias recorrentes

→ MATTER leva 5 (4 ↑ — Wanderer, Acadian, Illustrationcore, Frasurbane: a história precisa de substrato que guarde marca; 1 ↓ — Hudson River School, a luz de Cole editando a ferrovia para fora da paisagem: narrar também é apagar matéria); → ILLUMINATION ↑ leva 3 (Cinematic, Fairycore, Oceanpunk) — a hora do dia como narrador; → DENSITY ↑ e → RESONANCE ↑ levam 2 cada.

### Polaridades

8 XX / 11 XY — leve pendor de ruptura, raro numa ação de arquivo; e 4 Primárias (Pantanal, Wanderer, Baby Boomers, Ashcan School), todas narrando o tempo pela matéria: a água que reescreve, o caminho que vira casa, o denim que se data, o bar na hora de fechar.

# ETERNITY — o Djed erguido novamente

<aside>
<img src="https://app.notion.com𓊽" alt="https://app.notion.com𓊽" width="40px" />

**Essência.** ETERNITY mede a resistência à erosão dos ciclos de moda. Seu ideograma retorna ao Djed, agora erguido como monumento — a coluna que sobreviveu à exposição, com estabilidade conquistada por ter sido testada. No registro ↑, a imagem recusa datar-se; no registro ↓, carimba deliberadamente a própria época e a assume com orgulho.

</aside>

## Prompt-mestre (imagem-síntese)

Prompt universal em inglês para ETERNITY, no mesmo formato dos prompts universais das 9 Posições: os colchetes recebem a matéria, o cenário e a prova de sobrevivência próprios de cada estética, enquanto a arquitetura preserva a lei do Djed — duração demonstrada, nunca declarada.

> **↑ ETERNITY — universal prompt.** A figure in [signature garment rendered era-proof] standing in monumental tested stillness, upright carriage that reads as earned rather than styled, a silhouette five different decades would each claim as their own, one hand resting composed with nothing borrowed from any current gestural fashion, a level patient gaze addressed to whoever is looking regardless of when, hair in a shape that recurs across the century and skin groomed to no season, photographed level on a classical portrait lens in soft directional daylight with slow falloff, [setting of indeterminate century] behind with no signage, no vehicle and no technology anywhere in frame, one quiet evidence that the frame has already outlasted something — [evidence of survival] — printed in a tonal range that will not date, the image composed to be mistaken for an archive print and for next month's cover at once.
> 

**Universal ETERNITY ↓ negative line (always pair with the ↑ prompt):**

> No logos, no phones or current devices, no this-season accessory or just-released object, no trend crop or aspect-ratio fashion, no seasonal colour grade, no dated posters or signage, no vehicles, no feed-native address, no grooming timestamped to the quarter, no effect that names a decade.
> 

**Como usar para as 58 estéticas da lista.** O slot [signature garment rendered era-proof] recebe a matéria da estética já purgada de tudo que a data: para **Ancient Egyptian**, linho e ouro batido com desgaste de mãos, não de fábrica; para **Classical**, o drapeado cuja proporção sobrevive à civilização que o cortou; para **Desert**, lã crua contra taipa — a disciplina da sede não tem século. O slot [setting of indeterminate century] vira pedra dinástica, colunata, muro de adobe, dobra de rocha com a aresta de um fóssil (**Paleontology**), interior de madeira escurecida por gerações (**Japanese (Heritage)** — e ali a [evidence of survival] é a emenda de ouro mais velha que as mãos que seguram a tigela). Para as quatro entradas que amplificam duração suprimindo outra coisa — **Romani** (DOMAIN ↓: durar sem território, a casa é o trajeto), **Memento Mori** (DENSITY ↓: durar aceitando o relógio na mesa), **Landscape** (INTENTIONALITY ↓: durar sem autor visível), **Ruins** (MATTER ↓: durar deixando a matéria ir) — mantenha o prompt ↑ e retire do quadro exatamente o que a seta ↓ retira. Para **Atlantis**, única supressão primária, inverta para o registro carimbado: o trono datado, afundado — e ainda narrando.

## Fundamentos do elemento

### Identidade, sobrevivência e vertical testada

**Identity.** Resistance to fashion-cycle erosion. Its ideogram returns to the Djed, now raised as monument: the spine that survived exposure, stability earned by having been tested. Where INTEGRITY measures internal continuity, ETERNITY measures survival in time. In an image this element is proven by a frame that refuses to date itself, or by one that time-stamps itself gladly.

**The law of the tested vertical.** The Djed is the system's first position raised as monument: the spine that survived exposure. Permanence in frame is never claimed, it is earned — the carriage must read as tested, not styled, monumental stillness without rigidity. An image that announces its own importance has already dated itself; the pillar does not explain why it is still standing.

**The law of the removed timestamp.** Every element is interrogated for its date before it enters the frame — hardware, eyewear, grade, crop, gesture, brow. What survives the interrogation is what five decades would each claim as their own. The discipline is subtractive: era-proofing is not adding the past but removing the present tense of fashion.

**The law of the double reading.** Timelessness is not nostalgia. A frame that quotes 1965 exactly is stamped 1965 — period costume is a timestamp pointing backwards. The Djed asks for no date at all: the finished image must sustain both readings at once, archive print and next month's cover, and refuse to confirm either.

## Corpo — postura, gesto e olhar

**Model posture & structure.** The tested vertical — upright carriage that reads as earned rather than styled; weight settled the way a column settles; monumental stillness without rigidity; a stance five different decades would each claim as their own.

**Gesture.** Durable, era-less gestures — a hand resting on a lapel, arms composed at the sides, fingers quiet; nothing borrowed from any current gestural fashion, nothing a caption from 1960 or 2040 would misread.

**The look — how the eyes behave.** The archive gaze: level, patient, addressed to whoever is looking regardless of when; an expression calibrated to outlast its viewer; dignity without period styling, memory without nostalgia.

**Look & styling continuity.** Unornamented tailoring in stone-coloured wool or an equally proven silhouette; closures honest, hems weighted; no logos, no devices, no contemporary eyewear, no hardware that timestamps; every piece answering the question "which decade?" with silence.

**Camera.** The classical portrait register — 85mm at f/5.6, tripod, level horizon; a technique so canonical it belongs to no year; nothing in the optics or processing that names a decade.

**Composition.** Stable frontal-classical construction — the figure as pillar, generous even wall or sky above; no trend crops, no tilted horizons, no aspect-ratio fashion; proportions any century of portraiture would recognize.

**Lighting.** North-light quality: soft directional daylight with slow falloff — the lighting lineage every era of portraiture shares; no signature effect, no grade that dates.

**Beauty detail.** Era-proof beauty — clean groomed skin with no trend finish, brows in their natural architecture, a lip in a tone photography has always carried well; hair in a shape that recurs across the century, a clean crop or a low knot; nothing datable to a season.

**Cenography.** Architecture of indeterminate century — stone, plaster, a column, a wall without fixtures; no vehicles, no signage, no technology; a setting that could ratify any date offered for it.

**Colour.** A tonal range that will not date — stone, bone, iron, oxide, deep neutrals held with midtone discipline; monochrome permitted when it reads as choice, not as filter; no grade timestamped to a year.

**Survival proof.** Plant one verifiable evidence that the frame has already outlasted something: a heel worn down by walking rather than by a stylist, a mend older than the person wearing it, stone steps hollowed by generations of feet, a hairline crack in the plaster that predates the sitting. One proof only, witnessed rather than installed — survival demonstrated, never captioned.

**Practitioner lines (from the codices).** Cathleen Naundorf (the codex's one Eternity-led hand, gesture Guardar): haute couture on large-format Polaroid and hand-finished prints — the gown photographed as museum object, the process itself refusing to date. Richard Avedon (Expression joined with Eternity, gesture Encantar): real motion and real reaction composed so permanently that the leap outlived every season it was shot in. Bert Stern (Expression joined with Eternity, gesture Encantar): The Last Sitting — the frame that holds because its subject's time was ending. George Hurrell (Illumination joined with Eternity, gesture Reger): hot key spotlights, deep sculpted shadow and retouched-to-marble skin — faces built to be permanent. Ethan James Green (Integrity joined with Eternity, gesture Testemunhar): statuesque black-and-white portraiture that carries the sitter into the canon. Luigi & Iango (Technique joined with Eternity, gesture Refinar): polished sculptural studio monuments where hair, light and body are engineered past their year.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Composed for timelessness: a silhouette that could carry any of five decades, no logos, no current devices, architecture of indeterminate century, a tonal range that will not date.

> **↑ Prompt.** A silhouette that could carry any of five decades, unornamented tailoring in stone-coloured wool, no logos, no devices, no contemporary eyewear, architecture of indeterminate century behind, printed in a tonal range that will not date, the image composed to be mistaken for both an archive print and next month's cover.
> 

> **↑ Negative line.** No newest object held to camera, no current phone in hand, no this-year's sole angled to the lens, no freshly dated poster, no feed-native gaze or crop, no seasonal grade, no logo, no signage, no vehicle, no grooming that names the quarter, no effect that names the decade.
> 

**↓ Suppressed — repertory.** Proudly of-the-moment: this season's object held to camera, current technology in hand, a dated poster in frame, the image time-stamped on purpose.

> **↓ Prompt.** This season only, the newest bag held straight to camera, a current phone in hand, this year's sneaker sole angled to the lens, a freshly dated event poster half-visible behind, the image time-stamped on purpose and glad of it.
> 

> **↓ Negative line.** No timeless tailoring, no stone-coloured restraint, no architecture of indeterminate century, no classical portrait register, no north-light lineage, no era-proof grooming, no tonal discipline hiding the year, no archive gaze — the frame proudly answers the question "when?" with a single date.
> 

## Estéticas relacionadas a ETERNITY (A–Z)

As 58 estéticas classificadas sob ETERNITY, em ordem alfabética. **Leitura das setas:** ↑ = presença do elemento · ↓ = ausência do elemento.

### **11 ANAMNESIS**

**№ 011 / 1001** — *Known before it was learned*

**Nível:** 🌀 Além da Quaternária

**Eixo:** ETERNITY ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

### **Ancient Egyptian**

**№ 046 / 1001** — *Scarab built for solar rebirth*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Escaravelho construído para renascer com o sol** — (1001 Aesthetics, interpretação)

Egito faraônico: figuras em perfil canônico, hieróglifos, escaravelhos solares, ouro e lápis-lazúli.

**Paleta de cores** ouro, lápis-lazúli, turquesa e ocre sobre papiro

**Melhores usos:** histórico, símbolos, ilustração

**MidJourney:** `[tema], ancient Egyptian wall painting, hieroglyphs --v 6`

**Prompt universal (Seedream):** `Museum artifact photograph shot on 80mm lens with raking light, an ancient Egyptian tomb painting with canonical profile figures and crisp hieroglyphs, gold lapis lazuli and turquoise pigment on ochre papyrus, scarab and solar symbols, visible mineral pigment texture, archaeological reproduction quality, 8k`

### **Antique**

**№ 052 / 1001** — *Patina no forger can fake*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → SAGA ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Atmosfera e mood**

**Pátina que nenhum falsário imita** — (1001 Aesthetics, interpretação)

Objetos antigos de verdade: pátina, desgaste honesto, madeira e latão envelhecidos por séculos.

**Paleta de cores** âmbar, marrons profundos, verdete

**Melhores usos:** still life, interiores, texturas

**MidJourney:** `[tema], antique patina still life --v 6`

**Prompt universal (Seedream):** `Still life photograph shot on 100mm macro lens with soft window light, aged brass and dark oak with centuries of authentic patina, worn gilt edges and verdigris in extreme tactile detail, dust drifting in the light beam, amber and deep brown palette, Dutch master quietness, 8k`

### **Aristocratic**

**№ 056 / 1001** — *Rank rehearsed for ten generations*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Gosto herdado** — (1001 Aesthetics, interpretação)

Aristocracia: retratos a óleo nas paredes, salões de mansão, riqueza geracional silenciosa.

**Paleta de cores** verdes profundos, bordô, dourado velho

**Melhores usos:** retratos, interiores, branding de luxo

**MidJourney:** `[tema], aristocratic old money portrait --v 6`

**Prompt universal (Seedream):** `Environmental portrait shot on large format with 90mm lens, an aristocrat in an inherited manor drawing room, oil-painted ancestors on deep green walls, burgundy velvet and old gold frames, soft window light through heavy curtains, quiet generational wealth, painterly Vanity Fair gravitas, 8k`

### **Atlantis**

**№ 071 / 1001** — *Throne still ruling from the ocean floor*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↓ → NARRATIVE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Nota genealógica original (EN):** Classical myth, romantic ruin painting, and speculative undersea imagery fuse into one sunken grammar; each donor stays separately traceable and none alone produces the drowned throne, marking hybridization rather than single-parent reinterpretation.

**Atmosfera e mood**

**Trono que ainda reina do fundo do mar** — (1001 Aesthetics, interpretação)

Atlântida: ruínas submersas, colunas cobertas de coral, luz aquática descendo em feixes.

**Paleta de cores** azul-profundo, verde-água, dourado afundado

**Melhores usos:** fantasia, cenários, capas

**MidJourney:** `[tema], sunken Atlantis ruins, underwater kingdom --v 6`

**Prompt universal (Seedream):** `Underwater cinematic image rendered at 8k, the sunken kingdom of Atlantis, marble columns crusted with coral and drifting kelp, shafts of aquatic light descending through deep teal water onto a drowned golden throne, schools of silver fish, volumetric god rays, mythic epic scale`

### **Autumn**

**№ 075 / 1001** — *Leaf that gets beautiful as it dies*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** One seasonal-pastoral lineage is inherited whole and rewritten toward decline — the same landscape vocabulary is kept and re-read as beauty in decay, a reinterpretation within a single line rather than a graft of several.

**Atmosfera e mood**

**Folha que fica bonita morrendo** — (1001 Aesthetics, interpretação)

Outono: folhas douradas, luz baixa e quente, melancolia acolhedora.

**Paleta de cores** âmbar, ferrugem, vinho, dourado

**Melhores usos:** sazonal, lifestyle, cenários

**MidJourney:** `[tema], autumn golden light aesthetic --v 6`

**Prompt universal (Seedream):** `Golden autumn photograph shot on 85mm f/1.4 lens, rust and amber leaves drifting through low warm backlight, misty morning park with long shadows, cozy melancholy in wine copper and honey tones, gentle bokeh and soft lens flare, cinematic seasonal warmth, 8k`

### **Bourbon**

**№ 113 / 1001** — *Slow legs down the glass at 94 proof*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Nota genealógica original (EN):** Distilling craft, American frontier iconography, and connoisseur ritual converge; strip the barrel craft and the amber has no source, strip the frontier lineage and the label loses its story, strip the ritual and the pour stops being read — a weld of several traditions.

**Atmosfera e mood**

**Pernas lentas descendo o copo a 94 graus** — (1001 Aesthetics, interpretação)

Bourbon: âmbar na luz quente, carvalho, couro, bar masculino acolhedor.

**Paleta de cores** âmbar, caramelo, madeira escura, couro

**Melhores usos:** bebidas, branding, interiores

**MidJourney:** `[tema], bourbon amber whiskey aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a bourbon still life, amber whiskey catching warm tungsten light as slow legs run down a crystal tumbler, charred oak barrel and worn leather armchair in deep shadow, cigar smoke ribboning through a shaft of light, dark honey grading, whiskey-advertisement perfection, 8k`

### **BUDDHISM**

**№ 133 / 1001** — *Stupa, lotus, and the geometry of release*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** No earlier aesthetic can be named as its maker — stupa, lotus and the geometry of release are generated directly by the doctrine itself, and each element bears load, so removing any one collapses the whole rather than a branch.

**Atmosfera e mood**

**Estupa, lótus e a geometria da libertação** — (1001 Aesthetics, interpretação)

Arte budista: Buda dourado, mandalas intrincadas, lótus, névoa de incenso e devoção serena.

**Paleta de cores** dourado, açafrão, vermelho profundo

**Melhores usos:** espiritual, meditação, ilustração

**MidJourney:** `[tema], Buddhist sacred art, mandala and lotus --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a Buddhist temple interior, golden Buddha rising from lotus motifs amid intricate mandala geometry, saffron robes and deep crimson silk trimmed in gold leaf, incense haze turning shafts of light solid, serene devotional stillness, warm sacred grading, museum-grade detail, 8k`

### **Celtic**

**№ 144 / 1001** — *Knotwork without end, stone aligned to solstice*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Nota genealógica original (EN):** Insular manuscript illumination, megalithic stone alignment, and metalwork ornament converge; strip the manuscript line and the knot loses its discipline, strip the stone tradition and the solstice geometry disappears — several lineages braided into one system.

**Atmosfera e mood**

**Nó sem fim, pedra alinhada ao solstício** — (1001 Aesthetics, interpretação)

Celta: entrelaçados infinitos, cruzes de pedra, verde de colina úmida e mito antigo.

**Paleta de cores** verdes profundos, dourado de manuscrito, pedra

**Melhores usos:** ornamento, fantasia, tatuagem

**MidJourney:** `[tema], Celtic knotwork illuminated manuscript style --v 6`

**Prompt universal (Seedream):** `Museum-grade capture at 8k, Celtic artwork of endless interlaced knotwork carved into a weathered stone cross, misty green hills and solstice-aligned megaliths behind, illuminated-manuscript gold and deep green details, dawn fog and dew on ancient lichen, Book of Kells lineage, mythic archival clarity`

### **Cerrado Indigenous**

**№ 145 / 1001** — *Fire-tended plaza*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Nota genealógica original (EN):** Fire-managed ecology, circular village planning, and ritual calendar braid into one spatial grammar; remove the burning regime and the plaza loses its landscape, remove the ritual and the circle loses its center — recombination across strands.

**Atmosfera e mood**

**Praça cuidada pelo fogo** — (1001 Aesthetics, interpretação)

Povos do Cerrado: aldeia circular, grafismos corporais, palha de buriti e savana dourada de ipês.

**Paleta de cores** ocres, urucum, jenipapo, dourado de savana

**Melhores usos:** cultura, documental, ilustração

**MidJourney:** `[tema], Brazilian Cerrado indigenous village, body paint patterns --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, an indigenous Cerrado village scene, circular plaza tended by fire at dusk, geometric body paint in urucum red and genipapo black glistening in ember light, buriti palms and golden savanna with flowering ipê trees, respectful documentary intimacy in the spirit of Claudia Andujar, rich natural grading, 8k`

### **Chinese**

**№ 149 / 1001** — *Ink, bracket, and the long patience of the brush*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SAGA ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** There is nothing earlier to descend from — brush discipline, bracket structure and the primacy of the written line are founding conditions rather than inheritances, and each bears load, so removing any one collapses the whole.

**Atmosfera e mood**

**Tinta, madeiramento e a longa paciência do pincel** — (1001 Aesthetics, interpretação)

Arte chinesa: pintura de tinta shui-mo, montanhas em névoa, vazio caligráfico e selo vermelho.

**Paleta de cores** tinta preta, papel cru, vermelho de selo

**Melhores usos:** paisagem, caligrafia, ilustração

**MidJourney:** `[tema], traditional Chinese ink wash painting, shui-mo --v 6`

**Prompt universal (Seedream):** `Museum-grade scan of a traditional Chinese ink wash painting, misty mountains and wind-bent pines in masterful shui-mo brushwork, generous negative space breathing between peaks, red seal stamp on aged xuan paper, ink gradations from bone-black to vapor gray, Song dynasty patience, 8k archival digitization`

### **Classical**

**№ 159 / 1001** — *Proportion that outlasts its civilization*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** No earlier aesthetic can be named as its maker — proportion, order and the module are asserted as first principles rather than inherited, and each bears load, so removing any one collapses the whole rather than a branch.

**Atmosfera e mood**

**Proporção que sobrevive à própria civilização** — (1001 Aesthetics, interpretação)

Clássico greco-romano: colunas e frontões, mármore esculpido, simetria e proporção áurea.

**Paleta de cores** mármore branco, pedra, azul de céu antigo

**Melhores usos:** arquitetura, escultura, editorial

**MidJourney:** `[tema], classical Greco-Roman style, marble and columns --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm lens, a classical Greco-Roman composition, marble columns and sculpted figures in golden-ratio symmetry, white Pentelic stone glowing under ancient blue sky, raking sun defining every flute and fold of drapery, timeless proportion and enduring order, museum-grade architectural clarity, 8k`

### **Desert**

**№ 220 / 1001** — *Adobe Wall, Black Tent, and the Discipline of Thirst*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Parede de adobe, tenda negra e a disciplina da sede** — (1001 Aesthetics, interpretação)

Deserto: dunas esculpidas pelo vento, adobe e tenda nômade, luz dura e sombra rara.

**Paleta de cores** areia, terracota, céu branco de calor

**Melhores usos:** paisagem, moda, editorial

**MidJourney:** `[tema], desert aesthetic, adobe walls and wind-carved dunes --v 6`

**Prompt universal (Seedream):** `Shot on 8x10 large format with 300mm lens, a desert scene, wind-carved dunes and adobe walls, black nomad tent against a heat-white sky, harsh vertical light and precious shade, the discipline of thirst, Sebastião Salgado grandeur, ultra-fine grain detail, 8k`

### **Digital Platonism**

**№ 226 / 1001** — *Geometry That Predates Its Renderer*

**Nível:** ⚫ Quaternária

**Eixo:** ETERNITY ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**A geometria que precede seu renderizador** — (1001 Aesthetics, interpretação)

Platonismo digital: sólidos perfeitos flutuando em espaço abstrato, formas ideais renderizadas, matemática pura visual.

**Paleta de cores** branco puro, gradientes ideais, luz sem fonte

**Melhores usos:** abstrato, tech, capas

**MidJourney:** `[tema], perfect platonic solids in abstract digital space --v 6`

**Prompt universal (Seedream):** `Ultra-crisp render at 8k, a digital platonism composition, perfect platonic solids floating in sourceless abstract light, ideal mathematical forms that predate their renderer, pure white space with immaculate gradients, soft contact shadows and flawless geometry, gallery-grade minimal precision`

### **Dust**

**№ 248 / 1001** — *Time, ground to powder, refusing to disappear*

**Nível:** ⚫ Quaternária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O tempo moído em pó, recusando desaparecer** — (1001 Aesthetics, interpretação)

Poeira: partículas suspensas em feixe de luz, superfícies veladas de cinza, abandono respirável.

**Paleta de cores** cinza-poeira, sépia, feixes de luz

**Melhores usos:** atmosfera, narrativa, texturas

**MidJourney:** `[tema], dust motes in a light beam, abandoned dusty interior --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 80mm lens, a dust-laden scene, particles suspended in a single hard beam of light, surfaces veiled in grey powder, time ground fine and refusing to disappear, breathable abandonment in an empty room, chiaroscuro stillness, museum-grade detail, 8k`

### **Early Christian**

**№ 254 / 1001** — *Gold Ground That Refuses Depth*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O fundo de ouro que recusa profundidade** — (1001 Aesthetics, interpretação)

Arte paleocristã: mosaico e ícone sobre ouro plano, figuras frontais hieráticas, símbolo acima da perspectiva.

**Paleta de cores** ouro de mosaico, azul e vermelho litúrgicos

**Melhores usos:** arte sacra, histórico, editorial

**MidJourney:** `[tema], early Christian mosaic, flat gold ground, hieratic figures --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of an early Christian mosaic, frontal hieratic figures on a flat gold ground that refuses depth, liturgical blue and red tesserae glittering in candlelight, each tile edge visible, symbol above perspective, Ravenna solemnity, 8k archival capture`

### **Eco**

**№ 263 / 1001** — *Build With What the Earth Remakes*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Atmosfera e mood**

**Construir com o que a terra refaz** — (1001 Aesthetics, interpretação)

Ecológico: bambu, adobe e madeira certificada, telhado verde, design que devolve o que toma.

**Paleta de cores** verdes vivos, madeira clara, terra

**Melhores usos:** sustentabilidade, arquitetura, branding

**MidJourney:** `[tema], eco design, bamboo and green roof architecture --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 32mm lens, an eco design scene, bamboo adobe and certified timber construction with living green roof under bright morning sun, building only with what the earth remakes, bright greens and pale wood, sustainable architecture editorial, 8k`

### **Eldercore**

**№ 271 / 1001** — *The Habit Passed Hand to Hand*

**Nível:** ⚫ Quaternária

**Eixo:** ETERNITY ↑ → THEME ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O hábito passado de mão em mão** — (1001 Aesthetics, interpretação)

Avôs e avós: cardigã de tricô e chá na xícara de sempre, fotos antigas na estante, sabedoria doméstica acolhedora.

**Paleta de cores** bege quente, tricô pastel, sépia de fotografia

**Melhores usos:** lifestyle, narrativa, editorial afetivo

**MidJourney:** `[tema], eldercore, knitted cardigans and grandmother's kitchen warmth --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 50mm lens, an eldercore scene, knitted cardigan and tea in the usual cup by afternoon window light, old photographs on the shelf and a recipe known by heart, warm beige and sepia, habits passed hand to hand, tender documentary warmth, 8k`

### **Endlesscore**

**№ 285 / 1001** — *Zoom That Never Finds a Floor*

**Nível:** ⚫ Quaternária

**Eixo:** ETERNITY ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Atmosfera e mood**

**O zoom que nunca encontra o chão** — (1001 Aesthetics, interpretação)

Sem fim: corredores que se repetem, escadas de Escher, recursão infinita e vertigem suave.

**Paleta de cores** gradientes contínuos, tons repetidos ao infinito

**Melhores usos:** surreal, conceitual, arte digital

**MidJourney:** `[tema], endless recursive space, Escher-like infinite repetition --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, an endlesscore image, recursive corridors and Escher stairs repeating without floor, infinite zoom and gentle vertigo, continuous gradients repeating to infinity, impossible geometry rendered with architectural precision, dreamlike depth`

### **Erudite**

**№ 302 / 1001** — *Gilt-Spined Codex, Annotated in the Margins*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O códice de lombada dourada, anotado nas margens** — (1001 Aesthetics, interpretação)

Erudito: biblioteca de estudo profundo, livros anotados à mão, conhecimento vivido e não exibido.

**Paleta de cores** couro de livro, dourado de lombada, verde de abajur

**Melhores usos:** editorial, acadêmico, retratos

**MidJourney:** `[tema], erudite study, gilt-spined codex annotated in the margins, deep scholarship --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL2 with 50mm lens, an erudite study scene, gilt-spined codex annotated by hand in the margins, book leather and lamp green under a brass reading light, dust motes above the page, knowledge lived rather than displayed, old-library chiaroscuro, 8k`

### **Farmcore**

**№ 322 / 1001** — *Denim Overalls, Hay Bales, and the Morning Egg Basket*

**Nível:** ⚫ Quaternária

**Eixo:** ETERNITY ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Macacão de brim, fardos de feno e a cesta de ovos da manhã** — (1001 Aesthetics, interpretação)

Fazenda: rotina rural honesta, celeiro e horta, trabalho com as mãos e recompensa simples.

**Paleta de cores** brim azul, feno dourado, vermelho de celeiro

**Melhores usos:** lifestyle rural, editorial, branding artesanal

**MidJourney:** `[tema], farmcore, denim overalls, hay bales and morning egg basket --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Gold 200 with 50mm lens, a farmcore scene, denim overalls and hay bales with the morning egg basket in golden dawn light, barn red and hay gold, dust motes drifting through the barn beam, honest rural routine and simple reward, warm snapshot nostalgia, 8k`

### **Fine Art**

**№ 331 / 1001** — *Oil on Canvas Behind the Gilt Museum Frame*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Óleo sobre tela atrás da moldura dourada do museu** — (1001 Aesthetics, interpretação)

Belas-artes: pintura de museu com pedigree, composição clássica e técnica consagrada, autoridade institucional da arte.

**Paleta de cores** verniz de museu, jewel tones clássicos

**Melhores usos:** arte, editorial, retratos formais

**MidJourney:** `[tema], museum fine art oil painting, classical composition, gilt frame quality --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a fine art oil painting on canvas, classical museum composition with consecrated technique in the lineage of Rembrandt and Vermeer, varnished jewel tones under raking gallery light, visible brush texture, institutional authority of art, 8k archival capture`

### **GALACTIC**

**№ 360 / 1001** — *Pillars of Creation in Assigned Wavelengths*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Atmosfera e mood**

**Os Pilares da Criação em comprimentos de onda atribuídos** — (1001 Aesthetics; código: comunidade MidJourney, match aproximado)

Galáctico: nebulosas em falsa cor de telescópio, poeira estelar esculpida em luz, o cosmos como catedral.

**Paleta de cores** magenta e verde de nebulosa, azul profundo, pontos estelares

**Melhores usos:** espaço, capas, fundos épicos

**MidJourney:** `--sref 4187313441 --sw 1000` (galaxies & nebulae — match aproximado)

**Prompt universal (Seedream):** `Ultra-detailed deep-space telescope composition, a galactic image, Pillars of Creation-like nebula in false-color wavelengths, sculpted stellar dust glowing magenta and green against deep blue, Hubble palette rendering, the cosmos as cathedral, 8k`

### **01 GENESIS**

**№ 001 / 1001** — *First mark on the blank field*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → EDITING ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

### **Grandiose**

**№ 395 / 1001** — *Versailles's 73-Metre Hall of Mirrors*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Os 73 metros da Galeria dos Espelhos de Versalhes** — (1001 Aesthetics, interpretação)

Grandioso: escala palaciana e repetição infinita de espelho e lustre, poder expresso em metros de ouro.

**Paleta de cores** dourado, cristal, mármore, luz de lustre

**Melhores usos:** luxo, histórico, editorial dramático

**MidJourney:** `[tema], grandiose palace hall, Versailles Hall of Mirrors scale, endless gold and chandeliers --v 6`

**Prompt universal (Seedream):** `Shot on Canon 5DS R with 17mm tilt-shift lens, a grandiose interior, the 73-metre Hall of Mirrors with endless repetition of chandeliers and gilded arches, gold crystal and marble in symmetrical perspective, power expressed in metres, 8k`

### **Grandmacore**

**№ 396 / 1001** — *Vanilla-Stained Recipe Card That Stayed*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → NARRATIVE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O cartão de receita manchado de baunilha que ficou** — (1001 Aesthetics; código: sref-midjourney.com, categoria Cottagecore, match aproximado)

Vócore: crochê e pão assando, porcelana florida e poltrona de lã, o aconchego herdado que não sai de moda.

**Paleta de cores** creme, rosa desbotado, verde de porcelana, lã quente

**Melhores usos:** lifestyle acolhedor, editorial, branding artesanal

**MidJourney:** `--sref 1409766794 --sw 1000` (Sunkissed Serenity — match aproximado)

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 50mm lens, a grandmacore scene, a vanilla-stained recipe card beside fresh bread and crochet, floral china and a wool armchair in kitchen window light, cream and faded rose, inherited coziness that never goes out of style, 8k`

### **Heritage**

**№ 426 / 1001** — *Loom Keeps the Teacher's Name in Every Warp*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O tear guarda o nome da mestra em cada urdidura** — (1001 Aesthetics, interpretação)

Herança: ofício transmitido de mão em mão, têxtil e técnica com genealogia, o passado vivo no objeto presente.

**Paleta de cores** lã natural, tintura vegetal, madeira de tear

**Melhores usos:** artesanato, branding de tradição, editorial

**MidJourney:** `[tema], heritage craft aesthetic, traditional loom weaving passed down generations, natural dyed wool --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 645 with 80mm lens, a heritage image, a wooden loom keeping the teacher's name in every warp thread, naturally dyed wool and inherited technique in soft workshop light, the past alive in the present object, 8k`

### **Hindu**

**№ 435 / 1001** — *Nataraja's Ring of Fire Holds Creation and Ruin*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O anel de fogo de Nataraja sustenta criação e ruína** — (1001 Aesthetics, interpretação)

Hindu: bronze de Shiva dançando no círculo de chamas, templo esculpido em camadas, o cósmico em cada detalhe.

**Paleta de cores** bronze de Chola, açafrão, vermelho de kumkum, dourado de templo

**Melhores usos:** espiritual, arte, editorial cultural

**MidJourney:** `[tema], Hindu sacred art, Nataraja bronze dancing in the ring of fire, carved temple layers, Chola bronze --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D850 with 35mm lens, a Hindu sacred image, Nataraja's ring of fire holding creation and ruin in one dance, Chola bronze with saffron and kumkum red, carved temple gopuram layers behind, Raghu Rai documentary depth, 8k`

### **Hunter-Gatherer**

**№ 443 / 1001** — *Fire Ring Holds Knowledge Within a Day's Walk*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O círculo de fogo guarda o conhecimento a um dia de caminhada** — (1001 Aesthetics, interpretação)

Caçador-coletor: fogueira e ferramentas de pedra, pele e cesto trançado, o mundo conhecido no raio do fogo.

**Paleta de cores** ocre, carvão, pele curtida, laranja de fogueira

**Melhores usos:** ancestral, narrativa, editorial

**MidJourney:** `[tema], hunter-gatherer aesthetic, fire ring with stone tools and woven baskets, ochre and charcoal ancestral scene --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R6 with 35mm lens by firelight, a hunter-gatherer image, a fire ring holding knowledge within a day's walk, stone tools and woven baskets, ochre and charcoal on cured hide, 8k`

### **Immortal**

**№ 460 / 1001** — *Roman Marble Face Refuses Its Century*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O rosto de mármore romano recusa o seu século** — (1001 Aesthetics, interpretação)

Imortal: retrato que atravessa milênios, mármore que continua olhando de volta, a permanência como estética.

**Paleta de cores** mármore pálido, sombra de museu, dourado de pátina

**Melhores usos:** retrato, arte, editorial atemporal

**MidJourney:** `[tema], immortal aesthetic, Roman marble portrait refusing its century, timeless museum light --v 6`

**Prompt universal (Seedream):** `Shot on Leica M11 Monochrom with 75mm lens, an immortal image, a Roman marble face refusing its century, a portrait still looking back across millennia, pale marble under quiet museum light, 8k`

### **08 INFINITY**

**№ 008 / 1001** — *The count that never lands*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

### **Islamic**

**№ 479 / 1001** — *Alhambra Muqarnas Turn Geometry Into Filtered Light*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**As muqarnas de Alhambra transformam geometria em luz filtrada** — (1001 Aesthetics; código: sref-midjourney.com, categoria Geometric, match aproximado)

Islâmico: geometria sagrada infinita, azulejo e muqarnas, o padrão como caminho para o divino.

**Paleta de cores** azul de azulejo, turquesa, dourado, branco de estuque

**Melhores usos:** arquitetura, padrão, editorial cultural

**MidJourney:** `--sref 674813697 --sw 1000` (categoria Geometric — match aproximado)

**Prompt universal (Seedream):** `Shot on Sigma fp L with 20mm lens, an Islamic art image, Alhambra muqarnas turning geometry into filtered light, infinite sacred tile patterns in blue turquoise and gold, the pattern as path to the divine, 8k`

### **Jaded**

**№ 484 / 1001** — *Wilted Rose Remains After the Party*

**Nível:** ⚫ Quaternária

**Eixo:** ETERNITY ↑ → NUANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Atmosfera e mood**

**A rosa murcha permanece depois da festa** — (1001 Aesthetics, interpretação)

Jaded: glamour esgotado, taça pela metade e confete no chão, a beleza vista tarde demais para emocionar.

**Paleta de cores** rosa murcho, dourado apagado, cinza de manhã seguinte

**Melhores usos:** editorial, narrativa, moda melancólica

**MidJourney:** `[tema], jaded aesthetic, wilted rose remaining after the party, half-empty glass and fallen confetti, morning-after light --v 6`

**Prompt universal (Seedream):** `Shot on Leica M10 with 35mm lens, a jaded image, a wilted rose remaining after the party, half-empty glass and confetti on the floor in morning-after grey, Nan Goldin unflinching intimacy, glamour seen too late to move anyone, 8k`

### **Japanese (Heritage)**

**№ 487 / 1001** — *Kintsugi Keeps the Crack Inside the Tea Bowl*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → NUANCE ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O kintsugi guarda a rachadura dentro da tigela de chá** — (1001 Aesthetics, interpretação)

Japonês herança: cerâmica reparada com ouro, tatame e casa de chá, a imperfeição honrada como história.

**Paleta de cores** cerâmica crua, ouro de kintsugi, verde de matcha, madeira de chá

**Melhores usos:** artesanato, wellness, editorial cultural

**MidJourney:** `[tema], Japanese heritage aesthetic, kintsugi keeping the crack inside the tea bowl, gold repair and tea house calm --v 6`

**Prompt universal (Seedream):** `Shot on Canon 5DS R with 100mm macro lens, a Japanese heritage image, kintsugi keeping the crack inside the tea bowl, gold repair honoring imperfection as history, raw ceramic and matcha green in soft tea-house window light, 8k`

### **Landscape**

**№ 514 / 1001** — *Constable skies and open horizon*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → INTENTIONALITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Céus de Constable e horizonte aberto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Paisagem: o clima pintado como o verdadeiro sujeito, cumulus monumentais sobre horizonte de colheita.

**Paleta de cores** dourado de feno, verde de rio, branco de nuvem

**Melhores usos:** arte, editorial, impressão

**MidJourney:** `[tema], landscape painting aesthetic, Constable skies, towering cumulus over open harvest horizon --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an English Romantic landscape painting, a Constable-sky scene over the Stour valley, towering cumulus dragging shadow across an open harvest horizon, hay gold and river green under shifting silver light, glazed oil depth with visible scumbled cloud work, the weather itself painted as the true protagonist, 8k archival scan`

### **Memento Mori**

**№ 561 / 1001** — *Skull Keeping Time on the Table*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → DENSITY ↓

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**A caveira marcando o tempo sobre a mesa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Memento mori: a mortalidade posta na natureza-morta, vela apagada, fruta passada e ampulheta.

**Paleta de cores** castanho de vanitas, osso, sombra profunda

**Melhores usos:** natureza-morta, arte, editorial conceitual

**MidJourney:** `[tema], memento mori aesthetic, skull and snuffed candle on a vanitas table, hourglass and fading fruit --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Dutch vanitas still life, a memento mori image, a skull keeping time beside a snuffed candle and fading fruit, bone and deep umber under raking light, Pieter Claesz precision, mortality set on the table, 8k`

### **Mysticism**

**№ 585 / 1001** — *Symbols Built to Hide Their Door*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Símbolos construídos para esconder a própria porta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Misticismo: geometria sagrada em fumaça de incenso, diagramas que apontam para o indizível.

**Paleta de cores** índigo, dourado de vela, fumaça de incenso

**Melhores usos:** arte espiritual, editorial, capa

**MidJourney:** `[tema], mysticism aesthetic, sacred geometry glowing through incense smoke by candlelight, hidden door --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 500EL with 80mm lens by candle and incense light, a mysticism image, sacred geometry glowing faintly through drifting smoke in indigo darkness, Hilma af Klint diagram color hovering over ritual gold, a symbol legible only to those already inside, the door hidden by its own map, initiate stillness, 8k`

### **Noble**

**№ 627 / 1001** — *Aristocratic Conduct After the Throne*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**Dignidade que sobrevive ao trono** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nobre: postura, palavra mantida e um casaco bem cuidado — a aristocracia como conduta, não herança.

**Paleta de cores** grafite, camurça, branco de colarinho

**Melhores usos:** retratos, branding, editorial

**MidJourney:** `[tema], noble aesthetic, dignity that outlives the throne, bearing as aristocracy --v 6`

**Prompt universal (Seedream):** `Shot on Leica M3 with 90mm lens, a noble portrait, upright bearing and a well-kept graphite coat in cold window light, dignity worn as conduct rather than inheritance, suede and crisp collar white, quiet unbroken gaze, timeless print quality, 8k`

### **Nocturnal**

**№ 628 / 1001** — *Darkness Reveals What Daylight Flattens*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Atmosfera e mood**

**O mundo que começa quando as luzes apagam** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Noturno: a cidade às 3h, vitrines apagadas, gatos e semáforos conversando sozinhos.

**Paleta de cores** azul de madrugada, sódio esparso, preto vivo

**Melhores usos:** street, editorial, mood

**MidJourney:** `[tema], nocturnal aesthetic, 3am city, the world that begins when lights go out --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z6 with 24mm f/1.4 lens at ISO 12800, a nocturnal street at 3am, darkened shopfronts and one sodium lamp talking to an empty traffic light, deep midnight blue with living black shadows, the world that begins after closing time, clean high-ISO atmosphere, 8k`

### **Overgrown**

**№ 657 / 1001** — *Nature Reclaims the Clean Line*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Atmosfera e mood**

**A natureza retomando a planta baixa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Supercrescido: hera engolindo a casa modernista, raiz abrindo o piso — a paciência verde vencendo.

**Paleta de cores** verde invasor, concreto manchado, luz filtrada

**Melhores usos:** conceito, editorial, arte

**MidJourney:** `[tema], overgrown aesthetic, ivy swallowing a modernist house, green patience winning --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D780 with 35mm lens, an overgrown scene, ivy swallowing a modernist glass house while roots lift the terrazzo floor, invading green over stained concrete in filtered canopy light, nature quietly reclaiming the floor plan, lush decay detail, 8k`

### **Paleontology**

**№ 661 / 1001** — *Deep Time Held in One Fossil Edge*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Atmosfera e mood**

**Tempo profundo segurado pela borda** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Paleontologia: amonites em espiral, fósseis sob luz baixa e a paciência mineral de milhões de anos.

**Paleta de cores** pedra sedimentar, ocre fóssil, cinza de museu

**Melhores usos:** ciência, editorial, arte

**MidJourney:** `[tema], paleontology aesthetic, spiral ammonite fossil under low light, deep time held at the edge --v 6`

**Prompt universal (Seedream):** `Museum-grade specimen photograph, a spiral ammonite fossil lit low across its sediment bed, deep time held at the fractured edge of stone, fossil ochre against museum gray, every suture line and mineral ripple in focus, quiet scientific reverence, 8k`

### **Pathcore**

**№ 674 / 1001** — *Route Matters More Than Arrival*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → NARRATIVE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Atmosfera e mood**

**A rota vale mais que a chegada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pathcore: trilhas sinuosas, pegadas e bifurcações — o caminho como protagonista da imagem.

**Paleta de cores** terra batida, verde de beirada, névoa de manhã

**Melhores usos:** natureza, conceito, editorial

**MidJourney:** `[tema], pathcore aesthetic, winding trail and forks, the route over the arrival --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-T4 with 23mm lens, a pathcore scene, a winding dirt trail forking into morning mist with footprints choosing one branch, packed earth and trail-edge green pulling the eye forward, the route framed as protagonist over any arrival, quiet depth, 8k`

### **Pompeian**

**№ 695 / 1001** — *Disaster Seals the Room in Place*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Atmosfera e mood**

**Vermelho selado pelo desastre** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pompeiano: salas de afresco vermelho-lacre, figuras míticas e o cotidiano romano preservado pela cinza.

**Paleta de cores** vermelho pompeiano, ocre, negro de fresco

**Melhores usos:** histórico, interiores, editorial

**MidJourney:** `[tema], Pompeian aesthetic, red fresco room mythic figures, daily life sealed by ash --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of a Pompeian fresco room, walls of deep Pompeian red framing mythic figures and painted garlands, ochre panels and fresco black preserved by the ash that ended them, raking light over two-thousand-year-old brushwork, archaeological detail, 8k`

### **Pre-Columbian**

**№ 714 / 1001** — *Before Europe, After Forever*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por transmissão

**Nota (PT):** A duração é transmitida como continuidade reconhecível, resistindo à erosão dos ciclos.

**Nota genealógica original (EN):** The zero concept, computed inside Maya notation by 350 CE and never imported, anchors a mathematical grammar that passed from Olmec colossal heads through Maya stelae to Inca quipus without losing its cosmological spine — the same cyclical-time, matter-as-instrument logic transmitted across civilizations and catastrophes alike.

**Atmosfera e mood**

**Antes da Europa, depois do para sempre** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pré-colombiano: ouro moche, basalto olmeca e cosmologias inteiras gravadas sem uma palavra europeia.

**Paleta de cores** ouro antigo, basalto, jade

**Melhores usos:** histórico, cultura, editorial

**MidJourney:** `[tema], pre-Columbian aesthetic, Moche gold Olmec basalt jade cosmology, before Europe after forever --v 6`

**Prompt universal (Seedream):** `Museum-grade artifact photograph, a pre-Columbian arrangement of Moche hammered gold and a carved Olmec basalt head with jade ornaments, whole cosmologies engraved without a single European word, ancient gold against volcanic stone in reverent low light, 8k documentation`

### **Preppy**

**№ 717 / 1001** — *Old Money Whispers Louder Than New Money Screams*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** The grammar of collar, crest, and monogram was transposed from the British country house and regimental club to the American campus and New England harbor without severing its lineage — the inherited code was re-instrumented for leisure, keeping every heraldic referent while shedding the formal-service context that once commanded them.

**Atmosfera e mood**

**O código de vestir do dinheiro discreto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Preppy: madras, mocassim de barco e suéter no ombro — o uniforme de verão da costa leste.

**Paleta de cores** madras, marinho, branco de vela

**Melhores usos:** moda, lifestyle, branding

**MidJourney:** `[tema], preppy aesthetic, madras and boat shoes sweater over shoulders, east coast summer code --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS-1V with 85mm lens, a preppy portrait at a yacht club dock, madras shorts and boat shoes with a navy sweater knotted over the shoulders, sail white and old-money restraint in salt-bright light, the east coast summer dress code whispered not stated, 8k`

### **Rapa Nui**

**№ 741 / 1001** — *Stone Faces Holding an Island's Memory*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** The Eastern Polynesian marae-ahu tradition arrives intact — the cleared platform, the ancestor stood upright, the dead kept close to the settlement — then Rapa Nui re-instruments it: the modest ancestor-upright swells to tuff colossus, the platform multiplies into rows of hundreds, and the whole system turns inland, re-routing the grammar of ancestral protection through scale and orientation without cutting it.

**Atmosfera e mood**

**Memória da ilha guardada em pedra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rapa Nui: moai contra o crepúsculo do Pacífico, gramados vulcânicos e a escala do anseio ancestral.

**Paleta de cores** basalto, verde vulcânico, crepúsculo do Pacífico

**Melhores usos:** cultura, viagem, editorial

**MidJourney:** `[tema], Rapa Nui aesthetic, moai against Pacific dusk, island memory carved in stone --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 501C with 60mm lens, a Rapa Nui scene, a line of moai turned inland against deepening Pacific dusk, volcanic basalt faces above wind-flattened green, island memory carved at ancestral scale, last violet light on weathered stone, 8k`

### **Republican**

**№ 754 / 1001** — *Virtue Made Visible*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** The Greco-Roman grammar of trabeated stone and open colonnade arrives intact, and Republican aesthetic re-instruments it by routing the inherited order through civic obligation rather than imperial display, so that the same portico reads as collective covenant rather than personal authority.

**Atmosfera e mood**

**A virtude romana sem retoque** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Republicano: bustos de mármore com rugas e cicatrizes — o verismo da Roma antiga tratando idade como credencial.

**Paleta de cores** mármore, sombra de museu, toga crua

**Melhores usos:** histórico, arte, editorial

**MidJourney:** `[tema], Roman republican verism aesthetic, marble bust with wrinkles and scars, age as credential --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of a Roman Republican portrait bust, veristic marble recording every wrinkle scar and stern furrow, age presented as political credential rather than flaw, raw toga drapery below an unflattered face, dramatic museum side light, 8k documentation`

### **Retro-Futurism**

**№ 757 / 1001** — *Tomorrow According to Yesterday*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** Futurism's machine-worship and forward-lean forms arrive intact, and Retro-Futurism re-instruments them by reversing the temporal direction — the inherited chrome parabola and rocket fin are kept factory-fresh but aimed backward at a promise already expired, so the same aerodynamic conviction that once signalled tomorrow now signals a tomorrow that never came.

**Atmosfera e mood**

**O amanhã conforme prometido em 1959** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Retrofuturismo: carros voadores googie, cidades em cúpula e o otimismo atômico do futuro que não veio.

**Paleta de cores** turquesa atômico, laranja de foguete, cromo de capa

**Melhores usos:** sci-fi, capas, editorial

**MidJourney:** `[tema], retro-futurism aesthetic, 1959 googie flying cars domed cities, the tomorrow that never came --v 6`

**Prompt universal (Seedream):** `Ultra-detailed retro-futurist illustration, tomorrow as promised in 1959, googie flying cars sweeping over domed cities with boomerang antennas, atomic turquoise and rocket orange under chrome-bright skies, magazine-cover optimism for a future that never arrived, 8k`

### **Romani**

**№ 769 / 1001** — *Home Is the Journey*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → DOMAIN ↓

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** No prior aesthetic exists to inherit; centuries of migration out of the Indian subcontinent gathered textile logic, metalwork, and ornament from every territory the route crossed into a single portable grammar, and the accumulation itself is the origin — strip away the layered cloth and the hammered silver and no underlying movement waits beneath to carry the identity forward, only lived ethnic continuity with nothing prior to name as parent.

**Atmosfera e mood**

**O lar é a própria jornada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Romani: caravanas pintadas, música à beira do fogo e uma cultura que carrega casa e história na estrada — retratada com dignidade.

**Paleta de cores** vermelho de xale, madeira pintada, dourado de fogueira

**Melhores usos:** documental respeitoso, cultura, editorial

**MidJourney:** `[tema], Romani aesthetic, painted caravan fireside music, home carried on the road, dignified documentary --v 6`

**Prompt universal (Seedream):** `Shot on Leica M6 with 35mm lens, a respectful documentary portrait of Romani life, a hand-painted caravan glowing behind fireside violin music at dusk, shawl red and carved painted wood in firelight gold, home carried proudly along the journey, dignity in every frame, 8k`

### **Ruins**

**№ 776 / 1001** — *Time's Artistry*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → MATTER ↓

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** Romanticism's Burkean distinction between beauty and terror and the Picturesque eye arrive as the parent's own internal tools rather than as a second lineage, and Ruins re-instruments them by centering decay itself as the subject those tools always circled but never held — no recombination occurs, only a single inheritance deepened until the broken thing outranks the intact one.

**Atmosfera e mood**

**A arte autoral do tempo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ruínas: colunas caídas, arcos abertos para o céu e a vegetação assinando a coautoria da obra.

**Paleta de cores** pedra dourada, verde de reconquista, azul de céu aberto

**Melhores usos:** viagem, histórico, arte

**MidJourney:** `[tema], ruins aesthetic, fallen columns arches open to the sky, time's own artistry --v 6`

**Prompt universal (Seedream):** `Shot on Linhof Technika with 150mm lens, a ruins scene at golden hour, fallen columns and a broken arch open straight to the sky while wild fig writes its co-authorship through the stones, honeyed masonry and reclaiming green, time credited as the final artist, 8k`

### **Shabby Chic**

**№ 801 / 1001** — *Imperfectly Elegant*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** The English Country House tradition's slipcovered ease and tolerance for age arrive as the single dominant parent, with an Arts and Crafts inheritance folded into the same lineage rather than crossed with it, and Shabby Chic re-instruments that inheritance by turning tolerated wear into the actively sought goal — patrician ease reframed as deliberate distressing — so an aristocratic acceptance of age becomes, one turn later, a manufactured practice of wear kept on purpose.

**Atmosfera e mood**

**Imperfeitamente elegante** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Shabby chic: tinta descascada com proporção, floral desbotado e a pátina cultivada como assinatura de charme.

**Paleta de cores** branco descascado, rosa desbotado, verde sálvia

**Melhores usos:** interiores, casamentos, editorial

**MidJourney:** `[tema], shabby chic aesthetic, peeling paint faded florals cultivated patina, imperfectly elegant --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R6 with 50mm lens, a shabby chic interior, a chalk-white dresser with artfully peeling paint under faded rose linens and a chipped chandelier, sage green and blush worn soft by decades, patina cultivated as the signature of charm, gentle window light, 8k`

### **Soft Countriana**

**№ 824 / 1001** — *Gentle Rural Embrace*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** The pastoral tradition's ranking of rural life above the city arrives as the single parent, and Soft Countriana re-instruments that inheritance by translating an old literary ideal into a suburban consumer mood, so a georgic ideal becomes, one turn later, a limewashed kitchen where every surface has been aged on purpose.

**Atmosfera e mood**

**O abraço gentil do campo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Countriana suave: vestidos de algodão no varal, torta esfriando na janela e o interior rural sem nenhuma pressa.

**Paleta de cores** amarelo de manteiga, azul de gingham, verde de pasto

**Melhores usos:** lifestyle, editorial, branding

**MidJourney:** `[tema], soft countriana aesthetic, cotton dresses on the line pie cooling on the sill, gentle rural embrace --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya C330 with 80mm lens, a soft countriana scene, cotton dresses breathing on a clothesline while a pie cools on the farmhouse sill, butter yellow and gingham blue over pasture green, the countryside offering its gentlest embrace with no hurry anywhere, tender film warmth, 8k`

### **Statuesque**

**№ 844 / 1001** — *Human Form Ascends to Sculptural Perfection*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** Classical Antiquity's proportional canon arrives as the single parent, and Statuesque re-instruments that inheritance by narrowing it to one obsession, the human body held still, so a civic architectural grammar becomes, one turn later, a single figure disciplined into permanence on a plinth.

**Atmosfera e mood**

**A forma humana ascendendo à perfeição escultórica** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Escultural humano: postura de mármore, drapeado caíndo em colunas e o corpo iluminado como monumento.

**Paleta de cores** mármore quente, drapeado marfim, sombra de pedestal

**Melhores usos:** moda, retratos, editorial

**MidJourney:** `[tema], statuesque aesthetic, marble posture columnar drapery, the human form as monument --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 503CW with 120mm lens, a statuesque portrait, a figure in columnar ivory drapery holding marble stillness on a low pedestal, warm stone tones sculpted by one raked key light, the human form ascending deliberately into sculpture, monumental quiet perfection, 8k`

### **Teenage Dream**

**№ 896 / 1001** — *Eternal Summer Between Locker and Prom*

**Nível:** 🟣 Secundária

**Eixo:** ETERNITY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Nota (PT):** Uma linhagem durável é preservada e reinstrumentada sem adquirir um timestamp passageiro.

**Nota genealógica original (EN):** Americana's idealized small-town youth supplies the single parent, and Teenage Dream re-instruments that inheritance by swapping the soda fountain for the feed and the letterman jacket for the low-rise jean.

**Atmosfera e mood**

**O verão eterno entre o armário e o baile** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Teenage dream: corsage no pulso, estacionamento do baile ao entardecer e a certeza de que aquela música foi escrita para aquela noite.

**Paleta de cores** rosa de corsage, dourado de estacionamento, azul de fim de baile

**Melhores usos:** nostalgia, editorial, capas

**MidJourney:** `[tema], teenage dream aesthetic, wrist corsage prom parking lot at dusk, eternal summer between locker and prom --v 6`

**Prompt universal (Seedream):** `Shot on Contax Aria with 50mm lens on Portra 800, a teenage dream evening, a wrist corsage catching the last parking-lot gold outside prom as taffeta and rented suits lean on someone's car, corsage pink into end-of-dance blue, the certainty that this song was written for tonight, tender nostalgic glow, 8k scan`

### **Timeless**

**№ 900 / 1001** — *Design That Outlives the Trend Cycle*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → EDITING ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** The system owns no decomposable parent — it predates and supplies the proportional grammar that Classicism and Minimalism inherit rather than invent — the signature of a foundational node, not a reinterpretation.

**Atmosfera e mood**

**O design que sobrevive ao ciclo das tendências** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Atemporal: a poltrona Eames de 1956 ainda perfeita, o rádio de Dieter Rams ainda atual — o objeto que nenhuma década consegue datar.

**Paleta de cores** couro conhaque, jacarandá, branco de Braun

**Melhores usos:** design, produto, editorial

**MidJourney:** `[tema], timeless design aesthetic, 1956 Eames lounge Dieter Rams radio, design that outlives the trend cycle --v 6`

**Prompt universal (Seedream):** `Shot on Leica M6 with 50mm lens, a timeless design still life, a 1956 Eames lounge chair in cognac leather and rosewood beside a Dieter Rams Braun radio on a bare oak floor, forms no decade has managed to date, quiet daylight proving the trend cycle wrong again, immaculate restraint, 8k`

### **Vampire**

**№ 936 / 1001** — *Immortality Tailored in Black Velvet*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** The undead-aristocrat grammar survives the removal of any single literary vehicle — the Gothic novel, the Romantic lyric — and generates its own descendants, Paranormal Romance and Gothic-punk, rather than descending from them, the signature of a foundational node, not a reinterpretation.

**Atmosfera e mood**

**A imortalidade alfaiatada em veludo negro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vampiro: o salão à luz de candelabro, renda no punho e a paciência de quem tem séculos — a elegância como único apetite confessável.

**Paleta de cores** negro de veludo, vermelho de taça, marfim de vela

**Melhores usos:** gótico, editorial, capas

**MidJourney:** `[tema], vampire aesthetic, candelabra salon lace cuffs centuries of patience, immortality tailored in black velvet --v 6`

**Prompt universal (Seedream):** `Shot on Leica Noctilux 50mm at f/0.95, a vampire portrait by candelabra, black velvet tailoring and lace cuffs holding a garnet glass in a salon the color of old ivory, candlelight carving pale patience honed over centuries, elegance as the only confessable appetite, sumptuous gothic shallow focus, 8k`

### **Vanitas**

**№ 939 / 1001** — *Beauty Posed Beside Its Expiration*

**Nível:** 🔴 Primária

**Eixo:** ETERNITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota (PT):** A entrada funda uma nova relação com o tempo ao romper o ciclo anterior.

**Nota genealógica original (EN):** The memento-mori object-syntax survives the removal of the devotional tradition that preceded it and cannot be decomposed into a single parent aesthetic, the signature of a foundational node, not a reinterpretation.

**Atmosfera e mood**

**A beleza posando ao lado do próprio vencimento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vanitas: o crânio entre tulipas, a ampulheta ao lado da fruta madura demais e a vela apagada — o barroco lembrando que tudo isso passa.

**Paleta de cores** negro barroco, dourado de vela extinta, pétala murchando

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], vanitas aesthetic, skull among tulips hourglass beside overripe fruit, beauty posed with its expiration --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Dutch vanitas painting, a polished skull among drooping tulips beside an hourglass a snuffed candle and fruit one day past ripe, baroque black warmed by extinguished gold, beauty formally posed next to its own expiration date, exquisite mortal detail, 8k scan`

### **Y3K**

**№ 989 / 1001** — *Tomorrow Excavated as Post-Digital Ruin*

**Nível:** 🟤 Terciária

**Eixo:** ETERNITY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Linhagens de épocas distintas são reorganizadas numa forma resistente à datação.

**Nota genealógica original (EN):** Four lineages leave fingerprints with none decisive — cyberpunk's near-future dread, Afrofuturism's culturally situated deep-time speculation, Y2K's chrome vocabulary, and Post-Internet Art's gallery-dissolving logic — and the recombinant move of projecting a millennium forward is what none of the parents performed alone.

**Atmosfera e mood**

**O amanhã escavado como ruína pós-digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Y3K: servidores cobertos de musgo cromado, interfaces fossilizadas na rocha e a arqueologia do nosso futuro feita por quem vier depois dele.

**Paleta de cores** cromo oxidado, verde de musgo técnico, âmbar de fóssil digital

**Melhores usos:** conceito, sci-fi, arte digital

**MidJourney:** `[tema], y3k aesthetic, moss-grown chrome servers interfaces fossilized in rock, our future excavated as ruin --v 6`

**Prompt universal (Seedream):** `Ultra-detailed speculative render, a Y3K excavation, archaeologists of a later civilization brushing chrome-mossed server racks and interfaces fossilized into sedimentary rock, oxidized chrome and technical green under digital-fossil amber light, our tomorrow catalogued as a post-digital ruin, haunting deep-time wonder, 8k`

## Leitura do padrão — o que as 58 estéticas confirmam

### O caso Atlantis

Uma única supressão primária em 58 entradas — e é a rima que fecha o glossário: ETERNITY ↓ → NARRATIVE ↑, XY. A única queda de duração do corpus cai exatamente nos braços da única ação que nunca é suprimida em lugar nenhum: quando o trono afunda, a história assume. A permanência pode falhar; a narração da falha, não.

### A ação mais recebida do corpus

63 entradas de outras ações terminam em → ETERNITY — quase o dobro de EMANATIO (33), a segunda mais recebida. Tudo quer durar. Das 63 recepções, 51 são ↑ e 12 são ↓ — e as 12 supressões formam um mapa preciso de quem abre mão de durar: **Wabi-Sabi** e **Still Life** (MATTER ↑ → ETERNITY ↓: a matéria que aceita morrer é o que a torna presente), **Noir** (a sombra pertence à sua noite), as quatro de SEMIOTICS (**Americana**, **Exoticism**, **Imperial Russian**, **Factory Pomo** — códigos que sabem ser de época), as quatro de EMANATIO (**Social Media III**, **Scented Bloom**, **Ephemeral**, **Dazecore** — o que irradia agora paga com o depois) e **FuturAntérieur** (o amanhã que expirou por design).

### Dezessete famílias recorrentes

MATTER domina com 13 — 12 ↑ (Ancient Egyptian, Desert, Dust, Pre-Columbian, Statuesque, Autumn, Pompeian, Bourbon, Cerrado Indigenous, Y3K, Overgrown, Paleontology) e 1 ↓ (Ruins): o que quer durar procura substância. SEMIOTICS ↑ 9 (Vanitas, Erudite, Hindu, Celtic, Early Christian, Retro-Futurism, Preppy, Republican, GALACTIC): duração como código legível. SAGA ↑ 6 (Chinese, Aristocratic, Hunter-Gatherer, Noble, Farmcore, Antique): duração como linhagem contada. INTEGRITY ↑ 4 (Classical, Eco, Heritage, Immortal) e RESONANCE ↑ 4 (INFINITY, Teenage Dream, Rapa Nui, Soft Countriana). EDITING ↑ 3 (BUDDHISM, Timeless, GENESIS — durar é cortar) e ILLUMINATION ↑ 3 (Mysticism, Nocturnal, ANAMNESIS). Pares: EMANATIO ↑ (Vampire, Grandiose), NARRATIVE ↑ (Grandmacore, Pathcore — e Atlantis chega por queda), NUANCE ↑ (Japanese (Heritage), Jaded), TECHNIQUE ↑ (Digital Platonism, Fine Art). Solitárias: COHERENCE ↑ (Islamic, a primária que abre a lista), DENSITY ↑ (Endlesscore), ESTHETICS ↑ (Shabby Chic), THEME ↑ (Eldercore) — e as quatro secundárias suprimidas já mapeadas acima (Romani, Memento Mori, Landscape, Ruins).

### Polaridades

39 XX / 19 XY — dois terços da lista em continuidade, transmissão e revisão dominando. O contraste com EMANATION (41/43, quase empate) é o veredito da estação: presença irradia por qualquer via, mas duração se herda.

### O teste operacional

24 primárias em 58 entradas — quase metade da lista. ETERNITY não é um acabamento que se aplica; é onde as estéticas fundadoras já moram (Islamic, BUDDHISM, Hindu, Chinese, Ancient Egyptian, Pre-Columbian, Classical, GENESIS, INFINITY). O Djed fecha a mesa como a abriu: a primeira posição do sistema, agora monumento — o que se sustenta sem testemunhas é exatamente o que o mundo ergue no final.

# 4 DIRECTIONS — Ideograma 23, o veredito temporal

<aside>
<img src="https://app.notion.com䷖" alt="https://app.notion.com䷖" width="40px" />

**Essência.** DIRECTION não ocupa os níveis Primário ou Secundário. Ela responde a uma única pergunta: **o que esta estética faz com a gramática que herdou?** Seu ideograma é a Linha Mutante do I Ching — a linha inteira que se parte e a linha partida que se recompõe: o instante da transformação recebe uma marca própria. XX indica continuidade; XY indica disrupção.

</aside>

## Prompt-mestre (cláusula de direção)

Em cada prompt, DIRECTION entra por último como **uma cláusula de fechamento acompanhada de uma evidência visível no quadro**. A cláusula não descreve um clima: declara a operação temporal aplicada à herança — transmissão, revisão, ruptura ou rearticulação. Para linhagens autorais por direção, consulte o repertório indicado na referência original: [**IDsetters ↔ ID-MISE-EN-SCÈNE.**](https://app.notion.com/p/IDsetters-ID-MISE-EN-SC-NE-3ab7f812e162805db594e2f83065b58e?pvs=21).

## Fundamentos do veredito temporal

### Função, eixo e prova visual

- **XX — continuidade:** a gramática herdada permanece ativa, seja transmitida integralmente, seja revista com dívida reconhecida.
- **XY — disrupção:** a gramática herdada deixa de operar como antes, seja por uma ruptura demonstrável, seja por uma recombinação relacional.
- **Prova obrigatória:** a operação deve aparecer em uma evidência visível — nunca depender apenas da legenda ou da intenção declarada.

## Quatro direções (A–Z)

As quatro operações temporais em ordem alfabética. **Leitura do eixo:** XX = continuidade · XY = disrupção.

### **Rearticulação**

**Código:** RA — Rearticulation

**Eixo / polaridade:** XY — disrupção por rearticulação

**Nota (PT):** Códigos retirados de suas origens são recombinados numa nova gramática relacional.

**Identidade original (EN):** Codes broken from their origins and recombined into a new relational grammar; previously separated or asymmetrical languages joined on new terms.

**Tradução visual original (EN):** Combine two normally separate references into one working relationship in the frame. Not a collage: both sources stay identifiable, neither dominates, and the syntax between them is the subject.

**Cláusula de fechamento (EN):** …two visual languages that never share a frame joined here into one working grammar, each still identifiable, the relationship itself the subject.

**Exemplo de prompt (EN):** A liturgical vestment's embroidery grammar executed in motocross armour panels and worn as one continuous garment on a cathedral forecourt at dawn, both source languages legible, neither dominant, the new syntax between them photographed as the point.

### **Revisão**

**Código:** RV — Revision

**Eixo / polaridade:** XX — continuidade por revisão

**Nota (PT):** A herança permanece reconhecível, mas um parâmetro é deliberadamente reinstrumentado.

**Identidade original (EN):** The inheritance retained and fully legible, but re-instrumented: interpretation, use, medium, or authority changed while the debt stays acknowledged.

**Tradução visual original (EN):** Keep the reference recognizable and update exactly one parameter, making the update conspicuous. One substitution, everything else faithful.

**Cláusula de fechamento (EN):** …the inherited form kept fully recognizable while one element is visibly updated, and only one.

**Exemplo de prompt (EN):** A classic riding habit cut exactly to its nineteenth-century pattern but sewn in high-visibility technical nylon, everything else faithful, the boots, the crop, the stone stable yard, the single material substitution carrying the whole image.

### **Ruptura**

**Código:** RP — Rupture

**Eixo / polaridade:** XY — disrupção por ruptura

**Nota (PT):** Uma regra constitutiva da herança é quebrada, produzindo um antes e um depois demonstráveis.

**Identidade original (EN):** A constitutive rule of the inheritance broken, with a demonstrable before and after; the parent grammar rendered inert at that point.

**Tradução visual original (EN):** Stage one visible break of the source's own rule inside the frame. The violated convention must be identifiable from the image itself, ideally with the obedient world still visible at the edges.

**Cláusula de fechamento (EN):** …one rule of the inherited grammar visibly broken inside the frame, the break staged as the image's central event.

**Exemplo de prompt (EN):** A couture ballgown worn with its internal corsetry deliberately exposed and strapped outside the silk, the garment's most hidden rule dragged into daylight, guests in traditional dress blurred in the background still obeying the code the foreground has just ended.

### **Transmissão**

**Código:** TR — Transmission

**Eixo / polaridade:** XX — continuidade por transmissão

**Nota (PT):** A gramática herdada é preservada e transmitida integralmente, sem ironia nem deslocamento.

**Identidade original (EN):** The inherited grammar preserved and passed on intact. Reverence without irony; the source tradition carried forward as received.

**Tradução visual original (EN):** Render the inherited reference faithfully and recognizably: period-correct craft, the lighting lineage of the source carried forward, no trend markers, nothing that timestamps the image to a season.

**Cláusula de fechamento (EN):** …the whole scene rendered in the faithful light and styling grammar of its source tradition, period-correct in every visible detail, carried forward without commentary.

**Exemplo de prompt (EN):** An atelier at dusk, a master fitting a garment on an apprentice using the same brass pins, the same chalk, the same window light the trade has used for a century, every gesture and tool exactly as inherited, the photograph indistinguishable in manner from one taken sixty years earlier.

## Leitura do padrão — o que as treze ações revelam juntas

The nine positions got **monuments**; the thirteen actions got **instruments**. Look at the register shift across the table: the position side is architectural and ceremonial — a pillar, a sworn triangle, a solstice-tuned entrance stone, a sun, a tree. The action side is a workbench: a handheld ritual object, a navel-stone, a written instruction, an administrator, a code character, a ratio, an editor's mark, an ink scale, a geometric construction, a diagram, a lab plate, a filing system, and the pillar again. That's not accidental — the manuscript says it directly: this side of the system is "não o ser, o *dirigir*."[[1]](https://app.notion.com/p/IDsetters-ID-MISE-EN-SC-NE-3ab7f812e162805db594e2f83065b58e?pvs=21) Positions are what stands; actions are what the hand picks up. The ideograms themselves perform the difference.

The four stations give the sequence its dramaturgy — ID (Vajra, Omphalos): *decide before moving*; MISE (Squared Circle, Crescent, Li, Spiral): *build the scene that speaks for you*; EN (Obelos, Notan): *cut every gesture that isn't yours*; SCÈNE (Vesica, Knot, Plate, Quipu, Djed): *project the memory you leave*.[[1]](https://app.notion.com/p/IDsetters-ID-MISE-EN-SC-NE-3ab7f812e162805db594e2f83065b58e?pvs=21) Read the glyph types against the stations and a second pattern surfaces: the deciding station holds **objects** (things gripped), the composing station holds **laws** (procedure, administration, code, ratio), the cutting station holds **marks** (the two glyphs that are literally notations a hand adds to something else — the editor's spit, the ink dilution), and the impact station holds **records** (constructions, knots, patterns, archives — things that persist after the hand leaves). Decide with objects, compose with laws, cut with marks, endure as records. The table teaches its own workflow through the *kind* of thing each glyph is.

And the whole sequence is bracketed by the two exceptions. It opens (position 1) and closes (element 22) with the only repeated glyph — the Djed, spine and monument, the system's thesis. And buried at position 20 sits the only glyph whose form no hand draws — the cymatic plate, Vedic in its sound, drawn by vibration alone, guarding the one property no copy can fake. Between a symbol that must repeat to mean anything and a pattern that dies the moment it's repeated without its sound, the system states its two deepest rules with the composition of the table itself: **continuity must be re-erected, and authenticity cannot be transcribed.** Everything else — the eleven instruments in between — is the craft of living between those two facts.

## Registro de decisão — as cinco questões resolvidas

An earlier audit of these entries raised five flags; all five were resolved by amendment, none by replacing a glyph. The Vajra's diamond-half was restored to its Identity line — diamond, what nothing cuts; thunderbolt, what cuts everything. *Notan* was kept, anchored to 濃淡 — the ink-concentration scale itself — with a guard keeping the romanized word out of prompts. The Tibet repetition (Vajra + Endless Knot) was declared the table's first deliberate rhyme, and the I Ching (Li + the Changing Line) its second: decision and continuity from one land, the sign and the sign's change from one grammar. The Quipu received the same citation clause the Sankofa carries — plus its many hands: nobody narrates alone. And the Golden Spiral was renamed the Phi Spiral, with a guard keeping *golden ratio* and *golden spiral* out of every prompt. The table stands as dealt: no ideogram swapped, the Djed bookend untouched.