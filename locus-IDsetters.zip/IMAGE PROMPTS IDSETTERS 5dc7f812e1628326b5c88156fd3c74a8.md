# IMAGE PROMPTS IDSETTERS

# INTEGRITY — o Djed

<aside>
🏛️

**Essência:** INTEGRITY é a disciplina da lei única — a mesma regra estrutural precisa ser legível no corpo, no figurino, na luz e na arquitetura, do plano geral ao close extremo, sem cortes, sem segunda luz e sem contradição entre escalas. O teste é sempre o mesmo: *essa regra ainda vale se eu chegar mais perto?* Seu ideograma é o Djed — a coluna de quatro travessas reerguida em cerimônia pública todos os anos: estabilidade como ato repetido, nunca como estado.

</aside>

## Prompt-mestre (imagem-síntese)

> A figure holds one continuous structural logic across every scale of the frame — feet, hips, shoulders, and gaze stacked on the same vertical line, weight even on both feet or in one symmetric contrapposto that reads the same from across the room as it does in the tightest close crop. The camera is tripod-still, at the subject's own eye level, zero tilt, symmetric framing, treating the frame like a plumb line rather than an opinion; if it moves, it moves as one unbroken push from a full establishing shot to an extreme detail, with the same structural fact remaining legible at every distance travelled — no cut, no hidden edit. Verticals in the architecture — a colonnade, a row of doorframes, aligned mullions — converge toward the point the figure occupies, with one anchored, heavy mass low in the frame giving it gravity; shadow falls straight down the same vertical the body occupies, and nothing in the frame leans. One light source, one temperature, one direction, sustained from the nearest fold of cloth to the farthest wall, so nothing shifts in color or angle between foreground and background. The garment carries a single construction logic from hem to collar to accessory — finished inside as carefully as outside, one exposed seam standing for the whole system, nothing decorative that isn't load-bearing. Skin and grooming read as one identical fact whether seen from across the room or in extreme close-up — same texture, same tone, same finish, true pore and vein left legible rather than smoothed. The setting is real, load-bearing architecture the body could actually inhabit, any aging or patina physically real rather than simulated. Wherever the composition allows it, a mirror, polished floor, or reflection doubles the figure with an exact, unbroken match — same fold, same expression, same light — standing as the image's own witness that nothing was cut.
> 

**Linha negativa — o que este elemento proíbe:**

> No second light source of a different color temperature, no leaning vertical, no mixed construction systems in one garment, no set dressing from conflicting eras, no mismatched reflection or doubling, no detail that changes between the wide frame and the close crop, no expressive flourish — no extended hand, no thrown head, no raised brow — no fidgeting hands, no darting eyes, no smile assembled after the eyes have committed, no smoothed or averaged skin, no simulated or printed patina.
> 

## Fundamentos do elemento

**Identity.** Continuity of one organizing principle across every level of the system — private construction matching public silhouette, backstage matching onstage, with no cut between them. Its ideogram is the Djed, the four-crossbar spine re-erected in public ceremony every year: stability as a repeated act, never a state, verified by an unmoving witness rather than declared as an achievement. Two verbs occupy the pillar: Vislumbrar / Beholding, the vision received and hosted before it is explained, and Testemunhar / Witnessing, the witness whose stillness itself becomes testimony. Behind the pillar, two supporting forces set its terms without ever entering the frame as themselves — one converges the composition into a single plumb line, the other compresses the whole set into one anchored weight at its base. In an image this element is proven when a single structural logic is legible in garment, body, and architecture at once, and when that logic survives the trip from the widest establishing frame to the closest possible detail without a single fact changing along the way. (Distinct from ETERNITY, 22 — the same pillar raised again as public monument and tested by exposure over time; here the test is unwitnessed continuity, not survival.)

## Corpo — alinhamento, postura e gesto

**Macro/micro alignment.** Any claim the wide shot makes — an open stance, a welcoming hand, a relaxed jaw — must be corroborated by the smallest visible detail available, because the two scales are read as one fractal, not two separate images. A hand extended in generosity but gripped tense at the knuckle, a confident stance undercut by curled toes just visible at the hem, a warm expression that stops at the mouth and never reaches the eyes: these are the exact micro-signatures of the failure state, invisible at a glance and unmissable once seen, because this element exists specifically to survive that kind of inspection.

**Model posture & structure.** The body is checked at four stacked alignments before the shutter — feet, hips, shoulders, gaze — the same four crossbars that hold the Djed upright; if one drifts the whole column reads as tilted, and no styling disguises it. Weight sits even on both feet, or in a single classical contrapposto that a camera at the model's own eye level would still read as symmetric rather than candid. The spine stays stacked whether the frame is a full-length establishing shot or an extreme close crop on the collarbone — the posture does not relax between takes.

### **Gesture.** Two gestures alternate as the pillar's only verbs.

**Vislumbrar · Beholding:** the gaze lifts above and past the lens toward a point the frame cannot show, a micro-lift of the chin, total stillness in a figure who saw first and will not point or share it, hands quiet at the seams. 

**Testemunhar · Witnessing:** the gaze drops level and direct into the lens, frontal, unflinching, receiving rather than performing, the head never tilted because a tilt would editorialize the testimony. Both forbid narrative flourish — an extended hand, a thrown head, a raised brow — any expressive excess reads as decoration on a structure that is supposed to hold without decoration. A held body carries its full emotional range without ever showing the seam between registers — the same spine can hold ferocity or tenderness, but never a hand that fidgets at a hem, an eye that darts to check its own effect, or a smile assembled a half-second after the eyes already committed to it; those over-justifying micro-movements are the visible tells of a cut, caught by the eye before the mind can name what felt wrong.

## Regras de imagem — do figurino à prova de continuidade

**Look & styling continuity.** One construction logic runs from hem to collar to accessory: a single seaming system, a single fastening logic, nothing that photographs better than it is actually built — the garment's private construction must equal its public silhouette, because a garment whose inside contradicts its outside is the visual definition of a continuity error. Finished-inside-as-outside tailoring, one exposed seam standing in for the whole logic, no applied hardware that is not load-bearing. Nothing about the look shifts between a wide shot and a macro crop — no forgotten hem, no mismatched thread, no accessory that means one thing far away and another thing up close.

**Camera.** Tripod-still, chest height, zero tilt, symmetric framing — the camera behaves like a plumb line, not an opinion. Positioned at the subject's own eye level, never above or below, so proportion reads as architecture rather than candid observation. The governing discipline is a single unbroken take: the camera may push in from a full establishing shot to an extreme close detail, or pull out again, but the same structural fact must remain legible at every distance travelled — no cut, no hidden edit, no detail permitted to differ between the far frame and the near one.

**Composition.** Centred, axially symmetric, weighted like a classical elevation. Converging verticals — a colonnade, a row of doorframes, mullions — gather toward the single point the figure occupies, borrowing the logic of two crowns of force converging before release to give the frame its plumb line. A single anchored mass low in the frame — one dark column, one stone base, one piece of furniture too heavy to move — gives the composition its gravity, borrowing the logic of a whole world compressed into one place without overflowing. Shadow falls straight down the same vertical the body occupies; nothing in the frame leans.

**Lighting.** One source, one temperature, one direction, sustained across the entire depth of field — from the nearest fold of cloth to the farthest wall — so nothing shifts in colour or angle between foreground and background. A single soft key from directly above or a fixed raking angle, museum light on a statue, shadow falling straight down rather than sideways. The failure state of this element is exactly two light sources of different temperature crossing the frame from opposite sides — the visible signature of a system that cannot hold one truth across a single shot.

**Beauty detail.** Skin and grooming read as one fact whether the frame is a full-body establishing shot or an extreme close-up on the face — the same finish, the same texture, the same intensity of colour at both distances, because a face that looks different up close than it did from across the room is a continuity break the eye catches immediately. Hard, sculptural light on the skin so texture registers as testimony rather than disguise — pore, faint vein, or true tone left legible rather than smoothed into an average, with the full tonal range of the skin respected rather than flattened. No cosmetic decision contradicts itself between the two distances: the same lip, the same brow, the same sheen, near or far.

**Cenography.** Real, load-bearing architecture the body could actually inhabit — stone interiors, columns, thresholds, a room built with a ceiling nobody intends to photograph, because a set built only where the lens looks is a surface, not a room, and the body answers a real wall differently than a painted flat. Nothing decorative that is not structurally necessary — a stripped set holding only the objects the composition's plumb line and anchor weight actually require, no clutter, no prop from an unrelated era. Any aging or patina present is physically real — hand-worn stone, hand-aged plaster — never a simulated or printed surface standing in for one.

**Color continuity.** One colour temperature and one contrast curve held across the whole image the way a single grade is held across an entire film — skin, stone, and cloth all answering to the same light law whether they sit in the foreground or dissolve into the background, so no region of the frame has been secretly corrected to look better than the region beside it. Its failure state is a warmer face against a cooler wall, or a foreground carrying more contrast than the depth behind it — two grades caught sharing one frame.

**Continuity proof.** Wherever the composition allows a doubling — a mirror, a polished floor, a window's reflection, a second figure in matching dress — the reflected or repeated fact matches exactly: same fold, same expression, same light. This device is the image's own witness, the closest a still photograph can come to proving the unbroken take; the smallest mismatch here is the single most legible failure this element can produce.

## Polaridades — repertório amplificado (↑) e suprimido (↓)

**↑ Amplified — repertory.** One construction rule repeated at every scale: the garment's pleat interval echoing the architecture's rhythm, spine stacked, shoulders level, weight on both feet, verticals plumb, one light temperature, one material logic from hem to ceiling, the same fact holding true from the establishing frame to the closest possible crop.

> **↑ Prompt.** A figure stands dead-centre in a colonnade of pale limestone, spine stacked and shoulders level, gaze level and direct into the lens or lifted just past it toward something only they have seen, hands quiet at the seams and relaxed at the knuckle even in the tightest crop, wearing a floor-length garment whose knife pleats repeat the columns' fluting at the same interval and whose visible seams are finished as carefully as its silhouette, one cool daylight source falling parallel to every vertical from the nearest fold to the farthest column and holding the same colour temperature from the nearest thread to the farthest stone, a polished floor doubling the whole figure in exact unbroken reflection, skin left true-textured and identically lit whether read from across the room or in close crop, nothing in the frame leaning, the same structural rhythm legible in stone, cloth, skin, and posture at every distance the camera travels.
> 

> **↑ Negative line.** No second light source of a different colour temperature, no leaning vertical, no mixed construction systems in one garment, no set dressing from conflicting eras, no mismatched reflection or doubling, no detail that changes between the wide frame and the close crop, no expressive flourish — no extended hand, no thrown head, no raised brow — no fidgeting hands, no darting eyes, no smile assembled after the eyes have committed, no smoothed or averaged skin, no simulated or printed patina.
> 

**↓ Suppressed — repertory.** Inconsistent logics coexisting unresolved: garments mixing construction systems, asymmetric stance, set dressing from conflicting registers, two unmatched light sources, misaligned seams kept in frame, a face or a hem that reads one way from afar and another way in close-up.

> **↓ Prompt.** A model mid-stride in a room where nothing agrees, one half of the outfit sharply tailored wool and the other loose unhemmed muslin, a plastic chair beside a gilded console, two light sources of different colour temperature crossing from opposite sides, a mirror in frame reflecting a slightly different garment than the one worn, seams deliberately misaligned, hands held open in a gesture of ease while the knuckles whiten with tension in close crop, a detail visible only in close crop — a smudged lip, a mismatched button — that contradicts what the wide shot implied, the frame holding all of it without resolving any of it.
> 

> **↓ Negative line.** No plumb symmetric framing, no single sustained light temperature and direction, no matching reflection, no single construction logic running hem to collar, no macro detail corroborating the wide claim, no anchored mass, no converging verticals, nothing in the frame resolved into one law.
> 

## Estéticas relacionadas a INTEGRITY (A–Z)

As 30 estéticas classificadas sob INTEGRITY, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary · ⚫ Quaternary), eixo secundário e polaridade (XX — continuidade · XY — disrupção).

### **Art Singulier**

**№ 061 / 1001** — *Palace built one postal round at a time*

**Nível:** ⚫ Quaternary · **Eixo:** INTEGRITY ↑ → EDITING ↓

**Polaridade:** XY — disruption by rearticulation

Sits generations downstream of several traditions at once — outsider making, vernacular monument-building, and the collector's cabinet — and the accumulation logic that results behaves like none of its donors alone, confirming hybridization rather than a reworking of one line.

**Atmosfera e mood**

**Palácio construído uma ronda postal por vez** — (1001 Aesthetics, interpretação)

Arte singular: ambientes visionários autoconstruídos por décadas, como o Palais Idéal do carteiro Cheval.

**Paleta de cores** pedra, mosaico, terrosos

**Melhores usos:** arquitetura fantástica, cenários

**MidJourney:** `[tema], art singulier visionary environment, Palais Idéal --v 6`

**Prompt universal (Seedream):** `Wide-angle photograph shot on 24mm lens at blue hour, a visionary outsider palace hand-built from stones and mosaic over decades, obsessive ornamental detail encrusting every surface, warm lantern light against the twilight, Facteur Cheval Palais Idéal wonder, cinematic architectural detail, 8k`

### **Bauhaus**

**№ 081 / 1001** — *School That Refused Ornament*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → SYNTHESIS ↑

**Polaridade:** XY — disruption by rearticulation

Several lineages are welded here — the craft-workshop model, industrial standardization, and abstract-art pedagogy — and each remains separately traceable; strip the workshop and the school loses its hand, strip industry and the standard has no purpose, so fusion rather than single-parent reinterpretation.

**Atmosfera e mood**

**A escola que recusou o ornamento** — (1001 Aesthetics, interpretação)

Bauhaus: forma segue função, geometria pura, cores primárias, Dessau 1925.

**Paleta de cores** vermelho, amarelo, azul, preto, branco

**Melhores usos:** design, pôsteres, branding

**MidJourney:** `[tema], Bauhaus design, geometric primary colors --v 6`

**Prompt universal (Seedream):** `Ultra-crisp graphic composition rendered at 8k, Bauhaus geometric design of pure circles triangles and squares in primary red yellow and blue over a black and white grid, functional sans-serif typography, flat matte print texture like a 1925 Dessau exhibition poster, Herbert Bayer precision, perfectly balanced asymmetry, gallery-print quality`

### **Beaux-Arts**

**№ 084 / 1001** — *Stone that argues rank on your behalf*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuity by revision

A single classical lineage is carried forward whole and re-argued at civic scale — the orders, axis and hierarchy are kept intact and redeployed as institutional authority, a reinterpretation within one line rather than a graft of several.

**Atmosfera e mood**

**Pedra que defende seu status por você** — (1001 Aesthetics, interpretação)

Beaux-Arts: fachadas monumentais, colunas pareadas, ornamento clássico institucional.

**Paleta de cores** pedra clara, bronze, cinza monumental

**Melhores usos:** arquitetura, cenários, institucional

**MidJourney:** `[tema], Beaux-Arts monumental architecture --v 6`

**Prompt universal (Seedream):** `Shot on a large format camera with 90mm tilt-shift lens, a monumental Beaux-Arts limestone facade with paired Corinthian columns, sculpted garlands and bronze lamps glowing at blue hour, perfect architectural symmetry, warm interior light spilling down grand steps, crisp stone detail and hairline shadows, museum-grade architectural photography, 8k`

### **Bohemian**

**№ 104 / 1001** — *Last thing left to pawn*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → DOMAIN ↓

**Polaridade:** XY — disruption by rupture

No earlier style produces this — the law that material poverty is proof of artistic seriousness arrives as a root condition of a way of living, and removing voluntary precarity collapses the entire system rather than one of its branches.

**Atmosfera e mood**

**A última coisa que sobrou para penhorar** — (1001 Aesthetics, interpretação)

Boemia de ateliê: veludo gasto, telas empilhadas, arte acima do conforto.

**Paleta de cores** vinho, mostarda, tecidos desbotados

**Melhores usos:** retratos, interiores, editorial

**MidJourney:** `[tema], bohemian artist garret, worn velvet --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with 35mm lens, a bohemian artist's garret at midnight, worn velvet armchair and canvases stacked against peeling walls, candlelight and half-empty wine glasses throwing warm shadows, paint-stained hands rolling a cigarette, poverty traded for freedom, romantic amber grain, cinematic La Bohème atmosphere, 8k`

### **Brazilian Modernism**

**№ 123 / 1001** — *Curve the International Style forbade*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → SYNTHESIS ↑

**Polaridade:** XY — disruption by rupture

Its governing claim — that the free curve is structurally and culturally necessary where orthodoxy forbade it — is asserted at the root rather than inherited, and removing the curve collapses the entire argument instead of one branch.

**Atmosfera e mood**

**A curva que o International Style proibiu** — (1001 Aesthetics, interpretação)

Modernismo brasileiro: curvas sensuais de Niemeyer, jardins ondulados de Burle Marx, azulejos de Athos Bulcão.

**Paleta de cores** branco de concreto, azul de azulejo, verdes tropicais

**Melhores usos:** arquitetura, design, padronagem

**MidJourney:** `[tema], Brazilian modernism, Niemeyer curves and Burle Marx gardens --v 6`

**Prompt universal (Seedream):** `Museum-grade architectural capture at 8k, a Brazilian modernist composition of sensual concrete curves, Burle Marx wave-pattern gardens flowing into Athos Bulcão tile panels, white blue and tropical green under equatorial light, palm shadows raking across raw concrete, poetic tropical modernity, large-format clarity and precision`

### **Crystalline**

**№ 184 / 1001** — *Lattice held in light, the angle that refuses curve*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → ILLUMINATION ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**Retículo preso na luz, o ângulo que recusa a curva** — (1001 Aesthetics, interpretação)

Cristalino: facetas geométricas, refrações prismáticas, transparência estruturada em ângulos puros.

**Paleta de cores** transparentes, prisma, azul-gelo

**Melhores usos:** abstrato, joias, design

**MidJourney:** `[tema], crystalline structure, prismatic facets and refraction --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a crystalline composition, geometric faceted lattice held in cool directional light, prismatic refractions scattering spectral slivers across ice-blue transparency, pure angles refusing every curve, frost detail at pore-level sharpness, jewelry-campaign precision, gallery-print luminosity, 8k`

### **De Stijl (Neoplasticism)**

**№ 208 / 1001** — *Right angle does the arguing*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XY — disruption by rupture

**Atmosfera e mood**

**O ângulo reto faz o argumento** — (1001 Aesthetics, interpretação)

De Stijl: grades pretas sobre branco, retângulos de vermelho, azul e amarelo puros (Mondrian, Rietveld).

**Paleta de cores** primárias puras, preto, branco

**Melhores usos:** design, arte, padronagem

**MidJourney:** `[tema], De Stijl neoplasticism, Piet Mondrian style --v 6`

**LoRA (Civitai):** "Geometric colors — Mondrian style" (SD 1.5) — civitai.com/models/296645

**Prompt universal (Seedream):** `Ultra-crisp graphic composition at 8k, a De Stijl artwork, black grid lines over white with pure red blue and yellow rectangles, strict right angles doing all the arguing, Mondrian neoplasticism with flat matte surfaces and razor edges, museum-print precision`

### **Early Georgian (1714–1760)**

**№ 256 / 1001** — *Lake That Hides the Labor That Made It*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**O lago que esconde o trabalho que o fez** — (1001 Aesthetics, interpretação)

Georgiano inicial: mansão palladiana em simétrica pedra clara, jardim paisagístico “natural” minuciosamente construído.

**Paleta de cores** pedra clara, verdes de parque, céu inglês

**Melhores usos:** arquitetura, histórico, editorial

**MidJourney:** `[tema], early Georgian Palladian mansion and landscape garden --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm lens, an early Georgian estate, symmetrical Palladian mansion in pale stone under soft English parkland light, sweeping landscape garden with a serpentine lake that hides the labor that made it, morning mist on the lawns, painterly grandeur, 8k`

### **Elegance**

**№ 272 / 1001** — *Remove One Thing Before You Leave*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → COHERENCE ↑

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**Tire uma coisa antes de sair** — (1001 Aesthetics, interpretação)

Elegância: silhueta impecável sem excesso, uma joia só, contenção como forma máxima de sofisticação (Chanel).

**Paleta de cores** preto, marfim, pérola, dourado mínimo

**Melhores usos:** moda, branding premium, retratos

**MidJourney:** `[tema], timeless elegance, impeccable restrained silhouette --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H6D with 100mm lens, an elegance portrait, impeccable restrained silhouette with a single piece of jewelry, black and ivory with minimal gold under soft directional studio light, Chanel discipline, one thing removed before leaving, Irving Penn minimalism, 8k editorial`

### **Endurance**

**№ 286 / 1001** — *Cairn Taller This Year Than Last*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → ETERNITY ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**O marco de pedras mais alto este ano que no anterior** — (1001 Aesthetics, interpretação)

Resistência: paisagem árdua e figura persistente, acúmulo lento de esforço, vitória medida em anos.

**Paleta de cores** pedra, cinza de tempestade, terra batida

**Melhores usos:** esporte, motivacional, paisagem

**MidJourney:** `[tema], endurance, lone figure in harsh vast landscape, stone cairn --v 6`

**Prompt universal (Seedream):** `Shot on large format with 210mm lens, an endurance scene, stone cairn taller this year than last in a harsh vast landscape, persistent lone figure leaning into the wind, storm grey and beaten earth, victory measured in years, Sebastião Salgado gravitas, ultra-fine detail, 8k`

### **Eudaimonic**

**№ 308 / 1001** — *Aristotle's Flourishing, Measured Over a Whole Life*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → EFFECT ↓

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**O florescimento de Aristóteles, medido ao longo de uma vida inteira** — (1001 Aesthetics, interpretação)

Eudaimonia: vida plena e cultivada, jardim maduro e mesa partilhada, felicidade como prática de longo prazo.

**Paleta de cores** verde oliva, dourado de tarde, terracota serena

**Melhores usos:** lifestyle, bem-estar, editorial

**MidJourney:** `[tema], eudaimonic flourishing, mature garden and shared table in golden afternoon --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Gold 200 with 50mm lens, a eudaimonic scene, a mature garden and a shared table in golden afternoon light, olive green and serene terracotta, bread broken and glasses half-full, flourishing measured over a whole life, warm painterly grading, 8k`

### **Folk Punk**

**№ 342 / 1001** — *Washboard and Banjo Through a Blown-Out Amp*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → SEMIOTICS ↑

**Polaridade:** XY — disruption by rearticulation

**Atmosfera e mood**

**Tabuído e banjo através de um amplificador estourado** — (1001 Aesthetics, interpretação)

Folk punk: banjo com adesivos e viagem de trem clandestina, acústico tocado com raiva punk, DIY rural e urbano ao mesmo tempo.

**Paleta de cores** marrom de estrada, preto de patch, tinta de estêncil

**Melhores usos:** música, editorial alternativo, retratos

**MidJourney:** `[tema], folk punk, stickered banjo and patched denim, DIY freight-train energy --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 800 with 35mm lens, a folk punk scene, stickered banjo and washboard played with punk rage on a dive-bar stage, patched denim and stencil ink, road brown and patch black, DIY zine-culture grit, rural and urban energy at once, 8k`

### **Functionalism**

**№ 353 / 1001** — *Sullivan's 1896 Rule: Form Follows Function*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XY — disruption by rupture

**Atmosfera e mood**

**A regra de Sullivan de 1896: a forma segue a função** — (1001 Aesthetics, interpretação)

Funcionalismo: nada decorativo, cada linha justificada pelo uso, beleza como consequência da função.

**Paleta de cores** branco, cinza de concreto, aço

**Melhores usos:** arquitetura, design de produto, editorial

**MidJourney:** `[tema], functionalist architecture, form follows function, no ornament --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm tilt-shift lens, functionalist architecture, form follows function with every line justified by use, white concrete and steel without ornament under crisp midday sun, beauty as a consequence of purpose, Mies van der Rohe precision, 8k`

### **Golfcore**

**№ 387 / 1001** — *Argyle Vest at the Eighteenth Green*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → DOMAIN ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**O colete argyle no green do buraco dezoito** — (1001 Aesthetics, interpretação)

Golfe: gramado impecável e xadrez losango, polo e viseira, esporte como código de vestimenta.

**Paleta de cores** verde de green, argyle pastel, branco de polo

**Melhores usos:** lifestyle, moda, editorial

**MidJourney:** `[tema], golfcore, argyle vest at the eighteenth green, pristine country club style --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 with 135mm lens, a golfcore scene, argyle vest at the eighteenth green with pristine fairway stripes, pastel diamond knit and polo white under late-morning sun, country club calm, sport worn as dress code, 8k`

### **Greatest Generation – The Builders**

**№ 399 / 1001** — *Cornerstone Dated for the Next Fifty Years*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → ETERNITY ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**A pedra fundamental datada para os próximos cinquenta anos** — (1001 Aesthetics, interpretação)

Geração construtora: obra pública dos anos 1930–50, aço e granito feitos para durar, dignidade do trabalho que planeja séculos.

**Paleta de cores** granito, aço, sépia de fotografia de obra

**Melhores usos:** histórico, institucional, editorial

**MidJourney:** `[tema], 1940s public works, granite cornerstone dated for the next fifty years, WPA-era dignity --v 6`

**Prompt universal (Seedream):** `Shot on 4x5 Speed Graphic press camera, a greatest generation scene, a granite cornerstone dated for the next fifty years at a 1940s public works site, steel and stone built to last, Lewis Hine documentary dignity in sepia, labor that plans in centuries, 8k`

### **Greek II — Geometric and Archaic**

**№ 401 / 1001** — *Dipylon Meander Teaches the Kouros to Stand*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → ETERNITY ↓

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**O meandro do Dipylon ensina o kouros a ficar de pé** — (1001 Aesthetics, interpretação)

Grego arcaico: ânfora com meandros geométricos e o sorriso arcaico do kouros, terracota e figura rígida que aprende a andar.

**Paleta de cores** terracota, preto de verniz, ocre

**Melhores usos:** histórico, ilustração, editorial

**MidJourney:** `[tema], archaic Greek art, Dipylon geometric meander patterns on terracotta, kouros archaic smile --v 6`

**Prompt universal (Seedream):** `Museum-grade artifact photograph in raking softbox light, an archaic Greek image, Dipylon amphora with geometric meander bands, a standing kouros with the archaic smile, terracotta and black-figure varnish, rigidity learning to walk, 8k`

### **Greek III — Classical**

**№ 402 / 1001** — *Parthenon's Entasis Corrects the Eye*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → SYNTHESIS ↑

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**A êntase do Partenon corrige o olho** — (1001 Aesthetics, interpretação)

Grego clássico: proporção perfeita e colunas que se curvam para parecer retas, mármore em contrapposto, razão esculpida.

**Paleta de cores** mármore pentelico, sombra de colunata, céu ático

**Melhores usos:** arquitetura, histórico, institucional

**MidJourney:** `[tema], classical Greek style, Parthenon columns with entasis, contrapposto marble sculpture, perfect proportion --v 6`

**Prompt universal (Seedream):** `Shot on Linhof 4x5 with 150mm lens, a classical Greek image, Parthenon colonnade whose entasis curves correct the eye, contrapposto marble figures, Pentelic marble under Attic sky, reason carved in stone, 8k`

### **Hyperminimalism**

**№ 447 / 1001** — *Ando's Cross of Light Leaves the Room Bare*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → MATTER ↓

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**A cruz de luz de Ando deixa a sala nua** — (1001 Aesthetics, interpretação)

Hiperminimalismo: concreto liso e uma única abertura de luz, redução até restar apenas o essencial absoluto.

**Paleta de cores** concreto cru, luz branca, sombra profunda

**Melhores usos:** arquitetura, branding premium, editorial

**MidJourney:** `[tema], hyperminimalism, Tadao Ando cross of light in bare concrete room, absolute reduction --v 6`

**Prompt universal (Seedream):** `Shot on Sinar 4x5 with 150mm lens, a hyperminimalist image, a cross of light cut into smooth bare concrete like Tadao Ando's chapel, the room left empty except for light itself, reduction until only the essential remains, 8k`

### **Infrastructuralism**

**№ 471 / 1001** — *Pump Station Draws the City's Hidden Diagram*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → MATTER ↑

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**A estação de bombeamento desenha o diagrama oculto da cidade** — (1001 Aesthetics, interpretação)

Infraestruturalismo: beleza dos sistemas invisíveis, tubulação, subestação e aqueduto como protagonistas.

**Paleta de cores** cinza de concreto, amarelo de sinalização, aço galvanizado

**Melhores usos:** fotografia documental, editorial urbano, arquitetura

**MidJourney:** `[tema], infrastructuralism, pump station drawing the city's hidden diagram, pipes and substations as protagonists --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z7 with 19mm tilt-shift lens, an infrastructuralism image, a pump station drawing the city's hidden diagram, pipes valves and substations as protagonists, concrete grey with signal yellow, New Topographics detachment, the invisible systems made beautiful, 8k`

### **Late Modernism (1945-1975)**

**№ 517 / 1001** — *Concrete, systems, and aftermath*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → EXPRESSION ↓

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**Concreto, sistemas e o pós-guerra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Modernismo tardio: arquitetura de sistemas em concreto aparente, o plano tornado monumental.

**Paleta de cores** cinza de concreto, céu nublado, aço

**Melhores usos:** arquitetura, editorial, documental

**MidJourney:** `[tema], late modernism aesthetic, raw concrete systems architecture, postwar aftermath light --v 6`

**Prompt universal (Seedream):** `Shot on Sinar P2 4x5 with 90mm lens, a late modernism image, raw board-formed concrete systems architecture standing calm in postwar aftermath light, repeated structural bays under a flat overcast sky, Ezra Stoller documentary clarity with Corbusian weight, concrete grey and steel against cloud white, the master plan made monumental, 8k`

### **Masculine**

**№ 553 / 1001** — *Shoulder line under renegotiation*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → DOMAIN ↓

**Polaridade:** XY — disruption by rearticulation

**Atmosfera e mood**

**O espectro em disputa da autoconstrução masculina** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Masculino: a identidade sem armadura, jeans, couro e clavícula exposta em luz de janela.

**Paleta de cores** jeans, couro, luz neutra de janela

**Melhores usos:** retrato, moda, editorial

**MidJourney:** `[tema], masculine aesthetic, male self-fashioning in plain window light, denim and leather without costume --v 6`

**Prompt universal (Seedream):** `Shot on Leica M6 TTL with 75mm lens, a masculine image, the contested spectrum of male self-fashioning studied in plain north-window light, denim leather and a bare collarbone worn without costume or armor, Peter Hujar frankness meeting Richard Avedon stillness, grey tones holding tenderness and toughness in the same frame, identity photographed unguarded, 8k`

### **Modernism**

**№ 578 / 1001** — *Ornament Fired, Function Promoted*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**Ornamento demitido, função promovida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Modernismo: a forma seguindo a função sem desculpas, aço tubular e planos assimétricos.

**Paleta de cores** branco Bauhaus, aço, primários funcionais

**Melhores usos:** design, arquitetura, editorial

**MidJourney:** `[tema], modernism aesthetic, tubular steel and asymmetric planes, Bauhaus clarity, form follows function --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex Standard in black and white, a modernism image, tubular steel and asymmetric planes composed with Bauhaus clarity, functional primaries reading as crisp greys against white walls, Moholy-Nagy diagonal energy slicing the frame, Marcel Breuer chair geometry under a factory skylight, ornament dismissed and function promoted with full honors, 8k scan`

### **Neoclassical**

**№ 604 / 1001** — *Reason Cut Into Marble Proportion*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → COHERENCE ↑

**Polaridade:** XX — continuity by transmission

**Atmosfera e mood**

**Razão cortada em proporção de mármore** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neoclassicismo: linha sobre cor, virtude sobre ornamento, o antigo como corretivo moral.

**Paleta de cores** mármore, cinza de pedra, azul pálido

**Melhores usos:** arte, arquitetura, editorial

**MidJourney:** `[tema], neoclassical aesthetic, reason cut into marble proportion, line over color --v 6`

**Prompt universal (Seedream):** `Shot on a 4x5 Chamonix with 210mm lens, a neoclassical composition of Canova-smooth marble figures beneath severe columns, reason cut into exact proportion, Ingres line discipline over pale stone and cold northern light, virtue rendered in razor detail, 8k`

### **New Brutalism**

**№ 618 / 1001** — *Social Idealism Cast in Concrete*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → MATTER ↑

**Polaridade:** XX — continuity by revision

**Atmosfera e mood**

**Idealismo social fundido em concreto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Novo brutalismo: conjuntos habitacionais como manifesto, passarelas no céu e a ética exposta na forma.

**Paleta de cores** concreto, céu cinza, laranja de porta

**Melhores usos:** arquitetura, editorial, histórico

**MidJourney:** `[tema], new brutalism aesthetic, social housing estate as manifesto, streets in the sky --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad SWC with 38mm Biogon lens, a new brutalist housing estate, raw concrete walkways in the sky built as social idealism, exposed structure as ethics under an overcast English sky, one orange door breaking the gray, Smithsons conviction, 8k`

### **Purism**

**№ 735 / 1001** — *Machines Made Seductive by Le Corbusier*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XY — disruption by rupture

Late Cubism's multi-plane fracture — the grammar that shattered the bottle across simultaneous viewpoints — is inherited as the premise, then the fragmentation itself is cut; Purism returns the same bottle frontal, whole, and standardized, removing the one move that made Cubism Cubism.

**Atmosfera e mood**

**A máquina ensinada a seduzir** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Purismo: garrafas e violões destilados em silhuetas perfeitas, a natureza-morta com precisão de engenheiro.

**Paleta de cores** cinza-azulado, creme de tela, terracota contida

**Melhores usos:** arte, design, editorial

**MidJourney:** `[tema], purism aesthetic, bottles and guitars distilled to perfect silhouettes, engineered still life --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a purist still life, bottles and a guitar distilled into perfect interlocking silhouettes, Le Corbusier and Ozénfant machine-age calm in blue-gray cream and contained terracotta, the still life redrawn by an engineer who learned seduction, 8k scan`

### **Refined**

**№ 748 / 1001** — *Perfection Becomes a Social Obligation*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XY — disruption by rupture

No prior aesthetic exists to inherit; the premise that a flawless surface certifies moral worth ruptures every tradition that admitted patina, visible labor, or honest imperfection as signs of character, removing the one allowance that connected skilled making to human presence.

**Atmosfera e mood**

**A perfeição como obrigação social** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Refinado: uma orquídea, uma linha, nenhum erro — o gosto lapidado até restar apenas o essencial impecável.

**Paleta de cores** branco de porcelana, verde de haste, cinza de seda

**Melhores usos:** luxo, branding, editorial

**MidJourney:** `[tema], refined aesthetic, single orchid one line no mistakes, perfection as social obligation --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 205TCC with 110mm lens, a refined still life, a single white orchid arcing over porcelain in silk-gray light, one line and no mistakes anywhere, taste polished until only the impeccable essential remains, perfection carried as social obligation, 8k`

### **Shaker**

**№ 802 / 1001** — *Simplicity as Spirit*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XY — disruption by rupture

No design movement precedes the Shaker room; English Quakerism and radical Protestant dissent gave conviction, not a visual grammar, so the system has no aesthetic parent to revise. It anticipates the modern function-follows-form creed by a century and generates descendants rather than descending from one, so the whole grammar of peg rail, exposed joinery, and refused ornament branches downward into later minimalisms and none can be traced upward into it.

**Atmosfera e mood**

**A simplicidade como espírito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Shaker: caixas ovais, móveis sem ego e o trabalho manual feito como oração — beleza porque útil.

**Paleta de cores** madeira de cerejeira, azul shaker, branco de leite

**Melhores usos:** design, interiores, editorial

**MidJourney:** `[tema], shaker aesthetic, oval boxes egoless furniture, handwork done as prayer --v 6`

**Prompt universal (Seedream):** `Shot on an Ebony 4x5 with 150mm lens, a Shaker still life, nested oval boxes and a cherry-wood chair built without ego on scrubbed pine, milk-paint blue against honest grain in meetinghouse light, craftsmanship performed as prayer where beauty follows use, serene detail, 8k`

### **Shinto**

**№ 804 / 1001** — *Divine in Nature*

**Nível:** 🔴 Primary · **Eixo:** INTEGRITY ↑ → ETERNITY ↑

**Polaridade:** XY — disruption by rupture

No older aesthetic stands behind Shinto; its substrate is prehistoric Japanese animism, a religious practice rather than a prior visual movement, so nothing was reinterpreted or recombined to produce it. It gives rise to wabi-sabi, architectural minimalism, and the tea house while being consumed by none of them, so the whole grammar of purity, threshold, and renewal branches outward into later aesthetics and none can be traced upward into it.

**Atmosfera e mood**

**O divino habitando a natureza** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Xintoísmo: torii vermelho na floresta, corda shimenawa e a reverência a espíritos que moram em pedras e árvores.

**Paleta de cores** vermelhão de torii, verde de criptôméria, branco de papel shide

**Melhores usos:** espiritual, viagem, editorial

**MidJourney:** `[tema], shinto aesthetic, vermilion torii shimenawa rope sacred forest, the divine dwelling in nature --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX 50R with 63mm lens, a Shinto scene, a vermilion torii standing in cryptomeria forest mist with a shimenawa rope and white shide papers marking the sacred tree, kami reverence in green shadow and shrine red, the divine quietly at home in nature, 8k`

### **Soviet**

**№ 835 / 1001** — *Concrete, Red, and the Engineering of Belief*

**Nível:** 🟤 Tertiary · **Eixo:** INTEGRITY ↑ → EXPRESSION ↓

**Polaridade:** XY — disruption by rearticulation

Russian Futurism's machine worship, Cubism's constructed space, and Suprematism's geometric primary are welded into one form, no single ancestor surviving intact, so three lineages fuse into a red wedge on grey concrete that none of the three could produce alone.

**Atmosfera e mood**

**Concreto, vermelho e a engenharia da crença** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Soviético: blocos brutalistas sob faixas vermelhas, mosaicos de cosmonautas e a utopia administrada em concreto armado.

**Paleta de cores** cinza de concreto, vermelho de bandeira, mosaico dourado

**Melhores usos:** histórico, arquitetura, editorial

**MidJourney:** `[tema], soviet aesthetic, brutalist blocks red banners cosmonaut mosaics, the engineering of belief --v 6`

**Prompt universal (Seedream):** `Shot on Kiev 88 with 80mm lens, a Soviet-era scene, brutalist housing blocks under long red banners with a cosmonaut mosaic gleaming on the gable end, concrete gray ruled by flag red beneath a wide pale sky, belief engineered at municipal scale, stern documentary geometry, 8k scan`

### **Swiss**

**№ 881 / 1001** — *Grid That Makes Authority Look Neutral*

**Nível:** 🟣 Secondary · **Eixo:** INTEGRITY ↑ → EDITING ↑

**Polaridade:** XX — continuity by revision

Central European Modernism supplies the single parent, and Swiss design re-instruments that inheritance by sharpening Modernism's promise of clarity into a teachable grammar of grid, sans-serif type, and objective photography.

**Atmosfera e mood**

**O grid que faz a autoridade parecer neutra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Estilo suíço: Helvetica em grade rigorosa, foto objetiva e assimetria calculada — Müller-Brockmann provando que ordem também persuade.

**Paleta de cores** vermelho suíço, preto de Helvetica, branco de grid

**Melhores usos:** design gráfico, branding, editorial

**MidJourney:** `[tema], swiss international style aesthetic, strict grid Helvetica objective photography, authority made neutral --v 6`

**Prompt universal (Seedream):** `Ultra-precise graphic poster in the Swiss International Style, Helvetica set flush-left on a strict modular grid beside one objective photograph, Swiss red and black balanced in calculated asymmetry on white, Müller-Brockmann order making authority look perfectly neutral, immaculate typographic clarity, 8k`

Olhando a lista inteira de estéticas que o Locus classificou sob INTEGRITY (o Djed), dá pra ver um padrão bem nítido — sim, existe um sistema visual comum.

**O núcleo: a maioria são movimentos de arquitetura/design definidos por UMA regra de construção que precisa se manter idêntica em qualquer escala.**

Repare quem está na lista: Neoclassical, Bauhaus, De Stijl, Swiss, Purism, Functionalism, Modernism, New Brutalism, Beaux-Arts, Greek Geometric/Classical, Shaker, Infrastructuralism, Hyperminimalism. Isso não é coincidência — é praticamente um mapa da história do design racionalista ocidental (e não só ocidental) desde os gregos até o Bauhaus e o brutalismo.

O que todas essas estéticas compartilham visualmente, e que bate exatamente com a lógica do Djed (a coluna de travessas empilhadas — se uma trava sai do prumo, a coluna inteira entorta):

**Uma lei estrutural única** visível na fachada, no objeto e no detalhe ao mesmo tempo — grade, proporção, ordem de colunas, ausência de ornamento.

**Redução, não decoração** — o ornamento é cortado (Editing↑ aparece como parceiro em quase metade da lista: Swiss, Purism, Shaker, Modernism, De Stijl, Functionalism) porque qualquer coisa adicionada que não seja estrutural quebra a integridade do sistema.

**A regra sobrevive do plano geral ao close-up** — a fluta da coluna grega, a junta exposta do Bauhaus, a grade suíça: funciona de longe e de perto porque é a mesma lei em escalas diferentes.

**O segundo grupo — a mesma lógica aplicada a pessoas e crenças, não a prédios.** Shinto, Eudaimonic, Endurance, Bohemian, Masculine, Golfcore, Greatest Generation. Aqui não é uma fachada que precisa bater com a estrutura interna — é uma vida ou um código social testado por consistência: o Bohemian só é autêntico se a pobreza voluntária realmente aparecer até o fim (por isso a polaridade é "disruption by rupture" — não existe estética anterior, a regra nasce ali e não admite exceção); a Endurance é literalmente um cairn que só prova sua integridade se cada pedra nova obedecer à mesma lógica de empilhamento da anterior.

**O que isso confirma sobre o sistema:** INTEGRITY não é "minimalismo" como estilo — é qualquer estética, arquitetônica ou não, cuja prova visual é a mesma pergunta em qualquer escala: *essa regra ainda vale se eu chegar mais perto?* Por isso Bauhaus, Neoclassicismo e Shinto convivem na mesma posição — puxam de tradições completamente diferentes, mas todas são julgadas pelo mesmo teste de coerência estrutural, exatamente o que o Djed representa.

As regras concretas que a página especifica para compor uma imagem:

**Corpo — 4 pontos de alinhamento, sempre checados juntos**

Pés, quadril, ombros e olhar precisam estar na mesma linha vertical (as quatro travessas do Djed). Se um desalinha, a coluna inteira "aparenta estar torta" — não tem estilismo que disfarce. Peso igual nos dois pés, ou um contrapposto clássico simétrico.

**Só dois gestos permitidos, nunca misturados**

*Vislumbrar*: olhar sobe além da câmera, queixo levemente erguido, mãos quietas nas costuras.

*Testemunhar*: olhar direto e nivelado na lente, frontal, cabeça nunca inclinada (inclinar seria "editorializar" o testemunho).

Proibido em ambos: mão estendida, cabeça jogada, sobrancelha erguida, mãos mexendo na barra, olhos que desviam, sorriso montado meio segundo depois do olhar.

**Figurino — uma lógica de costura do começo ao fim**

Um único sistema de costura, do barra ao colarinho ao acessório. O acabamento interno tem que ser igual ao externo (roupa com forro malfeito por dentro = "erro de continuidade" visual). Nenhum acessório decorativo que não sustente estrutura. Nada muda entre o plano aberto e o close extremo.

**Câmera — travada, sem corte**

Tripé parado, altura do peito, zero inclinação, enquadramento simétrico, na altura dos olhos do sujeito. Regra central: um único plano-sequência — pode aproximar do plano geral até o detalhe extremo, mas o mesmo fato estrutural tem que se manter legível em toda a distância, sem corte escondido.

**Composição — centrada, verticais convergindo**

Eixo central, simetria axial. Colunatas, portas em fileira, ripas de janela — tudo convergindo para o ponto onde a figura está. Uma massa pesada e ancorada na parte baixa do quadro (uma coluna escura, uma base de pedra). Sombra cai reto para baixo; nada no quadro pode estar "inclinado".

**Luz — uma fonte, uma temperatura, do início ao fim da profundidade de campo**

Uma luz só, sem variar de cor ou ângulo do primeiro plano até o fundo. O estado de falha explícito: duas fontes de luz de temperaturas diferentes cruzando o quadro de lados opostos.

**Pele/beleza — mesmo resultado de perto e de longe**

Textura, tom e acabamento idênticos no plano geral e no close. Luz dura e escultural para a textura da pele funcionar como "testemunho", não disfarce — poro e veia ficam visíveis, sem suavização.

**Cenografia — arquitetura real, que sustentaria peso**

Interiores de pedra, colunas, umbrais — nada decorativo que não seja estruturalmente necessário. Qualquer pátina tem que ser real (pedra realmente desgastada), nunca simulada ou impressa.

**Prova de continuidade (o dispositivo mais específico)**

Sempre que possível, um espelho, poeira d'água ou piso polido que reflita a figura — e o reflexo tem que bater exatamente (mesma dobra, mesma expressão, mesma luz). Esse é o "testemunho" da própria imagem — e o menor desencontro aqui é o erro mais grave que essa posição pode cometer.

**Resumindo em uma frase:** o código visual de INTEGRITY não é "estética minimalista" — é uma disciplina de câmera e luz que testa se a mesma verdade estrutural aparece igual em qualquer distância, sem cortes, sem trocar a luz, sem a pele mudar de perto pra longe.

---

# DOMAIN — o Tetractys

<aside>
🔺

**Essência.** Território como ordem, nunca como cerca. O ideograma é o Tetractys — o triângulo de dez pontos jurado na costa do Egeu: um, dois, três, quatro — um mundo montado fileira por fileira, a base larga carregando o ápice. Dois verbos habitam o triângulo: **Decifrar / Deciphering**, o padrão aberto sem ser esgotado, e **Originar / Originating**, a fundação de um sistema consequente o bastante para ser reconstruído a partir de qualquer fileira. Na imagem, o elemento se prova por jurisdição: cada objeto admitido obedece a uma lei de entrada, a fronteira é visível, e o espectador sente antes de ler qualquer detalhe que *alguém governa aqui*.

</aside>

## Prompt-mestre (imagem-síntese)

> Photographed from the [territory]'s own threshold, the doorway or gateline cutting the lower edge of the frame as a visible frontier with everything foreign to this field halted just outside it, the wide base of the composition filled with the field's own infrastructure — [ranked tools / stacked material / shelving / furniture / signage specific to the territory] — visibly outnumbering and supporting the single figure held at the apex, the figure in a settled, minimum-energy stillness rather than a pose, weight even, shoulders wide and dropped, hands either fully still or engaged with an instrument that belongs only to this field, wardrobe cut from the territory's own material culture with one earned mark of wear or a single repaired seam rather than a pristine finish, the same governing rule legible at three shrinking scales — one instrument, its aligned row, the wall or bench that ranks the rows — a traceable chain from the object in the hand to the room that produced it, light entering only where the architecture admits it and graded in ranks from bright at the working center to penumbra at the boundary so illumination itself maps the hierarchy, one hour and one palette drawn from the field's own matter with no imported color anywhere, camera held at the visitor's station or the subject's own eye level — never a godlike overhead view — moving if at all like a stabilized rig through owned space, and one small detail proving the frontier is enforced: an object from outside the jurisdiction stopped at the door, or clutter that does not cross the threshold.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre):

> No sourceless even brightness, no placeless or generic object admitted inside the frontier, no trend markers or symbols borrowed from another jurisdiction, no printed or factory-faked distressing, no presenting arm or welcoming gesture toward the lens, no overhead or godlike vantage, no handheld trespasser's tremor, no color from outside the field's own palette, no figure floating without a supporting base, no rented-looking location free of wear, dust, or visible rules of entry.
> 

### Como adaptar o prompt a cada estética

Por que isso funciona para todas as 20 estéticas da lista: nenhuma linha nomeia um lugar, classe ou tribo específica — só descreve os mecanismos que a página define como universais de DOMAIN (base carregando o ápice, fronteira visível, gradação em quatro escalas, luz administrada por hierarquia). Basta trocar o que vai entre colchetes pelo vocabulário material de cada estética (ex.: para Frat → "the fraternity house," letras gregas, copos vermelhos; para BUSINESS → a sala de reunião, o terno; para Western → o rancho, a sela, o couro) e a estrutura do prompt continua idêntica.

## Fundamentos do elemento

**Identity.** Specificity of the historical, material, and formal field — territory as order, never as fence. Its ideogram is the ten-point triangle sworn on the Aegean coast: one, two, three, four — a world assembled row by row, from point to line to surface to volume, the wide base carrying the apex, and in the ratios between the rows the intervals that make a string sound in harmony. Two verbs occupy the triangle: Decifrar / Deciphering, the pattern opened without being exhausted, and Originar / Originating, the founding of a system consequent enough to be rebuilt from any of its rows. Behind it, one force dominates without entering the frame as itself — the whole world compressed into one governed place without overflowing — and a second signs the foundation, converging every element before release. In an image this element is proven by jurisdiction: a frame where every admitted object obeys one rule of entry, where the boundary is visible, and where the viewer senses before reading a single detail that *someone governs here*. (Distinct from INTEGRITY, 1 — the pillar proves one logic across scales; the triangle proves one jurisdiction across objects. The question is not "does the detail match the whole" but "was this admitted, and under what law.")

**The base carries the apex.** No domain is sustained from the summit. In the frame, the territory's infrastructure — floor, walls, benches, storage, ranked tools, stacked raw material — must visibly outnumber and physically support the figure at the apex. A domain shown as a backdrop behind a styled figure is a fence, not a territory; the image must prove the field would keep functioning after the camera leaves: storage actually full, tools within reach of the stations that use them, wear paths on the floor where the work really travels. Failure state: an apex without a base — a figure floating in a location rented for the afternoon, props unhandled, no dust, no wear, no rule.

**Exclusion made visible.** A sovereign territory is defined more by its frontier than by its area, and the founding act of any domain is the decision of what does not enter. Every DOMAIN image therefore carries evidence of refusal: a closed gate, a threshold the clutter does not cross, empty hooks where nothing irrelevant was allowed to hang, one category of object where a lesser room would hold six, a visitor's coat stopped at the entrance rack and not beyond. The frame reads as private property, never as vacant lot: nothing in it arrived by accident, and a single generic object deep inside the territory reads as invasion. The excluded world may appear at the edge — cropped, darker, out of focus beyond the doorway — present enough to prove the exclusion, never enough to compete.

**The four rows made visible.** Wherever the frame allows it, carry the ideogram as a legible gradation: one instrument (the point), its aligned row (the line), the bench or wall that holds the rows (the surface), the whole working room (the volume) — a scale of provenance the eye can climb in either direction. The same law must survive each step down: whatever rule governs the finest piece at the apex must still be readable, diluted but unbroken, in the widest row of the base — a workshop whose master object obeys one logic while its stock shelf obeys another is two territories pretending to be one. This gradation is the image's quietest proof of authority: the figure's rank is never asserted by the pose but demonstrated by the traceable chain from the instrument in the hand to the tray that holds it, the shelf that ranks the trays, and the room that produced them all.

## Corpo — postura, peso e gesto

**Model posture & structure.** The body of someone operating from home ground, in the minimum-energy state of the master: weight settled evenly, breath low, spine at ease rather than at attention, the economy of movement of a system that has found its stable structure and no longer spends force holding its position. The figure moves less than everything around it — the stillness of the one who governs, not the scanning of the one who visits. Shoulders wide and dropped, occupying space without pushing into it; hands either fully still or fully engaged with the territory's own instruments, never hovering, never fidgeting at a hem or checking their own effect. This stillness is dynamic, not rigid — a stabilized camera gliding through its own field, absorbing impact fluidly — and it must never decay into apathy: pressed, this body would absorb and resolve; the slack body of indifference is the failure state.

### **Gesture.** Two gestures alternate as the triangle's verbs.

**Decifrar · Deciphering:** the hands open a pattern that belongs to the field — unrolling a chart, holding a workpiece up to the light, fingers reading a weave, a grain, a graded row — gaze down and into the material, absorbed, decoding for no audience; the shadow is the demonstrative gesture performed at the camera, measurement sold as total knowledge. 

**Originar · Originating:** the founding gesture — placing the first object of an order the viewer can see continuing, marking a boundary line, setting a tool at the head of its rank — one hand establishing while the composition confirms; the shadow is the monument to the founder, a gesture that points back at its author. Both forbid the host's vocabulary: no presenting arm, no welcoming sweep, no display of the space to the lens — a domain is entered by invitation, and the image is the invitation withheld.

## Regras de imagem — do figurino à prova de fronteira

**Look & styling continuity.** Wardrobe drawn from the territory's own material culture — cut, cloth, closure, and weight belonging to this field's trade, climate, and rank, so the garment reads as the domain's fifth wall rather than a costume brought in from outside. The surfaces carry the proof of slow forging: real wear at exactly the points this field's work would produce — a burnished tool-side hip, heat-marked cuffs, an oiled collar — patina earned in use, never printed or factory-distressed. One visible scar outranks any pristine finish: a repaired seam, a re-soled boot, a scorch mark on leather — the certificate that this figure was tempered by the field rather than delivered to it; glass cooled fast shatters, steel that accepted the fire's time endures, and the styling must say steel. Refused: trend markers, logos from other jurisdictions, any accessory that could not survive one working day in this territory.

**Camera.** The camera behaves like a surveyor of the territory, not a guest inside it: positions taken at the field's own boundaries and axes — the threshold, the end of an aisle, the head of a ranked row — mapping jurisdiction rather than wandering through it. Height at the subject's eye level or slightly below, granting the field its own horizon — never the impossible overhead view no member of the territory could occupy. The viewer is placed at the visitor's station, the threshold or the rank below, so the room has declared who governs before the figure is even read; the territory is not summarized in one godlike glance but disclosed in succession, each frame earning the next room. The establishing frame is the contract: territory first, wide enough to show the base rows that carry the figure; a close-up is earned only by an object the territory itself ranks as important. When the camera moves it moves like a stabilized rig through owned space — smooth, unhurried, absorbing every step — never the nervous handheld tremor of a trespasser filming a war.

**Composition.** Triangular and hierarchical, built like the ideogram itself: a wide, dense base of the field's matter across the lower frame — benches, stacked bolts, ranked instruments — narrowing toward the figure as apex, or the figure held low while the ordered field rises behind in visible rows. Boundaries are compositional members: a doorframe, a fence line, a drawn threshold cuts the frame and declares where the jurisdiction ends. Vectors align — sightlines of tools, floorboards, shelving runs, and the figure's own gaze summing toward one direction, the visual proof that the field's forces reinforce instead of cancelling; an environment pointing one way while the figure points another reads as zero. One calibrated tension is kept and only one: a single gap between what is and what is becoming — an unfinished piece on the bench, one empty slot in a full rank — enough distance to prove growth, never enough to read as disorder.

**Lighting.** Light behaves as a resident administered by the territory, not a visitor: it enters where the architecture admits it — one high window, one worklamp over the bench, one corridor of sun through the gate — and the field governs it in ranks, brightest at the working center, graduated to penumbra at the boundaries, so illumination itself maps the hierarchy of the space. The threshold reads as a light-frontier: inside, warm and governed; beyond the door, cooler or darker. One hour rules the whole frame — the angle and temperature of the light agree with a single time of day across every surface, because a territory that contradicts its own hour reads as a rented set. Failure state: sourceless even brightness that flattens all ranks, erases the frontier, and treats every object as equally admitted — light without admission rules.

**Color & palette.** The palette is drawn from the territory's own matter and held as an act of permanence: the ochre of its dust, the oxide of its tools, the dye its trade actually handles — colors that recur because the field keeps producing them, never because a grade was laid over the frame. The territory's native light is perfected rather than replaced: shadows opened just enough to stay readable while the place keeps its own heat and hour, no imported temperature anywhere. One family of color sustained across every surface until it reads as the world's signature; a single hue from another jurisdiction — a logo red, a screen blue — is the same breach as a foreign object deep inside the frontier.

**Beauty detail.** Grooming reads as self-administration, never as display for the lens: skin carrying the field's climate legibly — workshop dryness, salt air, archive pallor — and hands that match the trade at macro distance, the hands of the one who governs this territory rather than the hands of a visitor styled to resemble them. Hair controlled by function — tied, cut, or capped as the work demands — holding the same logic in the wide shot and the close crop. Even constructed grooming obeys the row logic: built in graded, ranked layers that read as a governed field on the face itself, never as one accented point floating on unranked ground; where hair is structured, its movement is governed like everything else in the territory — a geometry that holds, not a sway that wanders. One scar-tier detail is admissible and precious: a healed nick, a callus ridge, a sun line at the collar — the tempering certificate carried on the body itself. Refused: beauty imported from another jurisdiction — editorial lacquer in a boatyard, a forge hand with untouched nails — the micro-invasion that collapses the entire claim of sovereignty in one detail.

**Cenography.** A field that could operate the moment the camera leaves, built in five agreeing layers. Spatial: real, working architecture of one trade or milieu, with a ceiling nobody intends to photograph. Relational: if a second figure appears, they obey the same code and a legible rank — same material culture, different station. Symbolic: marks, labels, tallies, and insignia of this jurisdiction only, readable as one sign system. Temporal: one hour, one season, one era of equipment — no object older or newer than the territory's own timeline allows. Decisional: visible admission machinery — hooks, racks, graded trays, ranked rows, a gate — the filters of entry photographed as furniture. Zones never mix: the working zone, the rest zone, and one sanctuary corner — a single curated point holding the field's own treasures — each keeping its one function, because a bench used for eating and a bed used for working are the scenographic definition of a collapsed domain. Every aging physically real: hand-worn handles, oiled thresholds, wear that maps actual use — never a printed patina.

**Boundary proof.** Wherever the frame allows it, show the frontier working: light crossing the threshold while clutter does not, an object from outside the jurisdiction halted at the door, the graded row that admits one more piece only at its proper rank. This device is the image's own gate — the closest a still photograph comes to proving that admission rules exist and are enforced. The smallest breach, one placeless object deep inside the territory, is the single most legible failure this element can produce.

## Polaridades — repertório amplificado (↑) e suprimido (↓)

**↑ Amplified — repertory.** Total territorial commitment: costume, props, surfaces, tools, light, and grooming drawn from one material culture; ranked, zoned space with a visible frontier and visible refusal; base rows carrying the figure at the apex; the body in settled minimum-energy stillness, decoding or founding with the field's own instruments; earned patina and one survived scar; one palette drawn from the field's own matter; the four rows legible from single instrument to whole room; no generic objects, no crossover cues, no placeless styling.

> **↑ Prompt.** Inside a working sailmaker's loft photographed from its own threshold, the doorframe cutting the lower corner of the frame as a visible frontier with the street's clutter halted outside it, benches and ranked bolts of waxed canvas filling the wide base of the composition, bronze grommets sorted in graded trays, hemp line coiled by hand along one aligned shelf run pointing toward the single high window, the model standing still at the loft's working center in a canvas coat with rope closures cut from the loft's own cloth, weight settled evenly on both feet, shoulders wide and dropped, one hand reading the weave of a sail panel with the absorbed downward gaze of someone decoding their own material, salt-dried skin and rope-callused hands rendered true in close crop, a mended seam left visible at the cuff, daylight entering only through that one window and grading from bright at the bench to penumbra at the door, sail dust hanging in the beam, the whole frame held in the loft's own palette of waxed ochre, oiled bronze, and raw hemp with not one imported color, the grommet in the model's palm traceable to its graded tray, the tray to its shelf, the shelf to the room, an unfinished panel waiting in one empty slot of an otherwise full rack, and not one object in frame that could belong anywhere else.
> 

> **↑ Negative line.** No sourceless even brightness, no placeless or generic object inside the frontier, no trend markers or foreign logos, no printed or factory distressing, no presenting arm or welcoming sweep toward the lens, no godlike overhead view, no handheld trespasser's tremor, no imported colour from another jurisdiction, no apex without a base, no rented location without wear, dust, or admission rules.
> 

**↓ Suppressed — repertory.** Territory deliberately dissolved: hybrid costume crossing trades and registers, a setting readable as several places at once, objects from unrelated jurisdictions granted equal standing, no threshold, no rank, no admission machinery anywhere, restless weight-shifting posture, flat even light and a palette from nowhere, so no single world claims the figure and nothing governs the frame.

> **↓ Prompt.** A figure on a rooftop at dusk wearing a fencing jacket over fisherman's waders with a jeweller's loupe on a chain, weight shifting mid-step and gaze scanning past the frame, surrounded by objects from unrelated trades granted equal footing, a music stand, a garden hose, a surveyor's tripod, no doorway, no gate, no ranked row anywhere in sight, all lit evenly and sourcelessly so no single world wins the frame and nothing in it answers to anything else.
> 

> **↓ Negative line.** No visible threshold or frontier, no ranked rows or graded trays, no admission machinery, no single material culture, no settled minimum-energy stillness, no governed light gradation, no palette drawn from one field's matter, no earned patina, no jurisdiction claimed anywhere in the frame.
> 

## Estéticas relacionadas a DOMAIN (A–Z)

As 20 estéticas classificadas sob DOMAIN, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary), eixo secundário e polaridade (XX — continuidade · XY — disrupção).

### **Athleisure**

**№ 069 / 1001** · *White sole that never left the studio*

**Nível:** 🟣 Secondary

**Eixo:** DOMAIN ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** um único pai — o sportswear de performance — segue adiante com materiais e silhuetas intactos, reinterpretado para contextos para os quais nunca foi cortado; a gramática é redirecionada, não reconstruída de várias fontes.

**Atmosfera e mood**

**Sola branca que nunca saiu do estúdio** — (1001 Aesthetics, interpretação)

Athleisure: legging com blazer, tênis imaculado, esporte usado como status.

**Paleta de cores** neutros, cinza mescla, branco

**Melhores usos:** moda, fitness, branding

**MidJourney:** `[tema], athleisure fashion editorial --v 6`

**Prompt universal (Seedream):** `Clean fashion editorial shot on Canon R5 with 85mm lens, a model in tailored leggings and an oversized blazer with pristine white sneakers, gym-to-street styling in heathered gray and bone, bright minimal urban architecture backdrop, soft even daylight, aspirational wellness polish, 8k`

### **Bourgeois**

**№ 114 / 1001** · *Matched bindings that signal before they're read*

**Nível:** 🔴 Primary

**Eixo:** DOMAIN ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** nenhuma estética anterior fornece isto — a própria classe gera uma gramática material em que as posses certificam status antes de serem usadas; remover essa função de sinalização colapsa o todo, não apenas um ramo.

**Atmosfera e mood**

**Encadernações combinando que sinalizam antes de serem lidas** — (1001 Aesthetics, interpretação)

Burguês: sala respeitável, estantes de mogno com livros combinando, conforto arrumado para exibição.

**Paleta de cores** verdes profundos, mogno, dourado discreto

**Melhores usos:** interiores, retratos, editorial

**MidJourney:** `[tema], bourgeois respectable interior, matched bookshelves --v 6`

**Prompt universal (Seedream):** `Shot on medium format with 55mm lens, a bourgeois drawing room with matched leather-bound book sets on mahogany shelves, deep green walls and a marble mantel clock, afternoon light through heavy drapes onto a wingback chair, comfort arranged for display, Wes Anderson symmetry with old-money patina, rich detail, 8k`

### **BUSINESS**

**№ 135 / 1001** · *Tailored argument for strategic authority*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** alfaiataria sob medida, disciplina de uniforme militar e identidade visual corporativa convergem — tire a alfaiataria e a autoridade perde o corte, tire a moldura corporativa e o terno para de argumentar estratégia; fusão, não revisão de um único pai.

**Atmosfera e mood**

**Argumento sob medida para autoridade estratégica** — (1001 Aesthetics, interpretação)

Corporativo: terno alinhado, sala de vidro, skyline pela janela, luz fria e confiante.

**Paleta de cores** azul-marinho, cinza, vidro

**Melhores usos:** corporativo, retratos, branding

**MidJourney:** `[tema], corporate business editorial --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 50mm lens, a corporate business editorial, tailored navy suit crossing a glass boardroom, floor-to-ceiling city skyline glowing at dusk, cool confident rim light on crisp lapels, watch and cufflinks in specular detail, strategic authority mood, steel-blue cinematic grading, magazine-cover polish, 8k`

### **COFFEE SHOP**

**№ 165 / 1001** · *One cup buys the right to stay until it's empty*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** sociabilidade de café europeu, ofício do specialty coffee e cultura de trabalho remoto convergem; tire a linhagem do café e o direito de permanecer desaparece, tire o fio do trabalho e a sala esvazia ao meio-dia — fusão de várias tradições.

**Atmosfera e mood**

**Uma xícara compra o direito de ficar** — (1001 Aesthetics, interpretação)

Cafeteria: madeira e lousa, vapor de máquina de espresso, laptop e caderno, tarde inteira numa mesa.

**Paleta de cores** marrons de café, creme, luz quente de janela

**Melhores usos:** lifestyle, branding, cenários

**MidJourney:** `[tema], cozy coffee shop interior, latte art --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 50mm f/1.8, a cozy coffee shop scene, espresso steam curling through warm window light, latte art and an open notebook on a worn wooden table, chalkboard menu soft in the background bokeh, the right to linger over one cup, amber film-like grading, tactile ceramic detail, 8k`

### **Cosmopolitanism**

**№ 178 / 1001** · *Dressed for arrival, not departure*

**Nível:** 🔴 Primary

**Eixo:** DOMAIN ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** a premissa de que o pertencimento é portátil e o mundo é a única casa é afirmada na raiz, não herdada; removê-la colapsa o sistema inteiro, não um ramo.

**Atmosfera e mood**

**Vestido para a chegada, não para a partida** — (1001 Aesthetics, interpretação)

Cosmopolita: lounge de aeroporto e rooftop internacional, mala de couro, mistura elegante de culturas em trânsito.

**Paleta de cores** neutros de viagem, couro, luzes de cidade

**Melhores usos:** viagem, editorial, branding

**MidJourney:** `[tema], cosmopolitan jet-set editorial --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 50mm lens, a cosmopolitan editorial, elegant traveler dressed for arrival crossing an international rooftop lounge, leather luggage and city lights bokeh below, cultures mixing in transit, polished global ease with Condé Nast Traveler gloss, steel-and-amber night grading, cinematic sophistication, 8k`

### **Dataism**

**№ 202 / 1001** · *World rendered as queryable light*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → ILLUMINATION ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O mundo renderizado como luz consultável** — (1001 Aesthetics, interpretação)

Dataísmo: fluxos de dados visualizados, malhas de pontos e gráficos luminosos, realidade como banco de dados.

**Paleta de cores** preto, ciano e verde de dados, branco de interface

**Melhores usos:** tech, infografia, capas

**MidJourney:** `[tema], dataism, luminous data visualization mesh --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a dataism visualization, the world rendered as queryable light, luminous point clouds and flowing data graphs over darkness, cyan and green information streams braiding into architecture, reality as database, Refik Anadol scale, volumetric glow with razor-fine particle detail`

### **Empire**

**№ 282 / 1001** · *Marble Veined With the Map of Conquest*

**Nível:** 🟣 Secondary

**Eixo:** DOMAIN ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Mármore com as veias do mapa da conquista** — (1001 Aesthetics, interpretação)

Império: colunas e águias, mármore e ouro napoleônico, grandiosidade que anuncia poder.

**Paleta de cores** mármore branco, ouro imperial, vermelho de manto

**Melhores usos:** histórico, arquitetura, dramático

**MidJourney:** `[tema], Empire style, Napoleonic marble columns, gold eagles and imperial grandeur --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H6D with 50mm lens, an Empire style scene, Napoleonic marble columns and gold eagles under candelabra light, mantle red against white marble veined like a map of conquest, grandeur announcing power, cinematic neoclassical opulence, 8k`

### **Empowerment**

**№ 283 / 1001** · *Fifteen Bodies at the Same Scale*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Quinze corpos na mesma escala** — (1001 Aesthetics, interpretação)

Empoderamento: figuras diversas em pé de igualdade, postura firme, dignidade coletiva sem hierarquia.

**Paleta de cores** tons de pele diversos, cores fortes e afirmativas

**Melhores usos:** campanhas, editorial, social

**MidJourney:** `[tema], empowerment photography, diverse figures at equal scale, strong dignified stance --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 45mm lens, an empowerment group portrait, fifteen diverse bodies at the same scale in even studio light, firm posture and collective dignity without hierarchy, strong affirmative colors against a clean backdrop, Annie Leibovitz campaign gravitas, 8k`

### **Frat**

**№ 348 / 1001** · *Greek Letters, Boat Shoes, and the Red Solo Cup*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Letras gregas, boat shoes e o copo vermelho** — (1001 Aesthetics, interpretação)

Fraternidade: campus americano e polo pastel, festa de quintal com copos vermelhos, camaradagem universitária ruidosa.

**Paleta de cores** azul-marinho, vermelho de copo, pastel de polo

**Melhores usos:** lifestyle, editorial, narrativa

**MidJourney:** `[tema], American frat aesthetic, Greek letters, boat shoes and red solo cups --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X100V with built-in flash, a frat scene, American campus house with Greek letters, boat shoes and pastel polos, red solo cups at a backyard party under string lights, navy and cup red, loud collegiate camaraderie, candid disposable-camera energy, 8k`

### **GEEK**

**№ 366 / 1001** · *Worbla Seam That Proves the Build*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A costura de Worbla que prova a construção** — (1001 Aesthetics, interpretação)

Geek: bancada de cosplay e action figures, colecionável e fã-arte, orgulho do trabalho manual nerd.

**Paleta de cores** cores de fandom, LED de setup, plástico de kit

**Melhores usos:** cultura pop, retratos, editorial

**MidJourney:** `[tema], geek culture, cosplay workbench with Worbla armor and figure shelves, fandom pride --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R with 24mm lens, a geek scene, cosplay workbench with a visible Worbla seam proving the handmade build, action figure shelves and LED setup glow, fandom colors under desk lamps, proud nerd craftsmanship, 8k`

### **Jock**

**№ 494 / 1001** · *Stadium Scoreboard Measures the Body in Public*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O placar do estádio mede o corpo em público** — (1001 Aesthetics, interpretação)

Jock: jaqueta de time e troféu de vitrine, gramado sob refletores, o desempenho como identidade.

**Paleta de cores** cores de time, verde de gramado, dourado de troféu, luz de refletor

**Melhores usos:** esporte, editorial, branding jovem

**MidJourney:** `[tema], jock aesthetic, varsity jacket under stadium floodlights, scoreboard measuring the body in public --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS-1D X with 400mm lens, a jock image, a stadium scoreboard measuring the body in public, varsity jacket and trophy case under floodlights, team colors on cut grass, Walter Iooss Jr. sports iconography, performance as identity, 8k`

### **Liminality**

**№ 525 / 1001** · *Rite-of-passage firelight on skin*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↓ → NARRATIVE ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** o único DOMAIN ↓ da lista — definida justamente pela *ausência* de território estável, é a prova negativa de que jurisdição é o eixo que organiza esta posição inteira.

**Atmosfera e mood**

**Luz de fogueira de rito de passagem na pele** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Liminalidade: o eu suspenso entre dois nomes, chama cerimonial contra o escuro.

**Paleta de cores** laranja de brasa, escuro cerimonial, pele iluminada

**Melhores usos:** retrato ritual, editorial, arte

**MidJourney:** `[tema], liminality aesthetic, rite-of-passage firelight on skin, threshold between two names --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R6 Mark II with 50mm lens by ritual firelight, a liminality image, rite-of-passage flames moving across painted skin at the threshold hour, ember orange carving faces out of ceremonial darkness, sparks rising into an unanswered sky, the self held suspended between two names, anthropological reverence without spectacle, 8k`

### **Pantanal Wetland Indigenous**

**№ 666 / 1001** · *Knowledge Kept in Flood Cycles*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Saber ancestral no ritmo da cheia** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Indígena pantaneiro: canoas, pesca tradicional e o conhecimento do ciclo das águas passado por gerações.

**Paleta de cores** barro de margem, verde de aguapé, algodão cru

**Melhores usos:** documental respeitoso, cultura, editorial

**MidJourney:** `[tema], Pantanal indigenous aesthetic, dugout canoe flood-cycle knowledge, ancestral wetland life --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X100V, a respectful documentary scene of Pantanal indigenous life, a dugout canoe gliding through water hyacinth at first light, hands that read the flood cycle mending a woven net, riverbank clay and raw cotton tones, dignity and ancestral knowledge in natural light, 8k`

### **Parkcore**

**№ 669 / 1001** · *Public Green as Urban Commons*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → MATTER ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O gramado como sala de estar pública** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Parkcore: mantas de piquenique, bicicletas deitadas e a cidade dividindo o mesmo verde comum.

**Paleta de cores** verde de grama, xadrez de manta, azul de tarde

**Melhores usos:** lifestyle, editorial, campanhas

**MidJourney:** `[tema], parkcore aesthetic, picnic blankets and bicycles on shared public green --v 6`

**Prompt universal (Seedream):** `Shot on Olympus mju-II, a parkcore afternoon, picnic blankets scattered like living rooms across public grass, bicycles lying in the shade and kites overhead, checkered textiles on lawn green under an easy blue sky, the city sharing one commons, candid warmth, 8k`

### **Paulista**

**№ 675 / 1001** · *Concrete Speed Under a Gray Sky*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Concreto, pressa e céu cinza-garoa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Paulista: Minhocão e avenidas em fluxo, o cinza de São Paulo como identidade e orgulho de ritmo.

**Paleta de cores** cinza de concreto, amarelo de táxi, garoa

**Melhores usos:** street, editorial brasileiro, documental

**MidJourney:** `[tema], paulista aesthetic, São Paulo concrete and drizzle, Minhocão overpass flow --v 6`

**Prompt universal (Seedream):** `Shot on Ilford Delta 400 with 28mm lens, a paulista street scene under the Minhocão overpass, concrete canyons and hurried silhouettes in the famous garoa drizzle, Thomaz Farkas modernist eye on São Paulo's gray pride and relentless rhythm, rich black-and-white grain, 8k scan`

### **Prairie**

**№ 712 / 1001** · *Frontier Myth Tailored for Modern Wear*

**Nível:** 🔴 Primary

**Eixo:** DOMAIN ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** a série Little House de Laura Ingalls Wilder tornou o corte legível — o sistema da pradaria despiu o sentimento pastoral europeu e fez do horizonte sem árvores e do fato material da madeira e do ferro trabalhados a lei irredutível, separando o pitoresco do funcional.

**Atmosfera e mood**

**O mito da fronteira sob medida** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pradaria: trigo até o horizonte, vestido de chita e a luz dourada da fronteira lembrada melhor do que foi.

**Paleta de cores** dourado de trigo, chita desbotada, céu imenso

**Melhores usos:** moda, editorial, paisagens

**MidJourney:** `[tema], prairie aesthetic, wheat to the horizon calico dress, frontier myth remembered golden --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya Universal Press with 100mm lens, a prairie scene, a calico dress moving through wheat that runs unbroken to the horizon, frontier gold under an enormous sky, the myth remembered better than it was lived, wind-combed grass in warm grain, 8k`

### **Roadman**

**№ 762 / 1001** · *Puffer Jacket as Street Rank*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → SEMIOTICS ↑

**Atmosfera e mood**

**A jaqueta puffer como patente de rua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Roadman: puffer preta, pochete cruzada e o código visual do grime britânico nos conjuntos habitacionais.

**Paleta de cores** preto de puffer, cinza de concreto, refletivo

**Melhores usos:** moda urbana, música, editorial

**MidJourney:** `[tema], roadman aesthetic, black puffer crossbody bag UK estate, grime street rank --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-Pro2 with 23mm lens, a roadman portrait on a UK council estate walkway, black puffer jacket worn as street rank with a crossbody bag and balaclava rolled to a beanie, concrete gray and reflective trims under sodium dusk, grime-video energy held still, 8k`

### **Street**

**№ 855 / 1001** · *City speaking in its own accent*

**Nível:** 🟤 Tertiary

**Eixo:** DOMAIN ↑ → EXPRESSION ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** hip-hop, skate e punk soldados numa prática só — o hip-hop dá o muro e o tag, o skate a mureta e a linha, o punk a recusa; nenhum dos três pais produziria o código sozinho.

**Atmosfera e mood**

**A cidade falando no próprio sotaque** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Street: o instante decisivo na faixa de pedestres, vapor de bueiro e gestos que nenhuma direção de arte inventaria.

**Paleta de cores** cinza de asfalto, amarelo de táxi, neon refletido em poça

**Melhores usos:** documental, editorial, arte

**MidJourney:** `[tema], street photography aesthetic, decisive moment at the crosswalk manhole steam, the city in its own accent --v 6`

**Prompt universal (Seedream):** `Shot on Contax T3 with 35mm lens, a street photograph, strangers aligning for one decisive second at a steaming crosswalk, taxi yellow slicing asphalt gray while neon doubles itself in a puddle, gestures no art director could invent, the city speaking in its own accent, candid film honesty, 8k scan`

### **Urbanism**

**№ 932 / 1001** · *City Draws Its Own Behavior*

**Nível:** 🔴 Primary

**Eixo:** DOMAIN ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** a gramática da cidade-como-objeto-desenhado sobrevive à remoção de qualquer precursor e gera os próprios descendentes (Green, Smart, Pedestrian e outros substilos documentados) — assinatura de nó fundacional, não de reinterpretação.

**Atmosfera e mood**

**A cidade desenhando o próprio comportamento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Urbanismo: a praça que convida a sentar, o cruzamento que acalma o tráfego e a vida pública coreografada pelo desenho — Jane Jacobs contra o viaduto.

**Paleta de cores** cinza de calçada, verde de praça, âmbar de poste

**Melhores usos:** arquitetura, editorial, conceito

**MidJourney:** `[tema], urbanism aesthetic, plaza that invites sitting crossing that calms traffic, the city drawing its own behavior --v 6`

**Prompt universal (Seedream):** `Aerial photograph from a drone at dusk, an urbanism study, a well-drawn plaza pulling foot traffic into café clusters while raised crossings slow the cars around it, sidewalk gray and square green warmed by amber street lamps, the Jane Jacobs choreography visible from above, orderly living geometry, 8k`

### **Western**

**№ 975 / 1001** · *Frontier Myth Riding Beyond Its History*

**Nível:** 🔴 Primary

**Eixo:** DOMAIN ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** duas linhagens pairam atrás — mitologia da fronteira e pintura romântica do sublime — mas nenhuma sobrevive ao teste de remoção: o sistema material de cavalo, horizonte e superfície gasta coere por si só.

**Atmosfera e mood**

**O mito da fronteira cavalgando além da própria história** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Western: o cavaleiro minúsculo contra os monumentos de arenito, poeira dourada no contra-luz e o mito maior que qualquer fato que o gerou.

**Paleta de cores** arenito de monumento, poeira dourada, azul desbotado de céu

**Melhores usos:** cinema, editorial, capas

**MidJourney:** `[tema], western aesthetic, tiny rider against sandstone monuments golden backlit dust, myth larger than its history --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 903 SWC, a western vista, a lone rider dwarfed by Monument Valley sandstone towers as golden dust hangs backlit in the last hour, butte red and faded sky blue in John Ford scale, the frontier myth riding calmly beyond anything that actually happened, iconic monumental grandeur, 8k`

## Leitura do padrão — o que as 20 estéticas confirmam

o padrão da RESONANCE é o mais coerente de todos os já mapeados, porque a lista inteira responde a uma pergunta só: **o que continua vibrando depois que a cena acaba — e dá para apontar o objeto que fez a travessia de volta?**

### **O primeiro dado, antes de qualquer cluster**

**Zero entradas suprimidas.** Das ~55, todas são RESONANCE ↑. Nenhuma Liminality, nenhuma Naive, nenhum Hermitcore. E isso não é coincidência isolada: **EFFECT, RESONANCE e SAGA — o Ato III inteiro — não têm um único caso ↓ catalogado**, enquanto o Ato I tem Liminality (DOMAIN ↓) e o Ato II tem Naive (TECHNIQUE ↓) e Hermitcore (EXPRESSION ↓).

A razão é estrutural, não estatística. Legado é uma posição de limiar: uma estética só chega aqui porque a travessia já aconteceu. "Ressonância suprimida" não é uma estética menor — é uma imagem que passou e não deixou nada, e nada que não deixou rastro pode ser catalogado. O registro ↓ continua válido como prompt (a transitoriedade deliberada, a beleza contente em existir uma vez só), mas nenhuma das 1001 o ocupa como identidade.

### **Os seis clusters**

**1. O cômodo como recipiente de memória — o maior bloco.**

Cluttercore ("a sala que lembra"), Nestcore, Cozy, Hygge, Cottagecore, Grandmillennial, Bohemian Vintage, Solitude, Biophilic. Aqui a Marca de Campo é literal: o objeto herdado gasto exatamente no ponto onde a mão o segura, a almofada que ainda guarda a forma do corpo. É a prova do *afterimage* — o cômodo continua organizado por alguém que já saiu.

**2. Revival explícito — o Sankofa sem metáfora.**

Romantic Revival, Rockabilly, Neo Medievalcore, Yugo-Nostalgia, Synthwave, Egyptomania, Soft Colonial Wanderlust, Gothic IV. Corpo avançando, cabeça virada para trás, ovo intacto no bico. Anemoia é o caso-limite fascinante: saudade de um passado nunca vivido — o ovo é inventado, e a travessia de volta não tem para onde voltar. Ela existe na lista precisamente porque testa o mecanismo até o ponto de ruptura.

**3. Vibração física — o mecanismo sem alegoria.**

Cymaticism (geometria que o som desenha na água), ASMR (sussurro a cinco centímetros do ouvido), Pulsing, Cuban (a clave que mantém o tempo), Sertanejo (a viola caipira). Estas não *ilustram* ressonância, elas **são** o fenômeno: um corpo faz outro corpo vibrar sem contato direto.

**4. O afeto que persiste depois da causa.**

Melancholia ("hora azul mantida além da saída"), Elegiac, Eerie, Halcyoncore ("quatro potes de âmbar segurando o sol das quatro"), Gothic V, Solitude. O gatilho já passou; o estado não.

**5. Identidade regional em custódia viva.**

Hawaiian, Irish, Cuban, Scouse, Sertanejo, Folkloric, Summer Camp. Aqui opera o *Guardar* — a herança que só sobrevive porque continua circulando, nunca a vitrine lacrada.

**6. A irresolução deliberada — o que fica porque o olho não conseguiu fechar.**

Cryptidcore (RESONANCE ↑ → ESTHETICS ↓ — beleza retida por lei, o quadro que se recusa a resolver), Eerie, Oceanic Surrealism, Haiku, DECAY. O que não foi entregue é o que o cérebro continua processando.

### **O comportamento de polaridade — e é aqui que o sistema se prova**

RESONANCE é dominada por **XX por revisão**: Soft Grunge, Neo Minimalism, Synthwave, Romantic Revival, Rockabilly, Cozy, Nautical, Biophilic, Pixiecore, Grandmillennial, Scouse, Summer Camp, Soft Colonial Wanderlust. Isso é o oposto exato da EXPRESSION, onde XY (fusão e ruptura) dominava.

E faz todo sentido: **revisão *é* a viagem de volta**. Herdar intacto e re-instrumentar é o próprio movimento do Sankofa traduzido em polaridade. Uma posição sobre atravessar e retornar transformado não pode ser majoritariamente XY — romper e seguir em frente é exatamente a sombra do verbo Atravessar, fuga com passaporte.

### **Os pares secundários confirmam a leitura**

→ **ETERNITY** (Romantic Revival, Sertanejo, Grandmillennial, Gothic IV, Halcyoncore ↓, Anemoia ↓): quando o que vibra é medido em décadas.

→ **MATTER** (Biophilic, Bohemian Vintage, Cozy, Nautical, Phenomenological, DECAY): quando o objeto carrega o desgaste como prova.

→ **SAGA** (Yugo-Nostalgia, Broadway, Gothic V, Neo Medievalcore): quando o rastro já virou história e passa a ser lido em anéis.

### **O que a lista confirma**

RESONANCE não é "estética nostálgica" nem "clima emotivo" como rótulo. É qualquer estética cuja prova visual é **um objeto específico que sobreviveu a uma travessia e continua ativo do outro lado** — o cachecol do pai, a viola, o pote de âmbar, o clave, o cômodo que não apaga quando o corpo sai. Por isso Cymaticism, Hygge e Yugo-Nostalgia convivem na mesma posição: água vibrando, quatro velas em novembro e socialismo preservado em âmbar coletivo são objetos incomparáveis, mas todos passam pelo mesmo teste — *o que ficou vibrando tem um portador nomeável, ou a cena simplesmente terminou?*

o padrão é ainda mais nítido do que em INTEGRITY — e num sentido diferente: aqui não é sobre uma regra estrutural que se repete em escala, é sobre **território como campo de jurisdição nomeável**.

**O núcleo: toda estética aqui é organizada por um lugar, uma instituição ou uma posição de classe específica — nunca por um princípio universal.**

Repare a variedade e o que ela tem em comum:

**Território geográfico real:** Paulista (São Paulo), Western/Prairie (a fronteira americana, as planícies), Pantanal Wetland Indigenous (o pantanal) — a estética *é* o lugar; removida a geografia, não sobra sistema.

**Território institucional:** Frat (a casa da fraternidade, o rush), BUSINESS (a sala de reunião, o escritório), Bourgeois (o objeto que certifica status antes de ser usado) — pertencimento a uma instituição ou classe é a própria gramática visual.

**Território praticado/informal:** Street (a rua como espaço vivido), Roadman (a estrada, o estate britânico), Parkcore (o parque como bem comum), COFFEE SHOP (a mesa que se compra por um café) — micro-territórios urbanos que só existem porque alguém os reivindica pelo uso, não pela posse.

**Território expandido a worldview:** Cosmopolitanism ("o mundo é a única casa"), Urbanism (a cidade como objeto desenhado), Empire (o alcance imperial), Dataism (o mundo tornado campo consultável) — aqui o território cresce até virar uma visão de mundo inteira, mas a lógica de fronteira/jurisdição continua.

**Território tribal/subcultural:** Jock (o vestiário, o campo), GEEK (a convenção, a comunidade de fã), Athleisure (o código do esporte que migra para a vida cotidiana) — pertencimento via prática e código, não via lugar físico.

Isso bate exatamente com a lógica do Tetractys que a página descreve: a base carrega o ápice — nenhuma dessas estéticas se sustenta a partir do topo, todas exigem a infraestrutura visível (a sede da fraternidade, a rede de skate spots, a mesa lotada da cafeteria) sustentando a figura. E a fronteira é sempre visível e ativa: o rush que barra quem não pertence, o portão do subúrbio fechado do Bourgeois, o "quem pode se sentar aqui" do COFFEE SHOP — exclusão como prova de soberania, não como acidente.

**O caso que confirma a regra ao contrário:** Liminality é o único DOMAIN ↓ (suprimido) da lista — e faz sentido perfeito. Liminalidade é definida justamente pela *ausência* de território estável: é o estar-entre, sem jurisdição fixa. Ela existe na lista de DOMAIN precisamente porque nega o que DOMAIN afirma em todos os outros — a prova negativa de que território é o eixo que organiza essa posição inteira.

**O que isso confirma sobre o sistema:** DOMAIN não é "estética regional" nem "cultura de nicho" como rótulo — é qualquer estética cuja identidade visual só se sustenta dentro de uma jurisdição nomeável, com regras de admissão e uma base material que a sustenta. Por isso Paulista, BUSINESS e GEEK convivem na mesma posição: cidade, escritório e convenção de quadrinhos são jurisdições de naturezas completamente diferentes, mas todas passam pelo mesmo teste — *isto pertence a este campo, sob qual lei de admissão?*

# SYNERGY — o Triskele

<aside>
🌀

**Essência:** SYNERGY é a amplificação mútua entre elementos que permanecem distintos. Seu ideograma é o Triskele — três braços, um centro, uma rotação — gravado na pedra de entrada do vale do Boyne antes das pirâmides, com os intervalos entre os braços deliberadamente mantidos vivos. Sua física é a correlação de longo alcance da revoada: cada estorninho acopla-se apenas aos seis ou sete vizinhos imediatos e, sem atrito, uma curva na borda reorganiza milhares em milissegundos. Seu verbo é **Traduzir / Translating** — levar sentido entre mundos preservando o que os separa. Na imagem, o elemento se prova quando figurino, corpo, luz e arquitetura se intensificam mutuamente permanecendo legivelmente separados — e nada no quadro chega um tempo atrasado.

</aside>

## Prompt-mestre (imagem-síntese)

> A [figure/group] caught mid-rotation in [a real place with its own working tempo — specify: a stair, a curved wall, a threshold, moving water], weight low and already in phase with the room rather than imposing a tempo on it, three material orders visibly present and kept separable — [name order 1: e.g. stone/architecture], [name order 2: e.g. cloth/textile from the aesthetic's own vocabulary], [name order 3: e.g. skin/body] — each remaining independently identifiable while all three demonstrably answer the same rotation, a visible interval or change of material kept open at every junction so the eye can count the parts and still read one turn, the hand or body meeting the adjacent element in flawless local agreement (a palm passing an object, a fold of cloth catching an edge of stone), a second figure if present matched in phase — same breath depth, same speed, same lean — without mirroring or fusing into the first, drape and hem still carrying the arc of the motion just completed so nothing in the frame arrives a beat late, one available light source travelling along the same rotation as the body and casting a shadow that continues the gesture rather than cutting across it, one unified hour and temperature shared by all three material orders, [the aesthetic's own specific materials, palette, and setting inserted here], nothing fused into an undifferentiated smear and nothing addressed to the lens as command.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre):

> No strobe or flash freezing the motion into a pose, no shadowless catalogue lighting, no two light sources of different temperature, no arrested or held pose, no cleared white studio, no rigid tailoring cancelling the turn, no mirrored or matched second figure, no conductor's or directing gesture, no overhead diagram view of the group, no element pointing against the rotation, no fused undifferentiated swirl, no grooming so sealed that motion could not disturb it.
> 

### Como adaptar o prompt a cada estética

**Como usar para qualquer estética da lista:** troque apenas os três colchetes de "material order" e o cenário pelo vocabulário próprio da estética — nada na estrutura do prompt nomeia um lugar, cultura ou tribo específica, só os mecanismos universais que a página já define como SYNERGY (rotação em três braços, acoplamento local, zero latência, luz viajante, intervalo mantido vivo). Por exemplo, para **Ubuntu** os três "orders" seriam corpo/corpo/círculo humano; para **Web 2.0**, tela/mão/rede; para **Mono-ha**, pedra/aço/vão entre eles — a arquitetura do prompt permanece idêntica.

## Fundamentos do elemento

**Identity.** Mutual amplification among elements that stay distinct. Its ideogram is the Triskele carved into the entrance stone at the Boyne valley before the pyramids: three arms, one centre, one rotation — and the intervals between the arms deliberately kept alive. The monument that carries it was built so the sun enters once a year, at the winter solstice, through a single aperture: an entire architecture tuned to one event. Its physics is long-range correlation. A starling in a murmuration does not watch the flock; it holds constant topological distance to its six or seven immediate neighbours, and because that local coupling carries no friction, a turn at the edge reorganizes thousands of birds in milliseconds. Its verb is Traduzir / Translating: carrying meaning between worlds while preserving what separates them — the shadow being the distortion of what you carry in order to please the receiving world. In an image this element is proven when garment, body, light, and architecture visibly intensify one another while remaining legibly separate, and when nothing in the frame arrives a beat late. (Distinct from INTEGRITY, 1 — the pillar proves one logic across scales of a single thing; the spiral proves three different things turning on one beat. Distinct from COHERENCE, 19 — the endless knot is one line crossing itself without break; the triskele is three lines that rotate together and never fuse.)

**Zero latency, made visible.** The failure state of this element is *lag*: audio arriving milliseconds behind the lips, the cut landing before the emotion finishes, the actor entering ahead of the cue. Every SYNERGY frame must be photographic proof that nothing in it is out of time — a hem still carrying the arc of the step that just ended, a second figure whose weight shift matches the first's inside the same beat, a shadow rotating on the same axis the body rotates on, a reflected ripple that agrees with the hand that made it. One element early or late and the frame reads as bad sync: the viewer feels the discomfort in the body before locating its cause.

**The three arms stay three.** Fusion is not the goal and is in fact the second failure state. If cloth, limb, and architecture blend into one undifferentiated swirl, the image has produced a smear, not a system. Each arm must remain independently identifiable — this is stone, this is silk, this is a shoulder — while all three demonstrably answer the same rotation. The interval between them is load-bearing: keep a visible gap, a change of material, a contrast of temperature at every junction, so the eye can count the arms and still read one turn.

**Local coupling over global address.** A SYNERGY frame is never built by addressing the crowd. It is built by making one relationship — between two adjacent elements — perfect, then letting the correlation propagate outward through the composition. In practice: the model's hand and the object it touches must be in flawless agreement; the second figure and the first must be in flawless agreement; the near fold of cloth and the near edge of architecture must be in flawless agreement. Depth then carries the wave: figures further back need only echo their own nearest neighbour, never the protagonist. A composition in which every distant element points at the central figure reads as command-and-control, which is the opposite element.

## Corpo — postura, fase e gesto

**Model posture & structure.** The body of someone already in phase with the room, not the body of someone imposing a tempo on it. Weight low, breath low, the minimum-energy state of a system that has stopped spending force to hold its position — the difference between a stabilized rig gliding through owned space and a handheld camera fighting its own operator. Movement is continuous and rotational rather than held: a turn caught mid-arc, a step whose momentum is still visibly travelling through the fabric, a torso that has already begun the next rotation while the trailing arm completes the last. Never the arrested pose; never the frozen contrapposto (that is INTEGRITY's spine). The shoulders and hips counter-rotate on the same axis, so the body itself contains two of the three arms. Where a second body is present, the two are coupled at close range and matched in phase — same breath depth, same speed, same lean — while remaining physically separate and never mirroring each other exactly; mirroring collapses two arms into one. The face is calm and low-arousal: this body is not performing effort, because effort is friction and friction is what SYNERGY has removed.

### **Gesture.** One verb governs this position, with one borrowed instrument.

**Traduzir · Translating** is the only gesture the spiral holds: carrying sense from one world into another without erasing what separates them. Photographed, it is the hand at the junction — fingers reading a surface that belongs to a different material order than the garment, a palm passing an object across a threshold, a body meeting an element from an incompatible register and losing nothing in the meeting. The gaze accompanies the carried thing rather than the camera: eyes down and across, following the transfer. The shadow of the gesture is distortion for approval — a hand that adjusts what it carries so the receiving world will like it better; visible in the frame as a gesture aimed at the lens instead of at the junction. Traduzir borrows Semiotics from the second act, so the transferred thing must be legible as belonging to a named other order, and it anticipates Coherence in the third: every well-torqued alliance wants to become an endless knot. Forbidden throughout: the conductor's gesture. No raised baton, no directing arm, no figure visibly commanding the others. Whoever shouts in the frame has already proven the correlation failed.

## Regras de imagem — do figurino à prova de correlação

**Look & styling continuity.** The garment is the visible interval between two systems. Build the look from at least two material families that belong to different worlds and let them stay distinguishable while sharing one rotation: bias-cut silk over technical mesh, hand-loomed wool against lacquered leather, festival embroidery over a working boot. The cut must be rotational rather than architectural — bias, spiral seam, wrap, cross-over, asymmetric hem — so the cloth records the turn the body is making instead of resisting it. Drape carries the correlation: the fabric must have enough weight and enough looseness to arrive a fraction behind the body and then catch up inside the same frame, which is the visible proof of transmission without loss. Layering is coupled, not stacked: each layer answers only the layer it touches. Refused: rigid tailoring that cancels the turn, matching sets that fuse the arms into one, any accessory that would break contact with the body in motion. One closure or fastening should sit at the junction between two material families, photographed as the point of exchange.

**Camera.** The camera is in phase with the subject, never in command of it. Available light almost always, because a strobe freezes motion into a pose and a pose breaks the correlation contract — the moving thing must be legibly still moving. Long lens from a courteous distance to compress the near and far arms of the spiral into one dense plane where they visibly belong to the same world; or a close, coupled wide angle held at the subject's own eye level, moving with the body rather than watching it. Height at eye level; never the overhead diagram of the flock, which converts correlation into administration. Shutter chosen for the ratio, not for sharpness: fast enough that the face and the primary garment hold, slow enough that the periphery — hem, hair, trailing hand, background figure — carries real motion blur as evidence that the crossing physically occurred. When the camera moves, it moves like a stabilized rig through owned space: smooth, unhurried, absorbing the step. Handheld tremor reads as trespass; a locked tripod reads as the wrong element entirely.

**Composition.** Rotational and tri-partite. Build three distinct compositional currents that turn on one shared centre — a curved architectural line, a curved textile line, a curved bodily line — and place the centre off the geometric middle so the eye keeps travelling rather than settling. Spiral scaffolding is native: a staircase, a coiled rope, a curved balustrade, a whirl of dust, a bend of water. Vectors must sum: the sightline of the second figure, the fall of the drape, and the direction of the light all resolve toward the same rotational direction — one element pointing against the turn is the compositional signature of dissonance. Keep the intervals open: visible gaps of ground between the three currents, so the arms can be counted. Depth is built in adjacency chains rather than hierarchy — foreground answers midground, midground answers background, and no plane addresses the whole frame at once. Where a crowd or a second body appears, place them at close topological distance, six or seven paces at most, and match their phase to the protagonist without matching their shape.

**Lighting.** One light source, travelling. The key must have a direction that agrees with the rotation — a raking beam that follows the same turn the body and the cloth are making, so the highlight travels the spiral instead of cutting across it. Available daylight is the native register: window light entering at one angle through a real aperture, sun through a doorway, the single solstice beam of the ideogram's own architecture. Shadow behaves as the third arm: it must fall on the same axis the body turns on, so the cast shadow reads as a continuation of the gesture rather than as a byproduct of it. Temperature is unified across all three arms — cloth, skin, and stone answer to the same hour — because two temperatures crossing the frame is the visible signature of two systems that never entered phase. Falloff should be gradual and continuous rather than stepped, letting one element hand the light to the next across their junction. Refused: shadowless catalogue flatness, which cancels rotation entirely; and multiple hard sources from opposing sides, which shatters one turn into competing beats.

**Beauty detail.** Grooming is tuned, not styled — the face of a nervous system at rest inside a room it agrees with. Skin carries a real, low-level sheen of exertion or ambient warmth, because SYNERGY is almost always photographed inside genuine motion or genuine climate: a damp hairline, a flush along the cheekbone, salt or dust settled where the air actually put it. The finish is satin rather than matte or lacquered, so light can travel across the face on the same continuous falloff it travels across cloth and stone. Hair is the fastest of the three arms and must be the clearest carrier of the turn: cut, tied, or loose in a way that records rotation and arrives a fraction behind the head, with the trailing ends permitted to blur while the face holds sharp. Colour on the face is drawn from the same family as the garment's second material, so the two worlds are visibly related without being identical — a lip that answers a leather, a lid that answers a stone. The jaw is unclenched and the brow is unheld: the twenty-minutes-in state, where the body has stopped negotiating with the environment. Refused: frozen editorial lacquer, cosmetic geometry that would survive unchanged through a turn, and any grooming so sealed that motion could not disturb it. If the styling could not survive the physical conditions in the frame, the crossing was not real. Hair is built as a visible multi-material assembly rather than a groomed surface — keratin, plus one botanical or structural order woven directly into it (dried branches, pressed flowers, wire, a hat built into the hair itself), each order kept legibly separate rather than disguised into a single texture — and the whole construction engineered to survive a real wind machine, so the trailing motion blur is captured in-camera and never added afterwards. If the woven element could not survive that wind, it is a prop and the arm is decorative.

**Cenography.** A real place with its own working tempo, entered rather than built. The set must contain a rotational architecture the body can genuinely couple with — a stair, a curved wall, a mooring line, a threshold, a body of water, a working floor with a wear path — and that architecture must have an existing rhythm the figure joins instead of overrides. Three material orders should be present and separable: one geological or built, one textile or organic, one human. The junctions between them are the set's real furniture; place the camera where two orders touch. Where a group appears, they are cast as a topological neighbourhood — a family, a crew, a band, a scene — with a legible shared code and real proximity, never extras arranged around a star. Ambient elements should be in motion at the room's own tempo: dust in the beam, steam, a curtain in a real draft, water moving at its own rate — evidence that the environment has a pulse and the figure has matched it. Any aging or patina is physically real, and the space should read as continuing to function after the camera leaves. Refused: the cleared white studio, which has no tempo to synchronize with; and the rented location with no wear, no draft, and no working order.

**Colour.** One temperature and one hour across the whole frame, but three separable families inside it — the visual equivalent of three instruments tuned to the same A. Draw each family from a different material order and let them share a common warmth or coolness rather than a common hue, so the eye reads relationship rather than repetition. Saturation should sit mid-range and continuous: extremes lock elements into isolation, and a fully flattened grade erases the intervals. Where a second figure or a crowd appears, their palette must be a legible variation on the protagonist's, never a match and never a clash. The diagnostic failure is a single element carrying a colour from a foreign hour — one cool face in a warm room, one screen-blue accent in an earth palette — which registers instantly as the element that never entered phase.

**Correlation proof.** Wherever the composition allows it, plant one device that demonstrates transmission without loss: a second figure whose motion is one beat downstream of the first and identical in quality; a reflection in moving water that agrees with the hand that disturbed it; a rope or a hem whose far end is still carrying the wave its near end started; dust or steam bending along the exact path the body just travelled. This is the image's own murmuration — the closest a still photograph comes to proving that a signal crossed the frame without dissipating. A device that shows the far end *out* of phase with the near end is the single most legible failure this element can produce.

**Group geometry & casting.** Where more than one body appears, the group is not a crowd and not a backdrop — it is one instrument with more moving parts than a single body can generate. Cast it as a real topological neighbourhood: a family, a crew, a scene, siblings, a band, people who already share a code and already stand at close range, never extras arranged around a star. Every figure keeps their own distance and their own dignity in frame — distinct silhouette, distinct colour variation, distinct facial state — because difference sustained, not dissolved, is the whole contract; a group styled into uniformity has fused the arms, and a group orbiting one protagonist has become command-and-control. The formation is designed before the bodies arrive: a geometry the figures are translated into rather than one improvised in front of the lens, with each body's phase matched to its nearest neighbour and no one breaking formation. Light is recalibrated at the level of physics rather than headcount — the key adjusted until every complexion present renders deep, saturated, and dimensional, because a frame whose lighting was calibrated for one skin and merely tolerates the rest has already dropped an arm. Collective regality replaces the lone figure: many people, one rotation, none swallowed.

## Linhas de praticantes prontas para prompt (dos códices)

*Shutter.* Toni Frissell — available-light outdoor action, real athletic movement, sharp face and garment against permitted peripheral motion blur. Norman Parkinson — bright outdoor daylight key, real distant location, dynamic elegant motion, dry wit in the expression. Frank Horvat — available street light, real passersby sharing the frame, candid 35mm documentary framing, natural environmental interaction. Ruth Ossai — printed studio backdrop, pattern-on-pattern styling, family and community casting, exuberant frontal poses. Amber Pinkerton — bright Caribbean daylight, sibling and community casting, vivid tropical colour, proud relaxed poses between two homes.

*Hair and face.* Odile Gilbert — monumental destructured period silhouette, dried branches or pressed flowers woven directly into the hair, hair built as an independent sculptural object that never fuses with the garment, motion-blur trail earned from a real studio wind machine, lyrical atmosphere carried by movement rather than by finish.

*Styling.* Simon Foxton — three wardrobes the market calls incompatible held in one rotation, nylon trackwear with white football socks, hip-hop gold and leather codes, a deliberately delicate pose against aggressive kit, a suburban backdrop, the preserved distance between the arms carrying both the humour and the charge. Jerry Stafford — one long-term muse in couture with cinema, photography, and costume held in the same frame, patient observational stillness, disciplines informing one another without merging.

*Commission and light.* Edward Enninful — deep saturated light calibrated so every complexion in the frame renders dimensional, a communal group frame of distinct individuals each keeping their own distance and dignity, street grammar and couture polish at equal rank with neither absorbed, collective regal joy instead of a single figure.

*Motion.* Gordon von Steiner — multiple bodies moving as one pattern with none breaking formation, camera and cut locked to strict musical bars, practical in-camera speed ramp, rewind, or freeze rather than composited effect, human geometry designed in the storyboard before the bodies arrive.

*Stage tempo.* Étienne Russo and Alexandre de Betak — a room given its own engineered pulse (snowfall rate, wave interval, a light rig choreographed to sound) that the bodies visibly join rather than override, the environment's frequency doing the work no gesture is allowed to do.

## Polaridades — repertório amplificado (↑) e suprimido (↓)

**↑ Amplified — repertory.** Three separable systems rotating on one shared beat: a garment cut to record the turn, a body already in phase with a room that has its own tempo, one travelling light source whose highlight follows the same rotation, a real place with a working rhythm, close topological coupling between adjacent elements, available light and permitted peripheral blur as evidence the crossing physically occurred, one unified hour and temperature across all three arms, intervals kept visibly open.

> **↑ Prompt.** A worn stone spiral staircase in a working building at mid-morning, a figure caught mid-turn three steps up in a bias-cut wool gown whose hem is still carrying the arc of the step just finished while the shoulders have already begun the next rotation, the raised hand reading the curve of an iron handrail at the exact junction where cloth meets metal, a second figure one landing below turning one beat downstream in the same tempo and a different colour of the same warm hour, hair trailing a fraction behind the head with the ends blurred and the face held sharp, a single daylight source entering through one high window and raking along the same turn so the cast shadow rotates on the axis the body rotates on, dust visibly bending through the beam along the path the body just travelled, damp hairline and satin skin with a real flush along the cheekbone, three material orders kept separable with open ground between them — stone, wool, iron — all answering one rotation, available light only, long lens at eye level compressing near and far arms into one plane, nothing in the frame arriving a beat late.
> 

> **↑ Negative line.** No strobe or flash freezing the motion into a pose, no shadowless catalogue lighting, no two light sources of different temperature, no arrested or held pose, no cleared white studio, no rigid tailoring cancelling the turn, no mirrored or matched second figure, no conductor's or directing gesture, no overhead diagram view of the group, no element pointing against the rotation, no fused undifferentiated swirl, no grooming so sealed that motion could not disturb it.
> 

**↓ Suppressed — repertory.** Co-presence without exchange: elements complete in themselves and indifferent to their neighbours, no shared beat and no shared hour, arrested posture, a set with no tempo to join, flat sourceless light that cancels rotation, and visible latency between the figure and everything around it.

> **↓ Prompt.** A model stands arrested and expressionless in a cleared white studio, weight locked and both arms flat at the sides, the garment hanging exactly as it would on a rack with no memory of any movement, an unrelated wooden stool placed a metre away at no relation to the body, a second figure at the far edge in a wholly different tempo and a cooler hour, shadowless even light from everywhere and nowhere so nothing rotates and nothing casts, lacquered sealed grooming that no motion could disturb, no dust, no draft, no wear on the floor, every element in the frame self-contained and indifferent to its neighbours.
> 

> **↓ Negative line.** No rotational architecture, no travelling key light, no peripheral motion blur, no coupled second figure, no shared temperature, no real working location, no junction between material orders, no evidence of transmission.
> 

## Estéticas relacionadas a SYNERGY (A–Z)

As 24 estéticas classificadas sob SYNERGY, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary · ⚫ Quaternary), eixo secundário e polaridade (XX — continuidade · XY — disrupção).

### **02 FLUX**

**№ 002 / 1001** · *Nothing keeps its outline*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → TECHNIQUE ↑

**Polaridade:** XX — continuidade por transmissão

### **03 RESONANCE**

**№ 003 / 1001** · *One string answers another*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por transmissão

### **10 NEXUS**

**№ 010 / 1001** · *Every thread crosses here*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → SYNTHESIS ↑

**Polaridade:** XX — continuidade por transmissão

### **Brazilian**

**№ 118 / 1001** · *Two pulses that never resolve*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** nenhuma estética anterior pode ser nomeada como sua criadora — o pulso duplo que nunca se resolve é condição de raiz da própria formação do país; remover essa não-resolução permanente colapsa o sistema inteiro.

**Atmosfera e mood**

**Dois pulsos que nunca se resolvem** — (1001 Aesthetics, interpretação)

Brasilidade: mistura de ritmos e texturas — praia, cidade e mata — em cores tropicais quentes.

**Paleta de cores** verde, amarelo, azul e tons tropicais quentes

**Melhores usos:** cultura, branding, editorial

**MidJourney:** `[tema], vibrant Brazilian culture aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a vibrant Brazilian street scene at golden hour, tropical color colliding with rhythmic movement, beach city and forest textures layered in one frame, capoeira silhouette against painted colonial walls, warm syncopated joy, saturated documentary richness, cinematic warmth, 8k`

### **Early Medieval Ottonian**

**№ 258 / 1001** · *Saxon Court That Calls Itself Rome*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A corte saxônica que se chama Roma** — (1001 Aesthetics, interpretação)

Otoniano: figuras alongadas de olhos enormes, ouro imperial denso, majestade bíblica com ambição romana.

**Paleta de cores** ouro denso, vermelho imperial, verde profundo

**Melhores usos:** histórico, arte sacra, editorial

**MidJourney:** `[tema], Ottonian illuminated art, elongated figures on dense gold --v 6`

**Prompt universal (Seedream):** `Museum-grade scan of an Ottonian manuscript painting, elongated hieratic figures with enormous eyes on dense burnished gold ground, imperial red and deep green pigments, gold leaf catching the light, Saxon court majesty claiming Rome, 8k archival reproduction`

### **Eco Industrial**

**№ 266 / 1001** · *Every Output Becomes Someone's Input*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Todo resíduo vira insumo de alguém** — (1001 Aesthetics, interpretação)

Eco-industrial: fábrica circular, tubulações que reciclam, materiais reaproveitados visíveis com estética funcional.

**Paleta de cores** aço reciclado, verde funcional, sinalização industrial

**Melhores usos:** indústria, sustentabilidade, editorial

**MidJourney:** `[tema], circular eco-industrial facility, visible recycling loops --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 67 with 105mm lens, an eco-industrial scene, circular factory where every output becomes someone's input, visible recycling loops and reclaimed steel under skylight glow, moss softening the machinery, Edward Burtynsky industrial-landscape clarity, functional green industrial aesthetic, 8k`

### **Festival**

**№ 328 / 1001** · *Bunting, Garlands, and the Procession Through the Square*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Bandeirinhas, guirlandas e a procissão pela praça** — (1001 Aesthetics, interpretação)

Festa popular: praça enfeitada e multidão em celebração, cor coletiva, alegria comunitária em movimento.

**Paleta de cores** bandeirinhas multicoloridas, dourado de festa, céu de tarde

**Melhores usos:** cultura, eventos, editorial

**MidJourney:** `[tema], festival procession through the town square, bunting and garlands --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 45mm lens, a festival scene, bunting and garlands over a procession through the town square in bright midday sun, multicolored flags and celebration gold, confetti caught in the air, Steve McCurry vibrance, communal joy in motion, 8k`

### **Holospectrum**

**№ 439 / 1001** · *Newton's Prism Recombines the Whole Chord*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → COHERENCE ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O prisma de Newton recombina o acorde inteiro** — (1001 Aesthetics; código: Kinomoto, match aproximado)

Holoespectro: luz separada em arco-íris completo, holografia e iridesência, todas as cores presentes ao mesmo tempo.

**Paleta de cores** espectro completo, iridesência holográfica, branco de prisma

**Melhores usos:** design, editorial futurista, branding

**MidJourney:** `--sref 3203919373 --sw 1000` (Rainbow Line Rendering — match aproximado)

**Prompt universal (Seedream):** `Shot on Sony A7R with 90mm macro lens, a holospectrum image, Newton's prism splitting and recombining the whole chord of light, holographic iridescence with the full spectrum present at once, rainbow diffraction on white, 8k`

### **Interactive**

**№ 474 / 1001** · *Sensor Wall Changes When the Hand Arrives*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A parede de sensores muda quando a mão chega** — (1001 Aesthetics, interpretação)

Interativo: instalação responsiva, luz que segue o corpo, a obra que só existe com o visitante dentro.

**Paleta de cores** luz responsiva, ciano e magenta de projeção, escuro de galeria

**Melhores usos:** instalação, tech, editorial

**MidJourney:** `[tema], interactive art installation, sensor wall changing as the hand arrives, responsive light following the body --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7S III with 24mm lens at high ISO, an interactive installation image, a sensor wall changing when the hand arrives, responsive cyan and magenta projection in a dark gallery, Rafael Lozano-Hemmer responsiveness, the artwork existing only with the visitor inside it, 8k`

### **Lichencore**

**№ 522 / 1001** · *Crust on stone: lichen maps*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Crosta na pedra: mapas de líquen** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lichencore: vida lenta escrita em escala de rocha, colônias de sálvia, menta e ferrugem.

**Paleta de cores** sálvia, menta, ferrugem, pedra fria

**Melhores usos:** natureza, textura, editorial

**MidJourney:** `[tema], lichencore aesthetic, crustose lichen mapping continents on cold stone, sage and rust colonies --v 6`

**Prompt universal (Seedream):** `Extreme macro photograph shot with Laowa 25mm ultra-macro lens, a lichencore image, crustose lichen mapping slow continents across cold granite, sage mint and rust colonies feathered at their advancing edges, flat overcast light revealing every powdered texture, a cartography of centuries per centimetre, patience made visible at rock scale, 8k`

### **Mid-Century Modern**

**№ 570 / 1001** · *Walnut, Glass, and the Open Plan*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Nogueira, vidro e planta aberta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mid-century modern: otimismo construído em madeira e luz, a casa de Palm Springs ao entardecer.

**Paleta de cores** nogueira, mostarda, teal de 1958

**Melhores usos:** interiores, arquitetura, editorial

**MidJourney:** `[tema], mid-century modern aesthetic, walnut and glass open plan at dusk, Eames furniture, Palm Springs --v 6`

**Prompt universal (Seedream):** `Shot on Linhof Technika with 121mm lens, a mid-century modern image, walnut and glass opening the plan to a Palm Springs dusk, Eames chairs in mustard and 1958 teal, Julius Shulman architectural clarity, optimism built in wood and light, 8k`

### **Mono-ha**

**№ 580 / 1001** · *Stone and Steel Allowed to Remain Themselves*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Pedra e aço autorizados a permanecer eles mesmos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mono-ha: matéria apresentada sem transformação, encontro entre rocha bruta e chapa industrial.

**Paleta de cores** cinza de pedra, aço fosco, chão de galeria

**Melhores usos:** arte, instalação, editorial conceitual

**MidJourney:** `[tema], mono-ha aesthetic, raw boulder resting on industrial steel plate, materials left as themselves --v 6`

**Prompt universal (Seedream):** `Shot on Toyo 4x5 view camera with 150mm lens, a mono-ha image, a raw boulder resting on an industrial steel plate in quiet gallery light, stone grey against matte metal, Lee Ufan restraint, materials allowed to remain themselves, 8k`

### **Myceliumcore**

**№ 583 / 1001** · *Underground Network Wearing Fruiting Bodies*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Rede subterrânea vestindo corpos de frutificação** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Myceliumcore: fungos como infraestrutura visível, fios brancos costurando o chão da floresta.

**Paleta de cores** branco de hifa, marrom de serapilheira, âmbar de cogumelo

**Melhores usos:** natureza, ciência, editorial

**MidJourney:** `[tema], myceliumcore aesthetic, white hyphae threading forest floor litter, amber mushrooms fruiting --v 6`

**Prompt universal (Seedream):** `Shot on OM System OM-1 with 90mm macro lens at forest-floor dusk, a myceliumcore image, white hyphae threading through leaf litter as amber mushrooms fruit above, the underground network wearing visible bodies, quiet infrastructure of the woods, 8k`

### **Naturecore**

**№ 593 / 1001** · *Forest Without the Picnic Filter*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → RESONANCE ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Floresta sem o filtro de piquenique** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Naturecore: mata real com lama, casca e clorofila, beleza sem cesta de vime.

**Paleta de cores** verdes profundos, marrom de casca, luz filtrada

**Melhores usos:** natureza, editorial, bem-estar

**MidJourney:** `[tema], naturecore aesthetic, raw forest without the picnic filter, mud bark chlorophyll --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 67 with 105mm lens, a raw forest scene without the picnic filter, wet bark mud and dripping chlorophyll after rain, deep green shadow and one shaft of filtered light, honest wilderness texture in medium format grain, 8k`

### **Organic**

**№ 653 / 1001** · *Curve That Refuses the Ruler*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A curva que recusa a régua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Orgânico: vagens, conchas e madeira sem corte reto, a forma decidida pelo crescimento.

**Paleta de cores** verdes vivos, casca, marfim de semente

**Melhores usos:** natureza, produto, branding

**MidJourney:** `[tema], organic aesthetic, curve refusing the ruler, form decided by growth --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 645 Pro with 80mm macro lens, an organic still life of seed pods shells and uncut driftwood, every curve refusing the ruler because growth made the decision, living greens bark and seed ivory in soft north light, tactile natural detail, 8k`

### **Sorority**

**№ 832 / 1001** · *Sisterhood Choreography in Collegiate Display*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a sociedade literária do século XIX (filiação fechada), a academia feminina antebellum (gramática de exibição) e a heráldica de broches das auxiliares maçônicas são soldadas numa forma só — nenhum ancestral sobrevive intacto; três linhagens fundem-se num sistema colegiado que nenhuma produziria sozinha.

**Atmosfera e mood**

**Coreografia de irmandade em exibição universitária** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sorority: bid day em cores combinadas, gritos de guerra ensaiados e a escadaria da casa como palco de pertencimento.

**Paleta de cores** rosa de letra grega, branco de varanda, dourado de tarde

**Melhores usos:** lifestyle, editorial, documental

**MidJourney:** `[tema], sorority aesthetic, bid day matching colors rehearsed chants house steps, sisterhood choreography --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F100 with 35mm lens on Portra 400, a sorority bid day, matching pink outfits mid-chant on the white porch steps of the chapter house, Greek letters and balloons in golden afternoon, sisterhood performed as precise joyful choreography, warm collegiate film color, 8k scan`

### **South Korean**

**№ 833 / 1001** · *Hanbok Lines Under Seoul Neon*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** contenção confuciano-budista, a assimetria pungnyudo da própria Coreia e o motor de soft power do Hallyu soldados numa forma só — uma gramática que liga uma cosmologia milenar ao espetáculo de banda larga; fusão que nenhuma das três linhagens produziria sozinha.

**Atmosfera e mood**

**Linhas de hanbok sob o neon de Seul** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sul-coreano: a curva serena do hanbok contra letreiros de Myeongdong — cinco séculos e cinco minutos coexistindo.

**Paleta de cores** jade de hanbok, magenta de neon, branco de seda

**Melhores usos:** cultura, moda, editorial

**MidJourney:** `[tema], south korean aesthetic, hanbok curve against Myeongdong neon, five centuries beside five minutes --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7 IV with 55mm lens, a South Korean night portrait, the serene curved lines of a jade silk hanbok standing calm against Myeongdong neon signs, magenta glow rimming white silk sleeves, five centuries and five minutes sharing one frame in Seoul, luminous cinematic contrast, 8k`

### **Systems**

**№ 889 / 1001** · *Beauty found in how everything connects*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** a Arte Conceitual fornece o único pai; Systems reinstrumenta essa herança desmaterializando o objeto um passo além — para a rede de dependências que o produz.

**Atmosfera e mood**

**A beleza de como tudo se conecta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sistemas: diagramas de fluxo, redes e dependências visíveis — a estética de enxergar o mecanismo inteiro de uma vez.

**Paleta de cores** azul de diagrama, branco técnico, laranja de nó crítico

**Melhores usos:** infografia, conceito, editorial

**MidJourney:** `[tema], systems aesthetic, flow diagrams visible dependencies whole mechanism at once, beauty in how everything connects --v 6`

**Prompt universal (Seedream):** `Ultra-precise diagrammatic composition, a systems visualization, hundreds of nodes and flow lines resolving into one legible network with critical paths burning orange through diagram blue, dependencies made visible until the whole mechanism can be seen at once, elegant technical beauty on white, 8k`

### **Toyism**

**№ 903 / 1001** · *Anonymous Artists Build a Shared Playground*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → EXPRESSION ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** o CoBrA fornece o único pai dominante; o Toyism reinstrumenta essa herança endurecendo o espírito coletivo num conjunto estrito de regras e enxertando uma superfície derivada do Pop.

**Atmosfera e mood**

**Artistas anônimos constroem um playground compartilhado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Toyismo: figuras lúdicas de contorno preto, pontos e narrativa codificada — o coletivo holandês pintando sob pseudônimo desde 1992.

**Paleta de cores** primárias de brinquedo, contorno preto, pontos de confete

**Melhores usos:** arte, murais, editorial

**MidJourney:** `[tema], toyism aesthetic, playful black-outlined figures coded narrative dots, anonymous collective playground --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Toyist painting, playful black-outlined figures and coded storybook creatures packed into a shared dreamscape stippled with confetti dots, toy-box primaries laid flat and clean, the anonymous Dutch collective building one playground under many pseudonyms, joyful precise detail, 8k scan`

### **Ubuntu**

**№ 919 / 1001** · *Personhood Built Through the Human Circle*

**Nível:** 🟤 Tertiary

**Eixo:** SYNERGY ↑ → EXPRESSION ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** cultura material vernacular bantu, estética política pan-africana e pensamento ético comunitário convergem aqui, cada um fornecendo uma camada estrutural que nada substitui — híbrido multilinhagem, não revisão de um único pai.

**Atmosfera e mood**

**A pessoa construída pelo círculo humano** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ubuntu: “eu sou porque nós somos” — a roda de conversa sob a árvore, as mãos dadas no conselho e a identidade tecida em comunidade.

**Paleta de cores** dourado de entardecer, terra vermelha, tecido de comunidade

**Melhores usos:** cultura, comunidade, documental respeitoso

**MidJourney:** `[tema], ubuntu aesthetic, circle of conversation under the tree I am because we are, personhood through community --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D780 with 35mm lens, an ubuntu gathering at golden hour, a circle of elders and children in conversation under a broad acacia as hands link across generations, sunset gold on red earth and community cloth, personhood visibly built through the human circle, warm dignified documentary light, 8k`

### **Vaudeville**

**№ 941 / 1001** · *Variety Held Together by the Next Act*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** o programa de dez atos e o relógio de apresentação contínua sobrevivem à remoção de qualquer fonte isolada — o concert saloon, o olio de minstrel — e geram os próprios descendentes no rádio, na revista e na televisão: assinatura de nó fundacional, não de reinterpretação.

**Atmosfera e mood**

**A variedade sustentada pelo próximo número** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vaudeville: o malabarista sai, a cantora entra, o cão adestrado espera na coxia — 1915 inteiro cabendo entre duas cortinas.

**Paleta de cores** vermelho de cortina, dourado de ribalta, sépia de cartaz

**Melhores usos:** histórico, artes cênicas, editorial

**MidJourney:** `[tema], vaudeville aesthetic, juggler exits singer enters trained dog in the wings 1915, variety held together by the next act --v 6`

**Prompt universal (Seedream):** `Shot on a Graflex Speed Graphic with flash powder, a vaudeville stage in 1915, a plumed singer mid-note at the footlights while a juggler exits left and a trained dog waits in the wings, curtain red and limelight gold over poster sepia, the whole evening held together by whatever comes next, theatrical period charm, 8k scan`

### **Villagecore**

**№ 952 / 1001** · *Community Memory Kept in Daily Craft*

**Nível:** 🔴 Primary

**Eixo:** SYNERGY ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** Pastoralismo, Arts and Crafts e Mingei são retratos tirados da vida de aldeia, não pais que a produziram; o assentamento baseado em comuns é um nó-raiz que outros movimentos citam, não um ramo que os cita.

**Atmosfera e mood**

**A memória da comunidade guardada no ofício diário** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Villagecore: o forno comunal aceso, cestas trocadas na praça e cada família reconhecível pelo ponto do bordado — a aldeia como arquivo vivo.

**Paleta de cores** trigo de praça, terracota de forno, azul de avental

**Melhores usos:** cultura, lifestyle, editorial

**MidJourney:** `[tema], villagecore aesthetic, communal oven baskets traded on the square families known by their stitch, the village as living archive --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex 2.8F, a villagecore morning, neighbors trading bread and baskets by the smoking communal oven as embroidered aprons identify each family by stitch, wheat gold and oven terracotta under soft square light, community memory kept alive in daily craft, warm timeless belonging, 8k`

### **Web 2.0**

**№ 967 / 1001** · *Social Web Learns to Perform*

**Nível:** 🟣 Secondary

**Eixo:** SYNERGY ↑ → EXPRESSION ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** retire a camada participativa e a Web 2.0 reverte limpa para a página HTML estática que nasceu para derrubar — um ancestral, uma geração de transformação, a mesma gramática de página religada para o leitor escrever de volta.

**Atmosfera e mood**

**A web social aprendendo a performar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Web 2.0: botões de vidro com reflexo, gradientes azuis, cantos arredondados e o beta eterno — 2007 convidando todo mundo a postar.

**Paleta de cores** azul de gradiente, branco de gloss, verde de botão RSS

**Melhores usos:** design, nostalgia, conceito

**MidJourney:** `[tema], web 2.0 aesthetic, glossy glass buttons blue gradients rounded corners eternal beta, the social web performs --v 6`

**Prompt universal (Seedream):** `Ultra-glossy digital interface artwork, a Web 2.0 composition from 2007, glassy reflective buttons with rounded corners floating over cheerful blue gradients beside a bright RSS orange badge and a beta ribbon, gloss white highlights on everything clickable, the social web learning to perform for its new audience, skeuomorphic shine, 8k`

### **Web 4.0**

**№ 969 / 1001** · *Interface Gives Way to Symbiosis*

**Nível:** ⚫ Quaternary

**Eixo:** SYNERGY ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** quatro linhagens convergem e nenhuma sozinha explica o todo — a gramática semântica da Web 3.0, a computação ambiente na borda da atenção, a alfabetização afetiva da computação afetiva, a tela desamarrada da computação espacial — cada uma já uma síntese anterior, colocando a fusão a pelo menos três gerações de profundidade.

**Atmosfera e mood**

**A interface cedendo lugar à simbiose** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Web 4.0: a tela desaparecendo, o ambiente respondendo antes do pedido e a computação dissolvida no quarto — a rede como sistema nervoso ambiente.

**Paleta de cores** branco ambiente, luz-resposta suave, azul de presença

**Melhores usos:** tech, conceito, editorial

**MidJourney:** `[tema], web 4.0 aesthetic, screen dissolving room answering before the request, the network as ambient nervous system --v 6`

**Prompt universal (Seedream):** `Ultra-minimal futuristic render, a Web 4.0 room, no screens anywhere as ambient light ripples across the walls answering a request the occupant has not yet finished forming, ambient white and presence blue pulsing softly around a single human silhouette, the interface dissolved into symbiosis, serene invisible computing, 8k`

## Leitura do padrão — o que as 24 estéticas confirmam

Dá para ver um sistema visual bem definido, e ele é o mais “relacional” dos três já mapeados (INTEGRITY = uma lei em escala; DOMAIN = território fechado; SYNERGY = **acoplamento entre elementos que permanecem distintos**).

**O núcleo: nenhuma estética da lista se sustenta sozinha — todas são definidas pelo que acontece *entre* dois ou mais agentes, nunca por um agente isolado.**

Repare nos grupos que se formam:

**1. Redes ecológicas (o modelo mais literal do triskele)**

Myceliumcore (rede subterrânea vestindo corpos de frutificação), Lichencore (líquen = alga + fungo, simbiose pura), Eco Industrial (“todo output se torna input de alguém”), Systems (“beleza encontrada em como tudo se conecta”), Organic, Naturecore. Aqui a correlação de longo alcance da revoada — cada parte reage à vizinha sem que ninguém comande — é literalmente o mecanismo biológico, não uma metáfora.

**2. Estruturas sociais coletivas**

Ubuntu (“pessoa construída através do círculo humano”), Sorority, Vaudeville (“variedade sustentada pelo próximo ato”), Festival, Villagecore, Toyism (artistas anônimos constroem um playground compartilhado). Nenhuma tem um “líder” na composição — a identidade emerge da rotação entre partes, exatamente o gesto proibido do triskele: “nenhum braço é primeiro.”

**3. Fusão cultural / identidade híbrida**

South Korean (hanbok sob neon de Seul), Brazilian (“dois pulsos que nunca resolvem”), Early Medieval Ottonian (corte saxão que se chama de Roma), Mid-Century Modern (nogueira + vidro + planta aberta). Aqui a “tradução” (o verbo Traduzir do triskele) é o mecanismo central: dois mundos formais se encontram e nenhum se dissolve no outro.

**4. Conectividade digital/interativa**

Web 2.0, Web 4.0, Interactive (parede sensora que muda quando a mão chega), NEXUS (“todo fio cruza aqui”). Correlação em tempo real — o input de um nó reconfigura o sistema inteiro sem hierarquia central.

**5. Coexistência material**

Mono-ha — “pedra e aço permitidos a permanecer eles mesmos” é quase uma definição em prosa do triskele: elementos lado a lado, sem fusão, sem domínio.

**6. As entradas primordiais (a prova do glifo)**

03 RESONANCE (“uma corda responde à outra”) e 02 FLUX (“nada mantém seu contorno”) são os dois casos-limite: RESONANCE é literalmente a física do acoplamento sem contato direto; FLUX é o que acontece quando o intervalo entre os “braços” nunca se fixa.

**O que isso confirma:** SYNERGY não é “colaboração” como conceito genérico — é qualquer estética cuja prova visual é a **coexistência de diferença sustentada**: duas ou mais forças (materiais, culturas, corpos, nós de rede) que se amplificam mutuamente sem que nenhuma vire fundo da outra. Por isso Ubuntu, Web 2.0 e Lichencore convivem na mesma posição — pessoa, protocolo digital e simbiose biológica são naturezas completamente diferentes, mas todas passam pelo mesmo teste: *o intervalo entre as partes continua vivo, ou uma parte engoliu a outra?*

Isso também explica por que XY (disrupção por ruptura/rearticulação) domina a lista — Brazilian, South Korean, Mono-ha, Vaudeville: fusões que soldam linhagens sem ancestral único sobrevivendo intacto. É o oposto estrutural de INTEGRITY, onde XX (continuidade) predominava — porque preservar uma lei através de escalas é continuidade, mas manter duas forças distintas em rotação sem que nenhuma vença é, quase sempre, o resultado de uma colisão original entre linhagens.

# EXPRESSION — o Ensō

<aside>
🖌️

**Essência:** EXPRESSION é a intensidade e a distinção do sinal exterior — a codificação de um estado interior em uma marca que o mundo consegue decifrar sem legenda. Seu ideograma é o Ensō: o círculo de tinta traçado em uma única respiração — o pincel desce, gira, sobe e nunca é corrigido, de modo que o que resta não é um círculo, é a condição exata da mão naquele segundo, irrepetível. Os mestres recusam fechá-lo: a lacuna fica aberta de propósito, porque um círculo perfeito mentiria sobre a mão imperfeita que o desenhou. Seu verbo é Encantar / Enchanting: mover quem recebe sem trair a verdade do que é mostrado. O prompt universal abaixo segue o mesmo formato dos de DOMAIN e SYNERGY (colchetes para trocar pelo vocabulário específico de cada estética): um sigilo só, um estado só, a falha protegida, nunca corrigida.

</aside>

## Prompt-mestre (imagem-síntese)

> **↑ EXPRESSION — universal prompt.** A figure committed entirely to one internal state, legible at once in jaw, shoulder line, hand, hem and ground, wearing or carrying exactly one recurring sigil — [the aesthetic's own specific object, colour, or gesture] — repeated with total coherence until it reads as a signature rather than styling; one dominant garment volume and one dominant colour with no competing focal point; one deliberate kept imperfection as proof of a real hand — [the aesthetic's own specific flaw: a ragged edge, an unironed crease, a smudge, an asymmetric cuff]; either a direct unblinking gaze held a few seconds past the point of comfort with the mouth at rest, or the eyes gone somewhere the frame does not show; hands visible and still, never hidden, never fidgeting, never self-adapting; camera handheld or hand-held-feeling at the subject's own eye level, close enough that the exposure reads as a transaction, grain kept rather than corrected, the crop tight and slightly wrong on purpose; composition off-centre with generous negative space and nothing else in the frame worth looking at; light either hard and undiffused with no fill so every asymmetry stays declared, or real available light pushed rather than corrected — never the flattering softbox package; skin and grooming left disturbed rather than sealed, real texture, real sheen, one feature loaded and the rest left alone; ground drawn from [the aesthetic's own real setting: a raw wall, an unglamorous real place, or a bare void] with exactly one object in frame and it is the sigil; the whole image readable as one unmistakable event from across a street, with the small imperfection of the gesture — a hem still travelling, an edge the fabric outran — left exactly where it fell.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre):

> No softbox-and-fill flattery, no retouched or smoothed skin, no corrected asymmetry, no tripod-locked symmetrical portrait, no flattering high angle, no balanced three-colour palette, no second competing focal point, no dressed set with unused decorative props, no presentational arm or garment displayed to the lens, no smile assembled after the eyes, no upturned chin seeking approval, no hidden or self-adapting hands, no sealed finish that motion could not disturb, no pose repeatable identically in a second frame, no two states visible in one body at once.
> 

### Como adaptar o prompt a cada estética

**Como usar para qualquer uma das +110 estéticas da lista:** troque só os três colchetes — o sigilo (ex.: para Punk → o alfinete de segurança; para Sapeur → o terno impecável; para Y2K → o cromado/plástico translúcido), a falha protegida (ex.: para Grunge → a manga puída; para Camp → o artifício exposto de propósito) e o cenário real (ex.: para Voguing → o salão de ballroom; para Hermitcore, inverter para o registro ↓ suprimido). Nenhuma palavra do prompt nomeia lugar, tribo ou estilo específico — só os mecanismos universais que a página já define como EXPRESSION (um sigilo só por quadro, um estado só, a falha como prova de mão real, o olhar direto ou desviado, luz que não mente). A estrutura permanece idêntica para todas.

## Fundamentos do elemento

**Identity.** Intensity and distinctiveness of the outward signal — the codification of an interior state into a mark the world can decipher. Its ideogram is the Ensō, the ink circle laid down in one breath: the brush descends, turns, lifts, and is never corrected, so what remains is not a circle but the exact condition of the hand in that one second, unrepeatable. Masters refuse to close it; the gap stays open on purpose, because a perfect circle would lie about the imperfect hand that drew it. Its physics is the breaking of replica symmetry: a complex system holds infinitely many valid equilibria and, at one decisive moment, freezes into a single configuration — and the freezing is what produces information. Symmetry is the death of identity; a sphere polished smooth is identical from every angle and therefore says nothing. Its verb is **Encantar / Enchanting**: to move whoever receives without betraying the truth of what is shown; its shadow is manipulating attention against the interest of the person granting it. In an image this element is proven by what announces itself first and by whether that announcement traces back to a real state — or by the deliberate refusal to announce anything at all. (Distinct from EFFECT, 7 — the Bindu measures the strike on the field; the Ensō measures the fidelity of the mark to the hand. Distinct from ESTHETICS, 15 — the spiral is proportion; the Ensō is signature, and a signature is permitted to be ugly.)

**One breath, one state.** The system carries many valid configurations at once — the commander, the mentor, the visionary — and every one of them is true. The failure state is the hedge: a figure caught between two of them, half-commanding and half-appealing, which reads as neither. An EXPRESSION frame commits entirely to one internal state and lets the others stay latent, and the commitment must be legible in the whole body at once: jaw, shoulder line, hand, hem, and ground all belonging to the same second. Two states visible in one frame is the visual signature of a system that has not yet broken symmetry.

**The gap kept open.** The imperfection is not tolerated, it is protected — it is the evidence that a hand and not a formula finished this. What the market would polish away is exactly what carries the signature: the accent, the asymmetry, the ragged edge where the fabric outran the light, the strand that will not lie flat, the smudge, the stride caught off-balance. Keep the edges; edges are what cut through noise and what allow a unique fit. Any frame in which every element has been corrected to an average has removed the only thing this element was measuring.

**The three-second test.** A frame carries EXPRESSION when it is identifiable with the name removed. The practical instrument is the **sigil**: one object, colour, gesture, or silence repeated with absolute coherence until it stops needing explanation and becomes a shortcut into the whole world of its owner — the black turtleneck, the single glove, the dark glasses worn indoors, the fan carried on set. Place exactly one sigil per frame and let it recur across the series; two competing sigils cancel each other and recognition collapses back into styling. The sigil must be materially specific enough to be drawn from memory by someone who saw the image once.

**The sustainable role — expression that rests.** The most diagnostic distinction in this element is between the mask and the face. A mask costs energy to hold, and the cost leaks as over-justifying micro-movement: a hand fidgeting at a hem, an eye darting to check its own effect, a smile assembled a half-second after the eyes already committed, a chin adjusted twice. A face costs nothing, and the frame reads it as authority before it reads anything else. Photograph the minimum-energy state: breath low, weight settled, the body spending nothing on the maintenance of its own image. Any expression that visibly tires is provisional; only the expression that visibly rests is structural.

## Corpo — postura, olhar e microexpressão

**Model posture & structure.** Expansion without effort. The body occupies its space rather than pushing into it — shoulders wide and dropped, chest open, spine stacked without military rigidity, weight settled evenly or in one unforced contrapposto. Hands stay visible and still: at the seams, flat on a surface, or fully engaged with a real object; never hidden in pockets, never crossed at the pelvis in the fig-leaf guard, never self-adapting (no touching the neck, no smoothing the hair, no turning a ring). Movement, when present, is slow and deliberate or genuinely fast and unrehearsed — never the medium tempo of someone waiting to be told what to do. The single most productive direction on set is to give a real physical action with a real consequence, then keep the shutter working after the direction expires: the two or three frames between the commanded action and the next instruction are where this element lives. Where the register is amplified, the body is caught mid-arc — running, turning, laughing, the hem still travelling. Where it is suppressed, the body is closed and self-contained: arms at the sides, silhouette folded like a letter, nothing offered.

### **Gesture.** One verb governs the ink circle.

**Encantar · Enchanting** is the only verb the ink circle holds: to move the receiver without falsifying what is shown. Photographed, it is a body that gives something real and asks nothing back — the laugh that arrived before the frame did, the stride the model actually took, the object handled rather than presented. The audience is a co-author here rather than a destination, which means one element is always withheld so a viewer completes it. The shadow is the gesture aimed at the lens for approval — the smile switched on, the hip angled to a remembered flattering position, the eye checking whether the charm landed. Forbidden throughout: the presentational arm, the display of the garment to the camera, any pose the model could hold identically for a second frame.

**The look — how the eyes behave.** The gaze is the highest-bandwidth carrier of this element and it has exactly two admissible modes. **Direct:** level into the lens, held, blink rate low, no head tilt, the mouth at rest with the corners neutral or falling — the gaze of someone not requesting permission to be looked at, held about three seconds past the point of comfort, because the interval most people break is the interval this element requires. **Averted:** the eyes gone somewhere the frame refuses to show, past the lens and slightly up, absorbed rather than dreamy, the face already inside a thought the viewer is not given. Both modes are calm at the baseline. Banned in both: the upturned chin seeking approval, the raised inner brow of appeal, the darting check, the rehearsed intensity of a stare performed at maximum for the whole exposure. One controlled leak is permitted and often decisive — a single micro-flash of irritation, amusement, or refusal surfacing for one frame as a boundary drawn without words.

**Face & microexpression.** The body settles into the truth well before the face does, so the face must be caught rather than composed. Photograph between the model's performances: the half-second after a phrase lands, the moment attention goes elsewhere, the exhale after the take is called. The mouth is the tell — a smile that reaches only the mouth and never the outer eye reads as fraudulent at any resolution, and no lighting rescues it. Asymmetry is allowed and usually correct; one side of the face is always a fraction ahead of the other, and that fraction is the hand in the ink.

## Regras de imagem — do figurino à prova de assinatura

**Look & styling continuity.** The garment is the interface, and the interface must be readable at speed: one dominant volume, one dominant colour, one closure logic, no competing focal points. The wardrobe is chosen for the state it produces in the wearer rather than the state it depicts — a garment that makes the body stand differently is doing this element's work, and the difference in stance must be visible in the frame. Every channel tells the same story: cut, colour, texture, posture, and expression aligned, because a rebel silhouette carrying an apologetic face is a broken code and the viewer detects the fraud before locating its cause. Keep one deliberate flaw as authorship: an unironed crease in expensive cloth, a hem that fell where it fell, a cuff pushed up asymmetrically, a garment worn slightly wrong on purpose. Refused: neutral trend-safe styling, three accessories where one would do, anything so corrected it could belong to anyone.

**Camera.** Handheld or hand-held-feeling, at the subject's own eye level, close enough that the exposure is a transaction rather than an observation. A 35mm or 50mm at conversational distance for the direct register; a longer lens at candid distance when the action must remain genuinely unwatched. Shutter fast enough to freeze the evidence of real motion, or deliberately slow enough that the periphery blurs while the face holds — never the neutral middle setting that turns action into a pose. Grain is kept, not corrected: grain is the record of urgency, of a frame taken because it could not wait for better conditions. The crop is tight — head-and-shoulders, or a single hand, or one facial feature standing for the whole — and it is often slightly wrong and kept that way. Zero post-hoc correction of the resulting imperfect frame; the moment retouching resolves the asymmetry, the ink circle has been redrawn with a compass. Forbidden: the tripod-locked symmetrical portrait, the flattering three-quarter high angle, the frame composed so carefully that no hand is detectable in it.

**Composition.** One event, unmistakable, and nothing competing. The figure is placed so a viewer crossing a street would read the frame in a single glance — one gesture, one colour, one silhouette — with the remainder given over to ground rather than to information. Off-centre placement is preferred to centred symmetry, because symmetry is the state this element exists to break. Negative space is generous and empty rather than furnished. Where the register is amplified, the gesture occupies the whole diagonal and the ground is a single plane behind it. Where it is suppressed, the figure is pushed toward the edge, tone-on-tone against the ground, offering no entry point and rewarding only slow looking. The one thing the frame must never contain is a second thing worth looking at.

**Lighting.** Light that tells the truth rather than light that flatters, in two legitimate registers. **Hard undiffused:** a single strobe or bare source, close, no fill, shadows falling where they fall, skin texture and every asymmetry fully declared — light as a refusal of negotiation, which is why the direct-gaze register almost always uses it. **Available:** real daylight, a window, an overcast street, a bulb already in the room, exposure pushed rather than corrected, so the frame records the conditions the moment actually happened in. Never the softbox-and-fill package that removes the shadow and, with it, the evidence. Backlight is permitted only when the halation is itself the mark. Where the register is suppressed, the light is flat, even, and sourceless so nothing is lit more than anything else. The diagnostic test: could this setup be applied unchanged to any other subject and still flatter? If yes, it is doing the opposite of this element's work.

**Beauty detail.** Makeup applied and then disturbed. The canonical procedure is to build the face correctly and undo it seconds before the shutter — the model rubs an eye, runs a hand across the cheek, presses the lip with a fingertip — so the finish carries the interval rather than the intention. Greasy smudged black blurred past the lash line; a smoky grey worked with balm or petroleum jelly into a wet dirty reflection; unblended organic stains of colour left where they fell; lipstick pressed on with the fingertip, no liner, no defined edge. Matting powder banned: real sweat and studio heat must register as sheen, and true skin texture — pores, faint veins, a mark, an under-eye shadow — stays legible rather than smoothed. Foundation translucent or skipped entirely; brows left in their real growth pattern. Hair sculpted by hand rather than brushed: sea-salt dry texture, a bun that appears to be dissolving inside the frame, static-charged stray strands positioned to throw graphic shadows across the skin, the whole thing mussed by hand seconds before the exposure and engineered to reshape unpredictably with the model's own movement. Where the register is amplified into declaration rather than undress, the opposite discipline applies with equal force: pure unmixed pigment at maximum contrast, gold leaf and gemstones physically adhered, giant cut-paper lashes, brows masked out and redrawn in a surreal shape, UV-reactive graphic linework — spectacle that cost hours and weighs something, never spectacle implied. Refused in both registers: any finish sealed so completely that motion, heat, or a hand could not disturb it.

**Cenography.** The ground must not compete. Three admissible worlds. **The void:** white or grey seamless, or a hand-painted infinite backdrop in a graduated neutral engineered to absorb hard flash without glare, so nothing survives in the frame except the body and its one gesture. **The raw wall:** unfinished plaster, poured concrete, a painted brick face — a plane with texture but no narrative, giving the gesture something to cut against. **The unglamorous real place:** a backstage corridor, a motel room, a parked car, a stairwell, a street at the hour it actually was — locations chosen for psychological weight rather than beauty, carrying the implication that something happened before the frame and something will happen after. In all three, exactly one object is permitted, and it should be the sigil or a real prop the body actually uses. The set must never be built only where the lens looks; a body answers a real wall differently than a painted flat. Refused: dressed sets holding three eras at once, decorative props no one touches, any location cleaned until no one appears to live there.

**Colour.** One saturated declaration against a ground that concedes, or no declaration at all. In the amplified register a single high-chroma block — a vermilion, a cadmium, an electric ultramarine — carries the entire frame while everything else drains to neutral, because a signature colour only signifies when it is the only colour permitted to speak; that colour then repeats across the series until the audience can identify the author from a swatch. In the suppressed register the palette collapses to a single family — dove on dove, bone on bone — with the difference between figure and ground measured in a fraction of a tone. Refused in both: the balanced three-colour palette, which is the visual form of refusing to choose.

**Signature proof.** Wherever the composition allows, plant one device proving the mark came from a real hand at a real moment: an edge left ragged where the fabric outran the exposure, a hem still carrying the arc of a step already finished, a smudge the model's own hand made, a hand-lettered mark applied to the garment on set, grain that could not be avoided at that shutter speed, a crop that cuts something the frame wanted. This is the ink circle's open gap made photographic, and it is the closest a still image comes to proving the state recorded was not designed. A frame in which every element could have been produced twice identically has failed this element regardless of how striking it is.

**If the image moves.** The circle survives into motion only as evidence of the hand, never as smoothness. Print the frame and cut it physically: hand-cut seams, torn paper, acrylic applied to the print itself so colour and image occupy one physical space rather than two compositing layers, rustic hand-lettered type laid over the frame, cubist fragmentation of body and garment reassembled slightly out of true. Stop-motion in preference to interpolation, because a hand moving the element between frames leaves the slight overshoot, the imperceptible shake, and the recovery — the signs of biological agency that perfect digital motion erases. Spasmodic kinetic rhythm, moving-fanzine energy, the seam shown rather than hidden. The held gaze becomes the break of the fourth wall: the figure acknowledging the lens as an argument that it is not contained by the frame. Refused: seamless interpolation, motion smoothed until no hand is detectable in it, and hand-made chaos deployed as a texture with nothing underneath — the seam must be about the instability of the fashioned body, or it is only a filter with a paint layer.

**The withheld.** Silence is a mode of this element, not its absence. What is not shown does the work: the face turned away, the object cropped out, the sentence the expression is clearly not going to finish, the refusal to explain the frame. A sustained pause is an act; a body that does not fill its own silence reads as sovereign, and a body that hurries to fill it reads as anxious. In the suppressed register this becomes the whole method — nothing asks to be seen first, and the reward is reserved for the viewer who returns.

## Oito registros da respiração — um por imagem

The law admits eight distinct working conditions. Choose one per image; they do not mix.

- *The caught action.* Give the body a real physical task with a real consequence — run, turn, leap, carry, laugh at something actually said — and photograph the consequence rather than the intention. Handheld, fast shutter, daylight, the off-balance stride and the windblown hem kept. Never "pretend to run."
- *The stripped state.* Remove jewellery, product, styling intervention and direction, then wait: the performance stops somewhere between the fifth and the fifteenth minute of sitting or lying in a real room. Available light only, rundown domestic interior, the cessation of performance as the subject.
- *The shared room.* Two or more bodies laughing with each other rather than for the lens — crossing sightlines, shared momentum, cigarette-and-coffee ease, the set run like a party. The camera is a guest, never an audience.
- *The interior night.* Private domestic space — a bedroom, a suburban bathroom, the back seat in a parking lot — under neon and pastel artificial night light, soft dreamy focus, halation around the highlights, grain kept as proof of proximity. The vulnerability is waited for; only the palette is built.
- *The nocturnal charge.* Makeup applied and then lived in: the model dances or moves hard before the shutter, sweat and strobe write the finish, the face reads as worn since the night before. Danger and desire admitted into the frame rather than cleaned out of it.
- *The glimpse.* The off-moment — between takes, sunlight on a car door, the frame where the mask slipped — odd crops, sun-faded colour, analogue film and unforced conversation instead of direction. The exchange looks almost careless; the timing is not.
- *The crossing at speed.* Mixed film stocks and formats inside one story, double exposure, airport blur, city neon, grain from a pushed stock — documentary intimacy and campaign scale in the same sequence, every frame a border crossed at velocity.
- *The witnessed scene.* Photographed from inside a community rather than about it: warm protective frames, the emotional atmosphere recorded before the garment, style codes attested rather than styled, the photographer's belonging visible in how close the camera is allowed to stand.

## Linhas de praticantes prontas para prompt (dos códices)

*Shutter.* Martin Munkácsi — handheld 35mm, fast shutter freezing genuine motion, natural daylight, real outdoor action, no correction of the imperfect pose. Richard Avedon — plain white seamless, hard undiffused strobe with no fill, a specific physical command rather than a mood, the shutter kept working through the interval after the direction expires. David Bailey — plain seamless, tight head-and-shoulders crop, direct unblinking gaze, visible grain, unposed micro-movement. Arthur Elgort — available light, candid telephoto distance, genuine walking motion, uncorrected grain, real street or backstage corridor. Bob Richardson — grainy pushed 35mm, motel room or parked car, cinematic tension, the face caught between its performances. Patrick Demarchelier — bright clean daylight, classical balance, the spontaneous expression caught two frames before it settles. Lillian Bassman — extreme selective dodge-and-burn, the frame bleached toward white, one gesture held in a narrow band of near-black.

*Hair and face.* Stephane Marais — greasy smudged black blurred past the lash line, unblended colour stain, no powder, fingertip lipstick, the makeup disturbed minutes before the shutter. Linda Cantello — smoky grey worked with balm into a dirty gloss, pale unblushed skin, faded bare lips, the model instructed to rub her own eyes before the frame. Yannick d'Is — hand-sculpted sea-salt dry texture, a bun dissolving inside the frame, static strands throwing graphic shadow on skin. Neil Moodie — texturized disconnected bob, windswept bedhead, hair mussed by hand seconds before the shot. Yadim — translucent or skipped foundation, brows in real growth, sweat sheen left to register. Kabuki — adhered gold leaf and gemstones, giant cut-paper lashes, brows masked and redrawn surreally, pure unmixed pigment at maximum contrast.

*Styling.* Francesca Burns — exposed coloured lingerie under a luxury garment, neon faux fur, retro plastic sunglasses, ripped denim, smeared lipstick kept in the shot, flash-lit backstage energy, a real body at ease. Ray Petri — one hand-lettered mark applied to the garment on set, the frontal hard-tender gaze, authorship stated in the most immediate material available.

*Ground.* Mary Howard — hand-painted infinite backdrop in a graduated neutral, calibrated to absorb hard flash without glare. Gideon Ponte — a real room with a real ceiling nobody intends to photograph, so the body answers architecture rather than a flat.

- *Shutter, continued.* **Corinne Day** — available natural light in a rundown domestic interior, no makeup and no styling intervention, the unguarded resting state waited for rather than directed. **Petra Collins** — teenage bedroom or suburban bathroom, neon-and-pastel artificial night light, soft dreamy focus, cinematic haze and halation around the highlights. **Ellen von Unwerth** — the set run as a party, playful erotic kinetics, models crossing sightlines, high-contrast cinematic frame. **Pamela Hanson** — women laughing with each other rather than for the camera, Riviera ease, cigarette-and-coffee intimacy. **Ryan McGinley** — euphoric youth in genuine motion, bodies running through nature under concert-like light. **Mario Testino** — the glamour snapshot lit with a continuous flattering glow, the frame of someone who was invited. **Mario Sorrenti** — diary-like intimacy and raw emotional proximity. **Jamie Hawkesworth** — warm documentary encounter with a stranger, sun-drenched and serendipitous. **Mark Borthwick** — analogue film and unforced conversation, the interaction left unfettered. **Michel Comte** — a fast, almost careless-looking exchange; the frame kept is the one where the mask slipped. **Clara Balzary** — the model between takes, sunlight on a car door, editorial built entirely from glimpses. **Max Vadukul** — black-and-white reportage kinetics, the body mid-event in a street story that refuses to pause. **Frances McLaughlin-Gill** — genuine motion in real city situations, casual realism at editorial polish. **Harley Weir** — saturated visceral colour and extreme close-ups of skin, mud, and fabric until the image reads somatic rather than visual. **Frank Lebon** — film stocks, formats, and social registers mixed inside one story. **Dexter Navy** — grainy psychedelic travel diary, double exposure, airport blur, city neon. **Shaniqwa Jarvis** — emotional atmosphere photographed first, communities held in warm protective frames. **Hick Duarte** — street and periferia style codes photographed from inside the scene. **J.R. Duran** — sun-drenched Mediterranean warmth, a charm so fluent the image reads as a compliment spoken aloud.
- *Hair and face, continued.* **Bedot** and **Cano Bock** — fingertip application, no retouching and no plasticised skin, the model instructed to hold an expression of total indifference; makeup as psychological uniform. **De Kluyver** and **Glatthaar** — cosmetics applied spontaneously with the hands rather than brushes, error embraced, rigid poses broken, direct flash fired straight at the face. **Gutierrez** — product applied and then danced in under nightlife strobe, sweat kept as finish. **Presche** — microscopic layers fused invisibly under diffused LED, heavy contour banned, real pore texture and continuous liquid reflection. **Frausto** and **Wilson** — resin moulds and heavy synthetic extensions building monumental heads that take over the frame. **Ghewy** and **Lai** — cold direct light emphasising the cut's straight lines under unstable daylight or compact-camera flash, the head as a monument of urban attitude.
- *Styling, continued.* **Harry Lambert** — 1970s flare-leg tailoring and lace-collared blouses with pearls, painted nails, and feather boas worn as the wearer's own clothing and never as costume. **Julia Sarr-Jamois** — acid colour, street print, and natural voluminous hair under direct intense sunlight, rigid studio posing dispensed with in favour of peripheral streets, spontaneous movement, and real smiles.

## Polaridades — repertório amplificado (↑) e suprimido (↓)

**↑ Amplified — repertory.** One unmistakable gesture and nothing competing: a silhouette readable at fifty metres, a single saturated colour block against a conceding ground, real motion caught mid-arc with the hem still travelling, a direct unblinking gaze held past comfort, hard undiffused light declaring every asymmetry, one recurring sigil object, visible grain, and the small imperfection of the sweep kept exactly where it fell.

> **↑ Prompt.** Against a raw grey plaster wall, a single vermilion cape caught mid-swing in one continuous arc, the edge ragged where the fabric outran the light, the wearer's weight settled and shoulders dropped with both hands visible and still, gaze level and unblinking into the lens with the mouth at rest and the jaw unclenched, one hard undiffused source close and unfilled so the shadow falls where it falls and skin texture and a faint under-eye shadow stay legible, hair hand-sculpted with sea salt and one static strand throwing a graphic shadow across the cheekbone, lipstick pressed on with a fingertip and already disturbed, no matting powder so real sheen registers, handheld 35mm at the subject's own eye level with visible grain and a crop slightly too tight, the figure off-centre against generous empty ground, one colour, one gesture, one object recurring from the series, the whole frame readable from across a street and the imperfection of the sweep left in.
> 

> **↑ Negative line.** No softbox-and-fill flattery, no retouched or smoothed skin, no corrected asymmetry, no tripod-locked symmetrical portrait, no flattering high angle, no balanced three-colour palette, no second competing focal point, no dressed set with unused decorative props, no presentational arm or garment displayed to the lens, no smile assembled after the eyes, no upturned chin seeking approval, no hidden or self-adapting hands, no sealed finish that motion could not disturb, no pose repeatable identically in a second frame, and no muted tone-on-tone, closed silhouette, or withheld signal.
> 

**↓ Suppressed — repertory.** Withheld signal: muted tone-on-tone, closed self-contained silhouette, flat sourceless light with nothing lit more than anything else, the figure pushed to the frame's edge, the face turned away or given nothing to declare, craft that surfaces only under slow looking, and no object in frame willing to be the first thing seen.

> **↓ Prompt.** A figure in dove-grey against a dove-grey wall, silhouette closed like a folded letter with arms at the sides and shoulders unexpanded, face turned a few degrees from the lens and offering nothing, bare skin with no colour and hair flat and unremarkable, flat even sourceless light so no plane in the frame is favoured, tone-on-tone throughout with the difference between figure and ground measured in a fraction of a step, the body placed near the frame's edge with the centre left empty, and only on close inspection the collar revealing a hand-rolled edge and eighty concealed pin-tucks, nothing in the frame asking to be seen first.
> 

> **↓ Negative line.** No saturated colour block, no hard undiffused key, no direct held gaze, no caught motion or travelling hem, no visible grain or urgency, no sigil object, no ragged edge or declared imperfection, no gesture occupying the diagonal, nothing in the frame that could be recognised from across a street.
> 

## Estéticas relacionadas a EXPRESSION (A–Z)

As 119 estéticas classificadas sob EXPRESSION, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary · ⚫ Quaternary), eixo secundário e polaridade (XX — continuidade · XY — disrupção).

### **Animecore**

**№ 049 / 1001** · *Eyes drawn bigger than the frame*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Olhos desenhados maiores que o quadro** — (1001 Aesthetics, interpretação)

Estética anime intensificada: olhos gigantes e brilhantes, cores chapadas, emoção exagerada.

**Paleta de cores** pastéis vivos com brilhos e estrelas

**Melhores usos:** personagens, capas, avatares

**MidJourney:** `[tema], animecore aesthetic --niji 6`

**Prompt universal (Seedream):** `Ultra-detailed anime illustration in crisp cel-shaded style, huge expressive sparkling eyes with layered star highlights, flat vivid pastel colors and a dramatic speed-line background, exaggerated joyful emotion, glossy kawaii shine on hair and lips, premium animation key-frame quality, 8k`

### **Atompunk**

**№ 073 / 1001** · *Atom rendered in turquoise and coral*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Design industrial de meados do século, imagética de propaganda da corrida espacial e revivalismo retrofuturista convergem; retire o símbolo atômico e a paleta é apenas modernista, retire as formas mid-century e o símbolo não tem onde pousar — fusão através de gerações.

**Atmosfera e mood**

**Átomo renderizado em turquesa e coral** — (1001 Aesthetics, interpretação)

Atompunk: era atômica dos anos 50, arquitetura googie, futuro otimista retrô.

**Paleta de cores** turquesa, coral, creme, cromado

**Melhores usos:** retrofuturismo, pôsteres, cenários

**MidJourney:** `[tema], atompunk 1950s, googie design --v 6`

**Prompt universal (Seedream):** `Retrofuturist photograph shot on 35mm film with 1950s color science, atomic age googie architecture with starburst signage, turquoise and coral against gleaming chrome, an optimistic space-age family scene, sharp midday desert sun, Populuxe advertising polish, Kodachrome saturation, 8k`

### **Beat Generation**

**№ 082 / 1001** · *Hundred-foot scroll taped together so the sentence wouldn't break*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → NARRATIVE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O fraseado do jazz, a poética de verso longo whitmaniana e a prática budista se trançam numa gramática de prosa espontânea; remova o jazz e a frase perde o fôlego, remova o fio místico e ela perde o destino — solda de linhas distintas.

**Atmosfera e mood**

**Rolo de trinta metros colado para a frase não quebrar** — (1001 Aesthetics, interpretação)

Geração beat: estrada aberta, máquina de escrever, jazz esfumaçado, liberdade datilografada.

**Paleta de cores** preto e branco de fotojornalismo, sépia

**Melhores usos:** editorial, literário, música

**MidJourney:** `[tema], beat generation 1950s road trip, typewriter --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Tri-X film with a Leica M3 50mm, a beat generation writer hunched over a typewriter in a smoky basement jazz club, endless paper scroll spilling to the floor, cigarette smoke curling through a single hanging bulb, high-contrast black and white photojournalism in the spirit of Robert Frank, raw grain, restless midnight energy`

### **Brazilian Beachwear**

**№ 119 / 1001** · *Tan line drawn by electrical tape*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EDITING ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Cultura de corpo de praia, minimização têxtil e a lógica de exibição do carnaval convergem; retire qualquer uma e a marca de sol deixa de ser decisão de design — várias linhagens trançadas numa prática que não se comporta como nenhuma delas isolada.

**Atmosfera e mood**

**Marquinha desenhada com fita isolante** — (1001 Aesthetics, interpretação)

Moda praia brasileira: biquíni, canga, sol forte de Ipanema e atitude.

**Paleta de cores** cores vivas de lycra, areia, azul-mar

**Melhores usos:** moda praia, verão, campanhas

**MidJourney:** `[tema], Brazilian beachwear fashion editorial --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.4, a Brazilian beachwear editorial on Ipanema sand, vivid bikini color against sun-bronzed skin, canga fabric snapping in the sea breeze, Dois Irmãos peaks hazy behind, harsh noon sunlight embraced with confident energy, water droplets and salt texture in macro detail, Vogue Brasil polish, 8k`

### **Brazilian Football**

**№ 121 / 1001** · *Remove the ball and everything stops*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → TECHNIQUE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O futebol codificado importado, a ginga da capoeira e a improvisação da pelada de rua se fundem; retire as regras importadas e não há jogo, retire a ginga e o drible perde o corpo — linhagens distintas soldadas num estilo que não se comporta como nenhuma delas isolada.

**Atmosfera e mood**

**Tire a bola e tudo para** — (1001 Aesthetics, interpretação)

Futebol brasileiro: várzea, campinho de terra, camisa amarela e ginga no fim de tarde.

**Paleta de cores** verde de gramado, amarelo, terra batida

**Melhores usos:** esporte, cultura, campanhas

**MidJourney:** `[tema], Brazilian street football culture --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 35mm with 50mm lens, barefoot kids playing football on a dirt pitch at golden hour, yellow jerseys glowing against red earth, improvised goalposts and dust kicked into backlight, joyful ginga mid-move, rooftops soft in the distance, documentary warmth, timeless film grain, 8k`

### **Brazilian Ostentation Funk**

**№ 124 / 1001** · *Sound wall three blocks loud*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O ritmo do baile funk, a exibição de marcas de luxo e a cultura dos paredões de som convergem; retire a linhagem do funk e a batida desaparece, retire os códigos de ostentação e a letra perde o assunto — várias tradições soldadas numa forma que nenhuma produz sozinha.

**Atmosfera e mood**

**Parede de som com três quarteirões de altura** — (1001 Aesthetics, interpretação)

Funk ostentação: correntes de ouro, carros de luxo, paredes de caixas de som no baile, flash e neon.

**Paleta de cores** dourado, preto, neon de baile

**Melhores usos:** música, moda urbana, capas

**MidJourney:** `[tema], Brazilian funk ostentação aesthetic, gold chains and neon --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with direct hard flash, a baile funk ostentation scene, gold chains and designer sunglasses flashing against towering speaker walls, luxury car doors open under neon, champagne spray frozen by strobe, loud confident energy with hip-hop video gloss, saturated night colors and gritty flash aesthetic, 8k`

### **Bubblegum Pop**

**№ 132 / 1001** · *Hook engineered for pre-teen devotion*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A composição do Brill Building, a instrumentação do rock e a produção industrial de estúdio convergem num único gancho de engenharia; retire a linhagem de ofício e a melodia falha, retire o sistema de estúdio e ela nunca chega ao público — fusão de linhas distintas.

**Atmosfera e mood**

**Refrão projetado para devoção pré-adolescente** — (1001 Aesthetics, interpretação)

Pop açucarado: cenário de clipe dos anos 2000 em cores de doce, alegria coreografada.

**Paleta de cores** rosa, azul-céu, amarelo doce

**Melhores usos:** música, capas, campanhas jovens

**MidJourney:** `[tema], bubblegum pop music video aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 32mm lens, a bubblegum pop music-video set, candy-pink and sky-blue seamless backdrops with oversized lollipop props, glossy choreographed smiles under high-key beauty light, sugary color grading with zero shadows, engineered catchy sweetness, early-2000s pop perfection, crisp production still, 8k`

### **Burlesque**

**№ 134 / 1001** · *Feather that enters two beats ahead*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → NUANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Variedades de music-hall, striptease teatral e paródia satírica convergem; retire a paródia e o número vira mera exibição, retire o palco de variedades e o timing fica sem casa — várias linhagens soldadas numa forma que nenhuma produz sozinha.

**Atmosfera e mood**

**A pluma que entra dois tempos antes** — (1001 Aesthetics, interpretação)

Burlesco vintage: leques de plumas, espartilho de lantejoulas, palco esfumaçado de cabaré.

**Paleta de cores** vermelho, preto, dourado, plumas

**Melhores usos:** teatro, retratos, editorial

**MidJourney:** `[tema], vintage burlesque cabaret, feathers and corset --v 6`

**LoRA (Civitai):** "Burlesque Dress" — civitai.com/models/146395

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.2, a vintage burlesque performance mid-reveal, ostrich feather fans and crystal-sequined corset under warm amber spotlights, smoky cabaret haze and red velvet drapes, Dita Von Teese theatrical glamour, glitter dust suspended in the beam, rich gold and crimson grading, cinematic tease, 8k`

### **Camp**

**№ 139 / 1001** · *Sensibility that announces its own construction*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por ruptura

**Nota:** Sua lei governante — a obra deve exibir o próprio artifício como o ponto — não pode ser herdada de nenhum estilo anterior; é uma sensibilidade de raiz, e remover a construção autoconsciente dissolve a categoria por inteiro.

**Atmosfera e mood**

**Sensibilidade que anuncia a própria construção** — (1001 Aesthetics, interpretação)

Camp: exagero teatral consciente, kitsch elevado a arte, extravagância que pisca para a câmera.

**Paleta de cores** saturadas teatrais, rosa, dourado

**Melhores usos:** moda, editorial, arte

**MidJourney:** `[tema], camp aesthetic, theatrical exaggeration --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 80mm lens, a camp fashion tableau, deliberately exaggerated theatrical styling with flamboyant kitsch elevated to art, saturated pinks and golds under high-key studio strobes, feathers sequins and winking self-aware extravagance in the spirit of David LaChapelle, glossy hyperreal detail, 8k`

### **Carioca**

**№ 141 / 1001** · *Ginga, salt air, and the body held in tropical light*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Prática corporal afro-brasileira, sociabilidade de praia e cultura musical urbana se trançam; remova a ginga e o andar perde a origem, remova a praia e o corpo perde o palco — recombinação entre linhagens, não um pai revisado.

**Atmosfera e mood**

**Ginga, ar salgado e o corpo na luz tropical** — (1001 Aesthetics, interpretação)

Rio de Janeiro: calçadão de ondas de Copacabana, Pão de Açúcar ao fundo, corpo em movimento no sol.

**Paleta de cores** azul-mar, branco do calçadão, verde de morro, dourado

**Melhores usos:** lifestyle, verão, editorial

**MidJourney:** `[tema], carioca Rio de Janeiro lifestyle --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 35mm with 35mm lens, a carioca lifestyle scene on Copacabana's wave-pattern sidewalk, sun-kissed bodies in motion with Sugarloaf hazy in the distance, salt air shimmer and tropical golden light, effortless Rio ginga, warm saturated film grading, documentary vitality, 8k`

### **CARTOONCORE**

**№ 142 / 1001** · *Ink line that keeps physics editable*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SAGA ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A gramática squash-and-stretch da animação, o desenho de tirinha e a cultura de remix da internet convergem; retire a linhagem da animação e a física deixa de ser editável, retire o fio do remix e o traço nunca escapa do estúdio — fusão de linhas distintas.

**Atmosfera e mood**

**Traço de tinta que mantém a física editável** — (1001 Aesthetics, interpretação)

Cartum clássico: contornos grossos, membros rubber-hose, squash and stretch, realidade maleável.

**Paleta de cores** cores chapadas saturadas

**Melhores usos:** personagens, ilustração, animação

**MidJourney:** `[tema], classic cartoon style, rubber hose animation --v 6` (ou `--niji 6` para traço mais anime)

**Prompt universal (Seedream):** `Exquisite illustration in classic 1930s cartoon style, bold ink outlines and rubber-hose limbs mid squash-and-stretch, flat saturated colors on cel-painted backgrounds, Fleischer Studios exaggerated physics, subtle film-cel dust and registration texture, playful editable-reality energy, crisp animation-archive quality, 8k`

### **Circus**

**№ 157 / 1001** · *Ring, the silk, and the body that refuses gravity*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Exibição equestre, tradição acrobática e espetáculo de feira itinerante convergem no picadeiro; retire a acrobacia e o risco desaparece, retire o aparato de turnê e o picadeiro nunca chega — recombinação de linhagens distintas.

**Atmosfera e mood**

**O picadeiro, a seda e o corpo que recusa a gravidade** — (1001 Aesthetics, interpretação)

Circo: lona listrada, trapezista na seda aérea, serragem, holofote e maravilha antiga.

**Paleta de cores** vermelho e branco de lona, dourado, luz quente

**Melhores usos:** espetáculo, pôsteres, infantil

**MidJourney:** `[tema], vintage circus spectacle, aerial silk performer --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 32mm lens, a vintage circus scene, aerial silk performer defying gravity in one warm spotlight beneath the striped big top, sawdust ring and gilded wagon wheels below, dust glittering in the beam, red white and gold palette, old-world wonder, cinematic production still, 8k`

### **Color Block**

**№ 168 / 1001** · *Hard edges, saturated fields, bounded argument*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** Uma única linhagem de cor abstrata segue adiante e é re-especificada como regra — os mesmos campos saturados persistem enquanto a mistura é proibida e as bordas se tornam absolutas; reinterpretação dentro de uma linha, não fusão.

**Atmosfera e mood**

**Bordas duras, campos saturados, argumento delimitado** — (1001 Aesthetics; código: Lummi)

Color block: grandes campos de cor pura com bordas nítidas, composição gráfica sem transições.

**Paleta de cores** primárias e saturadas em blocos

**Melhores usos:** design, moda, capas

**MidJourney:** `--sref 1673894843 --sw 1000` (Color Block, Lummi)

**Prompt universal (Seedream):** `Ultra-crisp graphic composition at 8k, color block design of large saturated fields in cobalt vermilion and yellow with hard clean edges, bold layout without gradients, bounded chromatic argument in the lineage of Ellsworth Kelly and Mondrian, flat matte print texture, gallery-print precision`

### **Coquette**

**№ 176 / 1001** · *Innocence is the costume, strategy is the seam*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A imagética de meninice do Rococó, os códigos da lingerie e a autoestilização da era das plataformas convergem; retire o pai histórico e a fita perde a referência, retire o fio das plataformas e a estratégia nunca se torna legível como look — fusão de linhagens distintas.

**Atmosfera e mood**

**Inocência é o figurino, estratégia é a costura** — (1001 Aesthetics, interpretação)

Coquette: laços de fita rosa, renda e pérolas, luz suave romântica, feminilidade calculadamente doce.

**Paleta de cores** rosa-bebê, branco-renda, pérola

**Melhores usos:** moda, social media, editorial

**MidJourney:** `[tema], coquette aesthetic, pink ribbons and lace --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.2, a coquette aesthetic scene, pink satin ribbons and delicate lace against soft skin, pearls glowing in romantic window light, sweet calculated femininity with strategy in the seams, Sofia Coppola's Marie Antoinette palette, creamy pastel grading with fine fabric detail, 8k editorial`

### **Cubism**

**№ 186 / 1001** · *Object seen from every side at once*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**O objeto visto de todos os lados ao mesmo tempo** — (1001 Aesthetics; código: sref-midjourney.com)

Cubismo: planos fragmentados e reorganizados, múltiplos pontos de vista simultâneos (Picasso, Braque).

**Paleta de cores** terrosos analíticos ou saturados sintéticos

**Melhores usos:** arte, retratos, capas

**MidJourney:** `--sref 3094283240 --sw 1000` (Geometric Serenity, categoria cubism) — o código 484604415 já presente nesta página também é da categoria

**LoRA (Civitai):** "Cubism Style" (Flux.1) — civitai.com/models/692810; "Cubism Strokes" (SDXL) — civitai.com/models/786658

**Prompt universal (Seedream):** `Museum-grade reproduction of a cubist painting, object fragmented into geometric planes seen from every side at once, analytical earth tones of ochre umber and slate with bold synthetic accents, Picasso and Braque influence, visible canvas weave and dry brush texture, fine craquelure, 8k archival scan`

### **Deconstructed Glamour**

**№ 212 / 1001** · *Autopsy of luxury*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**A autópsia do luxo** — (1001 Aesthetics, interpretação)

Glamour desconstruído: vestido de gala com costuras expostas, maquiagem borrada de propósito, luxo desmontado em peças (Margiela).

**Paleta de cores** nude, preto, brilhos deslocados

**Melhores usos:** moda, editorial, arte

**MidJourney:** `[tema], deconstructed glamour, exposed seams couture, Margiela style --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm f/1.4, a deconstructed glamour editorial, couture gown with exposed seams and raw hems, deliberately smudged glamour makeup under hard studio strobe, luxury dismantled into its parts, Margiela-style autopsy of fashion, stark high-fashion grading, 8k`

### **Disorder**

**№ 230 / 1001** · *Wound That Refuses to Heal*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↓

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**A ferida que se recusa a sarar** — (1001 Aesthetics, interpretação)

Desordem: composição rompida, camadas rasgadas e riscadas, caos expressivo sem resolução.

**Paleta de cores** contrastes crus, vermelho de alerta, preto riscado

**Melhores usos:** arte, música alternativa, capas

**MidJourney:** `[tema], expressive disorder, torn scratched chaotic layers --v 6`

**Prompt universal (Seedream):** `High-resolution capture of a disorder artwork, ruptured composition of torn and scratched layers, raw contrasts of alarm red against scrawled black, expressive chaos refusing resolution, the wound left open, impasto and gouged texture in raking light, 8k museum documentation`

### **Dramatic**

**№ 242 / 1001** · *Compress the human condition until it ignites*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → THEME ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Comprimir a condição humana até inflamar** — (1001 Aesthetics; código: match aproximado)

Dramático: luz de palco recortando o rosto, gesto no clímax, tensão emocional máxima no quadro.

**Paleta de cores** claro-escuro extremo, vermelho de tensão

**Melhores usos:** retratos, cinema, capas

**MidJourney:** `--sref 748611529 --sw 1000` (Moody and Cinematic Vibes — match aproximado)

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a dramatic portrait, stage light carving the face from darkness, gesture caught at its climax, extreme chiaroscuro with one tension-red accent, the human condition compressed until it ignites, theatrical editorial grading, 8k`

### **Early Modernism (1900–1920)**

**№ 259 / 1001** · *Seven Rooms With the Doors Blown Out*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**Sete salas com as portas arrebentadas** — (1001 Aesthetics, interpretação)

Modernismo inicial: fauvismo, cubismo e expressionismo explodindo juntos — cor liberta, forma quebrada, tradição derrubada.

**Paleta de cores** fauve saturado, contrastes radicais

**Melhores usos:** arte, editorial, capas

**MidJourney:** `[tema], early modernism 1900s avant-garde painting, fauvist color and broken form --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an early modernist painting 1900-1920, fauvist liberated color colliding with cubist broken form and expressionist urgency, visible impasto brushwork in raking light, tradition's doors blown out, radical avant-garde energy, 8k gallery documentation`

### **Eccentric**

**№ 261 / 1001** · *Cabinet That Argues With Itself*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O gabinete que discute consigo mesmo** — (1001 Aesthetics, interpretação)

Excêntrico: coleções improváveis juntas, estampas que brigam com orgulho, personalidade acima de qualquer regra.

**Paleta de cores** combinações improváveis, saturadas

**Melhores usos:** interiores, moda, retratos

**MidJourney:** `[tema], eccentric maximalist interior, curiosity cabinet chaos --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm f/2.8, an eccentric interior, improbable collections displayed together, proudly clashing prints and colors in warm lamplight, a curiosity cabinet arguing with itself, personality above every rule, World of Interiors editorial richness, 8k`

### **Emerging**

**№ 279 / 1001** · *Manifesto Still Wet on the Wall*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O manifesto ainda úmido na parede** — (1001 Aesthetics, interpretação)

Emergente: arte nova recém-colada, energia de cena nascente, o futuro sendo declarado agora.

**Paleta de cores** tinta fresca, contrastes crus, branco de cartaz

**Melhores usos:** arte contemporânea, editorial, cultura

**MidJourney:** `[tema], emerging art scene, freshly pasted manifesto posters, raw new energy --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 800 with 35mm lens, an emerging art scene, a manifesto still wet on the wall, freshly pasted posters and raw declaration energy under streetlight, fresh ink and poster white, dripping paste catching the glow, the future being announced now, documentary urgency, 8k`

### **Emo**

**№ 281 / 1001** · *Take Where the Voice Broke*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O take onde a voz quebrou** — (1001 Aesthetics, interpretação)

Emo: franja sobre o olho, preto com detalhe roxo, emoção crua dos anos 2000 sem vergonha de sentir.

**Paleta de cores** preto, roxo, vermelho escuro, xadrez

**Melhores usos:** retratos, música, nostalgia 2000s

**MidJourney:** `[tema], 2000s emo aesthetic, side-swept fringe, raw emotion --v 6`

**Prompt universal (Seedream):** `Shot on 35mm film with direct flash, a 2000s emo portrait, side-swept fringe over one eye, black with purple and dark red accents, raw unashamed emotion in a suburban bedroom of band posters, the take where the voice broke, MySpace-era grain elevated to editorial, 8k scan`

### **Environmental Art**

**№ 294 / 1001** · *Vista, Not the Object, Is the Medium*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → DOMAIN ↑

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**A vista, e não o objeto, é o meio** — (1001 Aesthetics, interpretação)

Land art: intervenção na paisagem à la Goldsworthy e Smithson, espiral de pedra e folha ordenada, a natureza como galeria.

**Paleta de cores** cores da própria paisagem

**Melhores usos:** arte, paisagem, conceitual

**MidJourney:** `[tema], land art intervention in landscape, Goldsworthy style natural materials --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 23mm lens, environmental land art, stone spiral and ordered leaves arranged in open landscape at first light, Goldsworthy-like natural intervention, the vista itself as the medium, colors of the land in perfect gradient, meditative documentation, 8k`

### **Erotic**

**№ 301 / 1001** · *Gaze That Returns Without Apology*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → RESONANCE ↑

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**O olhar que retorna sem pedir desculpa** — (1001 Aesthetics, interpretação)

Sensual artístico: sombra e curva sugeridas, tensão do não mostrado, confiança no olhar direto.

**Paleta de cores** pele em penumbra, vermelho profundo, preto

**Melhores usos:** fine art, retratos, fotografia artística

**MidJourney:** `[tema], sensual fine art photography, suggested curves in chiaroscuro, confident direct gaze --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R with 85mm f/1.4, a sensual fine art portrait, curves suggested in chiaroscuro shadow, the tension of what is not shown, a confident gaze that returns without apology, deep red and black, Helmut Newton drama in a single hard light, 8k editorial`

### **Euphoriccore**

**№ 309 / 1001** · *Strobe-Lit Peak Before the Comedown*

**Nível:** ⚫ Quaternary

**Eixo:** EXPRESSION ↑ → INTENTIONALITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O pico sob strobe antes da descida** — (1001 Aesthetics, interpretação)

Eufórico: pista de dança no auge, glitter e strobe, alegria química congelada no flash.

**Paleta de cores** neônica saturada, flash branco, glitter

**Melhores usos:** música, festa, editorial jovem

**MidJourney:** `[tema], euphoric rave peak, strobe-lit dancefloor, glitter and flash --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm f/1.4 and hard flash, a euphoriccore image, strobe-lit dancefloor at its peak before the comedown, saturated neon and white flash with glitter suspended mid-air, sweat and confetti caught in the strobe, chemical joy frozen mid-flash, Euphoria-series grading, 8k`

### **Expressionism**

**№ 313 / 1001** · *Munch's Scream and the Sky That Bleeds*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**O grito de Munch e o céu que sangra** — (1001 Aesthetics; código: sref-midjourney.com, categoria Expressionism)

Expressionismo: cor violenta e forma distorcida, emoção pintada em vez do mundo, o interior transbordando na tela.

**Paleta de cores** vermelhos sangrantes, laranjas e azuis em choque

**Melhores usos:** arte, retratos emocionais, dramático

**MidJourney:** `--sref 3522946248 --sw 1000` (categoria Expressionism)

**LoRA (Civitai):** "FF Style: Edvard Munch" (SDXL) — civitai.com/models/182009; "style of Edvard Munch 115" (SD1.5) — civitai.com/models/444864

**Prompt universal (Seedream):** `Museum-grade reproduction of an expressionist painting, violent color and distorted form, a sky that bleeds over a screaming figure, Munch-like emotional distortion in thick visible brushwork, painting the feeling instead of the world, raking gallery light on impasto, 8k`

### **Exuberance**

**№ 315 / 1001** · *Color Spilling Past Every Containing Line*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A cor transbordando de cada linha que a contém** — (1001 Aesthetics; código: Lummi, match aproximado)

Exuberância: alegria cromática sem contenção, cor que vaza dos contornos, energia vital máxima.

**Paleta de cores** espectro completo em saturação máxima

**Melhores usos:** festivo, arte, editorial vibrante

**MidJourney:** `--sref 618637360 --sw 1000` (Multicolor — match aproximado)

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, an exuberant image, color spilling past every containing line, full spectrum at maximum saturation in hard sunlight, pigment clouds bursting mid-air, chromatic joy without restraint, maximum vital energy, high-speed festival editorial, 8k`

### **Fantasy**

**№ 320 / 1001** · *A map invented, weather included*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SAGA ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A arquitetura de mundos subcriados** — (1001 Aesthetics, interpretação)

Fantasia: mundo inteiro com suas próprias leis, mapas e línguas, o imaginário construído com coerência total.

**Paleta de cores** paletas de mundo próprio, luz mítica

**Melhores usos:** capas, concept art, ilustração

**MidJourney:** `[tema], high fantasy world-building, sub-created world with its own laws --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a fantasy illustration, a fully sub-created world with its own architecture maps and languages, mythic golden light over coherent imaginary geography stretching to the horizon, Frazetta-grade heroic grandeur, wonder built with total internal logic`

### **FAUVISM**

**№ 323 / 1001** · *'Wild Beasts' of the 1905 Salon d'Automne*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↓

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**As 'feras' do Salon d'Automne de 1905** — (1001 Aesthetics, interpretação)

Fauvismo: cor pura e arbitrária de Matisse e Derain, céu que pode ser vermelho, pintura liberta da descrição.

**Paleta de cores** vermelhos, verdes e azuis puros e não naturais

**Melhores usos:** arte, retratos, paisagens vibrantes

**MidJourney:** `[tema], Fauvist painting, wild pure arbitrary color, Matisse and Derain style --v 6`

**LoRA (Civitai):** "Henri Matisse Style — Fauvism" (SD1.5) — civitai.com/models/792117; "style of Henri Matisse" (Flux) — civitai.com/models/674556

**Prompt universal (Seedream):** `Museum-grade reproduction of a fauvist painting, wild pure arbitrary color like the 1905 Salon d'Automne, a sky allowed to be red, bold flat brushwork freed from description with visible impasto, the raw chromatic courage of Matisse and Derain, gallery raking light, 8k`

### **Feminine**

**№ 325 / 1001** · *Lace Edges, Blush Tone, and the Curved Line*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → NUANCE ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Bordas de renda, tom de blush e a linha curva** — (1001 Aesthetics; código: Lummi, match aproximado)

Feminino: suavidade de renda e curva, rosa de blush, delicadeza como linguagem visual.

**Paleta de cores** rosa blush, marfim, lilás suave

**Melhores usos:** moda, beleza, branding

**MidJourney:** `--sref 3154438697 --sw 1000` (Pinks & Giggles — match aproximado)

**Prompt universal (Seedream):** `Shot on Leica Q2 in macro mode, a feminine composition, lace edges and blush tones along a curved line in soft window light, soft ivory and gentle lilac, delicacy as visual language, fine-art still-life clarity, 8k`

### **Feminist**

**№ 327 / 1001** · *Half the canon, put on notice*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A gramática visual da recusa** — (1001 Aesthetics, interpretação)

Feminista: cartaz e colagem de protesto, tipografia direta à la Barbara Kruger, imagem que devolve o olhar.

**Paleta de cores** preto, branco, vermelho de faixa

**Melhores usos:** campanhas, editorial, arte política

**MidJourney:** `[tema], feminist protest art, bold Kruger-style typography, visual grammar of refusal --v 6`

**Prompt universal (Seedream):** `Ultra-crisp graphic composition at 8k, a feminist visual, protest collage with bold direct typography in black white and banner red, Barbara Kruger confrontation, high-contrast halftone print texture, an image that returns the gaze and refuses`

### **Fin de Siècle**

**№ 330 / 1001** · *Absinthe and Beardsley's Ink at the Century's Close*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ETERNITY ↓

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Absinto e a tinta de Beardsley no fim do século** — (1001 Aesthetics, interpretação)

Fim de século: decadência elegante de 1890, nanquim sinuoso e absinto verde, beleza doente e refinada.

**Paleta de cores** preto de nanquim, verde absinto, dourado decadente

**Melhores usos:** ilustração, editorial, histórico

**MidJourney:** `[tema], fin de siècle decadence, Beardsley ink illustration, absinthe green 1890s --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a fin de siècle illustration, sinuous Aubrey Beardsley black ink with absinthe green and decadent gold, elegant 1890s decadence at the century's close, refined sickly beauty, fine linework crispness, 8k archival print`

### **Flamboyant**

**№ 333 / 1001** · *Sequins, Feathers, and the Refusal to Go Unseen*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Lantejoulas, plumas e a recusa de passar despercebido** — (1001 Aesthetics, interpretação)

Extravagante: brilho máximo e plumas em movimento, palco como estado de espírito, existência como espetáculo.

**Paleta de cores** lantejoula dourada, fúcsia, turquesa de palco

**Melhores usos:** performance, moda, editorial

**MidJourney:** `[tema], flamboyant stage costume, sequins and feathers, refusal to go unseen --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 70-200mm lens, a flamboyant performer, sequins and feathers in motion under hot stage light, gold fuchsia and turquoise catching every sequin, Alexander McQueen runway audacity, existence as spectacle and the refusal to go unseen, 8k`

### **Freeformcore**

**№ 349 / 1001** · *Composition With the Grid Thrown Out*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → INTENTIONALITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Composição com a grade jogada fora** — (1001 Aesthetics, interpretação)

Forma livre: layout sem grid, elementos flutuando por instinto, ordem substituída por ritmo orgânico.

**Paleta de cores** livres, definidas pela intuição da peça

**Melhores usos:** design experimental, arte, editorial

**MidJourney:** `[tema], freeform composition, grid thrown out, organic instinctive layout --v 6`

**Prompt universal (Seedream):** `Bold vector-free graphic composition at 8k, a freeformcore design, composition with the grid thrown out, elements floating by instinct in organic rhythm, order replaced by confident intuitive placement, hand-tuned asymmetry`

### **Funfair**

**№ 354 / 1001** · *Ferris's 1893 Wheel Against the Black Sky*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A roda de Ferris de 1893 contra o céu negro** — (1001 Aesthetics, interpretação)

Parque de diversões: roda-gigante iluminada na noite, algodão-doce e lâmpadas incandescentes, véspera de milagre mecânico.

**Paleta de cores** luzes quentes de lâmpada, vermelho e dourado de barraca, céu negro

**Melhores usos:** nostálgico, narrativa, editorial

**MidJourney:** `[tema], vintage funfair at night, Ferris wheel lit against the black sky --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 50mm lens, a funfair scene, a giant Ferris wheel of warm incandescent bulbs against the black night sky, candy stalls in red and gold glowing below, mechanical miracle atmosphere of a Coney Island summer, long-exposure light trails, 8k`

### **Future Funk**

**№ 356 / 1001** · *City Pop Pitched Up Three Semitones*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SAGA ↓

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**City pop acelerado três semitons** — (1001 Aesthetics, interpretação)

Future funk: anime dos anos 80 em neôn rosa, vinil japonês e skyline noturno, dança em VHS saturado.

**Paleta de cores** rosa neôn, roxo, azul de skyline, brilho VHS

**Melhores usos:** música, capas, editorial retrô

**MidJourney:** `[tema], future funk aesthetic, 80s city pop anime, neon pink Tokyo skyline, VHS glow --v 6`

**LoRA (Civitai):** "[Style] City Pop Style" (Flux) — civitai.com/models/1278623

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a future funk image, 80s Japanese city pop anime style pitched into neon, pink and purple Tokyo skyline at night with VHS glow and vinyl sparkle, Hiroshi Nagai sunset palette, saturated retro dance joy, chromatic aberration and scanline texture`

### **Futurism**

**№ 357 / 1001** · *Boccioni's Body Dragged Into Its Own Slipstream*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O corpo de Boccioni arrastado pela própria esteira de vento** — (1001 Aesthetics; código: sref-midjourney.com, categoria Futurism)

Futurismo: velocidade pintada, formas em deslocamento simultâneo, a máquina e o movimento como heróis de 1910.

**Paleta de cores** metálicos dinâmicos, vermelhos e azuis em vetor

**Melhores usos:** arte, movimento, editorial

**MidJourney:** `--sref 1132832705 --sw 1000` (categoria Futurism)

**Prompt universal (Seedream):** `Museum-grade reproduction of an Italian Futurist painting, a body dragged into its own slipstream like Boccioni, simultaneous displaced forms painting speed itself, dynamic metallic reds and blues in visible impasto, the machine as hero of 1910, gallery raking light, 8k`

### **Gabber**

**№ 359 / 1001** · *Rotterdam's 190-BPM Kick and the Hakken Stomp*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O kick de 190 BPM de Rotterdam e o passo hakken** — (1001 Aesthetics, interpretação)

Gabber: rave holandesa dos anos 90, agasalho Australian e cabeça raspada, energia bruta de armazém industrial.

**Paleta de cores** preto, laranja fluorescente, luz de strobe industrial

**Melhores usos:** música, subcultura, editorial

**MidJourney:** `[tema], 90s Rotterdam gabber rave, tracksuits and shaved heads, industrial warehouse strobe --v 6`

**Prompt universal (Seedream):** `Shot on Contax T2 with direct flash, a gabber scene, 1990s Rotterdam hardcore rave with tracksuits and shaved heads mid-hakken stomp, industrial warehouse strobe in black and fluorescent orange, sweat frozen by hard flash, raw 190 BPM energy in documentary rave style, 8k`

### **Gaudy**

**№ 365 / 1001** · *Shine that outshouts its object*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A sétima lantejoula que se recusa a sair** — (1001 Aesthetics, interpretação)

Espalhafatoso: brilho demais de propósito, estampa sobre estampa, mau gosto assumido como estilo.

**Paleta de cores** dourado, animal print, neôn em conflito proposital

**Melhores usos:** editorial irônico, moda ousada, kitsch

**MidJourney:** `[tema], gloriously gaudy, sequins over leopard print over gold, deliberate too-much --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 with 63mm lens and ring flash, a gaudy image, sequins over leopard print over gold with clashing neon, pattern on pattern worn with pride, David LaChapelle saturated excess, deliberate glorious too-much as style, 8k`

### **Gen Z**

**№ 371 / 1001** · *Hot-Pink Caption Sticker Over a Climate Chart*

**Nível:** ⚫ Quaternary

**Eixo:** EXPRESSION ↑ → COHERENCE ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O sticker rosa-choque sobre um gráfico climático** — (1001 Aesthetics, interpretação)

Geração Z: colagem de stories e ironia sincera, humor e ansiedade climática na mesma tela, estética de edição rápida.

**Paleta de cores** rosa-choque, verde lima, contraste de meme

**Melhores usos:** redes sociais, editorial jovem, campanhas

**MidJourney:** `[tema], Gen Z aesthetic, hot-pink caption stickers over serious charts, story-collage irony --v 6`

**Prompt universal (Seedream):** `Shot on smartphone with harsh front flash, vertical framing, a Gen Z visual, hot-pink caption sticker slapped over a climate chart, story-collage editing with lime green and meme contrast, sincere irony and humor sharing the screen with anxiety, 8k`

### **Girly**

**№ 378 / 1001** · *Hello Kitty, Lace Trim, and the Bow as Armor*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Hello Kitty, renda e o laço como armadura** — (1001 Aesthetics; código: Lummi, match aproximado)

Girly: rosa máximo e laços, fofura assumida como força, quarto de adesivos e brilho.

**Paleta de cores** rosa em todos os tons, branco de renda, brilho

**Melhores usos:** branding jovem, editorial pop, produto

**MidJourney:** `--sref 3854973013 --sw 1000` (Pastel Toyland — match aproximado)

**Prompt universal (Seedream):** `Shot on Kodak Portra 160 with 50mm lens, a girly image, Hello Kitty pinks with lace trim and a bow worn as armor, sticker-covered glittery room in soft window light, pastel rose and glitter silver, cuteness claimed as strength, 8k`

### **Glam**

**№ 381 / 1001** · *Bolan's Glitter Cheek on Top of the Pops*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O glitter na bochecha de Bolan no Top of the Pops** — (1001 Aesthetics, interpretação)

Glam: brilho de palco setentista, cetim e purpurina, androgínia cintilante sob luz de estúdio de TV.

**Paleta de cores** prata glitter, rosa cetim, dourado de palco

**Melhores usos:** música, moda, editorial retrô

**MidJourney:** `[tema], 70s glam, glitter cheek and satin under TV studio light, Top of the Pops shimmer --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Vision3 cine film with 50mm lens, a glam scene, 1970s glitter cheek and satin suit under TV studio light, silver sparkle with satin pink and stage gold, Mick Rock backstage shimmer, androgyny on Top of the Pops, 8k`

### **Glam Punk**

**№ 382 / 1001** · *Safety Pin Piercing a Sequin*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O alfinete atravessando a lantejoula** — (1001 Aesthetics, interpretação)

Glam punk: brilho rasgado de propósito, cetim com tacha, o espetáculo e a rebeldia costurados juntos.

**Paleta de cores** prata glitter, preto de couro, rosa rasgado

**Melhores usos:** música, moda alternativa, editorial

**MidJourney:** `[tema], glam punk, safety pin piercing a sequin, torn satin with studs --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F3 with 28mm lens and direct flash, a glam punk image, a safety pin piercing a sequin, torn satin and studded leather sharing one outfit, glitter silver with leather black, spectacle and rebellion stitched together, 8k`

### **Glam Rock**

**№ 383 / 1001** · *Bowie's Lightning Bolt Under a Tungsten Spot*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O raio de Bowie sob um spot de tungstênio** — (1001 Aesthetics, interpretação)

Glam rock: maquiagem de raio e macacão cintilante, palco setentista em luz quente, o alter ego como obra de arte.

**Paleta de cores** vermelho e azul de raio, dourado de tungstênio, prata

**Melhores usos:** música, retratos, editorial

**MidJourney:** `[tema], 70s glam rock, lightning bolt makeup under tungsten spotlight, Ziggy-era stage persona --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 500C with 80mm lens, a glam rock portrait, lightning bolt makeup under a warm tungsten spot, shimmering jumpsuit on a 1970s stage, red and blue bolt with tungsten gold, Brian Duffy studio boldness, the alter ego as artwork, 8k`

### **Gourmet**

**№ 394 / 1001** · *Foam That Collapses Ninety Seconds After Plating*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A espuma que colapsa noventa segundos após o empratamento** — (1001 Aesthetics, interpretação)

Gourmet: alta gastronomia em prato branco enorme, pinça e micro-erva, o efêmero como luxo comestível.

**Paleta de cores** branco de porcelana, cores de redução e ervas, luz de restaurante

**Melhores usos:** gastronomia, editorial, branding premium

**MidJourney:** `[tema], fine dining gourmet plating, collapsing foam and micro herbs on vast white porcelain --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z8 with 105mm macro lens, a gourmet plating, a delicate foam collapsing ninety seconds after plating, tweezer-placed micro herbs on vast white porcelain, reduction colors under directional restaurant light, the ephemeral as edible luxury, 8k`

### **Greek IV Hellenistic**

**№ 403 / 1001** · *Named Wound, Carved at the Seam of Empires*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SAGA ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A ferida nomeada, esculpida na costura dos impérios** — (1001 Aesthetics, interpretação)

Helenístico: drama e emoção no mármore, Laocoonte e o Gálata moribundo, o corpo em torção e a dor com nome.

**Paleta de cores** mármore dramático, sombra profunda, bronze

**Melhores usos:** arte, narrativa, editorial dramático

**MidJourney:** `[tema], Hellenistic sculpture style, dramatic twisting marble bodies, Laocoon pathos, deep carved shadow --v 6`

**Prompt universal (Seedream):** `Shot on Phase One XF with 150mm lens, a Hellenistic Greek image, dramatically twisting marble bodies with named wounds, Laocoon pathos and dying Gaul dignity, deep undercut shadows under a single raking spotlight, emotion carved at the seam of empires, 8k`

### **Groovy**

**№ 405 / 1001** · *Liquid Light Shows Under Haight-Ashbury Blacklight*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Liquid light shows sob a luz negra de Haight-Ashbury** — (1001 Aesthetics; código: sref-midjourney.com, categoria Psychedelic, match aproximado)

Groovy: letras derretidas e óleo projetado, pôster de rock de 1967, cores que vibram sob blacklight.

**Paleta de cores** laranja ácido, roxo elétrico, verde limão, rosa quente

**Melhores usos:** pôsteres, música, editorial retrô

**MidJourney:** `--sref 2179642028 --sw 1000` (categoria Psychedelic — match aproximado)

**Prompt universal (Seedream):** `Ultra-vivid psychedelic poster art, a groovy 1967 image, liquid light show projections under Haight-Ashbury blacklight, melted lettering in the style of Wes Wilson and Victor Moscoso, acid orange and electric purple vibrating, 8k`

### **Grotesque**

**№ 406 / 1001** · *Gargoyle Whose Mouth Becomes the Rainspout*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A gárgula cuja boca vira calha** — (1001 Aesthetics; código: sref-midjourney.com, match aproximado)

Grotesco: criaturas híbridas na pedra da catedral, o monstruoso funcional, feiura esculpida com propósito.

**Paleta de cores** pedra escura, verde de líquen, sombra de beiral

**Melhores usos:** arte dark, arquitetura, ilustração

**MidJourney:** `--sref 3694620941 --sw 1000` (Ink Sketch Gothic Surrealism — match aproximado)

**Prompt universal (Seedream):** `Shot on Leica M11 with 90mm lens, a grotesque image, a cathedral gargoyle whose open mouth becomes the rainspout, hybrid stone creatures with lichen under overcast sky, functional monstrosity carved with purpose, 8k`

### **Grunge**

**№ 408 / 1001** · *Flannel Cuff Frayed by an Actual History*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O punho da flanela puído por uma história real** — (1001 Aesthetics; código: Kinomoto, match aproximado)

Grunge: flanela e jeans rasgado de Seattle 1991, luz de porão e ruído analógico, o desleixo como recusa.

**Paleta de cores** xadrez desbotado, cinza de Seattle, marrom de porão

**Melhores usos:** música, moda, retratos

**MidJourney:** `--sref 929343584 --sw 1000` (Retro Grungy Cinematic Style — match aproximado)

**Prompt universal (Seedream):** `Shot on 35mm Kodak Tri-X pushed to 1600 with 28mm lens, a grunge image, a frayed flannel cuff worn by actual history, Seattle 1991 basement light with analog noise, faded plaid and ripped denim, Charles Peterson sweat-and-grain energy, dishevelment as refusal, 8k`

### **Harlem Renaissance**

**№ 416 / 1001** · *Aaron Douglas's Rings Put Blackness at the Center*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Os anéis de Aaron Douglas põem a negritude no centro** — (1001 Aesthetics, interpretação)

Renascença do Harlem: silhuetas em círculos concêntricos de luz, jazz e dignidade nos anos 1920, arte deco afro-americana.

**Paleta de cores** roxos e magentas em camadas, silhueta escura, dourado de jazz

**Melhores usos:** arte, música, editorial histórico

**MidJourney:** `[tema], Harlem Renaissance style, Aaron Douglas concentric rings of light, silhouettes in layered purples, 1920s jazz dignity --v 6`

**Prompt universal (Seedream):** `Bold Art Deco silkscreen composition, a Harlem Renaissance image, silhouetted figures inside Aaron Douglas concentric rings of light, layered purples and magentas with jazz gold, Blackness placed at the center of the composition, 8k`

### **Hermitcore**

**№ 428 / 1001** · *Thoreau's Ten-by-Fifteen Cabin Holds One Life*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↓ → INTENTIONALITY ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A cabana de três por cinco de Thoreau contém uma vida** — (1001 Aesthetics, interpretação)

Eremita: cabana mínima na floresta, uma cama, uma mesa, três cadeiras, a suficiência como riqueza.

**Paleta de cores** madeira de cabana, verde de lago Walden, cinza de amanhecer

**Melhores usos:** contemplação, lifestyle minimalista, editorial

**MidJourney:** `[tema], hermitcore, Thoreau's tiny cabin holding one whole life, Walden woods solitude --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex with 80mm lens, a hermitcore image, a ten-by-fifteen cabin holding one whole life, single bed and desk by Walden woods, dawn grey through pines, sufficiency as wealth, 8k`

### **High Fashion**

**№ 431 / 1001** · *Three Fittings Rewrite Forty Pattern Pieces*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Três provas reescrevem quarenta moldes** — (1001 Aesthetics, interpretação)

Alta moda: editorial de passarela e construção extrema, silhueta escultórica sob luz dura, a roupa como argumento.

**Paleta de cores** preto de passarela, branco de estúdio, um acento de coleção

**Melhores usos:** moda, editorial, campanha

**MidJourney:** `[tema], high fashion editorial, sculptural silhouette under hard studio light, extreme runway construction --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H6D with 100mm lens, a high fashion editorial, a sculptural silhouette rewritten across three fittings and forty pattern pieces, hard studio light on runway black and white, Peter Lindbergh monochrome intensity, the garment as argument, 8k`

### **Hot**

**№ 441 / 1001** · *Hot Pink Claims the Room Before the Door Closes*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → NUANCE ↓

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O rosa-choque reivindica a sala antes da porta fechar** — (1001 Aesthetics, interpretação)

Hot: cor de temperatura máxima, rosa e vermelho que entram primeiro, presença antes de qualquer palavra.

**Paleta de cores** rosa-choque, vermelho quente, magenta, laranja de brasa

**Melhores usos:** moda, campanha, editorial ousado

**MidJourney:** `[tema], hot aesthetic, hot pink claiming the whole room, maximum temperature color, bold presence --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q3 with 28mm lens, a hot image, hot pink claiming the room before the door closes, magenta and ember red at maximum temperature, Miles Aldridge saturated glamour, presence arriving before any word, 8k`

### **Hypercore**

**№ 446 / 1001** · *Twelve Neons Run at the Feed's Refresh Rate*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Doze neôns rodando na taxa de atualização do feed** — (1001 Aesthetics; código: Kinomoto, match aproximado)

Hypercore: estímulo máximo simultâneo, cores saturadas colidindo na velocidade do scroll, a atenção como campo de batalha.

**Paleta de cores** doze neôns ao mesmo tempo, colisão de saturação máxima

**Melhores usos:** digital, editorial experimental, música

**MidJourney:** `--sref 2183956950 --sw 1000` (high-saturation color clash — match aproximado)

**Prompt universal (Seedream):** `Ultra-saturated digital collage, a hypercore image, twelve neons running at the feed's refresh rate, maximum simultaneous saturation colliding at scroll speed, attention as battlefield, 8k`

### **Hyperpop**

**№ 449 / 1001** · *SOPHIE Pushes the Chorus Past Plausibility*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**SOPHIE empurra o refrão para além do plausível** — (1001 Aesthetics, interpretação)

Hyperpop: pop sintetizado até o plástico brilhar, cromo líquido e rosa digital, o artificial abraçado como sinceridade.

**Paleta de cores** cromo líquido, rosa digital, azul de bolha, brilho de plástico

**Melhores usos:** música, editorial pop, digital

**MidJourney:** `[tema], hyperpop aesthetic, liquid chrome and digital pink, plastic shine pushed past plausibility --v 6`

**Prompt universal (Seedream):** `Ultra-glossy 3D digital render, a hyperpop image, liquid chrome and digital bubblegum pink pushed past plausibility, glossy plastic textures and synthetic shine, the artificial embraced as sincerity, 8k`

### **Imaginative Realism**

**№ 459 / 1001** · *Frazetta's Dragon Carries Anatomical Weight*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O dragão de Frazetta carrega peso anatômico** — (1001 Aesthetics, interpretação)

Realismo imaginativo: fantasia pintada com rigor de natureza-morta, o impossível com músculo, luz e gravidade reais.

**Paleta de cores** óleo dramático, terra e bronze, luz de tempestade

**Melhores usos:** fantasia, capas, concept art

**MidJourney:** `[tema], imaginative realism oil painting, Frazetta dragon with real anatomical weight, dramatic fantasy realism --v 6`

**Prompt universal (Seedream):** `Ultra-detailed oil painting in the school of James Gurney, an imaginative realism scene, a dragon carrying true anatomical weight, the impossible rendered with real muscle light and gravity, dramatic earth and bronze storm palette, 8k`

### **Indie Sleaze**

**№ 466 / 1001** · *Disposable Flash Keeps the Club at 4 A.M.*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O flash descartável mantém o clube às 4 da manhã** — (1001 Aesthetics; código: kajimelo, match aproximado)

Indie sleaze: flash estourado de 2009, glitter borrado e american apparel, a noite documentada sem filtro.

**Paleta de cores** flash estourado, preto de clube, dourado de glitter, vermelho de olho

**Melhores usos:** editorial, música, moda retrô-2000s

**MidJourney:** `--sref 1383933938 --sw 1000` (90s Camcorder Vibes & DIY Collage — match aproximado)

**Prompt universal (Seedream):** `Shot on disposable camera with direct flash, an indie sleaze image, blown-out highlights and smeared glitter keeping the club alive at 4 a.m., Cobrasnake party-photo energy, 2009 party documented with no filter, 8k`

### **Ink Art**

**№ 472 / 1001** · *Sesshū Lets One Brushstroke Become a Mountain*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Sesshū deixa uma pincelada virar montanha** — (1001 Aesthetics; código: Lummi, match aproximado)

Arte de tinta: sumi-ê e nanquim, gesto único e vazio que respira, a montanha inteira em um traço.

**Paleta de cores** preto de nanquim em diluições, branco de papel de arroz

**Melhores usos:** arte, editorial zen, identidade minimalista

**MidJourney:** `--sref 152636141 --sw 1000` (Ink & Accent — match aproximado)

**LoRA (Civitai):** "Zen Ink Wash Sumi-e" (ZImage) — civitai.com/models/647926; "ink wash painting" (SDXL, trigger: ink wash painting) — civitai.com/models/231966

**Prompt universal (Seedream):** `Museum-grade ink painting reproduction, an ink art sumi-e image, one brushstroke becoming a whole mountain, diluted black ink on breathing rice-paper emptiness, Sesshū gesture and negative space, 8k`

### **Jazz Age (Roaring Twenties)**

**№ 491 / 1001** · *Josephine Baker's Charleston Breaks the Beaded Fringe Loose*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O charleston de Josephine Baker solta a franja de miçangas** — (1001 Aesthetics, interpretação)

Era do jazz: anos 20 em movimento, lantejoula e sax sob luz de cabaré, o corpo mais rápido que a música.

**Paleta de cores** dourado de lantejoula, preto de smoking, champanhe, vermelho de cabaré

**Melhores usos:** festa, editorial vintage, moda

**MidJourney:** `[tema], Jazz Age Roaring Twenties, Charleston breaking the beaded fringe loose, cabaret light and sequins --v 6`

**LoRA (Civitai):** "Art Deco — CE" — civitai.com/models/998799

**Prompt universal (Seedream):** `Shot on a 1920s Leica I with 50mm lens, a Jazz Age image, a Charleston breaking the beaded fringe loose, sequin gold and tuxedo black under cabaret spotlights, champagne sparkle, the body moving faster than the music, 8k`

### **LGBTQIA**

**№ 521 / 1001** · *Stonewall bricks and pride banners*

**Nível:** ⚫ Quaternary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Tijolos de Stonewall e bandeiras de orgulho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

LGBTQIA: alegria como resistência, espectro completo de bandeiras sobre uma rua em marcha.

**Paleta de cores** espectro completo, dourado de fim de tarde, tijolo

**Melhores usos:** documental, editorial, cultura

**MidJourney:** `[tema], LGBTQIA pride aesthetic, Stonewall brick and pride banners, golden-hour march, joy as resistance --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Kodak Ultramax with 28mm lens, an LGBTQIA image, Stonewall brick and hand-sewn pride banners lifted into golden-hour light, the full spectrum rippling over a marching embracing street, Kay Tobin Lahusen documentary warmth, glitter catching low sun on laughing faces, joy documented as the most durable form of resistance, 8k`

### **Lowbrow**

**№ 534 / 1001** · *Big Daddy Roth’s hot-rod monsters*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Os monstros hot-rod de Big Daddy Roth** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lowbrow: pop surrealismo underground, olhos esbugalhados, candy-flake e arte que nunca pediu licença.

**Paleta de cores** candy-flake, cromado, verde monstro

**Melhores usos:** ilustração, pop art, sticker

**MidJourney:** `[tema], lowbrow aesthetic, hot-rod monsters bursting from chrome exhaust, bubble eyes, candy-flake color --v 6`

**Prompt universal (Seedream):** `Ultra-vivid lowbrow pop surrealist painting, a lowbrow image, Big Daddy Roth hot-rod monsters bursting through chrome exhaust flames, bubble eyes and candy-flake metalflake color laid on like custom car lacquer, Robert Williams underground precision beneath the mayhem, monster green against showroom pink, gallery art that never asked the academy for permission, 8k`

### **Ludic**

**№ 536 / 1001** · *LEGO bricks as design language*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → INTENTIONALITY ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Peças de LEGO como linguagem de design** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lúdico: a seriedade construída a partir do brincar, studs primários em luz de estúdio.

**Paleta de cores** primários de brinquedo, branco de estúdio

**Melhores usos:** design, branding, editorial criativo

**MidJourney:** `[tema], ludic aesthetic, LEGO bricks assembling a city, primary studs, bright playful studio --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS 90D with 60mm macro lens, a ludic image, LEGO bricks assembling a serious city skyline as a design language, primary red yellow and blue studs under bright toy-box studio light, minifigure commuters mid-joke on a tiny plaza, Bjarke Ingels LEGO House logic, seriousness built entirely out of play, 8k`

### **Mandrake**

**№ 547 / 1001** · *Verde-Bandeira tracksuit in São Paulo*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Agasalho verde-bandeira em São Paulo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mandrake: elegância de quebrada escrita em lógica de marca, correntes de ouro contra concreto e comércio.

**Paleta de cores** verde-bandeira, dourado de corrente, concreto paulistano

**Melhores usos:** streetwear, editorial urbano, cultura BR

**MidJourney:** `[tema], mandrake aesthetic, verde-bandeira tracksuit styled sharp on a Sao Paulo street, gold chains --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R10 with 35mm lens and direct flash, a mandrake image, a verde-bandeira tracksuit styled razor-sharp against Sao Paulo concrete, gold chains and immaculate sneakers catching hard midday flash, commerce and quebrada elegance negotiating the same corner, baile funk confidence written in brand logic, style asserted as territory and self-respect, 8k`

### **Mannerism**

**№ 549 / 1001** · *El Greco’s elongated saints*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → COHERENCE ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Os santos alongados de El Greco** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Maneirismo: a elegância tensionada até o êxtase, verdes ácidos e cinzas espirituais além da anatomia.

**Paleta de cores** verde ácido, cinza espiritual, luz de tempestade

**Melhores usos:** arte, editorial dramático, histórico

**MidJourney:** `[tema], mannerism aesthetic, El Greco elongated saints twisting toward storm light --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Mannerist canvas, a mannerism image, El Greco's elongated saints twisting upward into storm light, acid greens and spiritual greys stretched past anatomy toward heaven, Parmigianino necks and Pontormo weightlessness in one impossible choreography, varnish glow over restless brushwork, elegance strained deliberately into ecstasy, 8k archival scan`

### **Memphis**

**№ 562 / 1001** · *Squiggle That Fired the Grid*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O rabisco que demitiu a grade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Memphis: o design brincando contra o bom gosto, squiggles e laminados em primários de 1981.

**Paleta de cores** primários pop, terrazzo, preto e branco gráfico

**Melhores usos:** design, mobiliário, branding ousado

**MidJourney:** `[tema], Memphis design aesthetic, squiggles and terrazzo laminate in 1981 primaries, playful anti-grid --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H5D with 80mm lens on a seamless yellow backdrop, a Memphis design image, squiggles terrazzo laminate and impossible furniture stacked in 1981 primaries, Ettore Sottsass playfulness firing the modernist grid, black-and-white graphic zigzags against pop red and turquoise, design cheerfully declaring war on good taste, 8k`

### **Milipili**

**№ 572 / 1001** · *Argentine Glamour with a Y2K Twist*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Glamour argentino com toque Y2K** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Milipili: Buenos Aires em modo it-girl, óculos gigantes, brilho labial e status casual.

**Paleta de cores** rosa milenar, dourado de shopping, jeans claro

**Melhores usos:** moda, social, editorial pop

**MidJourney:** `[tema], milipili aesthetic, Argentine it-girl glamour with a Y2K twist, oversized sunglasses, lip gloss --v 6`

**Prompt universal (Seedream):** `Shot on Contax T3 with 35mm lens and paparazzi flash, a milipili image, Argentine it-girl glamour with a Y2K accent outside a Recoleta cafe, oversized sunglasses lip gloss and light-wash denim catching hard flash, mall-gold jewelry against millennium pink, tabloid-page energy styled with studied ease, status worn as if by accident, 8k`

### **Neo Baroque**

**№ 595 / 1001** · *Baroque Drama Under Digital Excess*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Drama barroco sob excesso digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neobarroco: dobras douradas e claro-escuro reencenados com brilho de render e maximalismo contemporâneo.

**Paleta de cores** dourado, carmesim, negro profundo com neon

**Melhores usos:** moda, capas, arte digital

**MidJourney:** `[tema], neo baroque aesthetic, gilded drama with digital excess, chiaroscuro maximalism --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork, a neo-baroque composition where Caravaggio chiaroscuro collides with digital excess, gilded folds and crimson drapery lit by a single beam plus neon accents, hyperreal render gloss over old-master darkness, theatrical maximalism, 8k`

### **Neo Manneristcore**

**№ 597 / 1001** · *Renaissance Elongation With Contemporary Irony*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Alongamento renascentista com ironia contemporânea** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neomaneirismo: pescoços impossíveis e poses serpentinas reencenados com um sorriso de canto.

**Paleta de cores** verdes ácidos, rosa frío, cinza de mármore

**Melhores usos:** moda conceitual, arte, editorial

**MidJourney:** `[tema], neo manneristcore aesthetic, elongated serpentine figures with contemporary irony --v 6`

**Prompt universal (Seedream):** `Ultra-detailed contemporary painting, a neo-mannerist figure with Parmigianino elongation posed around ironic modern props, impossible neck and serpentine twist in acid green and cold rose, renaissance polish winking at itself, gallery-grade finish, 8k`

### **Neo-Expressionism**

**№ 606 / 1001** · *Paint Thrown Back at the Polite Surface*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → MATTER ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Tinta jogada de volta na superfície educada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neoexpressionismo: figuração crua e furiosa, camadas grossas e símbolos riscados por cima.

**Paleta de cores** terrosos violentos, preto de carvão, vermelho cru

**Melhores usos:** arte, capas, editorial expressivo

**MidJourney:** `[tema], neo-expressionism aesthetic, raw furious figuration, thick paint scratched symbols --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a neo-expressionist canvas, raw furious figuration in troweled impasto, crowned heads and scratched glyphs thrown back at the polite surface, Basquiat urgency with Baselitz weight, violent earth tones and raw red, every ridge of paint in focus, 8k`

### **New Romantic**

**№ 622 / 1001** · *Self You Assemble, Not a Self You're Given*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Piratas de sintético no clube das quintas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

New romantic: blusas de babados, maquiagem teatral e glamour inventado no Blitz Club de 1981.

**Paleta de cores** púrpura de palco, dourado teatral, pó de arroz

**Melhores usos:** moda, música, editorial

**MidJourney:** `[tema], new romantic aesthetic, ruffled pirate blouse theatrical makeup, Blitz Club 1981 --v 6`

**Prompt universal (Seedream):** `Shot on Olympus OM-2 with 50mm lens under club spotlights, a new romantic portrait at the Blitz Club 1981, ruffled pirate blouse and theatrical powdered makeup, stage purple and tarnished gold glamour invented from thrift and eyeliner, synth-era romance, 8k`

### **Overachiever**

**№ 656 / 1001** · *Success Worn as Visible Armor*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ETERNITY ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Sucesso vestido como armadura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Superconquistador: parede de troféus, agenda por minuto e a exaustão polida em apresentação.

**Paleta de cores** azul corporativo, dourado de troféu, branco de planilha

**Melhores usos:** editorial, conceito, retratos

**MidJourney:** `[tema], overachiever aesthetic, trophy wall minute-scheduled planner, success worn as armor --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 III with 85mm lens, an overachiever portrait before a wall of trophies and framed certificates, planner scheduled to the minute beside a cold coffee, corporate blue and trophy gold, success worn as armor over quiet exhaustion, clinical sharpness, 8k`

### **Pantomime**

**№ 667 / 1001** · *Silence Doing the Loudest Work*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O silêncio mais alto do teatro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pantomima: rosto branco, gesto exato e uma parede invisível mais convincente que cenário.

**Paleta de cores** branco de cena, preto de malha, vermelho mínimo

**Melhores usos:** teatro, retratos, editorial

**MidJourney:** `[tema], pantomime aesthetic, whiteface mime exact gesture, the loudest silence in theater --v 6`

**Prompt universal (Seedream):** `Shot on Ilford XP2 with 85mm lens, a pantomime portrait, whiteface mime pressing against an invisible wall more convincing than any set, black knit and one minimal red accent under a single stage spot, Marcel Marceau precision where silence is loudest, fine chromogenic grain, 8k`

### **Peacockcore**

**№ 676 / 1001** · *Display Biology Worn as Performance*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Exibição como biologia e performance** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Peacockcore: iridescência total, leque aberto e o direito de ocupar todos os olhares da sala.

**Paleta de cores** verde-pavão, azul-safira, dourado de olho de pena

**Melhores usos:** moda, editorial, arte

**MidJourney:** `[tema], peacockcore aesthetic, full iridescent display, spectacle as biology --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R IV with 135mm lens, a peacockcore portrait, full iridescent fan of sapphire and emerald feather-eyes opened behind the subject, display as both biology and performance, gold-flecked plumage detail claiming every gaze in the room, luminous shallow depth, 8k`

### **Periguete**

**№ 678 / 1001** · *Periphery Refuses a Low Volume*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Volume recusando o modo discreto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Periguete: lycra neon, brilho e salto plataforma no baile — a autoconfiança da periferia brasileira em modo máximo.

**Paleta de cores** rosa neon, dourado, animal print

**Melhores usos:** moda brasileira, editorial, cultura pop

**MidJourney:** `[tema], periguete aesthetic, neon lycra platform heels at the baile, volume refusing quiet --v 6`

**Prompt universal (Seedream):** `Shot on a compact Samsung point-and-shoot with hard flash, a periguete night portrait at a baile, neon pink lycra and gold hoops with animal-print platform heels, Brazilian periphery self-confidence set to maximum volume, sweat and glitter under raw flash, unapologetic energy, 8k upscale`

### **Pin-up**

**№ 686 / 1001** · *Femininity Became Weaponized Art*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↑

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Feminilidade encenada com piscadela** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pin-up: pose de calendário de 1950, lábio vermelho perfeito e o charme calculado ao milímetro.

**Paleta de cores** vermelho de batom, azul de calendário, creme de pele

**Melhores usos:** ilustração, retrô, editorial

**MidJourney:** `[tema], pin-up aesthetic, 1950s calendar pose perfect red lips, charm calculated to the millimeter --v 6`

**Prompt universal (Seedream):** `Ultra-polished pin-up illustration in the Gil Elvgren style, a 1950s calendar pose with perfect red lips and a knowing wink, airbrushed cream skin against calendar blue, playful charm calculated to the millimeter with painted gloss highlights, vintage advertising finish, 8k`

### **Playful**

**№ 693 / 1001** · *Rule Bent Until It Smiles*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A regra dobrada até sorrir** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Brincalhão: confete, formas saltitantes e cores primárias em recreio permanente.

**Paleta de cores** primárias de recreio, confete, branco de quadra

**Melhores usos:** branding, campanhas, produto

**MidJourney:** `[tema], playful aesthetic, confetti bouncing shapes, the rule bent until it smiles --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-T30 with 35mm lens, a playful composition, confetti mid-air over bouncing primary shapes on a clean court-white ground, red yellow and blue at permanent recess, every rule bent exactly until it smiles, bright crisp joy, 8k`

### **Polychrome**

**№ 694 / 1001** · *Color Refuses a Single Authority*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SYNERGY ↑

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A cor recusando autoridade única** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Policromia: a estátua grega como era de verdade — pintada, viva e muito menos branca que o mito.

**Paleta de cores** azul egípcio, vermelho cinábrio, ocre e ouro

**Melhores usos:** histórico, arte, editorial

**MidJourney:** `[tema], polychrome aesthetic, ancient sculpture in original painted color, whiteness demythologized --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a reconstructed polychrome Greek sculpture, original pigments restored in Egyptian blue cinnabar red and gilded ochre, color refusing the single authority of white marble myth, patterned garments and lifelike painted eyes, archaeological accuracy in studio light, 8k`

### **Post-Impressionism**

**№ 704 / 1001** · *Painting Starts Thinking in Public*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → MATTER ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** A última exposição impressionista, de 1886, marcou o corte: os planos construtivos de Cézanne, o cromatismo emocional de Van Gogh e a planura simbólica de Gauguin recusaram explicitamente o compromisso impressionista com a sensação óptica transitória, tornando inerte aquela gramática-mãe como sistema gerador.

**Atmosfera e mood**

**A pintura pensando em público** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pós-impressionismo: pinceladas construtivas, cor emocional e a estrutura visível do pensamento do pintor.

**Paleta de cores** amarelo de trigo, azul de noite estrelada, verde construído

**Melhores usos:** arte, paisagens, editorial

**MidJourney:** `[tema], post-impressionism aesthetic, constructive brushstrokes emotional color, thought made visible --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a post-impressionist painting, a landscape built from Cézanne constructive strokes and Van Gogh impasto ribbons, wheat yellow and starry-night blue as emotional argument, the painter's thinking left visible in every mark, 8k archival texture`

### **Post-Punk Futurism**

**№ 709 / 1001** · *Rebellion Evolved Into Tomorrow*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A síntese do Cabaret Voltaire entre confronto punk e composição com sintetizadores, somada à visão de mundo do Neuromancer de Gibson, produziu uma forma que nenhuma das três correntes-mãe renderia — o método DIY, a textura eletrônica e o argumento inclinado ao futuro soldados numa postura que inverteu a negação punk em construção.

**Atmosfera e mood**

**A rebelião industrial evolui para o amanhã** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Futurismo pós-punk: sintetizadores em galpões de Sheffield, cinza metálico e a frieza como manifesto de 1980.

**Paleta de cores** cinza industrial, preto de couro, azul de néon frio

**Melhores usos:** música, editorial, conceito

**MidJourney:** `[tema], post-punk futurism aesthetic, Sheffield 1980 synth warehouse, industrial rebellion becoming tomorrow --v 6`

**Prompt universal (Seedream):** `16mm Bolex freeze-frame, a post-punk futurist scene in a 1980 Sheffield warehouse, angular figures at analog synthesizers under one cold industrial lamp, leather black and metallic gray with a thin cold neon blue, rebellion evolving into tomorrow with Joy Division austerity, grainy cine texture, 8k scan`

### **Princesscore**

**№ 721 / 1001** · *Disney Royalty Becomes Daily Dress*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A espinha soberana do Royalcore, o preenchimento ornamental do Rococó e a inocência vitoriana foram recombinados pela consolidação da marca Disney Princess (2000) numa gramática que nenhum pai isolado detinha — soberania performada por compra, não por nascimento; um código que nenhuma das três fontes produziria sozinha.

**Atmosfera e mood**

**Coroa de tule no dia comum** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Princesscore: saias em camadas, tiaras e a convicção de que a realeza é um estado de espírito diário.

**Paleta de cores** rosa de tule, lilás, dourado de tiara

**Melhores usos:** moda, editorial, lifestyle

**MidJourney:** `[tema], princesscore aesthetic, layered tulle daily tiara, royalty as a daily state of mind --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-S20 with 56mm lens, a princesscore portrait, layered tulle skirt and a small tiara worn to an entirely ordinary day, blush pink and lilac with tiara gold in soft courtyard light, royalty practiced as a daily state of mind, dreamy shallow focus, 8k`

### **Protest**

**№ 726 / 1001** · *Placard That Refuses Decoration*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → ESTHETICS ↓

**Polaridade:** XX — continuidade por transmissão

**Nota:** A intervenção efêmera — imagens, textos, sons e corpos reunidos em público para produzir mudança política — está documentada ao longo de séculos que precedem todo suposto ancestral; a gramática que outras estéticas herdam é transmitida adiante intacta, com a recusa da beleza repetida como a primeira coisa gasta em nome da velocidade.

**Atmosfera e mood**

**Recusa escrita em letras simples** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Protesto: cartaz sem enfeite, mãos erguidas e a força da frase dita uma vez só.

**Paleta de cores** preto de tinta, branco de cartolina, vermelho pontual

**Melhores usos:** documental, editorial, conceito

**MidJourney:** `[tema], protest aesthetic, plain hand-lettered placard raised hands, refusal in simple letters --v 6`

**Prompt universal (Seedream):** `Shot on Leica M8 with 28mm lens, a protest scene, one undecorated hand-lettered placard held above a determined crowd, ink black on cardboard white with a single red word, refusal stated once in plain letters, documentary urgency and honest grain, 8k`

### **Provocative**

**№ 730 / 1001** · *Subtlety Fails the Entrance Exam*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O terror-como-prazer do Sublime romântico, a liberdade sem dívida moral da Decadência e a galeria-como-emboscada da vanguarda eram posições completas; recombinadas aqui, produzem a única estética em que violar uma proibição viva é ao mesmo tempo a lei organizadora, o critério de admissão e a única métrica de desempenho — fusão que nenhum dos três pais geraria sozinho.

**Atmosfera e mood**

**A sutileza reprovada no vestibular** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Provocativo: flash duro, cromo e atitude — a imagem construída para começar uma conversa difícil.

**Paleta de cores** preto de couro, cromo, vermelho de confronto

**Melhores usos:** moda, editorial, capas

**MidJourney:** `[tema], provocative aesthetic, hard flash on chrome and leather, image built to start an argument --v 6`

**Prompt universal (Seedream):** `Shot on 35mm with hard direct flash, a provocative fashion portrait, leather and chrome under Helmut Newton confrontation lighting, confrontation red against deep black, a gaze that failed subtlety's entrance exam on purpose, glossy high-contrast print, 8k`

### **Punk**

**№ 733 / 1001** · *Safety Pin Becomes a Thesis*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O corpo glam dos New York Dolls, o détournement situacionista e a jaqueta de couro Teddy Boy eram posições completas; recombinadas aqui, produzem a única estética em que um alfinete atravessado na lapela sinaliza ao mesmo tempo pobreza como estilo, recusa como estrutura e prova de pertencimento subcultural — gramática que nenhum dos três pais geraria sozinho.

**Atmosfera e mood**

**A tese do alfinete de segurança, 1977** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Punk: couro rasgado, cuspe e três acordes contra tudo — a recusa fotografada sem retoque.

**Paleta de cores** preto rasgado, xadrez, vermelho de raiva

**Melhores usos:** música, moda, editorial

**MidJourney:** `[tema], punk 1977 aesthetic, torn leather safety pins, three chords against everything --v 6`

**Prompt universal (Seedream):** `Shot on Canon F-1 with 24mm lens in a 1977 club crush, a punk frame, torn leather and safety pins under bare stage bulbs, spit and sweat mid-pogo with Ray Stevenson Roxy rawness, ripped black and tartan against rage red, unretouched high-grain refusal, 8k scan`

### **Raxet**

**№ 744 / 1001** · *Street Style Reading as Social Commentary*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A gramática territorial do hip-hop do South Bronx, a economia do logo-como-moeda do streetwear californiano e o motor de inversão de estereótipos do trap espanhol eram sistemas completos; recombinados aqui, produzem a única estética em que um monograma de luxo com erro de grafia funciona ao mesmo tempo como paródia, reivindicação e soberania — síntese que nenhum dos três pais alcançaria sozinho.

**Atmosfera e mood**

**Glamour de barraca de feira com orgulho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Raxet: brilho barato usado caro, unha decorada e a estética popular méxicana-latina celebrada sem ironia.

**Paleta de cores** rosa choque, dourado de bijuteria, animal print

**Melhores usos:** moda popular, editorial, cultura

**MidJourney:** `[tema], raxet aesthetic, market-stall glamour rhinestones decorated nails, cheap shine worn expensive --v 6`

**Prompt universal (Seedream):** `Shot on expired 35mm film with direct flash, a raxet portrait, rhinestone-studded market-stall glamour with decorated acrylic nails and gold-tone hoops, shock pink and animal print worn with full pride and zero irony, hard flash bounce on glossy surfaces, vivid popular-culture energy, 8k scan`

### **Recession Pop**

**№ 747 / 1001** · *Austerity Learns to Sparkle*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → MATTER ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O otimismo plástico do Y2K, a colagem em foco suave do Tumblr e o espetáculo de strass dos club kids são recombinados pelo filtro da escassez, produzindo a única estética em que o glamour é explicitamente uma habilidade, não um orçamento — e o barato é a pré-condição do brilho.

**Atmosfera e mood**

**Dançando enquanto a conta não chega** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Recession pop: festa de 2009 em apartamento apertado, lantejoula barata e hino de pista contra a crise.

**Paleta de cores** lantejoula prata, rosa de gloss, flash estourado

**Melhores usos:** música, nostalgia, editorial

**MidJourney:** `[tema], recession pop 2009 aesthetic, sequins house party digicam flash, dancing through the crisis --v 6`

**Prompt universal (Seedream):** `Shot on a 2009 party digicam with blown-out flash, a recession pop scene, cheap silver sequins and lip gloss in a crowded apartment party, red cups raised to a floor-filler anthem against the crisis outside, overexposed skin and datestamp energy, joyful low-fi sparkle, 8k upscale`

### **Riot Grrrl**

**№ 760 / 1001** · *Three Chords, a Zine, and No Permission*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** A forma xerocada faça-você-mesmo do punk chega intacta, e o Riot Grrrl a reinstrumenta roteando o método de produção herdado pelo testemunho feminista — o zine de recortes que antes anunciava a raiva de uma banda vira o sistema de entrega de feridas privadas de meninas transformadas em argumentos públicos.

**Atmosfera e mood**

**Feminismo fotocopiado no volume máximo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Riot grrrl: zines xerocadas de 1992, letra de caneta rabiscada e a raiva organizada em recorte e cola.

**Paleta de cores** preto de xerox, rosa de marcador, papel pautado

**Melhores usos:** música, editorial, design

**MidJourney:** `[tema], riot grrrl 1992 zine aesthetic, xerox collage scrawled marker, feminism photocopied at full volume --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a 1992 riot grrrl zine spread, xerox collage of cut-out letters band photos and scrawled marker slogans in the Kathleen Hanna orbit, photocopy black with one furious pink accent on ruled paper, feminism cut pasted and cranked to full volume, 8k`

### **Rock 'n' Roll**

**№ 765 / 1001** · *Music's Rebel Yell*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** Não há estética anterior a herdar; a fusão de vestuário operário, acabamento automotivo e volume amplificado de palco num só código legível re-irrompe de forma independente onde quer que a autoridade seja contestada pelo volume — rockabilly, Teddy Boys britânicos, revista de soul e bandas de garagem reconstroem do zero a mesma gramática irredutível; a jaqueta de couro e o backbeat são o dispositivo que nenhum movimento anterior legou.

**Atmosfera e mood**

**O grito rebelde da música** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rock 'n' roll: guitarra erguida, suor no contra-luz e o palco como único lugar sem regras.

**Paleta de cores** preto de palco, branco de contra-luz, vermelho de amplificador

**Melhores usos:** música, editorial, capas

**MidJourney:** `[tema], rock and roll aesthetic, guitar raised in backlight sweat and smoke, music's rebel yell --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Tri-X pushed to 1600 with 85mm lens, a rock 'n' roll frame, a guitar raised into smoky backlight with sweat flying mid-yell, amplifier red glowing at the stage edge, the last place without rules caught at full volume, explosive concert grain, 8k scan`

### **Romantic Italian**

**№ 770 / 1001** · *Poetry in Architecture*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → ETERNITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** A gramática do anseio e do sentimento sublime do Romantismo europeu chega intacta, e o dialeto italiano a reinstrumenta roteando esse sentimento por uma única disciplina herdada que nenhuma outra vertente romântica possuía — a proporção harmônica renascentista carregada no mármore — de modo que a paixão nunca se derrama, mas é abrigada, sempre respondida por uma coluna.

**Atmosfera e mood**

**Poesia escrita em arquitetura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Romântico italiano: varandas com glicínias, pedra dourada da Toscana e o entardecer que transforma ruído em serenata.

**Paleta de cores** pedra toscana, glicínia, dourado de entardecer

**Melhores usos:** viagem, casamentos, editorial

**MidJourney:** `[tema], romantic italian aesthetic, wisteria balcony Tuscan golden stone, poetry in architecture --v 6`

**Prompt universal (Seedream):** `Shot on Contax 645 with 80mm lens, a romantic Italian scene, wisteria spilling over a Tuscan balcony of golden stone as evening turns the piazza's noise into serenade, lavender blooms against honeyed walls in raking sunset light, poetry written directly in architecture, 8k`

### **Romanticism**

**№ 772 / 1001** · *Feeling's Triumph*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por ruptura

**Nota:** Não há estética anterior a herdar; a doutrina do círculo de Jena (1798) do sentimento sobre a razão formou-se apenas contra o racionalismo iluminista a recusar, não contra uma gramática a estender — a precedência da imaginação não se decompõe em ancestral identificável, e os movimentos posteriores tomam sua licença deste, não o contrário.

**Atmosfera e mood**

**O triunfo do sentimento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Romantismo: o caminhante sobre o mar de névoa, tempestades sublimes e a emoção coroada acima da razão.

**Paleta de cores** névoa azulada, rocha escura, dourado de tempestade

**Melhores usos:** arte, paisagens, capas

**MidJourney:** `[tema], romanticism aesthetic, wanderer above the sea of fog sublime storm, feeling's triumph --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Romantic painting, a lone figure on a dark crag above a churning sea of fog, Caspar David Friedrich sublime scale with storm gold breaking through blued mist, emotion crowned above reason in every brushstroke, 8k archival scan`

### **Russian Vanguard**

**№ 777 / 1001** · *Red Geometry Built for Revolution*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O plano fraturado multi-vista do Cubismo e o culto futurista da velocidade e da diagonal são recombinados sobre um chão russo já quebrado, e nenhum sobrevive sozinho — a fratura sem velocidade é Cubismo parado, a velocidade sem fratura é Futurismo sem nada a quebrar — a cunha e a diagonal fundem duas gramáticas doadoras num sistema de signos que nenhum pai alcançaria sozinho.

**Atmosfera e mood**

**Geometria vermelha construída para a revolução** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vanguarda russa: cunhas vermelhas, diagonais construtivistas e tipografia que marcha — a arte alistada em 1920.

**Paleta de cores** vermelho de cunha, preto de diagonal, papel cru

**Melhores usos:** design, histórico, capas

**MidJourney:** `[tema], russian avant-garde aesthetic, red wedge constructivist diagonals marching typography, art enlisted for revolution --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a Russian avant-garde lithograph, a red wedge driving through black circles on raw paper in the El Lissitzky manner, constructivist diagonals and stenciled typography marching in formation, geometry built and enlisted for revolution circa 1920, crisp print texture, 8k`

### **Samba**

**№ 781 / 1001** · *Brazil's Rhythmic Soul*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SYNERGY ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** O batuque de roda, a música de espírito do calundu e o carnaval de rua português são ritual bruto e prática popular, nunca uma estética anterior — a cristalização do Samba num sistema visual-sonoro autoconsciente não se decompõe em ancestral rearticulado ou revisado; é a raiz à qual a polirritmia e a gramática do figurino respondem, e manguebeat, funk carioca e samba-reggae tiram hoje sua licença dessa ruptura, não o contrário.

**Atmosfera e mood**

**A alma rítmica do Brasil** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Samba: plumas em movimento, surdo marcando o chão e a avenida inteira girando em sincronia dourada.

**Paleta de cores** verde e ouro, plumas vibrantes, luz de avenida

**Melhores usos:** cultura brasileira, música, editorial

**MidJourney:** `[tema], samba aesthetic, feathers mid-spin surdo drums carnival avenue, Brazil's rhythmic soul --v 6`

**Prompt universal (Seedream):** `Shot on Canon AE-1 with 50mm lens, a samba moment on the sambadrome avenue, feathers frozen mid-spin as surdo drums shake the ground, green and gold costume blazing under stadium light with motion blur only at the edges, Brazil's rhythmic soul at full turn, vivid festive grain, 8k`

### **Sapeur (La Sape)**

**№ 782 / 1001** · *Dressing for Dignity*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** O terno de três peças do dandismo europeu e o culto da superfície impecável chegam como pai único, e a Sape reinstrumenta essa gramática tomando o terno colonial de segunda mão e invertendo a contenção em exibição competitiva saturada — nenhuma segunda linhagem entra, só uma herança invertida — e a libré feita para marcar servidão vira, uma geração depois, reivindicação de igualdade.

**Atmosfera e mood**

**Vestir-se como ato de dignidade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sapeur: ternos impecáveis em cores corajosas nas ruas de Brazzaville — elegância como resistência e autoestima.

**Paleta de cores** rosa de terno, verde esmeralda, amarelo de lenço

**Melhores usos:** moda, cultura, editorial

**MidJourney:** `[tema], sapeur la sape aesthetic, immaculate bold-colored suit in Brazzaville, dressing for dignity --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex 3.5F, a sapeur portrait in Brazzaville, an immaculate emerald three-piece suit with a pink pocket square worn against dusty ochre streets, Daniele Tamagni documentary warmth, elegance carried as dignity and quiet resistance, proud upright framing, 8k`

### **Scene**

**№ 785 / 1001** · *Broadcast Yourself in Neon*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A gramática confessional do emo de terceira onda e o maximalismo neon criado na rave são soldados num perfil do MySpace, e nenhum sobrevive sozinho — tire o neon e colapsa em emo puro, tire o emo e não resta esqueleto — o espelho do quarto e a tela acesa fundem dois códigos já derivados num eu-transmissão que nenhum pai construiria sozinho.

**Atmosfera e mood**

**Transmita-se em neon** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Scene: franja chapada colorida, camadas de pulseiras e a autoimagem de 2007 editada para o perfil do MySpace.

**Paleta de cores** preto de franja, rosa choque, verde-limão de mecha

**Melhores usos:** nostalgia, moda jovem, editorial

**MidJourney:** `[tema], scene 2007 aesthetic, flat-ironed neon-streaked fringe bracelet stacks, MySpace self-broadcast --v 6`

**Prompt universal (Seedream):** `Shot on a 2007 pocket digicam at arm's length with hard flash, a scene-kid self-portrait for a MySpace profile, flat-ironed black fringe streaked lime and shock pink over raccoon eyeliner, bracelet stacks to the elbow, high-angle broadcast confidence, crunchy compressed flash color, 8k upscale`

### **Secessionism**

**№ 792 / 1001** · *Art With a Cause*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** O cipó em chicote e o campo orgânico achatado do Art Nouveau chegam como pai único, e o Secessionismo reinstrumenta esse vocabulário rumo a uma diretriz que o pai nunca exigiu — a retirada formal dos artistas de uma instituição — de modo que uma gramática decorativa de fronteiras dissolvidas vira, uma geração depois, declaração de soberania institucional.

**Atmosfera e mood**

**Arte com uma causa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Secessionismo: Viena 1898, folhas douradas e geometria orgânica — os artistas rompendo com a academia em manifesto visual.

**Paleta de cores** ouro de Klimt, branco de salão, verde de louro

**Melhores usos:** arte, design, editorial

**MidJourney:** `[tema], Vienna Secession aesthetic, gilded laurel organic geometry 1898, art with a cause --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Vienna Secession poster, gilded laurel leaves and organic geometry framing austere lettering in the Klimt and Olbrich orbit of 1898, Secession gold on salon white with laurel green, to every age its art and to art its freedom, 8k archival scan`

### **Sensational**

**№ 795 / 1001** · *More Is More*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota:** O horror vacui do Maximalismo e sua recusa do espaço vazio chegam como pai único, e o Sensational reinstrumenta essa herança com uma única diretriz adicional — acúmulo calibrado para prender o olhar — de modo que uma filosofia de superfícies preenchidas vira, uma geração depois, uma disciplina de superfícies competindo para serem vistas primeiro.

**Atmosfera e mood**

**Mais é mais, sempre** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sensacional: cor no talo, brilho sobre brilho e a composição que recusa qualquer dieta visual.

**Paleta de cores** fúcsia, dourado espelhado, azul kélvin alto

**Melhores usos:** campanhas, moda, capas

**MidJourney:** `[tema], sensational aesthetic, maximum color gloss on gloss, more is more always --v 6`

**Prompt universal (Seedream):** `Shot on Sony A1 with 24mm lens, a sensational editorial tableau, fuchsia satin against mirrored gold with confetti and high-kelvin blue gels firing at once, gloss stacked on gloss in deliberate excess, a composition that refuses every visual diet, maximal razor-sharp spectacle, 8k`

### **Shoe Diva**

**№ 805 / 1001** · *Confidence measured in heel height*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** A cultura de luxo da alta-costura, codificada por Charles Frederick Worth, chega como pai único, e a Shoe Diva a reinstrumenta promovendo um acessório de pontuação a protagonista — o sapato lido como frase, não como vírgula — de modo que toda uma gramática do glamour feminino vira uma disciplina organizada em torno de um único objeto laqueado.

**Atmosfera e mood**

**Confiança medida em altura de salto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Shoe diva: saltos como troféus em estante iluminada, sola vermelha e o sapato tratado como declaração de poder.

**Paleta de cores** vermelho de sola, preto de verniz, dourado de salto

**Melhores usos:** moda, produto, editorial

**MidJourney:** `[tema], shoe diva aesthetic, heels displayed like trophies red soles, confidence measured in heel height --v 6`

**Prompt universal (Seedream):** `Shot on Leica S3 with 100mm lens, a shoe diva still life, patent stilettos arranged like trophies on a lit shelf with one red sole turned outward, lacquer black and gold hardware under boutique spotlights, confidence measured openly in heel height, luxurious product sharpness, 8k`

### **Spanish Golden Age**

**№ 837 / 1001** · *Imperial Catholic Majesty Stages Divine Drama*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → ETERNITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A gramática devocional de fundo dourado da Ibéria tardo-medieval, a modelagem e a técnica a óleo do Renascimento italiano e o protocolo da corte borgonhesa são soldados numa forma só, sem que nenhum ancestral sobreviva intacto — três linhagens fundidas num teatro de ouro à luz de velas que nenhuma das três produziria sozinha.

**Atmosfera e mood**

**Majestade católica imperial encenando o drama divino** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Siglo de Oro: tenebrismo espanhol, golas de renda contra o breu e a corte de Madri pintada entre fé e império.

**Paleta de cores** preto de corte, dourado de retábulo, carmim de manto

**Melhores usos:** arte, histórico, editorial

**MidJourney:** `[tema], spanish golden age aesthetic, tenebrist light lace ruff against darkness, imperial catholic majesty --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Spanish Golden Age painting, a court figure in black with a white lace ruff emerging from tenebrist darkness in the Velázquez and Zurbarán manner, altar gold and carmine cutting the gloom, faith and empire staged as divine drama, 8k archival scan`

### **Stilyagi**

**№ 851 / 1001** · *Soviet Youth Defies Conformity Through Jazz*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O glamour de Hollywood, a cultura de jazz americana e a alfaiataria Teddy Boy britânica são soldados num único guarda-roupa soviético sem que nenhum ancestral sobreviva intacto — retire qualquer um e o todo colapsa — imagem, som e corte fundidos numa subcultura que nenhuma das três linhagens produziria sozinha.

**Atmosfera e mood**

**A juventude soviética desafiando a conformidade pelo jazz** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Stilyagi: Moscou 1955, paletós largos em cores proibidas, topetes engomados e discos de jazz gravados em chapas de raio-X.

**Paleta de cores** laranja proibido, verde de paletó, cinza soviético ao fundo

**Melhores usos:** histórico, moda, editorial

**MidJourney:** `[tema], stilyagi aesthetic, Moscow 1955 loud suits pompadours jazz on x-ray records, defying conformity --v 6`

**Prompt universal (Seedream):** `Shot on Zorki 4 with 50mm lens, a stilyagi evening in 1955 Moscow, a wide-shouldered suit in forbidden orange and a lacquered pompadour spinning jazz pressed on an X-ray record, banned color blazing against Soviet street gray, conformity defied one dance step at a time, defiant period grain, 8k scan`

### **Stuckism**

**№ 857 / 1001** · *Anti-Conceptual Rebellion Champions Authentic Art*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → INTEGRITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A pincelada expressionista, a figuração pós-impressionista e a cultura de manifesto-protesto são soldadas numa prática só — o traço carregado, o rosto reconhecível, o cartaz de piquete — sem que nenhum ancestral sobreviva intacto; três linhagens fundidas numa postura que nenhum dos três pais produziria sozinho.

**Atmosfera e mood**

**A rebelião anticonceitual defendendo a pintura autêntica** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Stuckismo: figuração teimosa em tinta grossa, ateliê doméstico e o manifesto de que arte que não é pintura é só ideia emoldurada.

**Paleta de cores** tinta crua, vermelho de manifesto, madeira de cavalete

**Melhores usos:** arte, conceito, editorial

**MidJourney:** `[tema], stuckism aesthetic, defiantly figurative thick paint home studio, anti-conceptual rebellion --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Stuckist painting, a defiantly figurative domestic scene in thick unfashionable impasto from a bedroom studio, raw color and manifesto red refusing every conceptual gallery trend, authenticity argued brushstroke by brushstroke against the framed idea, 8k scan`

### **Swenkas**

**№ 880 / 1001** · *Sunday-best swagger as competitive sport*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** O dandismo clássico fornece o único pai, e os Swenkas reinstrumentam essa herança pela exibição do trabalhador migrante zulu, convertendo o terno alfaiatado em instrumento de dignidade sob o apartheid.

**Atmosfera e mood**

**A elegância de domingo como esporte competitivo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Swenkas: trabalhadores zulus em ternos imaculados competindo em desfile de domingo — o swanking como orgulho, apuro e comunidade em Joanesburgo.

**Paleta de cores** vinho de terno, branco de camisa engomada, dourado de salão

**Melhores usos:** cultura, moda, documental respeitoso

**MidJourney:** `[tema], swenkas aesthetic, zulu workers in immaculate suits sunday swanking contest, dignity as competitive sport --v 6`

**Prompt universal (Seedream):** `Shot on Rolleicord Va, a swenkas contest on a Johannesburg Sunday night, a Zulu worker turning slowly in an immaculate wine-red suit as judges study the crease and the shoes, starched white and hall gold under bare bulbs, Sunday-best swagger practiced as sport pride and community, dignified documentary warmth, 8k`

### **Tachisme**

**№ 890 / 1001** · *Instinct Takes the Brush Before Theory*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota:** O Art Informel fornece o único pai, e o Tachisme reinstrumenta essa herança estreitando seu compromisso com a matière sem forma até restar apenas a mancha gestual.

**Atmosfera e mood**

**O instinto tomando o pincel antes da teoria** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tachismo: manchas e gestos caíndo na tela na velocidade do impulso — Georges Mathieu pintando mais rápido que o pensamento.

**Paleta de cores** preto de gesto, vermelho de impulso, cru de tela

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], tachisme aesthetic, stains and gestures at the speed of impulse, instinct before theory --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a tachiste painting, calligraphic slashes and flung stains landing at the speed of impulse in the Georges Mathieu manner, gesture black and impulse red across raw canvas, the brush arriving whole seconds before theory can object, vivid gestural energy, 8k scan`

### **Tacky**

**№ 891 / 1001** · *Good Taste Dies Under the Seventh Sequin*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XX — continuidade por revisão

**Nota:** Kitsch e Camp se resolvem num único movimento — a inversão deliberada de uma hierarquia de gosto — em vez de se fundirem numa terceira gramática, o que mantém o Tacky como reinterpretação de pai único, não híbrido de múltiplas linhagens.

**Atmosfera e mood**

**O bom gosto morrendo sob a sétima lantejoula** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tacky: onça com dourado, lantejoula com pelúcia e a certeza radiante de que discrição é covardia — o excesso celebrado sem ironia.

**Paleta de cores** dourado brilhoso, rosa choque, estampa de onça

**Melhores usos:** sátira, editorial, campanhas

**MidJourney:** `[tema], tacky aesthetic, leopard print gold sequins on plush, good taste dying under the seventh sequin --v 6`

**Prompt universal (Seedream):** `Shot on a disposable camera with hard flash, a gloriously tacky tableau, leopard print layered over gold lamé with sequins glued to plush and one rhinestone chihuahua collar, shock pink fighting shiny gold for the last inch of frame, good taste formally deceased under the seventh sequin, joyful flash-blasted excess, 8k scan`

### **Theatricality**

**№ 898 / 1001** · *Life Enters One Beat Ahead of Reality*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** A tradição teatral grega antiga fornece o único pai, e a Theatricality reinstrumenta essa herança amplificando o lugar-de-ver e o corpo mascarado numa gramática total da vida encenada.

**Atmosfera e mood**

**A vida entrando um compasso antes da realidade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Teatralidade: o gesto amplo sob o spot, a capa girando na entrada e cada frase entregue para a última fileira.

**Paleta de cores** vermelho de cortina, dourado de spot, negro de coxia

**Melhores usos:** artes cênicas, editorial, capas

**MidJourney:** `[tema], theatricality aesthetic, sweeping gesture under the spotlight cape turning at the entrance, delivered to the last row --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R1 with 85mm lens, a theatrical entrance, a caped figure mid-turn under a single golden spotlight as curtain red swallows the wings behind, the gesture sized for the last row of the balcony, life arriving one beat ahead of reality, dramatic stage-lit grandeur, 8k`

### **Tudor Henrician (1509–1547)**

**№ 913 / 1001** · *Doublet Makes the Monarch Larger*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** A exigência de magnificência visível é princípio fundacional e irredutível, que precede e organiza a corte inteira em vez de descender de qualquer pai único — assinatura de nó fundacional, não de reinterpretação.

**Atmosfera e mood**

**O gibão que faz o monarca maior** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Henriciano: ombros armados em veludo e pele, a pose frontal de Holbein e a silhueta desenhada para ocupar o trono e a moldura inteira.

**Paleta de cores** veludo negro, dourado de corrente, castanho de zibelina

**Melhores usos:** histórico, retratos, editorial

**MidJourney:** `[tema], henrician tudor aesthetic, padded doublet velvet and fur Holbein frontal pose, the silhouette that fills the throne --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Henrician court portrait in the Hans Holbein manner, a monarch squared frontally in a padded doublet of black velvet and sable with gold chains crossing the chest, the silhouette engineered to fill the throne and the frame alike, imposing painted authority, 8k scan`

### **Ukrainian New Wave**

**№ 921 / 1001** · *Resonant Echo of Freedom*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SAGA ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A vanguarda ucraniana dos anos 1920 e o cinema poético dos anos 1960 convergem aqui, cada um fornecendo uma camada estrutural que nada substitui — híbrido de múltiplas linhagens, não revisão de pai único.

**Atmosfera e mood**

**O eco ressonante da liberdade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nova onda ucraniana: bordado tradicional sobre streetwear, girassóis contra céu de tempestade e a identidade cultural amplificada em resistência.

**Paleta de cores** amarelo de girassol, azul profundo, branco de vyshyvanka

**Melhores usos:** cultura, editorial, arte

**MidJourney:** `[tema], ukrainian new wave aesthetic, vyshyvanka embroidery over streetwear sunflowers against storm sky, freedom's resonant echo --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R V with 35mm lens, a Ukrainian new wave portrait, traditional vyshyvanka embroidery worn over contemporary streetwear in a sunflower field under a storm-blue sky, sunflower yellow blazing against deep blue, cultural identity amplified into a resonant echo of freedom, defiant luminous clarity, 8k`

### **Ultra-Pop**

**№ 923 / 1001** · *Commercial Culture at Maximum Chroma*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Pop Art, prática digital pós-internet e cultura de streetwear de consumo convergem aqui, cada uma fornecendo uma camada estrutural que nada substitui — fixando o Ultra-Pop como híbrido de múltiplas linhagens, não revisão de pai único.

**Atmosfera e mood**

**A cultura comercial em croma máximo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ultra-pop: o produto herói em saturação de 110%, mascotes gritando de todas as superfícies e a vitrine calibrada para vencer o feed.

**Paleta de cores** magenta máximo, amarelo de estouro, ciano de vitrine

**Melhores usos:** branding, campanhas, arte digital

**MidJourney:** `[tema], ultra-pop aesthetic, hero product at 110 percent saturation screaming mascots, commercial culture at maximum chroma --v 6`

**Prompt universal (Seedream):** `Ultra-vivid commercial artwork, an ultra-pop explosion, a hero product levitating at 110 percent saturation while grinning mascots and starburst price tags detonate around it, maximum magenta and blowout yellow against showcase cyan, commercial culture cranked past the feed's pain threshold, dazzling chromatic overload, 8k`

### **Venture**

**№ 944 / 1001** · *Exploration Wearing a Pitch Deck*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → NARRATIVE ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** Reinterpreta sozinho a transparência de planta livre modernista, trocando a permanência da corporação pela impermanência encenada, sem fundir um segundo pai estrutural.

**Atmosfera e mood**

**A exploração vestindo pitch deck** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Venture: o quadro branco lotado até a borda, a demo rodando às três da manhã e o mapa do mundo redesenhado em dez slides.

**Paleta de cores** branco de whiteboard, azul de slide, laranja de post-it

**Melhores usos:** startups, editorial, branding

**MidJourney:** `[tema], venture aesthetic, whiteboard full to the edge 3am demo, the world redrawn in ten slides --v 6`

**Prompt universal (Seedream):** `Shot on Leica SL3 with 35mm lens, a venture night, founders circling a whiteboard filled to its edges while a demo glows on the laptop at three a.m., slide blue and post-it orange against loft glass and dark city, exploration dressed in a pitch deck and running on conviction, charged ambitious focus, 8k`

### **Visual Kei**

**№ 955 / 1001** · *Gender Challenged at Stage Volume*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** Glam rock, rock gótico e punk são importações contextuais, não pais constitutivos — remova qualquer um e o núcleo goth-punk ou glam-punk segue significando — e a gramática fundida gera a própria linhagem de Oshare Kei, Gothic Kei e Neo Visual Kei.

**Atmosfera e mood**

**O gênero desafiado em volume de palco** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Visual kei: cabelo esculpido contra a gravidade, maquiagem dramática sobre couro e renda — a androginia japonesa amplificada até a última fileira.

**Paleta de cores** preto de couro, prata de palco, vermelho de batom dramático

**Melhores usos:** música, moda, editorial

**MidJourney:** `[tema], visual kei aesthetic, gravity-defying sculpted hair dramatic makeup over leather and lace, androgyny at stage volume --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7S III with 85mm lens, a visual kei performance, a guitarist with gravity-defying sculpted hair and dramatic painted eyes in layered leather and lace caught mid-note in the strobes, stage silver and lipstick red slashing through black, gender challenged at full amplifier volume, theatrical electric intensity, 8k`

### **Voguing**

**№ 958 / 1001** · *Ballroom Houses Walk the Floor as Cathedral*

**Nível:** 🟣 Secondary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XX — continuidade por revisão

**Nota:** Descende de um único ancestral — o pageantry dos drag balls do Harlem — e reinterpreta sua pose estática num concurso categorizado e em movimento, sem fundir uma segunda linhagem estrutural.

**Atmosfera e mood**

**As houses do ballroom pisando a quadra como catedral** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Voguing: linhas de braço cortando o ar, o dip no último beat e as houses do Harlem transformando a passarela em rito — glória conquistada por categoria.

**Paleta de cores** dourado de troféu, preto de passarela, flash de ballroom

**Melhores usos:** cultura, dança, editorial respeitoso

**MidJourney:** `[tema], voguing aesthetic, arm lines cutting air dip on the last beat harlem houses, the floor walked as cathedral --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q2 with 28mm lens and on-camera flash, a ballroom voguing moment, a performer hitting a razor-lined dip on the final beat as the house cheers the runway's edge, trophy gold and runway black seared by flash in the Paris is Burning lineage, the floor walked as cathedral and category as liturgy, electric reverent celebration, 8k`

### **Wacky Pomo**

**№ 963 / 1001** · *Childhood Fever Dream as Retail Strategy*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EDITING ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Funde o antifuncionalismo do Radical Design italiano, a apropriação da Pop Art e a citação irônica do Pós-modernismo numa só gramática em que as três linhagens permanecem estruturais ao mesmo tempo — além do limiar de pai único de um Secondary.

**Atmosfera e mood**

**O sonho febril infantil como estratégia de varejo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Wacky pomo: squiggles roxos no carpete, colunas tortas de mentira e o food court de 1992 desenhado por um pierô em açúcar — o pós-moderno vendendo diversão.

**Paleta de cores** roxo de squiggle, verde-água de fico, amarelo de confete

**Melhores usos:** nostalgia, interiores, conceito

**MidJourney:** `[tema], wacky pomo aesthetic, purple carpet squiggles fake leaning columns 1992 food court, childhood fever dream as retail --v 6`

**Prompt universal (Seedream):** `Ultra-vivid interior photograph, a wacky pomo food court from 1992, purple squiggle carpet under deliberately leaning pastel columns and confetti-pattern laminate booths, teal and squiggle purple shouting over neon menu boards, the childhood fever dream deployed as retail strategy, gleeful postmodern chaos, 8k`

### **Xanadu**

**№ 985 / 1001** · *Opulence Building Its Own Myth*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Três pais constitutivos são insubstituíveis — o horror vacui do Maximalismo, a Sehnsucht (o anseio) do Romantismo e a transmissão orientalista da opulência da corte mongol; retire qualquer um e o sistema se dissolve em decoração, perde a carga narrativa ou vira cenário teatral — síntese de segunda geração.

**Atmosfera e mood**

**A opulência construindo o próprio mito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Xanadu: o palácio de prazeres decretado por Kubla Khan e reconstruído por cada magnata desde então — a fortuna empilhada até virar lenda e advertência.

**Paleta de cores** dourado de decreto, mármore de império, vermelho de tapeçaria

**Melhores usos:** conceito, cinema, editorial

**MidJourney:** `[tema], xanadu aesthetic, pleasure dome decreed fortune stacked into legend, opulence building its own myth --v 6`

**Prompt universal (Seedream):** `Ultra-detailed cinematic photograph in the Citizen Kane manner, a Xanadu great hall, one small figure dwarfed under decree gold and empire marble where crated treasures stretch beyond the fireplace's reach into shadow, tapestry red swallowed by scale, opulence building its own myth and its own warning in the same room, colossal melancholic grandeur, 8k`

### **Xicana**

**№ 986 / 1001** · *Decolonized Identity Painted as Ancestral Defiance*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Três linhagens convergem sem pai comum — a escala compositiva do muralismo mexicano, a dignidade inventiva do rasquachismo chicano e o vocabulário material sagrado da cosmologia mesoamericana indígena — cada uma permanece estruturalmente identificável dentro da síntese, e remover qualquer uma colapsa uma dimensão distinta, não o todo.

**Atmosfera e mood**

**A identidade descolonizada pintada como defesa ancestral** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Xicana: o mural onde Coyolxauhqui encontra a avó de braços cruzados, milho e serpente emplumada reivindicados — a arte chicana pintando a linhagem de volta.

**Paleta de cores** magenta de mural, turquesa ancestral, ocre de milho

**Melhores usos:** cultura, murais, editorial respeitoso

**MidJourney:** `[tema], xicana muralism aesthetic, Coyolxauhqui beside the grandmother corn and feathered serpent reclaimed, lineage painted back --v 6`

**Prompt universal (Seedream):** `High-resolution photograph of a Chicana mural in full sun, Coyolxauhqui rising beside a grandmother with crossed arms as reclaimed corn and the feathered serpent frame the composition, mural magenta and ancestral turquoise over corn ochre, decolonized identity painted back into the neighborhood at full scale, proud vibrant defiance, 8k`

### **Xtreme**

**№ 987 / 1001** · *Gravity Becomes the Opponent*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EFFECT ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Três linhagens convergem — o risco corporificado do esporte radical, a gramática de transmissão da mídia técnica de performance e a encenação comercial do espetáculo jovem de marca — e nenhuma sozinha produz o sistema da manobra como unidade de medida.

**Atmosfera e mood**

**A gravidade virando adversária** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Xtreme: o skatista invertido sobre o vert, o wingsuit riscando o desfiladeiro e o segundo em que o corpo aposta contra a física e cobra os juros.

**Paleta de cores** laranja de capacete, azul de céu vertical, grafite de rampa

**Melhores usos:** esportes, capas, campanhas

**MidJourney:** `[tema], xtreme aesthetic, inverted over the vert wingsuit down the canyon, the body betting against physics --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 120-300mm lens at 1/8000s, an xtreme instant, a skater frozen fully inverted above the vert ramp's coping against hard vertical blue, helmet orange and ramp graphite razor-sharp while the crowd blurs below, gravity formally promoted to opponent and losing this exact second, explosive adrenaline precision, 8k`

### **Y2K**

**№ 988 / 1001** · *Chrome Optimism at the Millennium Turn*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → EMANATIO ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Quatro linhagens distintas convergem sem dominante — a distopia-como-estilo do cyberpunk noventista, as superfícies cromadas do modernismo da era espacial, a cinética corporal da cultura rave e a ideologia tecno-utópica do Vale do Silício como adesivo; remova qualquer uma e sobram fragmentos reconhecíveis, não o todo.

**Atmosfera e mood**

**O otimismo cromado na virada do milênio** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Y2K: calça de cintura baixa com top metálico, celular flip de glitter e o futuro prateado que o ano 2000 prometeu com juros — tecno-otimismo vestível.

**Paleta de cores** prata cromado, rosa bebê metálico, azul de tela inicial

**Melhores usos:** moda, nostalgia, capas

**MidJourney:** `[tema], y2k aesthetic, low-rise metallic top glitter flip phone, the silver future the year 2000 promised --v 6`

**Prompt universal (Seedream):** `Shot on a Sony Mavica with flash, a Y2K portrait at the millennium turn, low-rise pants and a chrome metallic top beside a glitter flip phone and inflatable furniture, chrome silver and metallic baby pink under boot-screen blue light, wearable techno-optimism cashing the future's first check, glossy digicam euphoria, 8k scan`

### **Yippie**

**№ 990 / 1001** · *Revolutionary Theater Takes the Street*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** Nenhuma tradição anterior produziu as três condições ao mesmo tempo — alvo político, forma carnavalesca e encenação calibrada para a televisão — e remover qualquer precursor isolado (Situacionismo, recusa Beat, teatro de rua dos Diggers) deixa a combinação específica intacta.

**Atmosfera e mood**

**O teatro revolucionário tomando a rua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Yippie: 1968, o porco candidato à presidência, notas de dólar chovendo na bolsa de valores e o protesto encenado como comédia séria — Abbie Hoffman dirigindo.

**Paleta de cores** preto e branco de Tri-X, cartaz psicodîlico, bandeira de sarcasmo

**Melhores usos:** histórico, ativismo, editorial

**MidJourney:** `[tema], yippie aesthetic, 1968 pig for president dollar bills raining on the stock exchange, protest staged as serious comedy --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F with 35mm lens on Tri-X, a yippie street action in 1968, costumed protesters staging revolutionary theater as dollar bills rain from a balcony onto bewildered traders, grain and flash freezing the grins mid-provocation, the Abbie Hoffman doctrine of protest as serious comedy, anarchic joyful documentary energy, 8k scan`

### **Zazou**

**№ 995 / 1001** · *Wartime Defiance Wears an Oversized Suit*

**Nível:** 🔴 Primary

**Eixo:** EXPRESSION ↑ → SEMIOTICS ↑

**Polaridade:** XY — disrupção por ruptura

**Nota:** A cultura de jazz do entreguerras deu a trilha e o dandismo deu a vaidade, mas nenhum dos dois transformou o excesso em arma contra um regime de racionamento — essa fusão é invenção própria da estética, e o modelo do guarda-roupa-como-resistência retorna em toda subcultura posterior que se veste contra um Estado.

**Atmosfera e mood**

**A resistência de guerra num terno grande demais** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Zazou: Paris ocupada, 1942 — paletô comprido demais de propósito, guarda-chuva sempre fechado e swing proibido no porão — a extravagância como sabotagem.

**Paleta de cores** xadrez exagerado, creme de gabardine, negro de porão de jazz

**Melhores usos:** histórico, moda, editorial

**MidJourney:** `[tema], zazou aesthetic, occupied paris 1942 deliberately oversized jacket forbidden swing in the basement, extravagance as sabotage --v 6`

**Prompt universal (Seedream):** `Shot on a Rolleiflex Old Standard, a zazou gathering in occupied Paris 1942, young men in deliberately oversized checked jackets with tightly furled umbrellas swinging to forbidden jazz in a basement club, exaggerated plaid and gabardine cream defying the ration books upstairs, wartime defiance cut with extra cloth on purpose, clandestine stylish courage, 8k scan`

### **Zenitism**

**№ 997 / 1001** · *Balkan Avant-Garde Between East and West*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → SYNTHESIS ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Tire o Futurismo e a carga diagonal colapsa em geometria construtivista estática; tire o Construtivismo e a grade vermelho-e-preta perde a lógica estrutural; tire o Expressionismo alemão e a voz de manifesto se cala — os três doadores permanecem rastreáveis, e soldá-los a um substrato pan-eslavo balcânico é a adição irredutível que trava a fusão.

**Atmosfera e mood**

**A vanguarda balcânica entre Oriente e Ocidente** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Zenitismo: a revista Zenit de Ljubomir Micić, tipografia em colisão e o “barbarogênio” balcânico proposto para rejuvenescer a Europa cansada — Zagreb e Belgrado, 1921.

**Paleta de cores** preto de tipografia, vermelho de manifesto, cru de revista

**Melhores usos:** arte, design, histórico

**MidJourney:** `[tema], zenitism aesthetic, Zenit magazine colliding typography balkan barbarogenius 1921, avant-garde between east and west --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a zenitist magazine spread from 1921, colliding typography and constructivist fragments assembling the Balkan barbarogenius across the fold in the Ljubomir Micić manner, manifesto red and type black on rough journal cream, the avant-garde negotiating between East and West at full volume, radical typographic energy, 8k`

### **Zine**

**№ 999 / 1001** · *Underground Publishing With Staples Exposed*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → TECHNIQUE ↓

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Duas linhagens convergem e nenhuma sozinha produz o resultado — tire o punk e a página de recorte-e-cola perde a velocidade e o orgulho lo-fi, tire a tradição do panfleto e o formato perde a reivindicação de distribuição democratizada — a fotocopiadora funde as duas, uma geração inteira depois do pai punk.

**Atmosfera e mood**

**A publicação underground com os grampos à mostra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Zine: xerox em preto e branco, colagem cortada à tesoura, letra à mão por cima da fita — tiragem de cinquenta, influência de mil.

**Paleta de cores** preto de xerox, branco de sulfite, rosa de grampo punk

**Melhores usos:** design, cultura, editorial

**MidJourney:** `[tema], zine aesthetic, black and white xerox scissor-cut collage handwriting over tape, print run of fifty influence of a thousand --v 6`

**Prompt universal (Seedream):** `High-resolution flat lay photograph, a zine spread mid-assembly, xeroxed black-and-white collage cut by scissors and taped down with handwriting correcting the headline, staples exposed along the spine beside a pink highlighter, copy-machine black on cheap white stock, a print run of fifty carrying the influence of a thousand, defiant DIY authenticity, 8k`

### **Zoot Suit**

**№ 1001 / 1001** · *Cultural Defiance Cut With Extra Cloth*

**Nível:** 🟤 Tertiary

**Eixo:** EXPRESSION ↑ → DENSITY ↑

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Três linhagens convergem e nenhuma é opcional — o dandismo fornece o exagero, a performance do swing fornece a tolerância ao movimento violento e o pachuco fornece a identidade codificada que levou o terno do Harlem ao barrio; retire qualquer uma e a forma perde sua razão ou nunca atravessa o país.

**Atmosfera e mood**

**A rebeldia cultural cortada com tecido extra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Zoot suit: ombros largos, calça de cintura altíssima afunilada no tornozelo e a corrente até o joelho — pachucos e o Harlem de Cab Calloway vestindo orgulho em metragem dobrada, elegância como afirmação de existência.

**Paleta de cores** listrado ousado, dourado de corrente, vinho de feltro

**Melhores usos:** histórico, cultura, editorial respeitoso

**MidJourney:** `[tema], zoot suit aesthetic, wide shoulders high waist knee-length chain pachuco pride Cab Calloway harlem, defiance cut with extra cloth --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Medalist with 100mm lens, a zoot suit portrait in 1943, a young pachuco in a boldly striped drape jacket with mountain shoulders and a watch chain swinging to the knee beside a wine felt hat, tailored pride in doubled yardage under dancehall light in the Cab Calloway lineage, cultural defiance worn as immaculate elegance, dignified triumphant style, 8k scan`

## Leitura do padrão — o que as 119 estéticas confirmam

Dá pra ver um sistema visual muito nítido em EXPRESSION, e ele é diferente dos três anteriores num ponto importante: **este é de longe o maior grupo dos quatro analisados até agora** (mais de 110 entradas versus ~20-35 nos outros), o que já é um dado estrutural: quase toda estética tem algum componente de "sinal para fora", mas só uma fração faz **disso** o eixo organizador.

**O núcleo: nenhuma dessas estéticas descreve uma pessoa "expressiva" em geral — todas convertem um estado interior em UM objeto, gesto ou cor específico que funciona como assinatura decifrável sem legenda.** É exatamente a lógica do Ensō que a página descreve: o traço não pode ser corrigido, então o que sobra não é perfeição, é a prova de uma mão real naquele segundo — e o "sigilo" (*sigil*) é o mecanismo que torna isso repetível numa lista de mil estéticas sem virar genérico.

**Os clusters visíveis na lista:**

**1. Códigos subculturais via objeto único (EXPRESSION ↑ → SEMIOTICS ↑) — o maior bloco, de longe.**

Punk, Glam Rock, Glam, Glam Punk, Visual Kei, Voguing, Sapeur, Swenkas, Stilyagi, Zazou, Coquette, Raxet, Xicana, Atompunk, Yippie, Harlem Renaissance, New Romantic, Shoe Diva, Cubism, Fauvism, Russian Vanguard. Cada uma tem **um sigilo só**: o alfinete de segurança (Punk), o raio na bochecha (Glam Rock), o terno impecável usado como dignidade (Sapeur/Swenkas), o monograma com erro de ortografia (Raxet), o sapato promovido de acessório a protagonista (Shoe Diva). O padrão confirma a regra do Ensō: "*place exactly one sigil per frame... two competing sigils cancel each other.*"

**2. Excesso como argumento, não decoração (EXPRESSION ↑ → EDITING ↓/↑).**

Camp, Tacky, Sensational, Wacky Pomo, Bubblegum Pop, Exuberance, Memphis, Neo Baroque, Periguete, Romanticism, Tachisme, Playful. Aqui a "restrição" (Editing) é o que está sendo testado — ou anulada por completo (Camp: "a obra deve exibir seu próprio artifício"), ou invertida em regra própria (Color Block: bordas absolutas, sem mistura).

**3. Espetáculo como consequência imediata (EXPRESSION ↑ → EFFECT ↑).**

Circus, Provocative, Xtreme, Rock 'n' Roll, Funfair, Futurism, Early Modernism. O sinal aqui não é só visto — ele **detona** algo no espectador na hora.

**4. Auto-irradiação pública (EXPRESSION ↑ → EMANATIO ↑).**

Theatricality, Riot Grrrl, Y2K, Scene, Tudor Henrician, Peacockcore, Grotesque — o estado interior não é só codificado, é transmitido como brilho, like a monarquia Tudor que precisa de magnificência visível para existir como poder.

**5. Quebra de coesão como assinatura (EXPRESSION ↑ → COHERENCE ↓).**

Gen Z, Groovy, Hypercore, Indie Sleaze, Lowbrow, Mannerism, Expressionism — aqui o "erro" ou a colisão visual É o sinal, não um acidente a esconder.

**6. Volume/acúmulo como amplificador (EXPRESSION ↑ → DENSITY ↑).**

Ultra-Pop, Xanadu, Zoot Suit, Flamboyant, Neo Manneristcore, Brazilian Ostentation Funk — a quantidade de sinal é o próprio sinal.

**O dado mais revelador, porém, é o inverso:** só existe **uma única entrada suprimida** (EXPRESSION ↓) na lista inteira — Hermitcore. Isso confirma exatamente o que o Ensō descreve como registro raro: recusar o sinal por completo (silêncio, cor tom-sobre-tom, rosto que não entrega nada à lente) é uma escolha tão deliberada quanto gritar — só que quase nenhuma das 1001 estéticas escolhe esse caminho, porque **withholding** exige tanta disciplina quanto **broadcasting**.

**O que isso confirma sobre o sistema:** EXPRESSION não é "estilo ousado" como categoria vaga — é qualquer estética cuja prova visual é a existência de **um único traço não-corrigível e repetível** que funciona como marca registrada do interior de quem a usa. Por isso Punk, Sapeur e Y2K convivem na mesma posição — alfinete, terno e cromado de milênio são objetos de naturezas completamente diferentes, mas todos passam pelo mesmo teste: *removido esse objeto, a identidade ainda se lê à distância, ou colapsa em roupa comum?*

# TECHNIQUE — o Esquadro e Compasso

<aside>
📐

**Essência:** TECHNIQUE é o rigor, o aprendizado e a precisão da execução — o conhecimento guardado no corpo, não na teoria, e legível na superfície que ele produziu. Seu ideograma é o Esquadro e Compasso da tradição artesã egípcia, as duas ferramentas pintadas lado a lado nas paredes das tumbas dos cortadores de pedra do faraó por três milênios e meio: o esquadro **verifica** — noventa graus, prumo, chão, o que *é*; o compasso **projeta** — o arco, o alcance, o céu, o que *pode ser*; e entre os dois existe um único ponto de trabalho onde as duas disciplinas se fixam juntas. Seus verbos são **Fazer / Making** (dar forma necessária, não arbitrária) e **Refinar / Refining** (destilar o padrão responsável, decidido no milímetro). Na imagem, o elemento se prova quando a execução resiste à inspeção macro e uma restrição fisicamente real faz o trabalho que um efeito falsificaria. **Leitura das setas nesta seção: ↑ = presença (elemento amplificado, nu na superfície) · ↓ = ausência (elemento suprimido ou deliberadamente faltante).**

</aside>

## Prompt-mestre (imagem-síntese)

**Universal TECHNIQUE prompt** — construído no mesmo formato dos prompts universais de DOMAIN, SYNERGY e EXPRESSION na página (colchetes para trocar pelo vocabulário do ofício específico), extraído da lógica do esquadro e compasso: um ponto de trabalho só, verificação sem correção posterior, o rascunho descartado mantido em quadro como prova de que o caminho difícil foi escolhido de propósito.

> **↑ TECHNIQUE — universal prompt.** A hand or figure caught at the exact working point where [the aesthetic's own material or instrument] is being formed or judged — [name the operation specific to this trade: a cut, a stitch, a weld, a calculation, a rendered polygon, a strike] — the whole body committed to that single point of contact, gaze down and locked on the operation rather than the lens, weight settled and low, breath held at the tolerance moment, the free hand steadying rather than decorating; one hard directional source set low and near-parallel to the surface with no fill, so every ridge, stitch, tool mark, or deviation from flat throws its own micro-shadow and the workmanship becomes readable as relief; the instrument rank laid in graded order within reach, none of them decorative, beside a stock of unworked material proving the operation has a before; one visible earned repair or scar outranking any pristine finish — [the aesthetic's own tempering mark: a resoled boot, a rewoven seam, a healed weld, a scrapped test piece]; one discarded competent draft kept in frame — an earlier version set outside the working zone, proof the harder path was chosen on purpose; the gesture economical and terminal, no wind-up, no flourish, no second attempt, no glance at the tool before using it; the camera behaving like a measuring instrument — tripod-still or rail-mounted, aperture stopped down so the whole operation holds sharp edge to edge, no motion blur, no handheld tremor, no correction of the workmanship after capture; composition orthogonal and gridded, verticals plumb, the working plane running parallel to the frame edge so the picture itself reads as a straightedge; palette drawn from the trade's own matter — [raw stock, tool steel, chalk, unbleached cloth, circuit green, graphite, or the aesthetic's own instrument colors] — with exactly one functional signal color and nothing merely decorative; the whole frame built so a practitioner of this exact trade could grade the work from the photograph alone.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre ↑):

> No soft flattering fill, no shallow focus or motion blur, no handheld tremor or dutch tilt, no second light source of a different temperature, no retouching or smoothing of the workmanship after capture, no decorative prop nobody touches, no printed or faked distressing, no presentational arm or tool held up for display rather than used, no heroic chest-forward posture or performed concentration, no smile, no wide establishing shot of the whole ambition standing in for the doing of it, no pristine finish with no visible repair, no second focal point competing with the working point, no tolerance that cannot be verified by the eye.
> 

### Como adaptar o prompt a cada estética

**Como usar para qualquer uma das 36 estéticas da lista:** troque só os colchetes pelo vocabulário do ofício específico — nenhuma palavra na arquitetura do prompt nomeia um ofício, lugar ou estilo, só os mecanismos universais que a página já define como TECHNIQUE (um ponto de trabalho só, luz de verificação em relevo, repetição em intervalo igual, o rascunho descartado como prova, zero correção pós-captura). Exemplos de substituição:

**Haute Couture / Sartorial / Gentlemen's:** operação = o alfinete/a costura; prova de temperamento = a bainha remendada.

**NASAcore / BioTech / Robotics:** operação = o cálculo, o protocolo de bancada; prova = a peça redundante testada até destruir-se.

**Low Poly / Line Art / Geometric Abstraction / AXIOM:** operação = o traço/polígono gerado pela regra; prova = a malha deixada sem suavização, evidência de que a fórmula não foi corrigida à mão.

**Boxing / Sporty / Equestrian:** operação = o golpe/o passo treinado; prova = o corpo com cicatriz real, gesto econômico sem correção.

**Photorealism / HyperRealism / Illusion:** operação = a réplica pintada/esculpida; prova = o detalhe macro que resiste à inspeção de perto sem que a mão apareça.

## Fundamentos do elemento

**Identity.** Rigor, learning, and precision of execution — knowledge held in the body rather than in the theory, and legible on the surface it produced. Its ideogram is the builder's square and compasses of the Egyptian craft tradition, the two tools painted side by side on the tomb walls of the pharaoh's stonecutters for three and a half millennia: the square verifies — ninety degrees, plumb, ground, what *is*; the compass projects — the arc, the reach, the sky, what *can be*; and between them sits a single working point where the two disciplines are pinned together. Its physics is the rugged landscape: a terrain of false summits and shallow valleys in which the system cannot reach the deepest point by always descending, so it must accept a temporary worsening — climb back out of a comfortable hollow — to arrive somewhere lower and truer. Its biology is the engraved track: the wheel that has passed the same line a thousand times falls into the groove by itself, so mastery is not knowing the route but having cut the groove into the body until excellence arrives as a reflex and error requires effort. Two verbs occupy the tool. **Fazer / Making**, giving necessary rather than arbitrary form — material proposes, the cut disposes, and the work is born between the two; its shadow is fabrication without purpose, relation, or soul. **Refinar / Refining**, distilling responsible standards out of the raw, decided in the millimetre of dilution; its shadow is taste used as exclusion, refinement hardened into hierarchy. In an image this element is proven by workmanship that survives macro inspection and by a physically real constraint doing the work an effect would otherwise fake — or by making left deliberately provisional, the garment photographed between idea and object. (Distinct from INTEGRITY, 1 — the pillar proves one logic across scales of a finished thing; the square proves the *execution* was exact, and permits a coarse or ugly object as long as the coarseness was decided. Distinct from ESTHETICS, 15 — the spiral is proportion the body recognises before argument; the square is tolerance, and a tolerance can be beautiful or brutal. Distinct from MATTER, 12 — matter is the substrate's resistance; technique is the hand's answer to it.)

**Decoupage — the impossible cut into filmable planes.** The amateur photographs *the battle*; the director photographs plan one, the hand on the sword hilt. This element never stages a totality — it stages one fully resolved fragment whose resolution implies the whole. Every TECHNIQUE frame must therefore contain evidence of a large thing broken into a small executable one: a numbered shot list clipped to the bench, a pattern piece labelled and stacked among its siblings, a jig built to make one repeated cut identical, a graded tray holding one component of an assembly the frame does not show. Ambition compressed into a single morning's task is the whole argument. The failure state is the establishing shot of the entire ambition — the wide frame of the finished cathedral, which proves nothing about the laying of the stone.

**The rugged landscape — the refused comfortable version.** A shallow valley is comfortable, stable, and the exact address of mediocrity; the only way out is to accept a temporarily worse state. Photographically this is the discarded good draft kept in frame: the first version rejected while a harder second one is under the hand, the resoled boot beside the new last, the cut-apart sleeve of a garment that already fit, the director's cut in which the favourite scene is on the floor. One object in the frame should be the abandoned competent solution. Without it the image argues that the work was easy, and TECHNIQUE has no claim to make about easy work.

**The engraved track — effort spent before the frame, not inside it.** The stabilised dolly runs on rail laid before the shot begins, which is why the movement is fluid; the amateur operates by hand and the picture shakes. This element photographs the *rail*, never the strain. The body in frame is not exerting — it is executing along a groove cut by ten thousand prior repetitions, and the visible evidence is economy: the shortest possible gesture, no correction, no second attempt, no glance at the tool before using it. Sprezzatura is the operating rule — the difficulty was absorbed in the training and is withheld from the surface, so the hand that has done this for twenty years looks slower than the hand that has done it for two.

**Error as a designed zone.** The technician does not fear failing; the technician fears failing *without structure*. Aviation, surgery, and critical systems engineering are obsessive about checklists not from distrust of competence but from respect for the human limit. So the frame carries its own safe zone of failure: a checklist ticked in pencil, a redundant second tool laid ready, a test piece cut from the same stock and deliberately destroyed to calibrate the real one, a scrap bin of legible earlier attempts. The scrap is not shame — it is the tempering certificate. Glass cooled fast shatters; steel that accepted the fire's time endures, and the visible repair, the healed nick, the re-soled sole outranks any pristine finish in this element.

**The refusal — technique as the art of not doing.** At the highest level of mastery the range of acceptable actions narrows rather than widens; limit is technique applied to desire. In frame this is visible subtraction: one tool where a lesser bench would hold six, an empty slot in an otherwise full graded rack, a surface cleared to exactly the operation in progress, a material rejected and set outside the working zone. What the hand declines to do must be as visible as what it does.

## Corpo — postura, gesto e olhar

**Model posture & structure.** The body of someone executing a protocol, not summoning a mood. Weight settled and low, feet planted at working width, the spine long without military display — the minimum-energy state of a system that no longer spends force holding its own position. Movement is economical and terminal: the gesture goes directly to the material, does the thing, and stops; there is no wind-up, no flourish, no re-adjustment. Stillness in this element is *loaded* rather than restful — the body is mid-operation, breath held or slowed at the exact tolerance moment, shoulders dropped, jaw unclenched, the head inclined toward the work rather than toward the lens. Hands are the protagonist and are never hidden, never idle, never self-adapting: they are on the tool, in the material, or flat on the bench. Where a second figure appears, they are apprentice or assistant, positioned at a legible rank, watching the hands rather than the face. Forbidden: heroic posture, chest-forward authority, the presentational arm, arrested contrapposto, any stance the body could hold for a second identical frame without the work advancing.

**Gesture.** Two verbs, alternating, never blended in one frame. **Fazer · Making.** The forming gesture, caught at the instant material changes state: the blade entering, the needle pulled through, the press coming down, the pigment laid, the clay compressed. The whole body is committed to one point of contact, gaze down and locked on the working point, the free hand steadying rather than decorating. The shadow is fabrication for display — a hand angled so the camera reads the craft rather than a hand angled so the cut is true; visible as a gesture aimed at the lens instead of at the material.

**Refinar · Refining.** The tolerance gesture, caught at the instant a difference too small to name is being judged: a thumb testing an edge, a workpiece raised into raking light to read the plane, a caliper closing, a strand held against another strand, a stitch counted. The gaze narrows and the head tilts to a shallow angle that only reads a surface. The shadow is refinement performed as rank — the connoisseur's gesture aimed at excluding rather than at measuring.

Forbidden in both: the demonstrative hold, the tool presented rather than used, and any gesture that would look identical after the work was finished. If the frame cannot say whether the operation succeeded, the gesture was theatre.

**The look — how the eyes behave.** One dominant mode and one permitted exception. **Occupied:** the gaze is down and inside the working point, absorbed to the exclusion of the camera, blink rate low, the face doing nothing at all because every available resource has gone to the hands. This is the element's native look and it must not be sentimentalised — no furrowed concentration, no performed intensity, no tongue at the corner of the mouth. **Verifying:** the eyes lift off the material by a few degrees to read a plane against the light, the pupil narrowing on an edge rather than on a person, the head held at the shallow angle that makes a surface legible. Both modes are low-arousal and cost nothing to hold. The exception, permitted once per series: a level, unhurried look into the lens taken *between* operations, the tool still in hand, no smile assembled and no invitation offered — the look of someone interrupted mid-task who will return to it. Banned: the upturned chin, the raised inner brow, the darting check for effect, and any expression that arrives after the eyes have already committed.

## Regras de imagem — do figurino à prova de ofício

**Look & styling continuity.** The garment is a working instrument and is read as one. Cut for the operation: sleeves shortened, pushed, or buttoned back at the exact point the trade requires; apron, coat, or overall closing on the side the dominant hand does not cross; pockets positioned where the tool actually lives. Materials chosen for behaviour rather than appearance — canvas, drill, wool flannel, oiled leather, heavy cotton, unlacquered metal — and specified by construction: the weave, the weight, the closure, the finish. Wear is real and located: burnish at the tool-side hip, heat marks at the cuff, thread-bare at the knuckle-side pocket edge, an oiled collar. One visible repair is mandatory and outranks any pristine surface — a rewoven tear, a resoled boot, a replaced button that does not match. Construction is exposed on purpose where the trade would expose it: a felled seam, a bar tack, a taped edge, a chalk line not yet brushed out. Refused: trend markers, applied hardware that carries no load, distressing that was printed rather than earned, and any garment that would be damaged by one honest working day.

**Camera.** The camera behaves like a measuring instrument. Large-format or long-lens macro discipline; a tripod, a slow shutter, and a deliberate ground-glass composition, because every decision must be visible and reversible before the exposure rather than corrected after it. Height at the working plane — the bench, the last, the hand — not at the model's eye and never above the work looking down as an overview. Aperture stopped down until the whole operation holds in focus, because a shallow plane would concede which part of the craft the photographer could not resolve; where a macro crop is used, the entire cropped surface must be sharp edge to edge. Distance is close but not intimate: near enough that a practitioner of that trade could grade the workmanship from the photograph alone, far enough that the hand and the tool and the material are all in the same frame. No handheld tremor, no dutch tilt, no motion blur anywhere — blur in this element reads as an unresolved tolerance. When the image moves, the camera moves once, on rail, at constant speed. Post-hoc correction is forbidden: any imperfection retouched after capture voids the element's entire claim, since the argument is that the precision happened in front of the lens.

**Composition.** Orthogonal and gridded. Verticals plumb, horizontals level, the bench edge or the working plane running parallel to the frame edge so the eye can use the picture as a straightedge. Build the frame in three legible registers: the **working point** (the hand meeting the material, placed at a measurable position rather than a felt one — a third, a centre, an intersection of the format's own divisions); the **instrument rank** (tools laid in graded order, aligned, spaced at equal intervals, none of them decorative); and the **verification evidence** (the chalk line, the pattern piece, the jig, the checklist, the reject). Repetition at equal interval is native to this element and does the work drama would do elsewhere: nine identical components in a row, one of them being worked. Negative space is clean and swept rather than atmospheric. Forbidden: dynamic diagonals for their own sake, off-kilter framing, a second focal point competing with the working point, and any prop that could not be picked up and used.

**Lighting.** Light as a measuring tool, not as a mood. Two legitimate registers. **Raking:** one hard directional source set low and near-parallel to the surface, no fill, so every ridge, stitch, grain, tool mark, and deviation from flat throws its own micro-shadow and the workmanship becomes readable as relief. This is the element's diagnostic light — the same light a machinist uses to check a plane, a tailor to check a seam, a plasterer to check a wall — and its angle must be visible in the shadow direction. **Controlled specular:** one large soft bank or a single north window, positioned so that every highlight on a polished, wet, or metallic surface is a deliberate placement rather than an accident, with no stray catch light anywhere in the frame. One source, one direction, one temperature, held across the entire depth of field. Falloff is clean and legible. Shadow holds detail rather than going black, because a shadow that hides the work is a shadow that hides the tolerance. Refused: soft flattering fill from everywhere, coloured gels, theatrical backlight, atmospheric haze, lens flare, on-camera flash, and any second source of a different temperature.

**Beauty detail.** The face is finished the way an instrument is finished: exactly, invisibly, and to a tolerance. The base is engineered rather than covered — hydrated, translucent, built in microscopic fused layers so the camera registers true pore texture and the skin's own depth rather than an averaged surface. No mattifying powder where the work produces real heat; sweat sheen at the temple and hairline is a working condition and stays. One feature only carries a decision, and that decision is executed with millimetric precision: a graphic line that holds its width along its entire length, or a lip whose edge is cut clean, or a brow left in its true growth pattern and combed rather than drawn. Contour, where used, is calibrated to the lens distance rather than to the eye — shadow that redraws the plane the camera will read, not shadow visible in the room. Hair is a solved structural problem: cut, tied, pinned, capped, or lacquered to hold one silhouette through the whole operation, with the head's outline kept surgically sharp and no strand permitted to wander into the working point. Where the register is amplified toward the built face, the precision escalates rather than loosens: heat-pressed or moulded hair, hidden armature bearing the weight, edges cut with a blade, every millimetre planned before the first exposure. The hands are the second face and are cast, not styled — real callus, real nail condition, real trade marks, rendered sharp at macro distance. Refused: sealed lacquered finish nothing could disturb, generic smoothing, plasticised skin, and any grooming imported from a trade the frame does not contain.

**Cenography.** A working room that would keep functioning the moment the crew leaves, built to load-bearing standards rather than photographed where the lens looks. Build the ceiling nobody intends to photograph, hang the real door, mount the real bench — the body answers a real wall differently than a painted flat, and a real bench takes a real cut. Three elements are mandatory: a **working plane** (bench, table, last, loom, press, floor) marked with the wear paths of actual use; a **rank of instruments** in graded order, within reach of the operation they serve; and a **stock of material** in its unworked state, stacked or racked, proving the operation has a before. Zones stay separate — the working zone, the storage zone, the finished zone — because a bench that also serves as a desk is the scenographic definition of a collapsed craft. Two grounds are equally legitimate and must not be mixed: the **workshop**, real and inhabited, with dust in the light and a floor that records the route the work travels; or the **corner** — a physically real constraint built from plain seamless, a literal corner of two flats, a monolithic block, or a pure black ground — where nothing exists to recede into and the only content is the object and its tolerance. In either case, all aging is genuine: hand-worn handles, oiled thresholds, chalk in the grain. Refused: decorative props nobody touches, three trades sharing one room, a cleared studio with no wear, and any patina that was printed rather than earned.

**Colour.** Instrument palette. One temperature and one hour across the whole frame, drawn from the trade's own matter: raw stock, tool steel, oiled leather, chalk, canvas, graphite, machine grey, unbleached cotton, brass. Saturation stays low to mid so that value — light against dark — carries the reading, because tolerance is judged in value and not in hue. Exactly one signal colour is permitted and it must be functional: the chalk line, the marking thread, the red pencil correction, the safety mark, the dye lot tag. That colour appears only where the trade would put it. Refused: a decorative accent, a balanced three-colour palette, and any grade laid over the frame after capture — the colour must be what the room and the material actually produced.

**Craft proof.** Wherever the composition allows, plant one device that lets the viewer verify the workmanship rather than take it on trust: nine repetitions of a component at genuinely equal interval; a stitch line crossing a seam without deviating; a reflection that stays true across a polished surface; a pattern piece laid beside the finished part it produced; a caliper, a gauge, or a ruler in frame with the reading legible; the same edge shown twice, once as stock and once as worked. This is the square's own verification made photographic — the closest a still image comes to proving that the tolerance was met. A frame whose precision cannot be checked by the eye has only asserted precision, which is the single most legible failure this element can produce.

**If the image moves.** One take, on rail, at constant speed, following one operation from beginning to completion — the argument being that the crossing happened in real time and required no cut. No speed ramp, no cut-away to hide the difficult part, no composited assistance. If the operation fails, the failed take is the honest one. Sound, where present, is the tool's own: the shear, the press, the file, the needle through canvas — the audible proof of the material's resistance. **Practitioner lines (from the codices).**

## Linhas de praticantes prontas para prompt (dos códices)

*Studio and precision.* Horst P. Horst — one hard key low and raking at roughly thirty degrees, no fill whatsoever, the torso torqued three-quarter so the key catches the ridge of a shoulder blade or the curve of a corset seam, near-black shadow, dodge-and-burn worked at the enlarger until the sculptural edge stays crisp against the void. Irving Penn — a physically real corner where two studio flats meet so the sitter cannot recede from the camera's pressure, a single north window or one large bank, large-format ground glass disciplining the composition before the shutter, platinum-palladium printing holding sixty to seventy tones, and the sitter's own tool of trade as the only prop. Hiro — seamless pure black, every millimetre of specular highlight planned before the first exposure and corrected between frames, large-format contact sheet used as the precision instrument, one ordinary object placed beside one precious one in impossible exactness. Richard Burbridge — macro still-life precision applied to the face itself, paint and prosthetic built by hand in front of the lens, razor-controlled light, saturated colour against void. Bob Wolfenson — rigorous controlled studio light, restrained palette, classical eye-level framing, the sitter met rather than decorated. Zee Nunes — sculptural high-fidelity studio lighting refined to a hair's tolerance, monumental framing, immaculate rendering, saturation disciplined rather than loosened.

*Face and head.* Kevyn Aucoin — the bone measured before the brush is lifted, then invisible three-dimensional contour calibrated to the lens distance, severely arched thin brow, satin poreless skin engineered to generate its own highlight inside the camera rather than merely survive the studio's. Orlando Pita — architectural deconstructed bun with sharp lines, mirror-bright shine, invisible last-generation fixative holding a dynamic pose without weighting the silhouette, the head's outline kept surgically sharp in every frame. Peter Gray — hidden metal armature bearing the structure, three-dimensional geometric braid built to brutalist proportion, hair weight and angle calculated against the garment's silhouette, static rigorous pose under severe linear light. Malcolm Edwards — industrial heat press and acrylic mould used on set, hair folded and stretched into a two-dimensional synthetic sculpture, matte desaturated artificial colour, gravity refused by engineering rather than by retouch. Alain Pichon — surgical low bun embedded at the nape to mathematical precision, brushed-steel-clipped tension, acrylic gel bonding hair to scalp, continuous white light producing a single linear reflection across a chromed surface. Syd Hayes — chromed surgical fringe, heavy industrial clips fastening hair geometrically, straight graphic hairline cutting the frame, infinite white ground, low-angle framing magnifying the silhouette.

*The room.* Randall Peacock — monolithic cubes, cylinders, and floating planes in optical white or matte concrete-grey, surgical light cuts dividing the space to millimetric precision, static monumental posing, zero decorative props, industrial-design proportion tuned until set and tailoring read as one language. David White — mobile monolithic walls in matte asphalt-grey or chalk, transparent acrylic panels slicing the space linearly, a polished industrial floor returning light as one continuous mirrored plane, false-wall geometry converging on the model. Stefan Beckman — reconstructed mid-century or brutalist interior with embedded linear fluorescent light, false-wall inclines calculated in advance to correct the wide-angle lens's distortion, symmetric composition engineered for the camera rather than the live eye. Jean-Michel Bertin — film-continuity-grade consistency across every prop and surface, each object justified inside a coherent world rather than assembled for one frame. Mary Howard — a hand-painted infinite ground in one graduated neutral, mixed to absorb hard flash without glare. Gideon Ponte — the fully built room with a real ceiling nobody intends to photograph, real doors, hand-aged patina, and directional window light produced by real geometry at a real hour.

**Direction calls — the two verbs as spoken on set.** Refinar's body code is the millimetre correction itself: fingers at a lapel, the last half-centimetre of a cuff, head tilted in judgement, eyes narrowed to tolerance-testing, small gestures carrying absolute authority; its direction call is *one centimetre is wrong, fix only that, nothing else exists* — the discipline of Azzedine Alaïa fitting on his knees with pins in his mouth, the Savile Row chalk stroke, the final mirror check before a couture exit. Fazer's body code is work genuinely lodged in the body: hands mid-task, weight actually engaged, sleeves pushed back, the real resistance of the material visible in the forearms — never the mime of work, the work itself; its direction call is *actually do it, we photograph the doing, not the demonstration*, the standard met by Lee Miller photographed working for Vogue, Agnès Varda's gleaners, and the petites mains of *Dior and I* — hands that have opinions.

**The fitting as native scenario.** Beside the workshop and the corner, this element has one further legitimate ground: the fitting itself, the model as fitting-figure rather than as subject — arms raised for the tailor, standing for measurement, holding stillness with professional patience, gaze down at the work or held mid-distance during a pause, the attitude of precision experienced as intimacy. Cast one model beside real hands: petites mains playing themselves, not actors performing craft. The reference standard is Daniel Day-Lewis's Reynolds Woodcock in *Phantom Thread*, where the fitting scene is treated as the aesthetic's liturgy, alongside Cartier-Bresson's decisive geometry and Willy Vanderperre's studio precision.

**Fabric-calibrated optics.** The camera's technical settings are dictated by the material being photographed, not by the light alone — inherited studio science relayed intact rather than invented per shoot. Rigid matter — structured neoprene, moulded leather, tooled hardware — is met with hard directional light and macro discipline that renders every seam, edge, and mould line as static architecture, shadow ridges carving the surface like relief. Volatile matter — silk chiffon, muslin, tulle — is met with a slowed shutter that lets the fabric dissolve into its own luminous trail, motion blur promoted from accident to material property, the body kept as the one sharp axis inside the haze. The two registers never mix inside a single frame: a rigid object is never given volatile treatment and a volatile one is never frozen falsely sharp, because that falsification is exactly the failure this element exists to prevent.

**The exposed rig — technique as its own confession.** One further legitimate variant inverts the element's usual discretion: instead of hiding the apparatus, the frame keeps its own skeleton in view on purpose — light stands, sandbags, cable runs, a tethering monitor showing the same image it is capturing, an assistant half in frame — while the model acknowledges the camera directly, touching the lens, fingertips almost on the glass. Here the rule against concealment replaces the rule against correction: nothing is cut from the frame, the flood of evidence is kept rather than edited down, because the argument is that the manufacturing of the image is the image. This variant is legitimate only when the exposed rig is real and functioning, never a prop rig staged to look exposed.

**The forensic register — preparation as the whole subject.** A further legitimate mode withholds spectacle by law rather than by absence of budget: no leap, no detonation, no mid-air hero frame, ever. What replaces it is documentation of preparation held to the same standard the element always demands — the harness check performed as the craftsman's kneel, the wind read rather than performed, chalk dust arrested mid-air by a flash-freeze strobe with no golden-hour flattery permitted anywhere in the frame. The commit point is reached and held in the final frame; the leap itself is never shown. Every material must be able to name the specific force it was built to withstand, and the image is disqualified the moment spectacle sneaks back into it. Reference standard: Jimmy Chin's preparation frames in *Free Solo*, the van and the finger-taping rather than the wall; Steve McQueen's suit-up sequence in *Le Mans*; Harold Edgerton's ballistic freezes as the lighting canon.

**The ballistic register — technique as discharge, not polish.** At the opposite temperature from the atelier's patience sits technique performed at maximum speed and irreversibility: one uncorrectable gesture, committed in a fraction of a second, that cannot recur and is not permitted a second take. The camera goes directly overhead, the working surface becomes the picture plane itself, and raking light at a low angle catches wet ridges and impasto the same way it would catch a stitched seam — the physics identical, the tempo opposite. No beauty light and no smoothing are permitted; every trace must remain forensically legible as a record of the exact speed of the hand that made it. Reference standard: Hans Namuth's 1950 films of Jackson Pollock, including the shot filmed from beneath a sheet of glass — the original overhead technique camera.

**Menswear precision — a further practitioner line.** Alastair McKimm checks a hood's fold or a cargo's pooling over a sneaker the way a couture house checks a toile — by eye, by comparison against a mental standard, adjustment until the line is the one the material was built to make — holding street silhouette to the identical rigor a modernist minimalist garment receives on the same studio ground. Marie-Amélie Sauvé, a quarter-century technical partner first at Balenciaga then at Louis Vuitton, checks the future itself against wearability: rigid leather, geometric shoulder, technical fabric engineered to couture finish, continuous white light, static near-robotic poses with fluid movement eliminated entirely. Jodie Barnes holds a single standard of fit across heritage tailoring and directional design without ever loosening it, authority living in the exact fall of a shoulder and the precise break of a trouser. Tom Guinness checks a terrace-culture reference against real class history with the same rigor McKimm applies to a hood, buttoning a rigid knit polo to the collar under hard direct light that simulates a pub bathroom rather than a studio. Vince Levy strips every accessory and trace of makeup until an industrial jumpsuit's exposed triple stitching, checked against real structural stress, is the only signal left standing, under diffuse continuous light that eliminates dramatic shadow so the architecture of the drape can register at full force.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Workmanship legible at macro distance and verifiable in frame: even-interval hand stitching, controlled drape, tool marks of mastery, a physically real constraint doing the work, one hard raking source revealing construction as relief, the instrument rank in graded order, chalk lines and pattern pieces present as verification, one visible earned repair, an economical terminal gesture, a plumb orthogonal composition, and no correction after the exposure.

> **↑ Prompt.** Close on a tailored shoulder held in the physically real corner where two studio flats meet, one hard source raking low and nearly parallel to the cloth with no fill, every pick stitch along the lapel roll standing in its own micro-shadow at even interval, chalk lines still ghosting the canvas beneath and a bar tack visible at the seam's end, the maker's hands in frame with real callus and short trade-cut nails, the thumb testing the edge of the roll and the eyes down and inside the working point, sleeves pushed and buttoned back at the trade's own line, a burnished wear mark at the tool-side hip and one rewoven repair left unhidden at the cuff, a thimble, shears, and nine identical basted panels ranked at equal spacing along the bench edge running parallel to the frame, one cut-apart sleeve of an earlier competent version set outside the working zone, the bench worn along the route the work actually travels, palette held to chalk, tool steel, oiled leather, and undyed canvas with a single red pencil correction as the only signal colour, large format stopped down so the entire crop holds edge to edge, the whole image built so a master tailor could grade the workmanship from the photograph alone.
> 

> **↑ Negative line.** No soft flattering fill, no shallow focus, no motion blur, no handheld tremor, no dutch tilt, no coloured gel or theatrical backlight, no atmospheric haze or lens flare, no second light source of a different temperature, no retouching of the workmanship after capture, no decorative prop nobody touches, no printed or faked distressing, no presentational arm or tool held up to the lens, no heroic chest-forward posture, no performed concentration, no smile, no cleared studio without wear, no second focal point, no accent colour that serves no function.
> 

**↓ Suppressed — repertory.** Making left provisional and shown as fact: pinned hems, exposed basting, fitting marks, tape and safety pins, tolerance abandoned mid-decision, the groove not yet cut, the object caught between idea and thing with the indecision kept rather than resolved.

> **↓ Prompt.** A muslin toile pinned directly onto the standing body, basting thread loose and trailing, one shoulder cut open and re-pinned twice with the earlier pin holes still visible, hem raw and dragging on a paper-strewn floor, fitting corrections scrawled in red pencil across the chest and a second contradictory correction beside the first, safety pins substituting for a closure nobody has decided on, hands stilled halfway through an unfinished adjustment and the gaze off past the mirror rather than into the work, a strip light overhead spilling flat and sourceless across the room so no plane is favoured and no seam throws a shadow that could be read, no ranked tools and no graded stock anywhere, the garment photographed exactly halfway between idea and object and unapologetic about it.
> 

> **↓ Negative line.** No raking diagnostic light, no controlled specular, no macro-legible stitch, no ranked instruments, no verification device, no jig, no chalk line, no completed operation, no earned patina, no orthogonal plumb composition, no evidence of a groove already cut.
> 

## Estéticas relacionadas a TECHNIQUE (A–Z)

As 36 estéticas classificadas sob TECHNIQUE, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary · ⚫ Quaternary), eixo secundário e polaridade (XX — continuidade · XY — disrupção). **Leitura das setas: ↑ = presença do elemento · ↓ = ausência do elemento.** Naive é a única estética da lista definida pela *ausência* de TECHNIQUE (↓); nas demais entradas, o ↓ aparece apenas no eixo secundário (o segundo elemento é que está suprimido).

### **04 MATRIX**

**№ 004 / 1001** · *The hidden grid bearing every form*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

### **05 VERTEX**

**№ 005 / 1001** · *All lines, one point of arrival*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → SYNERGY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

### **07 ZENITH**

**№ 007 / 1001** · *Nowhere left above*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → INTENTIONALITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

### **09 AXIOM**

**№ 009 / 1001** · *Rule that needs no proof*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → COHERENCE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

### **Abstract Expressionism**

**№ 013 / 1001** · *Painting at the size of feeling*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**Pintura no tamanho do sentimento** — (1001 Aesthetics, interpretação)

Gesto em escala monumental: respingos, pinceladas violentas e emoção crua, na linha de Pollock, de Kooning e Rothko.

**Paleta de cores** contrastes dramáticos — preto e primárias, ou campos de cor profundos

**Melhores usos:** arte emocional, capas, cenários dramáticos

**MidJourney:** `[tema] in the style of abstract expressionism, gestural brushstrokes --v 6`

**Prompt universal (Seedream):** `Large-format photograph shot on Phase One IQ4 with 80mm lens of a massive abstract expressionist canvas, violent gestural brushstrokes and dripped splattered paint in thick glistening impasto, raw emotional energy in the manner of Pollock and de Kooning, dramatic raking gallery light revealing every ridge of pigment, 8k museum reproduction`

### **Adrenaline**

**№ 023 / 1001** · *Risk you paid good money for*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EFFECT ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Risco que você pagou caro para sentir** — (1001 Aesthetics, interpretação)

Esportes radicais em momento congelado: ângulos extremos, motion blur nas bordas, energia de câmera de ação.

**Paleta de cores** cores vivas de equipamento contra céu, rocha ou neve

**Melhores usos:** esportes, campanhas de energia, capas

**MidJourney:** `[tema], extreme sports action shot, adrenaline rush --v 6`

**Prompt universal (Seedream):** `Extreme sports photograph shot at 1/2000s on a 16mm wide-angle lens, athlete frozen mid-air against a vast canyon, motion blur streaking the edges of the frame, vivid gear colors slicing through rock and sky, harsh midday sun with polarized contrast, adrenaline-charged editorial energy, 8k`

### **Algorithmic**

**№ 039 / 1001** · *Code that taught itself to draw*

**Nível:** ⚫ Quaternary

**Eixo:** TECHNIQUE ↑ (presença) → EFFECT ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**Código que aprendeu a desenhar** — (1001 Aesthetics, interpretação)

Arte generativa: curvas paramétricas, ruído de Perlin, geometria que emerge do código.

**Paleta de cores** gradientes digitais limpos ou monocromático estilo plotter

**Melhores usos:** tech, dataviz, identidade digital

**MidJourney:** `[tema], generative algorithmic art, parametric curves --v 6`

**Prompt universal (Seedream):** `Ultra-crisp generative artwork rendered at 8k, parametric flowing curves and emergent geometric patterns with plotter-pen precision, clean digital gradients on a deep neutral field, perfect anti-aliased mathematical lines, museum of digital art presentation, elegant creative coding aesthetic`

### **Biomimicry**

**№ 093 / 1001** · *Leaf that taught paint how to self-clean*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → SYNTHESIS ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** uma única linhagem de design de engenharia é levada adiante e ganha nova fonte de autoridade — o método permanece intacto enquanto a natureza substitui o precedente como referência; a tradição é redirecionada, não fundida com outras.

**Atmosfera e mood**

**Folha que ensinou a tinta a se limpar** — (1001 Aesthetics, interpretação)

Biomimética: engenharia copiada da natureza — lótus, colmeias, estruturas que evoluem.

**Paleta de cores** naturais com tech limpo

**Melhores usos:** produto, arquitetura, editorial

**MidJourney:** `[tema], biomimicry design, nature-inspired engineering --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 120mm macro lens, a biomimicry design study pairing a lotus leaf's water-beading surface with its engineered product twin, honeycomb lattice prototypes on white acrylic, clean studio softbox light, botanical specimen beside milled titanium, elegant scientific styling, crisp product-render clarity, 8k`

### **BioTech**

**№ 099 / 1001** · *Microscope that turned into a compiler*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** uma única linhagem de instrumento científico é levada adiante e re-especificada como ferramenta de autoria — o vocabulário do laboratório sobrevive intacto enquanto a observação é reescrita como edição; mudança de propósito dentro de uma só linha, não fusão.

**Atmosfera e mood**

**Microscópio que virou compilador** — (1001 Aesthetics, interpretação)

Biotech: laboratório impecável, DNA em telas holográficas, ciência corporativa polida.

**Paleta de cores** branco, azul clínico, verde-tela

**Melhores usos:** ciência, corporativo, editorial

**MidJourney:** `[tema], biotech laboratory, DNA on screens --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a pristine biotech laboratory where DNA sequences scroll across holographic screens, scientist in white silhouetted against clinical blue light, pipettes and gene-editing rigs gleaming on spotless benches, cool corporate sci-fi grading with cyan highlights, shallow cinematic depth, 8k production still`

### **Boxing**

**№ 116 / 1001** · *Twelve rounds written in rope and sweat*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** esporte de combate, encenação de espetáculo e auto-fabricação operária convergem; tire o espetáculo e o ringue vira só treino, tire a linhagem de classe e a luta perde o sentido fora das cordas — solda de tradições distintas, não um único pai revisado.

**Atmosfera e mood**

**Doze rounds escritos em corda e suor** — (1001 Aesthetics, interpretação)

Academia de boxe: ringue gasto, suor e giz no ar, luz dura direcional, grão documentário.

**Paleta de cores** contrastes duros, vermelho de luva, cinzas de ginásio

**Melhores usos:** esporte, retratos, campanhas

**MidJourney:** `[tema], gritty boxing gym photography --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Tri-X with 35mm lens, a gritty boxing gym at dawn, sweat and chalk dust suspended in one hard shaft of window light, worn ring ropes and cracked red gloves, fighter's taped fists mid-wrap, high-contrast documentary grain in the spirit of Larry Fink, twelve rounds of grit, cinematic monochrome`

### **Choreographic**

**№ 152 / 1001** · *Preparation made visible before the first tendu*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** treinamento codificado do balé, o release da dança moderna e a prática de notação convergem; tire o vocabulário codificado e a preparação não tem o que tornar visível, tire a notação e a frase não pode ser transmitida — fusão de linhagens distintas.

**Atmosfera e mood**

**A preparação visível antes do primeiro tendu** — (1001 Aesthetics, interpretação)

Coreográfico: corpo de bailarino em ensaio, estúdio de madeira e barra, movimento congelado com giz no ar.

**Paleta de cores** neutros de estúdio, luz de janela, pele

**Melhores usos:** dança, editorial, movimento

**MidJourney:** `[tema], contemporary dance rehearsal photography --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Tri-X with 50mm lens, a dance rehearsal photograph, dancer mid-preparation at the studio barre, chalk dust suspended in raking window light across worn wooden floors, muscle tension and frayed ribbon detail, visible discipline before the first tendu, black-and-white grain, quiet documentary reverence, 8k`

### **Cyberpunk**

**№ 189 / 1001** · *High tech with low life*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → INTEGRITY ↓ (ausência)

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**Alta tecnologia com vida rasteira** — (1001 Aesthetics; código: Kinomoto/X)

Cyberpunk: megacidade de néon sob chuva, hologramas e decadência urbana, cromo e implantes contra o beco escuro.

**Paleta de cores** néon magenta e ciano, preto urbano, chuva

**Melhores usos:** sci-fi, personagens, cenários

**MidJourney:** `--sref 2390430647 --sw 1000` (Neon Cyberpunk Style)

**LoRA (Civitai):** "Cyberpunk Anime Style" — civitai.com/models/128568 (Flux/SDXL/SD1.5); "Cyberpunk SDXL" — civitai.com/models/152914 (trigger: Cyberpunk Style)

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a cyberpunk megacity at night, neon signs and holograms doubling in rain-slick streets, chrome implants glinting in low-life alleys beneath corporate towers, magenta and cyan glow through steam, Blade Runner 2049 grading with anamorphic flare, high tech low life, 8k production still`

### **Diorama**

**№ 228 / 1001** · *Vitrine, the Painted Horizon, and the Frozen Pose*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → DOMAIN ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A vitrine, o horizonte pintado e a pose congelada** — (1001 Aesthetics, interpretação)

Diorama: cena em miniatura dentro de caixa, fundo pintado em curva, figuras congeladas sob luz de museu.

**Paleta de cores** luz de vitrine, fundos pintados, miniatura

**Melhores usos:** narrativa, produto, arte

**MidJourney:** `[tema], museum diorama, miniature scene in glass case --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 100mm macro lens, a museum diorama scene, miniature figures frozen mid-pose inside a glass vitrine, curved painted horizon backdrop, warm display lighting with faint glass reflections, tiny world held in a box, tilt-shift charm, exquisite miniature detail, 8k`

### **Early Cyber**

**№ 255 / 1001** · *Phosphor Green Burning the 3 AM Dark*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**Verde-fósforo queimando a madrugada das 3h** — (1001 Aesthetics; código: Lummi, match aproximado)

Ciber primitivo: monitor CRT de fósforo verde, linhas de comando, modem e a internet crua dos anos 80–90.

**Paleta de cores** verde-fósforo, preto de tela, cinza de gabinete

**Melhores usos:** tech retrô, narrativa, capas

**MidJourney:** `--sref 698401885 --sw 1000` (Cyber Aesthetic — match aproximado)

**Prompt universal (Seedream):** `Shot on 35mm film with 28mm lens, an early cyber scene, phosphor-green CRT terminal burning in a 3 AM dark room, command lines reflected on tired glasses, dial-up modem and beige tower cases, raw 1980s internet frontier, film grain and screen glow, cinematic hacker still`

### **Equestrian**

**№ 299 / 1001** · *Horse Signs the Contract First*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O cavalo assina o contrato primeiro** — (1001 Aesthetics, interpretação)

Eqüestre: couro de sela e tweed, estábulo nobre, elegância rústica do mundo hípico.

**Paleta de cores** marrom de couro, verde caça, latão

**Melhores usos:** moda, lifestyle, editorial

**MidJourney:** `[tema], equestrian style, saddle leather and tweed, noble stables --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 85mm lens, an equestrian scene, saddle leather and tweed at noble stables in golden morning light, hunting green and brass details, breath steaming from the horse, rustic elegance of the riding world, Ralph Lauren campaign warmth, 8k`

### **Gentlemen's**

**№ 373 / 1001** · *Savile Row Lapel Roll Under Inspection*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → NUANCE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A curva de lapela de Savile Row sob inspeção** — (1001 Aesthetics, interpretação)

Cavalheiro: alfaiataria londrina e clube de couro, uísque e xadrez discreto, elegância que se prova nos detalhes.

**Paleta de cores** grafite, marrom de couro, verde garrafa, dourado de uísque

**Melhores usos:** moda masculina, branding premium, editorial

**MidJourney:** `[tema], Savile Row tailoring, gentlemen's club leather and whisky, inspected lapel roll --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad H6D with 80mm lens, a gentlemen's scene, Savile Row lapel roll under inspection in a leather-armchair club, whisky gold and bottle green with charcoal tailoring, warm library lamplight, elegance proven in the details, 8k`

### **Geometric Abstraction**

**№ 374 / 1001** · *Malevich's Black Square Refuses the World*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**O Quadrado Negro de Malevich recusa o mundo** — (1001 Aesthetics; código: MidLibrary "Geometric Abstraction Society")

Abstração geométrica: suprematismo e formas puras, quadrado e círculo como argumento total, pintura sem mundo.

**Paleta de cores** preto, branco, vermelho e amarelo suprematistas

**Melhores usos:** arte, design gráfico, editorial

**MidJourney:** `--sref 390384 --sv 4 --sw 1000` (Geometric Abstraction Society)

**LoRA (Civitai):** "FF Style: Kazimir Malevich — Suprematism" — civitai.com/models/186419

**Prompt universal (Seedream):** `Museum-grade reproduction of a suprematist painting, geometric abstraction, pure forms refusing the world like Malevich's Black Square, interlocking squares and circles in black white red and yellow, hard-edge flat color on white, gallery lighting, 8k`

### **Handcrafted**

**№ 414 / 1001** · *Drawknife Mark the Sander Was Told to Leave*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A marca da plaina que mandaram a lixadeira deixar** — (1001 Aesthetics, interpretação)

Artesanal: ferramenta manual visível no objeto final, imperfeição assinada, o humano preservado na superfície.

**Paleta de cores** madeira crua, couro, linho, ferro de ferramenta

**Melhores usos:** artesanato, branding autêntico, editorial

**MidJourney:** `[tema], handcrafted aesthetic, visible drawknife marks on wood, honest tool traces, artisan workshop light --v 6`

**Prompt universal (Seedream):** `Shot on Pentax 67 with 105mm lens, a handcrafted image, drawknife marks the sander was told to leave, raw wood and leather in workshop window light, the human hand preserved in the finished surface, 8k`

### **Haute Couture**

**№ 421 / 1001** · *Twenty Pins Hold the Bodice Before the First Fitting*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → INTENTIONALITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Vinte alfinetes seguram o corpete antes da primeira prova** — (1001 Aesthetics, interpretação)

Alta costura: ateliê parisiense e musselina alfinetada, mãos que costuram o impossível, o vestido antes de existir.

**Paleta de cores** branco de musselina, dourado de ateliê, preto de alfaiate

**Melhores usos:** moda, editorial, branding de luxo

**MidJourney:** `[tema], haute couture atelier, pinned muslin bodice before the first fitting, Parisian workshop light --v 6`

**Prompt universal (Seedream):** `Shot on 8x10 large format with 300mm lens, a haute couture image, twenty pins holding a muslin bodice before the first fitting, Parisian atelier hands sewing the impossible, Irving Penn studio stillness, the dress photographed before it exists, 8k`

### **High Renaissance**

**№ 432 / 1001** · *Raphael's Spolvero Fixes Plato at the Vanishing Point*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O spolvero de Rafael fixa Platão no ponto de fuga** — (1001 Aesthetics, interpretação)

Alta Renascença: composição perfeita e perspectiva absoluta, afresco equilibrado onde cada figura tem lugar calculado.

**Paleta de cores** tons de afresco, azul ultramar, vermelhos e ocres renascentistas

**Melhores usos:** arte, histórico, editorial clássico

**MidJourney:** `[tema], High Renaissance fresco style, Raphael School of Athens composition, perfect one-point perspective --v 6`

**Prompt universal (Seedream):** `Museum-grade fresco reproduction, a High Renaissance image, a balanced composition fixing the philosopher at the vanishing point like Raphael's School of Athens, ultramarine and ochre Renaissance palette, every figure in its calculated place, 8k`

### **Hypermodern**

**№ 448 / 1001** · *OLED Surface Updates Before the Frame Settles*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → ETERNITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A superfície OLED atualiza antes do frame assentar** — (1001 Aesthetics, interpretação)

Hipermoderno: superfícies vivas e interfaces contínuas, o presente que se atualiza mais rápido que a percepção.

**Paleta de cores** preto OLED, ciano de interface, branco de tela viva

**Melhores usos:** tech, produto, editorial futurista

**MidJourney:** `[tema], hypermodern aesthetic, living OLED surfaces updating in real time, seamless interface architecture --v 6`

**Prompt universal (Seedream):** `Shot on RED Komodo with 50mm lens, a hypermodern image, an OLED surface updating before the frame settles, living interfaces on seamless black glass, the present refreshing faster than perception, 8k`

### **HyperRealism**

**№ 450 / 1001** · *Ron Mueck's Silicone Pore Outlasts the Photograph*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O poro de silicone de Ron Mueck sobrevive à fotografia** — (1001 Aesthetics, interpretação)

Hiper-realismo: detalhe além da câmera, pele, poro e fio de cabelo em escala impossível, o real intensificado até inquietar.

**Paleta de cores** tons de pele reais, luz de estúdio neutra, detalhe absoluto

**Melhores usos:** retrato, arte, produto premium

**MidJourney:** `[tema], hyperrealism, skin pores and fine detail beyond photography, Ron Mueck sculptural realism --v 6`

**LoRA (Civitai):** "Hyper Realism by aidma" (Flux, trigger: aidmaHyperrealism) — civitai.com/models/730373; "HyperRealism" (SDXL) — civitai.com/models/1865288

**Prompt universal (Seedream):** `Ultra-detailed hyperrealist painting, a hyperrealist image, silicone-perfect skin pores that outlast the photograph, every hair and blemish rendered at Chuck Close scale, the real intensified until it unsettles, 8k`

### **Illusion**

**№ 457 / 1001** · *Escher's Staircase Makes the Exit Impossible*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → MATTER ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A escada de Escher torna a saída impossível** — (1001 Aesthetics, interpretação)

Ilusão: geometria impossível, escadas que sobem para baixo, arquitetura que trai a lógica do olho.

**Paleta de cores** cinza de litografia, preto e branco de gravura

**Melhores usos:** arte conceitual, editorial, capas

**MidJourney:** `[tema], impossible geometry illusion, Escher staircase making the exit impossible, lithograph style --v 6`

**Prompt universal (Seedream):** `Ultra-crisp lithograph-style composition, an illusion image, an Escher staircase making the exit impossible, impossible geometry in lithograph grey, architecture betraying the eye's logic, 8k`

### **Labcore**

**№ 507 / 1001** · *Test tubes, protocols, bench light*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EXPRESSION ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Tubos de ensaio, protocolos, luz de bancada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Labcore: precisão científica como estética, vidro borossilicato, aço inox e coreografia de protocolo.

**Paleta de cores** branco clínico, azul nitrila, aço inox

**Melhores usos:** ciência, editorial tech, branding farmacêutico

**MidJourney:** `[tema], labcore aesthetic, test tubes and pipettes, cold bench light, clinical precision --v 6`

**Prompt universal (Seedream):** `Shot on Sony A7R V with 90mm macro lens, a labcore image, test tubes and pipettes aligned in ranks under cold fluorescent bench light, borosilicate refractions and nitrile blue gloves on brushed stainless steel, Thomas Struth laboratory formality, clinical white broken only by a pH-indicator color, protocol as choreography and precision as beauty, 8k`

### **Lattice**

**№ 519 / 1001** · *Mashrabiya screens and shadow grids*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → DENSITY ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Telas de mashrabiya e grades de sombra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lattice: privacidade projetada como padrão, cedro entalhado fatiando o sol duro em grades de sombra.

**Paleta de cores** cedro, sombra dura, interior fresco

**Melhores usos:** arquitetura, padrão, editorial

**MidJourney:** `[tema], lattice aesthetic, mashrabiya screens casting shadow grids, carved cedar geometry, hard sunlight --v 6`

**Prompt universal (Seedream):** `Shot on Leica M-A with 35mm lens on Ilford Delta 100, a lattice image, mashrabiya screens casting migrating shadow grids across a cool tiled interior, carved cedar geometry slicing hard afternoon sun into soft stars, Fan Ho light-shaft drama in Cairo stillness, privacy engineered as ornament and climate as pattern, 8k scan`

### **Line Art**

**№ 526 / 1001** · *One continuous stroke, no shading*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → DENSITY ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Um traço contínuo, sem sombreado** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Line art: economia como elegância, a figura inteira carregada por uma só linha.

**Paleta de cores** tinta preta, branco absoluto

**Melhores usos:** ilustração, logo, tatuagem

**MidJourney:** `[tema], line art aesthetic, one continuous stroke, no shading, black ink on white --v 6`

**Prompt universal (Seedream):** `Ultra-clean minimalist line drawing, a line art image, one continuous unbroken stroke carrying an entire reclining figure with no shading and no second chances, black ink on radiant white paper in the Picasso single-line lineage, Matisse economy where every curve earns its place, elegance measured by everything left out, 8k`

### **Low Poly**

**№ 533 / 1001** · *Faceted triangles, no smoothing*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → DENSITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Triângulos facetados, sem suavização** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Low poly: geometria honesta sobre a própria contagem de polígonos, planos chapados em cores de crepúsculo.

**Paleta de cores** gradientes de crepúsculo, planos chapados, facetas

**Melhores usos:** games, 3D, ilustração

**MidJourney:** `[tema], low poly aesthetic, faceted triangles, flat shading, gradient dusk landscape --v 6`

**Prompt universal (Seedream):** `Ultra-clean low poly 3D render, a low poly image, faceted triangles building a mountain landscape with deliberately no smoothing, flat-shaded planes graded through a dusk gradient from coral to indigo, a lone geometric deer standing at the treeline, early PlayStation memory refined into gallery minimalism, geometry honest about its own polygon count, 8k`

### **Naive**

**№ 589 / 1001** · *Perspective Ignored, Truth Left Intact*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↓ (ausência) → EXPRESSION ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a única entrada da lista com TECHNIQUE ↓ — definida justamente pela *ausência* de treinamento técnico: perspectiva ignorada, verdade preservada apesar disso. É a mesma lógica de Hermitcore em EXPRESSION e de Liminality em DOMAIN — a posição também precisa de um caso que a define pela falta.

**Atmosfera e mood**

**Perspectiva ignorada, verdade intacta** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Arte naif: proporções erradas com sinceridade certa, memória pintada sem escola.

**Paleta de cores** cores francas de memória, verdes e vermelhos diretos

**Melhores usos:** ilustração, folk, editorial afetivo

**MidJourney:** `[tema], naive art aesthetic, wrong perspective honest truth, untrained folk painting --v 6`

**Prompt universal (Seedream):** `Ultra-charming naive painting, a village scene with perspective ignored and truth left intact, frank memory colors laid flat without shading, Grandma Moses winter-fair sincerity, every figure loved more than measured, folk-art museum quality, 8k`

### **NASAcore**

**№ 592 / 1001** · *Engineering Discipline Becomes Visual Authority*

**Nível:** 🟤 Tertiary

**Eixo:** TECHNIQUE ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Disciplina de engenharia virando autoridade visual** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

NASAcore: salas limpas, macacões brancos, o worm logo vermelho e a estética da missão.

**Paleta de cores** branco de sala limpa, vermelho worm, azul de missão

**Melhores usos:** tech, editorial, branding

**MidJourney:** `[tema], NASAcore aesthetic, clean room white suits, red worm logo, mission documentation --v 6`

**Prompt universal (Seedream):** `Shot on a NASA-issue Nikon F4 with 28mm lens, mission documentation of a spacecraft clean room, white bunny suits and gold foil insulation under even fluorescent light, red worm logo on brushed panels, engineering discipline as visual authority, archival Apollo-era clarity, 8k`

### **Neo Impressionism**

**№ 596 / 1001** · *Optical Color Carrying Modern Emotion*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → ILLUMINATION ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Cor óptica carregando emoção moderna** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neoimpressionismo: pontos de cor pura calculados para vibrar no olho, ciência a serviço do sentimento.

**Paleta de cores** complementares puros em pontos, luz de tarde

**Melhores usos:** arte, paisagens, editorial

**MidJourney:** `[tema], neo impressionism aesthetic, pointillist divided color, optical vibration --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a neo-impressionist painting, divided pure-color dots calculated to vibrate in the eye, a riverside afternoon built from optical mixing, Georges Seurat calm engineering with Paul Signac chroma, luminous pointillist texture in razor focus, 8k`

### **New Formalism**

**№ 620 / 1001** · *Rulebook Smuggles the Rebellion*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O livro de regras contrabandeando a rebelião** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Novo formalismo: colunas e arcos modernos em mármore branco, o classicismo devolvido à era do vidro.

**Paleta de cores** mármore branco, dourado discreto, sombra de treliça

**Melhores usos:** arquitetura, institucional, editorial

**MidJourney:** `[tema], new formalism aesthetic, modern marble colonnade, classicism smuggled into the glass age --v 6`

**Prompt universal (Seedream):** `Shot on a Sinar F2 4x5 with 120mm lens, a new formalist building, slender modern colonnade and delicate marble grilles casting lattice shadows, Edward Durell Stone elegance smuggling classicism into the glass age, white stone against dusk blue, architectural print precision, 8k`

### **Photorealism**

**№ 684 / 1001** · *Reality Rendered Past Belief*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Pintura disfarçada de fotografia** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Fotorrealismo: vitrines e reflexos pintados com paciência de lente, o truque revelado só de perto.

**Paleta de cores** reflexo urbano, cromo, vidro de vitrine

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], photorealism aesthetic, painted storefront reflections indistinguishable from photograph --v 6`

**Prompt universal (Seedream):** `Museum-grade capture of a photorealist painting, a storefront window with layered reflections of the street painted stroke by patient stroke, Richard Estes chrome and glass clarity indistinguishable from a photograph until inches away, urban color in impossible painted precision, 8k`

### **Robotics**

**№ 763 / 1001** · *AI Develops Taste*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** — (não indicada na lista original)

**Atmosfera e mood**

**A inteligência artificial desenvolvendo gosto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Robótica: servos expostos e mãos precisas — a máquina passando de ferramenta a autora com critério próprio.

**Paleta de cores** branco de laboratório, alumínio, azul de sensor

**Melhores usos:** tecnologia, conceito, editorial

**MidJourney:** `[tema], robotics aesthetic, exposed servos precise hands, AI developing taste --v 6`

**Prompt universal (Seedream):** `Shot on Phase One XF with 80mm lens, a robotics still, an articulated robotic hand with exposed servos holding a single brushstroke it just chose, lab white and machined aluminum lit by sensor blue, the machine crossing from tool to author with taste of its own, immaculate detail, 8k`

### **Sartorial**

**№ 783 / 1001** · *Tailoring treated as a first language*

**Nível:** 🔴 Primary

**Eixo:** TECHNIQUE ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** nenhum movimento único precede a arte codificada de vestir-se bem; construção-sobre-ornamento e caimento-sobre-moda formam-se sem estética anterior a estender, apenas contra o problema bruto de vestir um corpo — dandismo, minimalismo e moda modesta descendem desta raiz, e nenhum pode ser rastreado acima dela.

**Atmosfera e mood**

**A alfaiataria como primeira língua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sartorial: giz no tecido, lapelas desenhadas à mão e o caimento discutido como gramática — Savile Row em detalhe.

**Paleta de cores** flanela cinza, giz de alfaiate, madeira de atelier

**Melhores usos:** moda masculina, editorial, branding

**MidJourney:** `[tema], sartorial aesthetic, chalk lines hand-drawn lapels Savile Row fitting, tailoring as first language --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad 500C/M with 150mm lens, a sartorial scene in a Savile Row fitting room, chalk lines across gray flannel as hands pin a hand-drawn lapel, workshop wood and mirrors in soft northern light, tailoring spoken fluently as a first language, meticulous fabric detail, 8k`

### **Sporty**

**№ 840 / 1001** · *Athletic Power Engineering Bodies in Motion*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → EFFECT ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a doutrina funcionalista do form-follows-work chega como pai único, e Sporty re-instrumenta essa herança vinculando-a a um único sujeito, o corpo em movimento — a lógica de prédios-e-ferramentas vira, uma geração depois, um jersey projetado para ler-se como pura capacidade.

**Atmosfera e mood**

**A potência atlética desenhando corpos em movimento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sporty: músculo em extensão plena, suor em suspensão e a engenharia do gesto esportivo congelada no pico.

**Paleta de cores** azul de pista, laranja de uniforme, branco de linha

**Melhores usos:** esporte, campanhas, editorial

**MidJourney:** `[tema], sporty aesthetic, full-extension muscle sweat mid-air peak action, athletic power in motion --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R3 with 400mm lens, a sporty peak moment, a sprinter at full extension over track blue with sweat suspended mid-air at the line, uniform orange straining against white lane geometry, the engineering of the athletic body frozen at maximum output, explosive frozen clarity, 8k`

### **Survivalcore**

**№ 874 / 1001** · *Gear, grit, and plans for when everything fails*

**Nível:** 🟣 Secondary

**Eixo:** TECHNIQUE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** o sublime selvagem do Romantismo fornece o pai único, e Survivalcore re-instrumenta essa herança cobrando competência como preço de entrada — mantém a reverência e subtrai a contemplação.

**Atmosfera e mood**

**Equipamento, garra e planos para quando tudo falhar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Survivalcore: mochila organizada por cenários, faca afiada à luz de headlamp e a autossuficiência praticada como religião.

**Paleta de cores** verde-oliva, laranja de sinalização, cinza de pederneira

**Melhores usos:** outdoor, editorial, conceito

**MidJourney:** `[tema], survivalcore aesthetic, scenario-packed rucksack knife by headlamp, self-reliance as religion --v 6`

**Prompt universal (Seedream):** `Shot on Pentax K-3 III with 21mm lens, a survivalcore camp at dusk, gear laid out in disciplined grid beside a tarp shelter as a headlamp beam checks the knife edge, olive drab and signal orange against flint gray woods, plans stacked for the day everything fails, rugged practical detail, 8k`

## Leitura do padrão — o que as 36 estéticas confirmam

Dá pra ver um sistema bem definido em TECHNIQUE, e ele é o mais "artesanal" dos cinco já mapeados (INTEGRITY = lei em escala; DOMAIN = território fechado; SYNERGY = acoplamento entre diferentes; EXPRESSION = sinal único e não-corrigível). Aqui a lógica é outra: **o "como foi feito" É o conteúdo visível** — exatamente o par esquadro/compasso do glifo, verificação (o que É) e projeção (o que PODE SER) fixados num único ponto de trabalho.

**O núcleo comum:** nenhuma dessas 36 estéticas é sobre "ter uma habilidade" em geral — todas são sobre execução cuja maestria fica **nua na superfície**, verificável de perto, sem precisar de legenda. Removida a evidência da técnica, a estética desaparece (não sobra "conceito" nenhum por trás).

**Os clusters visíveis:**

**1. Corpo treinado — a técnica vivendo no músculo, não na teoria.**

Sporty, Boxing, Equestrian, Choreographic, Adrenaline. Aqui a prova é o gesto econômico e sem correção — "Twelve rounds written in rope and sweat" é literalmente o Fazer sem discurso. Adrenaline é o caso-limite: risco pago em dinheiro pela competência de quem sabe exatamente onde está o limite.

**2. Ofício — a mão exata, o corte que não perdoa.**

Haute Couture ("Twenty Pins Hold the Bodice"), Sartorial, Gentlemen's (Savile Row), Handcrafted ("Drawknife Mark the Sander Was Told to Leave"), High Renaissance (spolvero de Raphael). Todos fazem a técnica de alfaiataria/desenho virar a própria linguagem — Sartorial chega a dizer isso na tese: "tailoring treated as a first language."

**3. Rigor científico/tecnológico importado como autoridade visual.**

BioTech, Algorithmic, Robotics, Early Cyber, NASAcore, Hypermodern, o próprio 04 MATRIX (primordial). O laboratório, o compilador, a engenharia aeroespacial — o método da ciência exata emprestado para produzir credibilidade estética. NASAcore nomeia isso quase literalmente: "Engineering Discipline Becomes Visual Authority."

**4. Sistema gerado por regra reduzida ao mínimo.**

Geometric Abstraction (o quadrado negro de Malevich), Low Poly, Line Art, Lattice (mashrabiya), New Formalism, o próprio 09 AXIOM e 05 VERTEX (primordiais). Aqui a técnica não é gesto manual — é regra que se auto-executa: uma fórmula tão exata que dispensa a mão depois de escrita.

**5. Ilusionismo — a maestria usada para enganar o olho ou empurrar o real além da crença.**

Photorealism, HyperRealism (poros de silicone do Ron Mueck), Illusion (a escada de Escher), Diorama, Neo Impressionism. Técnica aqui prova a si mesma ao produzir algo que não deveria ser possível a olho nu.

**O caso negativo, que confirma a regra (↓ = ausência):** Naive é a única entrada com TECHNIQUE ↓ — e faz sentido perfeito. Naive existe *precisamente* pela ausência de treinamento técnico: perspectiva ignorada, verdade preservada apesar disso ("Perspective Ignored, Truth Left Intact"). É a mesma lógica do Hermitcore em EXPRESSION e da Liminality em DOMAIN — a posição também precisa de um caso que a define pela falta.

**O que isso confirma sobre o sistema:** TECHNIQUE não é "artesania" nem "expertise" como rótulo genérico — é qualquer estética cuja identidade visual só se sustenta se a execução resistir a uma inspeção de perto: o ponto de costura, o polígono da malha, a linha de código, o gancho no boxe. Por isso Haute Couture, NASAcore e Low Poly convivem na mesma posição — agulha, foguete e triângulo renderizado são objetos de natureza completamente diferente, mas todos passam pelo mesmo teste: *a tolerância foi cumprida, e o quadro prova isso sem precisar de legenda?*

⁠

# THEME — o Sol

<aside>
☀️

**Essência:** THEME é a força da posição conceitual recorrente — o centro que permanece enquanto tudo o mais gira ao redor. Seu ideograma é o ouro dos alquimistas, ☉: um círculo com um único ponto dentro, o metal que não corrói, o único glifo do sistema simples o bastante para ser traçado num só gesto. Sua física é a quebra espontânea de simetria: a agulha equilibrada na ponta contém todas as direções ao mesmo tempo e por isso não existe — no instante em que cai para um lado, um mundo começa. Sua ótica é o rack focus: nenhuma lente segura tudo de uma vez, então a mão gira o anel, um plano se resolve e todo o resto recebe permissão para virar um desfoque bonito e luminoso. Dois verbos habitam o Sol: **Harmonizar** — segurar forças contrárias em interferência produtiva, porque matar qualquer um dos lados mata a obra — e **Nutrir** — sustentar a vida da obra e de quem a faz por ritmo, pausa e estação. Na imagem, THEME se prova quando um único motivo mantém o quadro inteiro em órbita e um plano foi visivelmente escolhido sobre todos os outros.

**Leitura das setas nesta seção: ↑ = presença do elemento (amplificado) · ↓ = ausência do elemento (suprimido).**

</aside>

## Prompt-mestre (imagem-síntese)

> **↑ THEME — universal prompt.** A figure or object settled at the exact centre of a room organized entirely around it — everything else oriented toward that point without anyone looking directly at it, weight settled evenly or in one unforced contrapposto, breath low, hands quiet and fully visible, engaged with or resting near [the aesthetic's own recurring object or material] — the same motif repeating at three scales and in three different materials, once as a small detail, once at mid-scale, once in the architecture itself; a single plane held sharp — the face, the hand, the one object — while the rest of the depth surrenders into soft, luminous, never-dark bokeh, shot wide open so the blur reads as a gift rather than a loss; one broad, warm, low-contrast light source filling the room rather than carving it, one hour and one palette governing everything, drawn from [the aesthetic's own slow, seasonal matter: wood, cloth, clay, metal, stone] with exactly one accent colour breaking the base and nothing else competing; a signature garment or object worn identically across the frame — one base silhouette, one accent, one totem carried until it needs no explanation; a second figure, if present, angled fractionally toward the centre and softer in focus, never staring at it directly; generous open space left around the anchor so the emptiness reads as a decision; one visible act of exclusion — a direction chosen, three things visibly forgone — proving the frame committed rather than hedged; the room itself bearing evidence that the centre governs even where it is absent — a cushion still holding a shape, a cup still warm, a chair angled toward a point nobody currently occupies.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre):

> No two equal focal points, no motif repeating fewer than three times or degrading into decorative wallpaper, no hedged or undecided direction, no hard raking key or chiaroscuro, no deep or dead-black shadow, no second competing accent colour, no balanced three-colour palette, no cleared white studio with nothing to orbit, no rented location with no wear, no object that could belong equally to another world, no restless or scanning gaze, no figure or room that hedges between worlds, no everything-equally-sharp frame that has chosen nothing.
> 

### Como adaptar o prompt a cada estética

**Como usar para qualquer uma das 12 estéticas da lista:** troque só o vocabulário entre colchetes pelo material específico da estética — nada na arquitetura do prompt nomeia um lugar, tribo ou estilo, só os mecanismos universais que a página já define como THEME (um motivo em órbita em três escalas, um plano só escolhido, luz que nutre em vez de cortar, um objeto/uniforme repetido, o ato de exclusão visível). Por exemplo:

**English Country / Pastoral** → motivo: a cena pastoral repetida (flor, ovelha, sebe); matéria: lã, madeira, terra.

**Dark Western / Gothic II** → inverter para a luz única suprimida (ILLUMINATION ↓): a mesma estrutura de centro, mas a luz vira vela/janela isolada em vez de banho amplo.

**Art Hoe / Kidcore** → motivo: a cor/objeto-bandeira única (amarelo cádmio, o arco-íris); matéria: tinta, tecido reciclado.

**Dystopian / Cli-Fi** → motivo: o aviso/objeto que resume a tese (a linha d'água, o cartaz); matéria: concreto, plástico degradado.

**ARTivism / Young Poland** → motivo: o emblema nacional/político único; matéria: tinta de spray, vidro, madeira entalhada.

## Fundamentos do elemento

**Identity.** Strength of the recurring conceptual position — the centre that holds while everything else turns. Its ideogram is the alchemists' gold: a circle with a single point inside it, ☉, the metal that does not corrode and the only glyph in the system simple enough to be drawn in one stroke. Its physics is spontaneous symmetry breaking: a needle balanced on its tip holds every direction at once and therefore does not exist, and the moment it falls one way a world begins. Its optics is the rack focus: no lens holds everything at once, so the hand turns the ring, one plane resolves, and everything else is permitted to become a beautiful blur. Two verbs occupy the sun. **Harmonizar / Attuning**, holding contrary forces in productive interference because killing either side kills the work, and **Nutrir / Nurturing**, sustaining the life of the work and of whoever makes it through rhythm, pause and season. Behind them two forces set the terms without entering the frame as themselves: proportion read as a law of growth rather than an ornament, and light administered in phases rather than spent all at once. In an image this element is proven when one motif holds the entire frame in orbit and one plane has visibly been chosen over all the others. (Distinct from EFFECT, 7 — there the circle falls away and the centre is released into the field; here the centre is still contained. Distinct from INTEGRITY, 1 — the pillar proves one logic across scales, the sun proves one subject across time. Distinct from COHERENCE, 19 — the knot is one line crossing itself, the sun is one point everything else circles.)

**The choice made visible.** The failure state of this element is a frame that kept all its options open — a body that could belong to three worlds, a room that hedges between two eras, a palette that refuses to pick. Every THEME frame must contain one visible act of exclusion: a single decisive asymmetry inside an otherwise ordered field, one direction the whole composition has committed to, one thing chosen and three things visibly forgone. Vapour is free and nobody admires it; the crystal is rigid and it is what the eye trusts. Photograph the crystal.

**Exclusion made optical.** The rack focus is not a mood, it is this element's signature mechanism. One plane holds true — a face, a hand, a single object on a table — and the rest of the depth surrenders into soft round bokeh without ever going dark. Shoot wide open, and keep the discarded planes *luminous* rather than black: the blur is what was given up, and it must look like a gift rather than a loss. A THEME frame where everything is equally sharp has not chosen anything.

**Orbit at three scales.** One motif repeats across the frame at three different magnitudes and in three different materials — the same circle as a button, as a woven medallion, as the courtyard's cobble ring; the same arc as an eyebrow, a chair back, a doorway. The repetition is never decorative pattern; it is gravity. Three scales is the working minimum: two reads as coincidence, four begins to read as wallpaper.

**Density over volume.** Presence here is measured in weight, not in noise. The figure occupies the smallest amount of physical space in the frame and still governs it, because everything else — furniture, light path, secondary figures, the fall of a curtain — is oriented toward that point without anyone looking directly at it. Nothing in a THEME frame shouts. If a body has to gesture to be found, the centre was not real.

**The centre that does not tire.** Nutrir is the slow half of this element and it is photographable: seasonal material caught at its own pace, a repeated daily object worn smooth at the exact point it is held, food or drink at the temperature a body actually wants, a pause treated as an event rather than a gap. Warmth without heat, care without policing. The shadow to avoid is care turned into siege — a room so tended it forbids anything harder from entering.

**Light that opens rather than carves.** The crescent of Ur is read here in its ascending register: light governed in phases, never spent all at once, and never used to cut. THEME does not do chiaroscuro — that is EFFECT's corridor, and it produces dread. Here the source is broad, warm and low in contrast, filling the room instead of sculpting a face out of a void, so the frame reads as nourishment rather than tension. Shadow exists, but it stays open, transparent and legible to the eye.

## Corpo — postura, olhar e gesto

**Model posture & structure.** The body of someone who has already decided and is no longer negotiating. Weight settled evenly or in one unforced contrapposto, spine long without military effort, shoulders wide and dropped, breath visibly low in the torso — the minimum-energy state of a system that has stopped spending force to hold its own position. Stillness is the default and it is dynamic, not frozen: this body could move and is choosing not to. Hands are quiet and fully visible — resting flat on a surface, holding one real object, folded loosely at the waist — never hidden, never self-adapting, never checking their own effect. The face is at rest and costs nothing to hold; a mask leaks through over-justifying micro-movement, and the leak is the single most legible failure this element produces. Where a second figure appears, they are angled fractionally toward the centre and slightly softer in focus, so the room's hierarchy is stated without anyone performing rank.

**Gesture.** Two verbs, alternating, never blended in one frame.

**Harmonizar · Attuning.** Two opposed facts held in one body without either one being killed: a hard tailored shoulder above an open unguarded face, a monumental garment worn with total ease, an austere room with one warm living thing in it. Photographed, it is a body positioned exactly at the junction of the two forces — half in the warm plane, half in the cool one; one hand on stone, one on cloth — with an expression that resolves neither. The shadow is surface harmony: conflict smoothed away until the image is merely pleasant. Keep the tension visible and unresolved; the balance is the content, not the peace.

**Nutrir · Nurturing.** The tending gesture, done slowly and for no audience: hands turning something on a stove, watering, folding, sanding, feeding, pouring, waiting. The gaze goes down into the task, absorbed. The object being tended is one that will still be here next season. The shadow is the demonstrative version — care performed toward the lens, the hands held up so the caring can be admired.

Forbidden in both: the presentational arm, the garment displayed to the camera, and any gesture that would look identical in a second frame. Both verbs must look repeatable as a life and unrepeatable as a photograph.

**The look — how the eyes behave.** Two admissible modes, both low-arousal. **Anchored:** level into the lens, blink rate slow, no head tilt, mouth at rest with the corners neither lifted nor pressed — the gaze of someone who is not asking to be looked at and is not troubled by being seen. It reads as warmth without invitation, held about two seconds past the point most people break. **Orbital:** eyes down and into the task, or out to a point roughly forty-five degrees off the lens, absorbed in something the frame does not show — the attention of someone whose subject is elsewhere and permanent. Banned in both: the upturned chin seeking approval, the raised inner brow of appeal, the darting check, performed intensity, and the smile that arrives after the eyes have already committed.

## Regras de imagem — do figurino à prova de órbita

**Look & styling continuity.** The wardrobe is a signature uniform, and it is built in four parts. **The base (roughly 80% of the frame):** one garment or silhouette the wearer would put on every day — the same coat, the same collar, the same trouser line — recurring identically across the whole series so the figure becomes recognisable by outline alone. **The accent (roughly 20%):** exactly one element that breaks the base and carries the charge — a colour, a scarf, a shoe, a piece of hardware. **The totem:** one object worn or carried in every single frame until it stops needing explanation — a ring, a pair of glasses, a cuff, a watch, a fan. **The exclusion list:** three things this world never admits, and their absence should be legible to anyone who knows the register. Materials are slow: cloth that ages well, leather that records the hand, wood, wool, unlacquered metal, patina earned at the exact points a body actually touches. Refused: trend markers, competing focal points, anything that photographs better than it wears, and any second accent competing with the first.

**Camera.** One lens, one distance, one height — repeated. The signature is the framing itself, so the camera behaves like a fixed law rather than an opinion: a normal-to-short telephoto (50mm to 85mm equivalent) at conversational distance, held at the subject's own heart-to-eye level, never above and never below. Aperture wide open, f/1.4 to f/2.8, because the shallow plane is the element's whole argument — one thing chosen, everything else honoured in blur. Available light is the native register; the exposure is generous rather than protective, so shadow stays open. The camera is still: no handheld tremor, no restless reframing, no dutch tilt. Where the image moves, it moves as a single slow push or a single rack — one focus change from the periphery to the centre, or the reverse, done once and not repeated. Across a series the frame does not vary; only the season, the garment and the light do. That constancy is the argument.

**Composition.** Concentric, not linear. Build the frame in four rings the eye can read from the inside out: the **centre** (the anchor — one figure, one object, one point of stillness placed slightly off geometric centre so the eye keeps returning rather than settling); the **ring** (the immediate matter the centre governs — the table, the tools, the second figure, the near fold of cloth); the **focus** (the one visible act of choice — the plane held sharp, the single asymmetry, the one accent colour); and the **field** (the space the presence has reorganised — furniture angled inward, a light path bending toward the anchor, distant figures oriented without staring). Verticals stay plumb and horizontals stay level, so nothing in the geometry competes with the one intentional break. Generous open space around the anchor: the composition must have room to breathe, and the emptiness must read as a decision rather than a shortage. Forbidden: two equal focal points, a second thing worth looking at, and any element pointing away from the centre.

**Lighting.** One broad warm source, low in contrast, entering the room the way daylight actually enters it — a large window, an open door, a sky reflected off a pale wall, late-afternoon sun filtered through white cloth. The key sits high and wide rather than tight and raking; fill comes from the room's own bounce rather than a second unit, so a single light logic covers the entire depth of field. Falloff is slow and continuous, from the anchor outward to a periphery that stays luminous even where it goes soft. One hour governs the whole frame — the angle and temperature agree everywhere, because a room that contradicts its own hour has no centre. Where the light must be governed in phases, govern it by *withholding brightness*, never by adding darkness: a plane left dimmer, never a plane cut to black. Refused: hard raking key, chiaroscuro, deep shadow, dramatic backlight, theatrical vignette, coloured gels crossing the frame, on-camera flash, and any second source of a different temperature.

**Beauty detail.** The face is the fixed point, so the grooming is built once and never varies across the series — the same finish, the same intensity, the same silhouette, whatever the garment does. Skin is the constant: hyper-hydrated and translucent, cream product rather than powder, a real sheen at the temple and the top of the cheek, true pore texture and the tone's own depth left legible rather than smoothed toward an average. No mattifying powder, no heavy coverage, no hard contour carving the face into planes. One feature only is loaded — either the eye or the mouth, never both — and that rule holds across the entire body of work even as the palette shifts. Where the eye is chosen: soft brown-taupe or gloss-textured transparent shadow that catches light like water, no hard geometric line, brows in their real growth pattern. Where the mouth is chosen: a velvety saturated lip carrying the accent colour, or a bare hydrated lip with no drawn contour. Blush is honey or peach, warm and diffused, placed to read as circulation rather than as pigment — massage the face by hand before the shutter so the flush is genuinely the body's. Hair is one repeatable silhouette, groomed to hold its shape without lacquer, moving as real hair moves. The whole face must survive being read from across a room and again in close crop with nothing changing between the two distances.

**Cenography.** A real, inhabited, load-bearing room the figure clearly did not visit — build the ceiling nobody intends to photograph, because a body answers a real wall differently than a painted flat. The set is organised heliocentrically: one anchor object too heavy or too permanent to move (a table, a hearth, a stone basin, a single chair, a loom), with everything else arranged in orbit around it and the wear paths on the floor proving the orbit is real. The motif recurs at three scales somewhere in the architecture, in three different materials. Zones stay separate: the working zone, the resting zone, and one sanctuary corner holding the few objects this world treats as precious. Seasonal evidence is mandatory and physical — fruit at its actual ripeness, a fire actually burning, cloth actually drying, a plant at a real stage of its year — because Nutrir cannot be implied. All aging is genuine: hand-worn thresholds, oiled handles, a cushion holding the shape of a body. One warm living element is always admitted, even into the most austere room. Refused: the cleared white studio (no centre to orbit), the rented location with no wear, decorative props nobody touches, three eras sharing one room, and any object that could belong equally to another world.

**Colour.** One temperature, one hour, one dominant family across the whole frame — warm, oxygenated, with the light visibly moving *through* the colour rather than sitting on it. Draw the palette from the world's own slow matter (clay, wheat, honey, oiled wood, unbleached linen, patinated brass) and hold it until it becomes the signature a reader could identify from a swatch alone. Against that family, exactly one accent — the 20% — carried by a single element and repeated in the same value across the series. Saturation stays mid-range and continuous; contrast stays gentle, because a colour break is a second focal point and this element permits only one. Refused: the balanced three-colour palette, cold neutral greys, desaturated somber grading, and any hue arriving from another hour.

**Orbit proof.** Wherever the composition allows it, plant one device that shows the centre governing without asserting itself: a second figure whose body is angled toward the anchor while their eyes are elsewhere; the same motif caught at a third scale in a reflection; steam or dust bending along the path the anchor's warmth makes; a doorway framing the anchor from the next room. The strongest version is the impregnation proof — evidence the centre remains after the body leaves: the cushion still holding a shape, the cup still warm, the tool set down mid-task, the room reorganised around a chair nobody is sitting in. A frame in which the room has *not* answered the centre is the single most legible failure this element can produce.

**The sensory field.** THEME is the only element whose signature is expected to register beyond the eye, so build the other senses into the frame as physical evidence: a sound implied by a visible source (a kettle, a needle, rain on one window, a room quiet enough that quietness is the fact); a scent implied by a real material (resin, citrus peel, wool, woodsmoke, wet stone); a texture the hand in frame is actually reading; a taste offered by something genuinely edible and genuinely ready. Each one must be traceable to an object the camera can see. Atmosphere with no visible cause is decoration, and decoration has no centre.

## Linhas de praticantes prontas para prompt (dos códices)

*Camera.* Louise Dahl-Wolfe — on-location natural daylight with a reflector fill card holding shadows open, warm ochre-and-turquoise palette sustained season after season, the model given an implied activity rather than a pose. Aldo Fallai — Renaissance-inflected soft directional light, muted earth tones, unhurried noble stance, one visual identity fed campaign after campaign until house and photographer are indistinguishable. Gilles Bensimon — bright saturated light, approachable rather than aloof expression, one accessible-beauty motif relayed consistently across an enormous body of work. Leslie Zhang — one lush classical motif sustained across a whole era, soft painterly light, theatrical craft props, tender dignified casting. Joshua Woods — warm filmic colour, neighbourhood and family settings, nostalgic light used in a present-tense scene.

*Face and hair.* Lucia Pieroni — translucent hyper-hydrated skin as the unmoving centre, gloss-textured transparent shadow reflecting like water, soft peach blush, bare unlined lips, impressionist luminosity under soft natural light. Tom Pecheux — the one-feature rule held for decades: smoky eye or red lip, never both loaded at once, clean skin, cinematic continuous lighting, unforced confidence. Gucci Westman — cream illuminator placed to mimic clean sweat sheen, honey-peach flush, hydrated unlined lips, intense direct natural light revealing true pore texture. Mary Greenwell — soft brown-taupe smoky eye with no hard lines, velvety naturally radiant skin, lip matched to the true undertone, hand massage before application so the blush is real circulation. Fulvia Farolfi — impeccable polish held to the same standard across every campaign, shadowless dignity, monumental calm.

*Room.* Gideon Ponte — the fully built interior with a real ceiling and real doors, hand-aged patina, directional window light produced by real geometry at a real hour. Mary Howard — the hand-painted infinite ground in one graduated warm neutral, mixed to absorb light without glare, the same painted family returning across decades. Randall Peacock — one monolithic vocabulary refined season after season rather than reinvented, proportion tuned until room and garment read as a single design language. Emma Roach — restrained portraiture-scaled staging, a draped frame the eye passes *through* rather than looks at, environment built to support the mood instead of announcing it.

*Styling.* Marie Chaix — one wardrobe held across every collaborator: generous texturally rich wool overcoats, jersey that follows the body's real movement, oversized men's tailoring on a female frame, palette restricted to navy, chocolate, ice and olive, no loud jewelry, soft natural light, unhurried everyday movement; elegance built from cut rather than exposure. Olivier Rizzo — the same fixed centre played cold: shrunken ribbed knitwear, rigid tailored shorts over black knee socks, narrow tubular shoulders, worn white canvas sneakers, every logo and ornament stripped, cold continuous studio light on an empty grey set, arms held rigidly at the sides. Tonne Goodman — a uniform that has not moved in four decades (pressed white shirting, rigid dark straight denim, navy blazer with gold buttons, polished loafers, zero jewelry), kept alive by real outdoor motion: wind-textured hair, a model striding or running through a genuine street or beach under direct sun. Marion Niquet — the single-subject discipline: one subject given an entire issue's attention, personal style curated and intentional, patience itself as the visual register.

*Motion and staging.* Tim Walker — the green screen banned before the budget conversation, because only a real surface throws the shadow that convinces the eye; build at full scale or rewrite the brief, saturated pastel palette, wide-angle distortion of a handmade set, choreographed rather than posed performance. Grace Coddington — draw the arc by hand before the camera is loaded, build the set for real rather than in post, let wind and rain act on the fabric as the most honest art directors alive, cast a character mid-story instead of a model mid-pose, and defend the negative space against the crop, because that is where the reader dreams.

*Ensemble warmth (when the centre is a world rather than a person).* Bruce Weber — one warm motif fed across a lifetime instead of declared once, ensemble casting including animals, relaxed communal interaction proving the world is inhabited rather than staged. Tyler Mitchell — warm protective sunlight, idyllic outdoor setting, vibrant pastel and primary colour at full saturation, leisure props that argue for the right to ease. Micaiah Carter — warm seventies palette, soft nuanced light, nostalgic family-album framing, tender nurturing contact between subjects.

**The two registers.** The Sun admits a warm register and a cold one, and both are legitimate as long as the centre does not move. The warm register (Dahl-Wolfe, Fallai, Weber, Mitchell, Pieroni, Westman, Greenwell, Chaix) nourishes: broad low-contrast light, real rooms, seasonal matter, contact between bodies. The cold register (Rizzo, Pecheux, Farolfi) governs by subtraction: continuous even studio light with no shadow event, an empty set, an unbroken rule held for decades, a body at rest with arms at the sides and an expression that performs nothing at all. What both refuse is drama — the warm register refuses it by filling the room, the cold register by emptying it. Choose one per series and do not mix them inside a single frame.

**Set law, from the codices.** One motif governs every frame; without the sustained subject, brilliance is only noise. As the leading element, the still centre is literal: the figure dead-centre and sharp while the world blurs, or one colour, one object, one law recurring across all twelve pages. As the supporting element, the set is subordinated to the motif — every prop keyed to the single idea, the camera returning to the same axis like a compass needle. Composition is radial and centred, the point-in-circle made literal; one dominant source acts as the sun, every exposure keyed to it, and fill is forbidden to compete. Casting is fixed by structure, not preference: a THEME lead takes one model only, locations may change and the motif may not. Motif discipline governs the series — the chosen sign recurs on every page (woven, printed, carried, or cast as a shadow), one support may repeat, nothing else does. Direction calls, said aloud on set: for Harmonizar, *"you are the tuning fork — don't move, let the room match you"*; for Nutrir, *"the other figure eats first."* And the kill switch: swap the location for a neutral one. If the images still work, the centre never led — rebuild it.

**Optical variant — the orbit made visible.** An anamorphic lens turns the law into physics: the figure dead-centre and surgically sharp while the background compresses and visibly curves at the frame edges, bokeh going oval instead of round, a real dusk street bending around one perfectly still body. Peripheral distortion is the orbit rendered optically, and the stillness at the centre is what makes the bending readable.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** One motif in orbit at three scales and three materials; a single plane chosen and everything else surrendered to luminous bokeh; one broad warm source, one hour, one palette family with a single accent; a settled minimum-energy body governing a room that is angled toward it; seasonal matter caught at its own pace; a signature uniform recurring identically across the series; a totem object; and one visible act of exclusion.

> **↑ Prompt.** A worn kitchen at late afternoon, a single tall window filling the whole room with broad warm light and no hard shadow anywhere, one figure standing still at a heavy oak table that has clearly never been moved, weight settled evenly on both feet, shoulders wide and dropped, wearing the same unlined wool coat and open collar they wear in every frame of the series with one saffron scarf as the only accent and a plain brass ring on the working hand, one hand resting flat on the wood and the other slowly turning a copper pot on the stove with the absorbed downward gaze of someone tending something that will still be here next season, the same circle repeating at three scales — the coat's horn button, a woven medallion on the scarf, the ring of the copper pot rim — shot at 85mm wide open so the pot rim and the hand hold true while the whole room behind melts into soft luminous bokeh that stays warm and never goes dark, camera at the subject's own heart level and perfectly still, translucent hyper-hydrated skin with real sheen at the temple and true pore texture, honey-peach flush that reads as circulation, the mouth left bare and the eye left soft with brows in their real growth, palette held to clay, wheat, honey and oiled wood with the saffron as the single break, quinces ripening in a bowl and steam bending along the warm air the stove makes, the chair beside the table still holding the shape of a body, generous open space around the figure, nothing in the frame competing for the eye and everything in the room angled quietly toward the point where the figure stands.
> 

> **↑ Negative line.** No chiaroscuro, no deep shadow, no dramatic backlight, no dark background, no theatrical vignette, no hard raking key, no second light source of a different temperature, no on-camera flash, no clinical digital sharpness across the whole frame, no cold desaturated grading, no balanced three-colour palette, no second accent colour, no second focal point, no cleared white studio, no rented untouched location, no decorative unused props, no trend-coded garments, no presentational arm or garment shown to the lens, no tension, brooding or performed intensity, no upturned chin, no hidden or fidgeting hands, no restless handheld camera, no dutch tilt.
> 

**↓ Suppressed — repertory.** No centre and no commitment: nothing repeats, every plane equally sharp, no chosen direction, a palette that hedges, a body that could belong to three worlds at once, and a room in which no object outranks any other.

> **↓ Prompt.** An open field under a flat white sky, a figure in unpatterned clothing carrying nothing and wearing nothing they could be recognised by, weight shifting mid-step and gaze scanning past the frame, every plane from the nearest grass blade to the far treeline rendered equally sharp so nothing has been chosen, no two shapes in the frame alike, no motif recurring anywhere at any scale, no accent colour and no dominant family, no anchor object, no wear path, no seasonal evidence, nothing in the landscape oriented toward the figure and nothing in the figure oriented toward the landscape, the composition held together only by the horizon.
> 

> **↓ Negative line.** No recurring motif, no shallow plane or bokeh, no anchor object, no orbit, no signature uniform or totem, no single accent, no sustained palette, no seasonal matter, no impregnation evidence, no settled governing stillness.
> 

## Estéticas relacionadas a THEME (A–Z)

As 12 estéticas classificadas sob THEME, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary), eixo secundário e polaridade (XX — continuidade · XY — disrupção).

**Leitura das setas: ↑ = presença do elemento · ↓ = ausência do elemento.** Todas as 12 estéticas são THEME ↑ (presença) — esta é a única seção sem nenhum caso de elemento suprimido; em Dark Western e Gothic II, a seta ↓ aparece apenas no eixo secundário (ILLUMINATION ↓, ausência de luz farta).

### **Ageism-Resistance**

**№ 034 / 1001** · *Authority wears architectural eyewear*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → DOMAIN ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Autoridade usa óculos arquitetônicos** — (1001 Aesthetics, interpretação)

Envelhecer com estilo e poder: cabelos grisalhos assumidos, moda statement, a estética advanced style.

**Paleta de cores** grisalho prateado com cores statement (vermelho, cobalto, mostarda)

**Melhores usos:** editorial, campanhas, retratos

**MidJourney:** `[tema], advanced style fashion editorial, stylish elderly icon --v 6`

**Prompt universal (Seedream):** `Fashion editorial portrait shot on Canon R5 with 85mm f/1.4 lens, a silver-haired elder in a bold color-block designer outfit and architectural eyewear, confident direct gaze, crisp studio light with sculpted shadows, cobalt and mustard accents against pure gray, advanced style icon energy, magazine cover quality, 8k`

### **Art Hoe**

**№ 059 / 1001** · *Cadmium yellow carried like a flag*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Várias linhagens distintas se trançam aqui — história da arte de museu, vestido vintage de brechó e autocuradoria nativa de plataforma — e remover qualquer uma impede as demais de produzir o resultado: recombinação, não reinterpretação de uma única matriz.

**Atmosfera e mood**

**Amarelo cádmio carregado como bandeira** — (1001 Aesthetics, interpretação)

Estética art hoe: girassóis, Van Gogh, macacão manchado de tinta, criatividade vestida.

**Paleta de cores** amarelo cádmio, verdes, tons de pele diversos

**Melhores usos:** lifestyle, redes sociais, ilustração

**MidJourney:** `[tema], art hoe aesthetic, sunflowers and paint --v 6`

**Prompt universal (Seedream):** `Bright lifestyle portrait shot on 35mm f/2 lens, a young artist in paint-stained overalls surrounded by sunflowers and Van Gogh prints, cadmium yellow everywhere, golden window light on canvases and brushes, authentic creative mess with tumblr-era charm, warm joyful grading, 8k`

### **ARTivism**

**№ 063 / 1001** · *Stencil dry before the sirens*

**Nível:** 🟣 Secondary

**Eixo:** THEME ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** Uma única tradição-mãe — o cartaz político e a gráfica de protesto — é levada adiante intacta e redirecionada para a intervenção direta de rua: o vocabulário sobrevive, só o propósito e o lugar são reescritos.

**Atmosfera e mood**

**Expressão criativa como ação política** — (1001 Aesthetics, interpretação)

Arte-ativismo: murais, cartazes e intervenção urbana carregando uma mensagem.

**Paleta de cores** alto contraste — vermelho, preto, branco

**Melhores usos:** causas, murais, campanhas

**MidJourney:** `[tema], artivism protest mural, political street art --v 6`

**Prompt universal (Seedream):** `Documentary photograph shot on 28mm lens, a monumental protest mural on a city wall, bold high-contrast red black and white imagery, raised fists rendered in dripping spray paint, passersby dwarfed below, overcast urban light, urgent political street art energy, 8k detail`

### **Cli-Fi**

**№ 161 / 1001** · *Wet-bulb line rendered as plot*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Enredo de ficção científica, ciência climática e realismo documental convergem; sem a ciência o enredo perde a restrição, sem o aparato ficcional resta só um relatório — recombinação, não revisão de uma única matriz.

**Atmosfera e mood**

**A linha de bulbo úmido virada enredo** — (1001 Aesthetics; código: MidLibrary, match aproximado)

Ficção climática: cidades semi-submersas, céu de calor extremo, adaptação humana em paisagem alterada.

**Paleta de cores** laranjas de calor, cinzas de fumaça, azul de enchente

**Melhores usos:** sci-fi, capas, conceitual

**MidJourney:** `--sref 3686306686 --sw 1000` (Romantic Dystopian Haze — match aproximado)

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a climate-fiction scene, half-submerged city skyline under an extreme heat sky, survivors poling through flooded streets amid smoke haze, heat-orange sun against floodwater blue, plausible near-future drama with Blade Runner 2049 scale, cinematic atmospheric grading, 8k production still`

### **Dark Western**

**№ 201 / 1001** · *Desert returns the verdict*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → ILLUMINATION ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A seta ↓ está no eixo secundário: a luz aqui é escassa e sentenciadora — o deserto como fonte única que julga em vez de revelar —, invertendo o banho amplo e farto típico do Sol. O centro (THEME) continua em presença plena.

**Atmosfera e mood**

**O deserto devolve o veredito** — (1001 Aesthetics, interpretação)

Faroeste sombrio: silhueta de pistoleiro contra céu de tempestade, poeira e couro gasto, moralidade em ruínas.

**Paleta de cores** ocres queimados, preto, céu de chumbo

**Melhores usos:** cinema, personagens, capas

**MidJourney:** `[tema], dark western, grim gunslinger under storm sky --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a dark western scene, grim gunslinger silhouette against a storm-lead sky, dust devils and worn leather in burnt ochre light, the desert delivering its verdict, brutal frontier morality with The Proposition grading, cinematic grain and haze, 8k production still`

### **Dystopian**

**№ 251 / 1001** · *Warning that predates the wreckage*

**Nível:** 🟣 Secondary

**Eixo:** THEME ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O aviso que precede o escombro** — (1001 Aesthetics; código: MidLibrary)

Distopia: cidade vigiada em ruína parcial, propaganda desbotada, futuro que deu errado como alerta.

**Paleta de cores** cinza-concreto, verde-doentio, vermelho de alerta

**Melhores usos:** sci-fi, narrativa, capas

**MidJourney:** `--sref 1651909103 --sw 1000` (catalogado no top 25 Most Dystopian da MidLibrary)

**LoRA (Civitai):** "Dystopian Dreamcore" (SD 1.5) — civitai.com/models/1057870

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a dystopian cityscape, surveilled half-ruined metropolis with faded propaganda posters, sickly green haze over concrete grey, alarm-red accents blinking through smog, the warning that predates the wreckage, Children of Men grading, 8k production still`

### **English Country**

**№ 288 / 1001** · *Foxgloves Cut From the Lane That Morning*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Dedaleiras cortadas da estrada naquela manhã** — (1001 Aesthetics, interpretação)

Campo inglês: chintz florido e cães na poltrona, jardim que entra pela casa, conforto herdado sem esforço.

**Paleta de cores** rosa de chintz, verde jardim, creme antigo

**Melhores usos:** interiores, lifestyle, editorial

**MidJourney:** `[tema], English country house style, chintz florals, fresh-cut foxgloves --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 with 35mm lens, an English country interior, chintz florals and dogs on the armchair by window light, foxgloves cut from the lane that morning in a jug, chintz pink and garden green, inherited effortless comfort, World of Interiors warmth, 8k`

### **Gothic II Romantic Gothic**

**№ 390 / 1001** · *Walpole's Ruin Lit by One Candle*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → ILLUMINATION ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Como em Dark Western, a ausência está só no eixo secundário: uma vela única em vez de luz farta — o centro governa pela escassez da fonte, não pela abundância.

**Atmosfera e mood**

**A ruína de Walpole iluminada por uma só vela** — (1001 Aesthetics; código: MidLibrary "Gothic Complexity")

Gótico romântico: castelo em ruína sob a lua, melancolia sublime do século XVIII, o passado assombrando com beleza.

**Paleta de cores** azul de luar, preto de ruína, âmbar de vela única

**Melhores usos:** narrativa, histórico, dark romântico

**MidJourney:** `--sref 2411221631 --sv 4 --sw 1000` (Gothic Complexity)

**Prompt universal (Seedream):** `Shot on ARRI Alexa Mini with 32mm lens, a romantic gothic scene, a ruined castle lit by one candle under the moon, sublime 18th century melancholy in the mood of Caspar David Friedrich, moonlight blue and ruin black with a single amber flame, the past haunting beautifully, 8k`

### **Kidcore**

**№ 500 / 1001** · *Rainbow Refusal of Adult Time*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A recusa arco-íris do tempo adulto** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Kidcore: nostalgia dos anos 90 infantis, plástico primário, adesivos e alegria de parquinho usada de propósito.

**Paleta de cores** vermelho, amarelo e azul primários, arco-íris, plástico brilhante

**Melhores usos:** branding lúdico, moda, editorial nostálgico

**MidJourney:** `[tema], kidcore aesthetic, rainbow plastic toys and stickers, 90s playground nostalgia, loud primary colors --v 6`

**Prompt universal (Seedream):** `Shot on Canon Sure Shot with 35mm lens and direct flash, a kidcore image, rainbow plastic toys and sticker-covered lunchboxes refusing adult time, primary red yellow and blue in loud saturation, playground joy worn on purpose, 8k`

### **Nouveau Organic**

**№ 635 / 1001** · *Art Nouveau Grows a Digital Nervous System*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Chicote art nouveau com sistema nervoso digital** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nouveau orgânico: curvas de Mucha crescendo como circuito vivo, vitral que respira em render.

**Paleta de cores** verde-seiva, ouro, opala

**Melhores usos:** arte digital, branding, capas

**MidJourney:** `[tema], nouveau organic aesthetic, art nouveau whiplash curves grown as living circuitry --v 6`

**Prompt universal (Seedream):** `Ultra-detailed 3D render, art nouveau whiplash curves regrown as a living digital nervous system, Mucha tendrils carrying light like circuitry through stained-glass petals, sap green gold and opal iridescence, organic ornament that breathes, flawless subsurface glow, 8k`

### **Pastoral**

**№ 673 / 1001** · *City Dreams in Sheep and Hedgerows*

**Nível:** 🔴 Primary

**Eixo:** THEME ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O campo sonhado à distância segura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pastoral: rebanhos ao entardecer, colinas douradas e a vida rural editada até virar poema.

**Paleta de cores** dourado de feno, verde de colina, âmbar de tarde

**Melhores usos:** arte, paisagens, editorial

**MidJourney:** `[tema], pastoral aesthetic, flocks at dusk golden hills, countryside edited into a poem --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a pastoral painting, flocks drifting home through golden stubble beneath a swollen harvest moon, Samuel Palmer visionary warmth over hedgerows and thatch, hay gold and hill green in amber dusk, the countryside edited into a poem, 8k scan`

### **Young Poland**

**№ 991 / 1001** · *Modernism Rising Through Partition*

**Nível:** 🟤 Tertiary

**Eixo:** THEME ↑ (presença) → SYNTHESIS ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Quatro linhagens convergem e nenhuma pode ser removida sem colapso — sem o Arts and Crafts britânico a marcenaria perde o argumento patriótico, sem o Simbolismo o vidro volta a ser ilustração, sem a linha do Art Nouveau o ornamento se achata, sem o Romantismo polonês a melancolia perde a pátria.

**Atmosfera e mood**

**O modernismo erguendo-se através da partição** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Młoda Polska: os vitrais de Wyspiański em Cracóvia, simbolismo e folclore fundidos — a nação dividida pintando a própria alma para não esquecê-la.

**Paleta de cores** azul de vitral, dourado de trigo simbólico, verde de folclore

**Melhores usos:** arte, histórico, editorial

**MidJourney:** `[tema], young poland aesthetic, Wyspianski stained glass symbolism fused with folklore, a partitioned nation painting its soul --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction in the Stanisław Wyspiański manner, a Young Poland stained-glass design, a monumental allegorical figure swirling in pastel and glass blue as folk embroidery motifs braid through symbolist wheat gold, folklore and modernism fused under partition, a divided nation painting its soul to keep it, soaring lyrical intensity, 8k scan`

## Leitura do padrão — o que as 12 estéticas confirmam

Olhando a lista de THEME (o Sol) — que é de longe a menor das seis posições já mapeadas, só 12 entradas contra as 20-110+ das outras — dá para ver um padrão bem definido, e o tamanho reduzido da lista já é o primeiro dado: THEME é a posição mais rara e mais exigente das seis, porque poucas estéticas conseguem sustentar **um único motivo dominando o quadro inteiro sem nenhuma concorrência**.

**O núcleo comum: nenhuma dessas estéticas é sobre "ter um tema" em geral — todas têm UM elemento (objeto, cor, ideia, luz) que governa a composição inteira e para o qual tudo mais está orientado, mesmo sem apontar diretamente para ele.** É exatamente a lógica do ☉ que a página descreve: um ponto contido num círculo, a agulha em pé que só existe como sistema no instante em que cai para um lado. Antes disso não há tema — só possibilidades em suspensão.

**Os clusters visíveis:**

**1. Idílio fixo — a mesma cena repetida como assinatura (THEME ↑ → ETERNITY ↑).**

English Country ("Foxgloves Cut From the Lane That Morning"), Pastoral ("City Dreams in Sheep and Hedgerows"). Aqui o "motivo em órbita a três escalas" é literalmente a paisagem rural — ela se repete no jardim, no tecido, no prato posto à mesa — e a prova de THEME bate com ETERNITY porque o motivo não muda de estação a estação, só amadurece.

**2. Luz única como o próprio tema (THEME ↑ → ILLUMINATION ↓).**

Dark Western ("Desert returns the verdict"), Gothic II Romantic Gothic ("Walpole's Ruin Lit by One Candle"). Ambas têm uma fonte de luz só — o deserto, a vela — que não ilumina para revelar detalhe, mas para **sentenciar**: tudo no quadro responde a essa única fonte, exatamente a "luz administrada em fases" do Sol, aqui invertida para ILLUMINATION ↓ porque a luz é escassa, não farta.

**3. Um objeto/cor único carregado como bandeira (THEME ↑ → RESONANCE ↑ e correlatos).**

Art Hoe ("Cadmium yellow carried like a flag"), Kidcore ("Rainbow Refusal of Adult Time"), Ageism-Resistance ("Authority wears architectural eyewear"). Aqui o "totem" que a página descreve — o objeto carregado em todo quadro até dispensar explicação — é a peça central: o amarelo cádmio, o óculos de armação, o arco-íris. Recorte de escala igual em qualquer tamanho: o objeto sozinho já é o argumento inteiro.

**4. Aviso/tese sustentada como centro narrativo (THEME ↑ → NARRATIVE ↑ / SEMIOTICS ↑).**

Dystopian ("Warning that predates the wreckage"), Cli-Fi ("Wet-bulb line rendered as plot"). Aqui o "motivo" não é um objeto físico mas uma tese fixa — o aviso, a linha de temperatura crítica — que organiza o enredo inteiro como o Sol organiza a composição: tudo no quadro é uma variação sobre a mesma advertência central.

**5. Movimento político/nacional como missão única (THEME ↑ → EMANATIO ↑ / SYNTHESIS ↑).**

ARTivism ("Stencil dry before the sirens"), Young Poland ("Modernism Rising Through Partition"). O motivo aqui é a causa — a intervenção urgente, a identidade nacional emergente — sustentada com disciplina absoluta apesar da pressão externa (as sirenes, a partição), exatamente o "corpo que já decidiu e não está mais negociando" que a página descreve como postura do THEME.

**6. Motivo orgânico transposto de mídia (THEME ↑ → MATTER ↑).**

Nouveau Organic ("Art Nouveau Grows a Digital Nervous System") — a curva vegetal do Art Nouveau vira o próprio tema estrutural quando reaparece como rede nervosa digital: o motivo sobrevive à mudança de matéria porque a matéria é secundária ao centro que se repete.

**O que isso confirma sobre o sistema:** THEME não é "ter um conceito forte" como qualidade genérica — é qualquer estética cuja prova visual é a existência de **um centro único que organiza tudo ao redor dele sem nunca ser diretamente apontado**, testável pela pergunta que a página propõe: *se eu trocar o cenário por um neutro, a composição ainda funciona, ou o centro nunca liderou de verdade?* Por isso English Country, Dystopian e Kidcore convivem na mesma posição — jardim inglês, aviso climático e arco-íris infantil são objetos de natureza completamente diferente, mas todos passam pelo mesmo teste: *existe uma coisa só sendo escolhida, e três coisas visivelmente abandonadas para que ela vença?*

Vale notar também que THEME é a única das seis posições analisadas até agora **sem nenhum caso de polaridade suprimida** (↓) na lista de estéticas — mesmo Dark Western e Gothic II, que carregam ILLUMINATION ↓, são THEME ↑. Isso bate com a identidade da própria posição: hedging (manter opções abertas) é o estado de falha do Sol, então uma estética classificada aqui só existe *porque* já cruzou o limiar de compromisso — não sobra espaço estrutural para um "THEME suprimido" ser catalogado como uma estética própria, ao contrário de Naive (TECHNIQUE ↓) ou Hermitcore (EXPRESSION ↓).

# EFFECT — o Bindu

<aside>
💥

**Essência:** EFFECT é a força do primeiro encontro perceptivo — o momento em que a consequência ultrapassa a intenção. Seu ideograma é o Bindu do Caxemira tântrico: o ponto sem círculo, sem moldura, sem linha de contenção — a semente irradiando por conta própria. EFFECT não é a intensidade sentida; é a consequência que o mundo devolve — não o volume do golpe, mas a largura da cratera. Três verbos habitam o ponto: **Transgredir**, **Inverter** e **Transmutar** — um só por quadro, nunca dois. E o Bindu é a única posição com **dois regimes de carga que não podem se misturar num mesmo quadro** (tenebrista e luminoso): o prompt carrega uma chave de regime nos colchetes, e a linha negativa muda junto.

**Leitura das setas nesta seção: ↑ = presença do elemento (amplificado) · ↓ = ausência do elemento (suprimido).**

</aside>

## Prompt-mestre (imagem-síntese)

> **↑ EFFECT — universal prompt.** A field already visibly tuned to its critical angle — [the aesthetic's own matter or crowd one grain from collapse: a pile at the point of slipping, a room one silence from turning, a surface one degree from breaking] — with a single figure or object delivering the strike through minimum movement: every gesture reduced by half and each remaining one carrying double weight, hands still and never negotiating with the frame, the body occupying its space rather than pushing into it. Exactly one of three operations is performed and never two: [**Transgredir** — a rule of this world's own frame visibly crossed, chin lifted through the violation, the aftermath shown rather than the crossing performed / **Inverter** — the expected configuration completed in exact reverse, deadpan, no wink, the thing that should lead absent and the thing that should hide leading / **Transmutar** — [the aesthetic's own material] caught mid-change of state and sealed at that exact instant, the transformation left legible as physical evidence]. The face is held at the Kuleshov edge — at rest, undecided, offered as a surface the viewer completes — or level and unblinking into the lens without requesting permission; never a smile assembled after the eyes, never a darting check for effect. One dominant impression only: [the aesthetic's own single saturated colour block or single overwhelming form] occupying the frame with radical cropping isolating a limb, a prop, or a fragment so the omission carries the narrative, generous negative space holding the implied event, and no second element competing. The whole frame is committed to ONE register and mixes nothing from the other: **[TENEBRIST/CONFRONTATIONAL:** one motivated hard source or a flash fired close to the lens, deep textured shadow with real detail and slow falloff, no fill, contrast pushed until the image lands before any detail resolves, wet asphalt / corridor / poolside-at-night ground, low angle so the silhouette towers**]** or **[LUMINOUS/WELLBEING:** soft diffused natural light with even fill and no hard shadow anywhere, warm oxygenated tone with nothing muddy, open sky or open ground with generous breathing room, the same forward-weighted command but the jaw unclenched and the breath low, the strike arriving as ease rather than dread**]**. Total commercial-grade polish applied regardless of what the content is doing — the gloss itself is the provocation in the first register and reads as generosity in the second; skin rendered with true texture and real asymmetry, never smoothed to an average. Wardrobe carries the charge and never explains it: one dominant silhouette plus one recurring coded object drawn from a fixed five-sign vocabulary repeated across the series until the audience reads it without being told. Plant one charge proof showing consequence rather than cause — [a stain, a chalk outline, an ordinary found object styled with the precision of the most precious one, a mirror returning an event that already happened just outside the frame, a material suspended at the instant of its own change]. Everything scaled and sited so the strike belongs to this argument specifically and could not be transplanted: the image is felt first and read second.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre):

> No two registers in one frame, no chiaroscuro vocabulary mixed with open-light vocabulary, no second competing focal point, no explanatory prop, no caption-dependent gesture, no demonstrative pose performed at the lens for approval, no expression fully resolved into one named emotion, no smile assembled after the eyes commit, no upturned chin, no fidgeting or self-adapting hands, no body negotiating with itself mid-frame, no wink or irony that never resolves into commitment, no spectacle standing in for a transformation the material does not actually show, no cause shown where the aftermath should be, no generic scale detached from this argument, no quiet tone-on-tone figure at the frame's edge, nothing that takes more than three seconds to land.
> 

### Como adaptar o prompt a cada estética

**Como usar para as estéticas da lista.** Só três decisões mudam; a arquitetura permanece idêntica.

**1. O campo no ângulo de repouso** — troque pelo campo próprio da estética: para **Stormcore**, a queda de pressão antes do céu quebrar; para **Uprising**, a rua já saturada; para **Op Art / Hypnoticcore**, a retina já tensionada pela frequência; para **Wellness / Summer**, o corpo já disposto ao relaxamento.

**2. O verbo (um só por quadro)** — **Transgredir** para Revolutionary, Vanguard, Edgy, Uprising, Power. **Inverter** para Oddcore, Liminal Space, Mirrorcore, Sweetcore, Lagom (a inversão sendo a dose exata onde se espera excesso). **Transmutar** para GLITCH, Distorted, Artificial Life, Kineticism, Racing, Dopamine.

**3. O regime de carga** — tenebrista para Power, Revolutionary, Edgy, Stormcore, Distorted, Liminal Space, Psychedelic, GIANT, Sublime. Luminoso para Wellness, Summer, CITRUS, Teddy, Sweetcore, Lagom, Jovial, Sensory, Dopamine, Escapism. Nunca os dois: as duas linhas negativas se cancelam se combinadas.

Nada na arquitetura do prompt nomeia lugar, tribo ou estilo — só os mecanismos que a página já define como EFFECT: criticalidade auto-organizada, Ponto de Irradiação, rosto Kuleshov, uma impressão dominante, corte radical, prova pelo rastro, e o regime de luz travado.

## Fundamentos do elemento

**Identity.** Force of the first perceptual encounter — the moment consequence overtakes intention. Its ideogram is the Bindu of tantric Kashmir: the point without a circle, no frame, no containing line, the seed radiating on its own account. Theme's ☉ keeps a point locked inside a ring — the sun as a centre that holds and sustains. Effect is that same point with the ring removed: the energy that finally touches the field. Effect is not the intensity felt; it is the consequence the world hands back — not the loudness of the strike, but the width of the crater. Three verbs occupy the point: **Transgredir / Transgressing** (break a closed system to build a liveable territory past it — the shadow is demolition with no territory built after), **Inverter / Inverting** (turn a structure inside out to expose what it hid — the shadow is irony that corrodes every commitment), and **Transmutar / Transmuting** (change state at a real, visible cost — the shadow is selling spectacle as change). In an image this element is proven when the frame produces consequence before comprehension — the viewer is struck, then reads — or when a quiet first glance is built precisely enough to be returned to and struck a second time. (Distinct from THEME, 6 — Theme's sun is the centre contained, sustaining continuity; Effect is the same centre released, spending its charge once, irreversibly, on contact. Distinct from EXPRESSION, 4 — Expression proves the mark came from a real hand; Effect proves the mark changed something outside the hand.)

**Criticalidade Auto-Organizada — the physics of the strike.** A sandpile takes grain after grain without event, then reaches an angle of repose at which the next grain — no heavier, no different from the others — triggers an avalanche. Effect is not the size of the gesture; it is the state of the field the gesture lands on. The image must show the field already tuned to its critical angle: a queue visibly one word from breaking, a room visibly one silence from turning, a pile of matter visibly at the point of collapse. The photographable proof is preparation, not force — ninety percent construction, ten percent detonation, and the frame catches only the ten.

**Ponto de Irradiação — minimal presence, maximum response.** A violin string too loose returns no note; too tight, it snaps. At the exact tension, the bow barely touches it and the room fills. Photographed, this is economy of movement: reduce the model's gestures to their minimum, then let each remaining one carry the full charge a lesser image would spend across ten. An image that whispers and still commands the frame has found the Ponto de Irradiação; an image that shouts and still needs a caption has missed it.

**The Kuleshov face — projection over declaration.** A neutral face edited beside a bowl of soup, a coffin, a woman reads back as hunger, grief, desire in turn — the face supplies nothing; the audience completes it. Effect's most efficient instrument is the face that has not yet decided what it feels, held long enough that the viewer's own appetite or fear fills the gap. The instant an expression fully resolves into one named emotion, projection stops and the image becomes information rather than impact.

**Two charges — the strike and the glow.** Effect has two legitimate registers and no single frame may mix them. **Tenebrist charge** (Effect ↑ → Illumination ↑, by transmission): the lineage of Caravaggio and classic cinema — one motivated source, deep textured shadow, the charge delivered as gravity and consequence. **Luminous charge** (Effect ↑ → Illumination ↑, corrected register): the same amplified pair read through Theme, Esthetics, and Emanation instead of tenebrism — soft diffused light that opens the space rather than carves it, warm oxygenated tone, an ease that still lands with total, immediate impact but registers as nourishment rather than dread. A generator's uncorrected default collapses "emotional charge" into darkness; the luminous charge is the deliberate correction, achieved by describing the physical conditions of wellbeing (open sky, even fill, a face at rest) rather than requesting the feeling directly. Never blend chiaroscuro vocabulary and open-light vocabulary in one prompt — the two charges cancel each other.

## Corpo — postura, olhar e gesto

**Model posture & structure.** Two postures, one per register, never merged. **Commanding (tenebrist / confrontational):** tall, weight forward or squared, chin level, the stance of someone who does not ask permission to be looked at; economy of movement is deliberate, not passive — every gesture reduced by half, every remaining one doubled in weight; hands still, never fidgeting, because a body negotiating with the frame has already lost the charge. **Released (luminous / wellbeing):** open stance, shoulders dropped, weight even, the ease of a body no longer performing effort — jaw unclenched, breath low — the same economy of movement, spent on rest instead of threat. In both registers the body occupies its space rather than pushing into it; a body caught mid-negotiation with itself (adjusting, checking, softening) has broken the strike before the shutter closes.

**Gesture.** Three verbs, never blended in one frame.

**Transgredir · Transgressing** — break a closed system and stand in the territory beyond it. Photographed: a rule of the frame's own world visibly crossed, its aftermath shown rather than the act of crossing performed for the lens. The shadow is demolition with nothing built after.

**Inverter · Inverting** — turn a structure inside out to expose what it hid. Photographed: the object or figure doing the opposite of what the frame's convention demands — product absent where product should lead, safety implied where safety is expected, glamour applied to what glamour usually excludes. The shadow is irony that never resolves into commitment.

**Transmutar · Transmuting** — change state at a cost that shows. Photographed: the material itself altered — solarized, sealed in resin, sandwiched between negatives, encased in perspex, caught mid-melt — the transformation left legible as evidence, not merely implied. The shadow is spectacle standing in for change; if the material looks the same after, the transmutation did not happen.

Forbidden in all three: the demonstrative pose, the gesture performed at the lens for approval rather than at the world for consequence.

**The look — how the eyes behave.** Two admissible modes. **Direct confrontational:** level into the lens, unblinking, no tilt, the gaze of someone who owns the frame and does not request its approval. **Kuleshov-neutral:** the face held at rest, undecided, offered as a surface the viewer completes rather than reads — held exactly at the edge where a viewer starts projecting and stops before the expression resolves into one named emotion. Banned in both: the upturned chin seeking approval, the smile assembled after the eyes commit, the darting check for effect — any leak that tells the viewer the body is negotiating rather than delivering.

## Regras de imagem — do figurino à prova de carga

**Look & styling continuity.** Build a fixed, recurring sign vocabulary — five objects or conditions belonging to the aesthetic's secret register, repeated across the body of work until the audience reads them as code without being told what they mean. The product may be barely present; styling communicates through implication and prop rather than inventory. Wardrobe carries the charge, never explains it — one dominant silhouette, one recurring narrative- or fetish-coded object, and total production polish even when the content underneath is confrontational; the polish itself becomes the provocation.

**Camera.** Hard, close, undiffused — flash fired near the lens rather than softened at a distance, so glamour photographed in imperfect proximity reads as more real than glamour photographed at flattering remove. Radical cropping isolates a limb, a prop, or a fragment over the whole body or face, and the omission carries the narrative — showing only the element that makes no sense without what was removed. For the luminous register, the same discipline of proximity holds but the flash gives way to soft available light with generous exposure, still shot close and direct, still asking for maximum immediate impact without hardness.

**Composition.** One dominant impression per frame, nothing competing — a single saturated colour block, a single implied narrative event kept entirely off-frame, a single commanding figure occupying the diagonal. Graphic and flat rather than layered: primary colour blocking pushed to the edge of legibility, generous negative space carrying the implied violence or the implied calm equally. The eye must land on the charge before it can parse detail — a second competing element dilutes the strike.

**Lighting.** Tenebrist register: single motivated hard source, deep textured shadow holding real detail, slow smooth falloff, no fill — light as protagonist and narrator, the garment and face are things light happens to. Confrontational register: hard on-camera or close strobe, flat and undiffused, the imperfection of proximity read as evidence rather than flaw. Luminous / wellbeing register: soft diffused natural light, even fill, golden-hour warmth that opens the space rather than carving it, no hard shadow anywhere — the correction to the default drift toward darkness. Never mix registers within one frame.

**Beauty detail.** Flawless commercial-grade polish applied without exception, regardless of subject matter — the gloss itself is the provocation when content is confrontational, and the same unblemished finish reads as generosity when content is luminous. Skin rendered with true texture under hard light in the tenebrist register (real pore, real asymmetry, nothing smoothed to an average); skin luminous and hydrated with real sheen in the wellbeing register, warmth read as circulation rather than pigment. In both registers the finish never apologizes for the content it carries.

**Cenography.** Four families. **Noir / confrontational:** hotel corridors and poolsides at night, glossy wet asphalt, interiors that suggest a crime, an accident, a transaction just outside the frame. **Monumental / detonation:** scale built specifically to overwhelm collective perception at once — a mountain of flowers filling a courtyard, a runway cut through an actual wheat field, an ice floor beneath an infinite mirrored ceiling, a kilometre of colour laid across a landscape — engineered so the room produces the strike before any garment does. **Chromed / plasticized:** neon-saturated interiors, mirror and lacquered optical plastic multiplying a single texture into pop hyper-reality. **Luminous / wellbeing:** open sky or open background, generous breathing room, nothing that competes with the ease of the space.

**Colour.** Tenebrist: earthy, somber, warm desaturated tones with continuous unbroken gradients, oil-painting depth. Confrontational: highly saturated primary blocking pushed past comfort — red, yellow, flesh tones at their extreme. Luminous: warm luminous tones with oxygen in the colour, nothing muddy, nothing muted past legibility. Monumental: whatever single colour the detonation requires, held at total saturation across the entire built environment — one colour block is the whole argument.

**Charge proof.** Plant one element that proves consequence rather than intention: a found, ordinary object styled with the same precision as the most sacred garment in the shoot; a material caught mid-transformation and sealed at that exact instant, an object suspended in perspex or resin at the moment of its own change; a chalk outline, a stain, a mirror reflecting an event that has already happened just outside the frame. The strongest proof shows the aftermath, never the cause.

**Scale & detonation — the corona.** Effect's monumental register works like a halo bursting from one point: build one perfectly synchronized event, timed to the second across light, sound, and space, and let its image throw outward across thousands of viewers simultaneously — the event itself lasts an hour; its corona lasts a week. Site-specificity is mandatory: the monumental gesture must belong to one particular argument (a wheat field for rural romance, an ice floor for permanence and thaw), or it reads as formula rather than consequence.

## Praticantes (dos códices)

**Practitioner lines (from the codices).**

*Photography.* Lee Miller — deadpan direct flash regardless of subject matter, solarized development carried from Surrealism into documentary rigor, a found object styled with couture precision, flat unromanticized affect that refuses to soften a hard register for a soft viewer or glamorize a hard one for a hardened viewer. Helmut Newton — hard close flash, noir hotel-and-poolside locations, tall commanding Amazonian stance, direct confrontational gaze that asks no permission, a fixed vocabulary of fetish-coded props (stiletto, glass, corridor) repeated until the audience reads it as code. Guy Bourdin — saturated primary colour blocking pushed to its limit, radical cropping isolating a limb or prop over the face, an implied off-frame narrative violence, full glossy commercial production values applied to deeply unsettling content, without a wink. Heji Shin — flawless commercial gloss applied to taboo subject matter, tight unflinching framing, the polish itself as the provocation, deadpan affect. Suffo Moncloa — flat saturated colour grounds, sculptural stripped-back bodies, bold minimal styling, the image reduced to its loudest essential signal.

*Moving image.* Inez & Vinoodh — the set flooded with deafening music so performance collapses and the model's real threshold survives; rapid stream-of-consciousness cutting locked to the track; macro framing on lips, hands, fabric detail; 16mm grain composited over 4K sharpness so two generations of image cross on one body; the direct-to-lens gaze breaking the fourth wall. Marie Schuller — expressionist claustrophobic framing, Dutch tilted angles, degraded analog overlays (re-filmed CRT, corrupted VHS) that introduce real signal decay rather than a digital filter, the body styled toward the mythological or monstrous, industrial noise alternated against absolute silence so the nervous system never settles.

*Set design & scale.* Villa Eugénie / Étienne Russo — real ice runways beneath infinite mirrored ceilings multiplying a single silhouette, tonnage-scale artificial snow, full indoor fields of live flora, mechanical wave systems, an engineered room-frequency the audience's own heartbeat is made to follow. Marla Weinhoff — ultra-reflective chromed and coloured mirror surfaces, lacquered optical plastics, neon-saturated plasticized domestic interiors built specifically for high-contrast viral reproduction. Bureau Betak (Alexandre de Betak) — monumental live-flora installations, synchronized light and sound rigs choreographed to the second, real landmark sightlines built into the stage, production engineered to detonate live and across a global feed at the same instant. Thomas Petherick — garments sealed flat between sheets of perspex, mineral stalactite forms filling an in-the-round stage, fashion caught mid-transformation inside its own material rather than displayed beside it.

*Beauty & hair.* Kevyn Aucoin — invisible three-dimensional contour calibrated to manufacture its own highlight inside the camera lens, the face re-engineered rather than corrected, changing state under the hand into a satin-skinned icon. Christiaan Houtenbos — the buzzcut as the Bindu made literal on a human scalp, no volume left to distribute attention, the hairless geometry becoming the compositional anchor the rest of the frame must organize around. Topolino — chromatic violence as beauty: shoe polish, thrown acrylic paint, cracked clay masks, pure pigment blown directly into the eyes, full-face monochrome cyan or red coverage that forces the camera to register the model as an alien or expressionist creature rather than an object of desire. Aaron de Mey — a sharp, saturated graphic colour code (one wing of eyeliner extended past the lash line, one hard-edged block of shadow) engineered to hold its charge from the printed page down to the smallest digital storefront.

*Styling.* Ray Petri — a hard tender gaze that refuses both aggression and apology, forbidden sign systems worn on the same body at full fidelity (an MA-1 flight jacket over a kilt, an exposed cotton boxer waistband beneath tailoring), authorship stated as hand-lettered tape applied directly to the garment on set. Panos Yiapanis — rope and industrial safety pins binding designer cloth directly onto the body in real time, boiled wool and aged leather stacked into a herculean silhouette, the face hooded into monument; the transformation is irreversible — once the bindings come off the look cannot be reassembled, which is the manuscript's own test for a genuine Transmutar.

*Editorial governance.* Diana Vreeland — the Bindu doctrine at magazine scale: one amplified "flaw" (a profile, a jawline, a gap-toothed smile) lit as insignia rather than corrected, blood-red lacquered environments, models directed as mythic fauna in poses quoting statuary and wild-animal motion, a destination landscape promoted to psychological co-star, energy concentrated at a single point rather than distributed evenly across the frame — the strike outranks the buttonhole. Franca Sozzani — Inverter run at editorial scale: luxury's own seduction aimed at what a news format flips past, single-theme visual essays run to essay length, high couture staged against ecological or social ruin, cinematic seriality standing as evidence rather than opinion. Katy England — Transgredir staged as collective ritual: garments torn, dirtied, and distressed by hand minutes before exposure, a threshold of trauma crossed in public with no cosmetic recovery, the crossing left legible as the garment's own finish.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** Immediate impact, either charge: colossal scale or a single dominant colour block, contrast pushed to maximum or light opened to total warmth, a low angle that makes the silhouette tower or open sky that makes the ease tower instead — emotional charge thick enough to be the subject before it is read.

> **↑ Prompt (tenebrist charge).** A colossal cadmium-yellow gown filling two-thirds of the frame against wet black asphalt at night, one figure, one colour block, shot from a low angle so the silhouette towers, hard undiffused flash fired close to the lens, contrast pushed until the image lands before any detail resolves, a single fetish-coded prop repeated from a recurring vocabulary, direct confrontational gaze into the lens, the strike arriving first and the explanation never.
> 

> **↑ Negative line.** No soft diffused fill, no golden-hour warmth, no averted or dreamy gaze, no multiple competing light sources, no explanatory prop, no smile.
> 

> **↑ Prompt (luminous charge).** A figure standing in an open field under soft warm golden-hour light with no hard shadow anywhere, one dominant saturated colour held across the whole garment, the pose commanding and forward-weighted but the face at rest and unhurried, generous open sky behind filling the frame with breathing room, warm oxygenated tone with nothing muddy, the image striking the viewer with ease rather than dread, felt before it is read.
> 

> **↑ Negative line.** No chiaroscuro, no deep shadow, no noir location, no confrontational prop, no tension in the jaw or brow, no desaturation.
> 

**↓ Suppressed — repertory.** Quiet first glance built to be earned slowly: the figure nearly dissolved into the room's own tone, placed at the frame's far edge, held at the exact tension where nothing detonates yet — the sandpile not yet at its angle of repose, the Kuleshov face offered but not yet completed by the viewer.

> **↓ Prompt.** At first glance an empty beige room, and only after several seconds the figure resolves — dressed tone on tone in the room's own colour, seated at its far edge in still, even, unremarkable light, the posture entirely at rest, the face neutral and undecided, an image built to be walked past once and returned to only by a patient eye.
> 

> **↓ Negative line.** No saturated colour block, no hard flash, no confrontational gaze, no monumental scale, no implied narrative violence, nothing that could be read in under three seconds.
> 

**Gesture — the three verbs, direction call and body code.** Three gestures alone serve this position, one verb per frame, never two. **Transgredir · Transgressing:** breaking the stated rule inside the frame — stepping over the marked line, touching the forbidden object, entering the plane the set has declared off-limits — performed with joy, chin lifted through the violation, never apology; the call on set is *the tape marks where you cannot go — go.* **Inverter · Inverting:** the expected pose completed in exact reverse — the gown worn backwards, the body upside down, the gaze that flips the viewer into the subject — deadpan essential, a wink kills the charge; the call is *do the exact opposite of the pose everyone expects on this set.* **Transmutar · Transmuting:** change of state caught mid-frame — fabric becoming wing, silhouette altering between exposures, the double exposure as chrysalis — the one gesture of the three where motion blur is permitted, because the becoming, not the state, is the subject; the call is *between this frame and the next you become something else — show me the middle.*

**Cover-logic & scale codex.** As engine, this position runs cover logic: one overwhelming visual event per frame, the silhouette readable at a hundred meters, no subplot and no second idea competing for the eye. As scene, the set is an arena of force — storm field, floodlit lot, desert pan, or architecture pushed to converge on the figure — scaled to dwarf the body or let the body detonate it, camera held at the distance where consequence reads as total. Three scale registers recur in the repertoire: the figure made colossal against a wet night city (the tenebrist charge above); the figure made small against converging architecture — an ultra-wide lens at an extremely low angle so brutalist verticals close in on a lone upright silhouette until the garment reads as an extension of the building, one dominant vector, structural severity, no decorative element competing with the scale; and the body kept full scale while the fabric itself becomes the overwhelming event — one sculptural silhouette filling the frame, volume and weight arguing while the face stays sovereign, the glamour code relayed rather than broken.

Practitioners: Nick Knight × Alexander McQueen (the strike staged at full architectural scale), Helmut Newton's *Big Nudes* (scale itself as the impact), Mert & Marcus at maximum gloss-force, Txema Yeste (cover logic through fabric as co-author, the sculptural event overwhelming the frame while the face stays sovereign). Film anchors: Furiosa's readable silhouette against annihilating scale in *Mad Max: Fury Road*, the napalm dawn of *Apocalypse Now*.

## Estéticas relacionadas a EFFECT (A–Z)

As 31 estéticas classificadas sob EFFECT presentes na lista, em ordem alfabética — cada toggle traz número, epíteto, nível, eixo com leitura das setas e polaridade.

**Nota da lista:** a análise da seção menciona 32 estéticas e cita **Jovial**, mas a lista bruta original continha apenas 31 entradas — Jovial não tinha linha de classificação (nível, eixo, polaridade) na lista.

### **Artificial Life (A-Life)**

**№ 062 / 1001** · *Organisms nobody designed, crawling out of a grid*

**Nível:** ⚫ Quaternary

**Eixo:** EFFECT ↑ (presença) → SYNERGY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** sistemas computacionais, morfogênese biológica e prática visual generativa fundem-se aqui; retire a biologia e a grade deixa de significar crescimento, retire o código e a emergência fica sem substrato — o resultado é uma solda de várias linhagens, não a revisão de uma só.

**Atmosfera e mood**

**Organismos que ninguém desenhou, saindo da grade** — (1001 Aesthetics, interpretação)

Vida artificial: autômatos celulares, criaturas digitais emergentes, Game of Life evoluíndo.

**Paleta de cores** verde-terminal, grid escuro, gradientes digitais

**Melhores usos:** tech, arte generativa, dataviz

**MidJourney:** `[tema], artificial life simulation, cellular automata --v 6`

**Prompt universal (Seedream):** `Ultra-crisp generative simulation render at 8k, emergent digital organisms crawling out of a glowing cellular grid, evolving patterns in terminal green and electric blue on deep black, phosphor trails and data particles, computational biology visualization with mesmerizing organic motion frozen mid-frame`

### **Bold**

**№ 107 / 1001** · *Built to be hit, not considered*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** uma única linhagem de comunicação gráfica é herdada inteira e reajustada para impacto imediato — os mesmos dispositivos de contraste e escala persistem enquanto a sutileza é deliberadamente trocada; uma reinterpretação dentro de uma linha, não um híbrido.

**Atmosfera e mood**

**Feito para impactar, não para ser ponderado** — (1001 Aesthetics, interpretação)

Bold: tipografia pesada, contraste máximo, cor que grita primeiro.

**Paleta de cores** primárias saturadas, preto pesado

**Melhores usos:** branding, pôsteres, social

**MidJourney:** `[tema], bold graphic design, heavy contrast --v 6`

**Prompt universal (Seedream):** `Ultra-crisp graphic design at 8k, massive extra-heavy typography slamming across the frame in saturated primary red and yellow on pure black, maximum contrast with razor edges, Swiss-brutalist confidence made to hit not to be considered, flat vector precision, billboard-scale impact, gallery-print quality`

### **CITRUS**

**№ 158 / 1001** · *Sun held in the hand at breakfast*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** natureza-morta botânica, cultura doméstica mediterrânea e branding cromático moderno convergem; retire o branding e a paleta fica no pomar, retire a linhagem da natureza-morta e a fruta perde o enquadramento — fusão de várias linhas.

**Atmosfera e mood**

**O sol segurado na mão ao café da manhã** — (1001 Aesthetics, interpretação)

Cítrico: laranjas e limões cortados, respingos de suco, luz de manhã mediterrânea, frescor ácido.

**Paleta de cores** laranja, amarelo-limão, verde-lima, branco

**Melhores usos:** food, verão, branding fresco

**MidJourney:** `[tema], citrus still life, juicy mediterranean morning light --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a citrus still life, sliced blood oranges and lemons with sparkling juice droplets suspended mid-splash, bright Mediterranean breakfast light raking across zest texture, zesty orange yellow and lime palette on white marble, mouthwatering specular detail, high-end food editorial, 8k`

### **Distorted**

**№ 233 / 1001** · *Whose Pixel Did You Lose?*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → INTEGRITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**De quem foi o pixel que você perdeu?** — (1001 Aesthetics; código: Lummi, match aproximado)

Distorção: rostos e formas esticados, glitch e warp, realidade derretida digitalmente.

**Paleta de cores** cores derretidas, glitch RGB

**Melhores usos:** arte, música, experimental

**MidJourney:** `--sref 3887785008 --sw 1000` (Twisted Realities — match aproximado)

**Prompt universal (Seedream):** `Shot on Canon R5 with 85mm lens then digitally ruptured, a distorted portrait, stretched and warped features with RGB glitch separation, digitally melted reality and datamosh smears, forms pulled past recognition into lost pixels, CRT scanline texture, unsettling 8k glitch-art finish`

### **Dopamine**

**№ 239 / 1001** · *Color is the dose*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → EXPRESSION ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A cor é a dose** — (1001 Aesthetics; código: Lummi, match aproximado)

Dopamina: saturação máxima e alegre, rosa-choque com amarelo e turquesa, euforia cromática instantânea.

**Paleta de cores** rosa-choque, amarelo, turquesa, lilás vibrante

**Melhores usos:** social media, moda, branding alegre

**MidJourney:** `--sref 1235219147 --sw 1000` (Hypercolor Realities — match aproximado)

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a dopamine aesthetic image, maximum joyful saturation, hot pink clashing happily with yellow and turquoise styling, hard direct flash and glossy surfaces, instant chromatic euphoria, color as the dose, high-energy editorial pop, 8k`

### **Dynamic**

**№ 250 / 1001** · *Interval where stillness breaks into motion*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O intervalo onde a quietude vira movimento** — (1001 Aesthetics, interpretação)

Dinâmico: corpo no instante da explosão de movimento, linhas de velocidade, energia congelada no pico.

**Paleta de cores** contrastes enérgicos, borrões de movimento

**Melhores usos:** esporte, dança, publicidade

**MidJourney:** `[tema], dynamic action shot, explosive motion frozen at peak --v 6`

**Prompt universal (Seedream):** `Shot on Sony A9 with 70-200mm lens at 1/8000s, a dynamic action image, body caught at the exact interval where stillness breaks into motion, dust and sweat droplets frozen mid-air, motion blur trailing the background, explosive energy at its peak, sports-campaign grading, 8k`

### **Edgy**

**№ 267 / 1001** · *Safety Pin Through Fabric and Skin at Once*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → EXPRESSION ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Atmosfera e mood**

**Alfinete atravessando tecido e pele ao mesmo tempo** — (1001 Aesthetics, interpretação)

Edgy: couro rasgado e alfinetes, atitude de confronto, estética que provoca antes de agradar.

**Paleta de cores** preto, prata de metal, vermelho de provocação

**Melhores usos:** moda alternativa, música, retratos

**MidJourney:** `[tema], edgy punk-inflected fashion, safety pins and torn leather --v 6`

**Prompt universal (Seedream):** `Shot on Contax T2 with direct flash, an edgy fashion portrait, torn leather held by safety pins, confrontational stance and raw attitude against raw concrete, black and metal silver with one provocation-red accent, an aesthetic that provokes before it pleases, punk editorial grit, 8k`

### **Escapism**

**№ 303 / 1001** · *Door Left Ajar to a Second World*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A porta entreaberta para um segundo mundo** — (1001 Aesthetics, interpretação)

Escapismo: fresta de luz de outro lugar, guarda-roupa de Nárnia, o cotidiano com uma saída secreta.

**Paleta de cores** cotidiano opaco contra fresta luminosa e saturada

**Melhores usos:** fantasia, narrativa, conceitual

**MidJourney:** `[tema], escapism, ordinary room with a door left ajar to a glowing second world --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 28mm lens, an escapism scene, ordinary muted room with a door left ajar onto a luminous saturated second world, Narnia wardrobe feeling, golden light spilling across the grey floor, the everyday with a secret exit, cinematic fantasy grading, 8k still`

### **GIANT**

**№ 376 / 1001** · *Doorway Reduced to a Notch in the Mass*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → SAGA ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A porta reduzida a um entalhe na massa** — (1001 Aesthetics, interpretação)

Gigante: escala esmagadora, estrutura monumental que anula o humano, a porta como detalhe mínimo no colosso.

**Paleta de cores** cinza de monumento, sombra profunda, figura minúscula

**Melhores usos:** arquitetura, épico, conceitual

**MidJourney:** `[tema], monumental gigantic structure, doorway reduced to a notch in the mass, crushing scale --v 6`

**Prompt universal (Seedream):** `Shot on Sinar 4x5 large format with 75mm lens, a giant architecture image, a doorway reduced to a tiny notch in a monumental mass, tiny human figure against crushing scale, monument grey and deep shadow, Andreas Gursky monumental flatness, the colossus that erases proportion, 8k`

### **GLITCH**

**№ 384 / 1001** · *I-Frame Deleted Until the Image Breaks*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O I-frame deletado até a imagem quebrar** — (1001 Aesthetics; código: kajimelo, categoria glitch)

Glitch: erro digital como estética, datamosh e pixels deslocados, a falha elevada a linguagem visual.

**Paleta de cores** RGB deslocado, neôn de erro, ruído digital

**Melhores usos:** arte digital, música, editorial experimental

**MidJourney:** `--sref 1654329871 --sw 1000` (Glitch Photography Meets Organic Realism)

**LoRA (Civitai):** "Glitch Style" (Flux) — civitai.com/models/103667; "Camera Circuit-Bending" (Flux) — civitai.com/models/1185370

**Prompt universal (Seedream):** `Corrupted digital video still, a glitch art image, deleted I-frames and datamoshing until the image breaks, displaced RGB channels and pixel sorting with digital noise, Rosa Menkman glitch-study aesthetics, the error elevated to visual language, 8k`

### **Hypnoticcore**

**№ 451 / 1001** · *Riley's Squares Keep the Eye From Resolving*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → INTEGRITY ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Os quadrados de Riley impedem o olho de resolver** — (1001 Aesthetics; código: sref-midjourney.com, categoria Psychedelic, match aproximado)

Hipnótico: op art e padrões que vibram, geometria repetida até o olhar oscilar, a imagem que não deixa você parar.

**Paleta de cores** preto e branco vibrante, contrastes ópticos puros

**Melhores usos:** arte óptica, capas, editorial experimental

**MidJourney:** `--sref 52398513 --sw 1000` (categoria Psychedelic — match aproximado)

**Prompt universal (Seedream):** `High-contrast op art composition, a hypnoticcore image, Bridget Riley squares keeping the eye from resolving, vibrating black and white geometry repeated until the gaze oscillates, 8k`

### **Kineticism**

**№ 503 / 1001** · *Naum Gabo’s line set in motion*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → ETERNITY ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A linha de Naum Gabo posta em movimento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Kineticismo: arte cinética, escultura que vibra, o movimento como a própria obra.

**Paleta de cores** aço, prata em vibração, preto de galeria

**Melhores usos:** arte, instalação, motion design

**MidJourney:** `[tema], kinetic art aesthetic, standing wave sculpture in motion, Naum Gabo lineage, gallery spotlight --v 6`

**Prompt universal (Seedream):** `Long-exposure photograph shot on Nikon FM2 with 50mm lens, a kineticism image, a standing wave sculpture blurring into pure motion, Naum Gabo's line set in motion, steel arcs vibrating under gallery spotlights, movement itself as the artwork, 8k`

### **Lagom**

**№ 512 / 1001** · *Right-amount test, made Swedish*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → DENSITY ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O teste da medida certa, à moda sueca** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Lagom: nem pouco nem demais, bétula e lã em luz nórdica uniforme, equilíbrio habitável.

**Paleta de cores** bétula clara, lã crua, cinza nórdico

**Melhores usos:** interiores, branding, lifestyle

**MidJourney:** `[tema], lagom aesthetic, Swedish balance, birch and wool, even Nordic daylight --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad X2D with 55mm lens, a lagom image, a Swedish table set with exactly enough and nothing more, birch and wool in even Nordic daylight, the right amount as quiet ethic, balance you can inhabit, 8k`

### **Liminal Space**

**№ 524 / 1001** · *Fluorescent hallways after closing*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → COHERENCE ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Corredores fluorescentes depois do fechamento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Espaço liminal: familiaridade esvaziada até inquietar, paredes menta e chão encerado sem ninguém.

**Paleta de cores** menta institucional, fluorescente, chão encerado

**Melhores usos:** arte conceitual, fotografia, atmosfera

**MidJourney:** `[tema], liminal space aesthetic, humming fluorescent hallway after closing, unsettling emptiness --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX50R with 32mm lens, a liminal space image, a fluorescent hallway humming after closing time, institutional mint walls and a waxed floor reflecting doorways nobody exits, Lynne Cohen deadpan stillness with backrooms unease, every surface familiar and no one ever arriving, the ordinary emptied until it quietly unsettles, 8k`

### **Mirrorcore**

**№ 576 / 1001** · *Room Doubled Until Reality Slips*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → INTEGRITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Sala duplicada até a realidade escorregar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mirrorcore: reflexos multiplicando o espaço além da conta, prata infinita e luz duplicada.

**Paleta de cores** prata de espelho, luz duplicada, profundidade infinita

**Melhores usos:** arte, moda, editorial conceitual

**MidJourney:** `[tema], mirrorcore aesthetic, a room doubled in infinite mirrors until reality slips, silver reflections --v 6`

**Prompt universal (Seedream):** `Shot on Sony A1 with 24mm lens, a mirrorcore image, a room doubled in facing mirrors until reality quietly slips its moorings, silver reflections multiplying one figure past counting, Yayoi Kusama infinity-room logic in cold daylight, fingerprints on a single pane betraying which world is real, space losing its edges by recursion, 8k`

### **Oddcore**

**№ 640 / 1001** · *Empty Hallway Smiles Back*

**Nível:** ⚫ Quaternary

**Eixo:** EFFECT ↑ (presença) → DENSITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Familiar o bastante para incomodar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Oddcore: o corredor vazio que parece sorrir, objetos comuns levemente errados, humor e inquietação juntos.

**Paleta de cores** bege de corredor, verde fluorescente pálido, tons deslocados

**Melhores usos:** arte, conceito, editorial

**MidJourney:** `[tema], oddcore aesthetic, empty hallway that smiles back, familiar but slightly wrong --v 6`

**Prompt universal (Seedream):** `VHS camcorder freeze-frame, an oddcore scene, an empty beige hallway that somehow smiles back, ordinary objects arranged slightly wrong under pale fluorescent green, familiar enough to unsettle, analog noise and tracking lines, uncanny domestic humor, 8k upscale`

### **Op Art**

**№ 649 / 1001** · *Geometry That Makes the Retina Fight Back*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Geometria enganando a retina de propósito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Op art: xadrez ondulado e grades vibrantes que se movem sem sair do lugar.

**Paleta de cores** preto e branco vibrante, acentos cromáticos puros

**Melhores usos:** arte, capas, padrões

**MidJourney:** `[tema], op art aesthetic, warped checkerboard optical vibration, geometry tricking the retina --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of an op art composition, warped checkerboards and vibrating grids that move while standing still, Victor Vasarely geometric illusion in high-contrast black and white with pure chromatic accents, retinal trickery in razor-sharp flat print quality, 8k`

### **Optical Illusion**

**№ 650 / 1001** · *Reality Loses the Vote*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A imagem que discute com o próprio olho** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Ilusão de ótica: escadas de Penrose, rotações fantasmas e figuras que trocam de forma no olhar.

**Paleta de cores** contrastes calculados, cores de vibração

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], optical illusion aesthetic, Penrose impossible geometry, image arguing with the eye --v 6`

**Prompt universal (Seedream):** `Ultra-clean graphic composition, an optical illusion built from impossible Penrose geometry and phantom-rotation patterns, Akiyoshi Kitaoka peripheral vibration in calculated contrast pairs, the image politely arguing with its own viewer, vector-sharp precision, 8k`

### **Power**

**№ 711 / 1001** · *Authority Cast as Architecture*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → INTENTIONALITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Nota:** a gramática produtora de submissão — escala axial, massa centralizada, geometria hierárquica — foi carregada intacta das colunatas egípcias aos bulevares de Haussmann e aos planos de Germânia de Speer, cada império reinventando a mesma lei de dominância sem alteração.

**Atmosfera e mood**

**Autoridade fundida em arquitetura** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Poder: corredores de mármore longos demais, mesas ao fundo e a escala usada como instrumento de intimidação.

**Paleta de cores** mármore escuro, dourado institucional, sombra de coluna

**Melhores usos:** editorial, conceito, capas

**MidJourney:** `[tema], power aesthetic, authority cast as architecture, endless marble corridor to one desk --v 6`

**Prompt universal (Seedream):** `Shot on a 5x7 large format camera with 150mm lens, a portrait of power, one distant desk at the end of an endless dark marble corridor, institutional gold and column shadows using scale as intimidation, authority cast literally as architecture, monumental symmetry, 8k`

### **Psychedelic**

**№ 731 / 1001** · *Reality Opts Out of Straight Lines*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → COHERENCE ↓ (ausência)

**Polaridade:** XY — disrupção por ruptura

**Nota:** a linha em chicote e o campo orgânico denso do Art Nouveau chegam intactos; então a paleta secessionista contida é cortada e substituída por rodamina e Day-Glo sob ultravioleta — a vibração de valores iguais resultante destrói o decoro de superfície que governava toda a lei sensorial do pai.

**Atmosfera e mood**

**A percepção com o volume no máximo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Psicodélico: letras derretendo, espirais cromáticas e o cartaz de 1967 vibrando até quase ilegível.

**Paleta de cores** magenta e laranja vibrando, verde ácido, roxo elétrico

**Melhores usos:** música, capas, arte

**MidJourney:** `[tema], psychedelic 1967 poster aesthetic, melting lettering chromatic spirals, perception at full volume --v 6`

**Prompt universal (Seedream):** `Ultra-vivid 1967 psychedelic poster art, melting hand-drawn lettering swirling into chromatic spirals, Wes Wilson Fillmore style with vibrating magenta-orange and acid green pairs, perception turned to full volume until nearly illegible, flat silkscreen intensity, 8k`

### **Racing**

**№ 738 / 1001** · *Speed Drawn as Sacred Geometry*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a doutrina de velocidade do Futurismo, a superfície laminar do Streamline Moderne e o culto da Era da Máquina ao mecanismo exposto eram posições completas; recombinadas aqui, produzem a única estética em que um corpo de carbono simultaneamente evangeliza a velocidade como metafísica, curva-se ao vento como sua única lei e trata o motor nu como altar — uma síntese que nenhum dos três pais geraria sozinho.

**Atmosfera e mood**

**Velocidade como geometria sagrada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Corrida: panning na reta, listras de equipe e o mundo derretido em faixas atrás do carro.

**Paleta de cores** vermelho de escuderia, branco de listra, asfalto

**Melhores usos:** esporte, editorial, campanhas

**MidJourney:** `[tema], racing aesthetic, panning shot melted background, speed as sacred geometry --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F2 with 300mm lens panning at 1/30s at Monza, a racing image, the car razor-sharp while the world melts into horizontal streaks, scuderia red and stripe white over blurred asphalt, speed treated as sacred geometry, classic motorsport grain, 8k scan`

### **Revolutionary**

**№ 759 / 1001** · *Art as a Molotov Cocktail*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → INTENTIONALITY ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** não há estética anterior a herdar; a gramática da ruptura-como-composição irrompe de novo, independentemente, onde quer que o poder concentrado seja contestado pelo fazer — protesto romântico, agitação socialista, cartaz anticolonial e ruptura vanguardista reconstroem a mesma lei irredutível do zero; a marca que toma partido é o único dispositivo que nenhum movimento anterior legou.

**Atmosfera e mood**

**A diagonal vermelha da história** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Revolucionário: xilogravura de cartaz, punho e bandeira em diagonal — a imagem feita para derrubar e reconstruir.

**Paleta de cores** vermelho de bandeira, preto de xilo, papel de guerra

**Melhores usos:** histórico, editorial, design

**MidJourney:** `[tema], revolutionary aesthetic, woodcut poster red diagonal flag and fist, built to overthrow --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a revolutionary woodcut poster, a flag and fist driving one red diagonal across rough black cuts, wartime paper texture with gouged urgent linework, an image built to overthrow and rebuild in the same gesture, raw print contrast, 8k`

### **Sensory**

**№ 796 / 1001** · *Designing for the Senses*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → NUANCE ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** o ambiente redutivo e de baixa estimulação do Minimalismo chega como único pai, e Sensory o reinstrumenta com uma diretiva adicional — redução reenquadrada como dosagem ajustável, não como ausência permanente — e uma filosofia de subtração sensorial vira, uma volta depois, uma disciplina de estimulação controlada pelo usuário.

**Atmosfera e mood**

**Design para todos os sentidos** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sensorial: veludo, vidro frio, casca de cítrico — texturas compostas para serem sentidas pelos olhos.

**Paleta de cores** veludo vinho, vidro claro, laranja de casca

**Melhores usos:** produto, gastronomia, editorial

**MidJourney:** `[tema], sensory aesthetic, velvet cold glass citrus peel, textures felt through the eyes --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100 II with 120mm macro lens, a sensory still life, crushed wine velvet against sweating cold glass and freshly torn citrus peel misting oil into raking light, textures composed to be touched through the eyes, every fiber droplet and pore in focus, 8k`

### **Stormcore**

**№ 853 / 1001** · *Pressure Drop Before the Sky Breaks*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → ILLUMINATION ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** nenhuma estética está atrás de Stormcore; a resposta de assombro e terror ao clima avassalador precede a paisagem romântica e o sublime marítimo que parecem antecedê-la — ambos são codificações posteriores da mesma reação-raiz, não sua fonte — de modo que a estética gera descendentes (cinema-catástrofe, cultura de caçadores de tempestade) sem descender de nenhum deles.

**Atmosfera e mood**

**A queda de pressão antes do céu romper** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Stormcore: shelf cloud engolindo a planície, luz verde-chumbo e o segundo de silêncio total antes do primeiro trovão.

**Paleta de cores** verde-chumbo, cinza de supercelula, branco de raio

**Melhores usos:** natureza, capas, editorial

**MidJourney:** `[tema], stormcore aesthetic, shelf cloud swallowing the plains lead-green light, the second before thunder --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D6 with 24-70mm lens, a stormcore moment, a supercell shelf cloud swallowing the plains in lead-green light while the grass goes unnaturally still, one white fork of lightning testing the horizon, the pressure drop held in the second before the sky breaks, ominous vast drama, 8k`

### **Sublime**

**№ 858 / 1001** · *Consciousness Encounters Overwhelming Vastness*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a elevação retórica de Longino fornece o único pai, e Burke e Kant reinstrumentam essa herança ancorando-a no terror e na magnitude matemática/dinâmica, transformando uma doutrina da linguagem numa doutrina da escala sem adicionar uma segunda linhagem.

**Atmosfera e mood**

**A consciência diante da vastidão esmagadora** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sublime: a cordilheira ocupando o céu inteiro e a figura humana reduzida a vírgula — o belo que também assusta.

**Paleta de cores** branco de geleira, granito imenso, azul de altitude

**Melhores usos:** paisagens, arte, capas

**MidJourney:** `[tema], sublime aesthetic, mountain range filling the sky human figure as a comma, beauty that also frightens --v 6`

**Prompt universal (Seedream):** `Shot on an 11x14 view camera with 360mm lens, a sublime landscape, a glaciated range filling the entire sky while one human figure stands reduced to a comma on the moraine, altitude blue and immense granite in Ansel Adams tonal majesty, consciousness meeting a vastness it cannot hold, 8k`

### **Summer**

**№ 861 / 1001** · *Long light and the permission to slow down*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → ETERNITY ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Nota:** a tradição de lazer sazonal dos jardins de prazer fornece o único pai, e Summer reinstrumenta essa herança estreitando-a a um único registro térmico — claro, horizontal, tocado de sal — sem recombinar uma segunda linhagem na raiz.

**Atmosfera e mood**

**A luz longa e a permissão de desacelerar** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Verão: pés descalços no deque quente, limonada suando no copo e o dia que se recusa a terminar antes das nove.

**Paleta de cores** dourado de fim de tarde, azul de lago, branco de algodão

**Melhores usos:** lifestyle, natureza, editorial

**MidJourney:** `[tema], summer aesthetic, bare feet on the warm dock sweating lemonade, long light and permission to slow down --v 6`

**Prompt universal (Seedream):** `Shot on Olympus Pen EE-3 half-frame, a summer evening, bare feet on a sun-warmed lake dock beside a sweating glass of lemonade, cotton white and lake blue soaked in nine-o'clock gold, the long light granting official permission to slow down, sun-faded holiday grain, 8k scan`

### **Sweetcore**

**№ 879 / 1001** · *Sugar-coated color worn without apology*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → INTENTIONALITY ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Nota:** a cultura kawaii fornece o único pai, e Sweetcore reinstrumenta essa herança convertendo o objeto fofo em objeto comestível, a pelúcia em fondant, o mascote em cupcake.

**Atmosfera e mood**

**Cor açucarada usada sem pedir desculpa** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sweetcore: glacê pastel, morangos com brilho e laços de confeitaria — a doçura assumida como posição estética.

**Paleta de cores** rosa de glacê, menta de confeito, amarelo de baunilha

**Melhores usos:** confeitaria, branding, editorial

**MidJourney:** `[tema], sweetcore aesthetic, pastel icing glossy strawberries bakery bows, sugar worn without apology --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS R8 with 35mm lens, a sweetcore tableau, a tiered cake in pastel icing crowned with glossy strawberries beside bakery boxes tied in ribbon, frosting pink and confection mint under vanilla-soft light, sugar-coated color worn entirely without apology, delicious crisp detail, 8k`

### **Teddy**

**№ 895 / 1001** · *Comfort Overbuilt in Faux Fur*

**Nível:** 🟣 Secondary

**Eixo:** EFFECT ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a linhagem do conforto doméstico fornece o único pai, e Teddy a reinstrumenta por um único dispositivo — o objeto segurado que acalma — em vez de fundir vários movimentos.

**Atmosfera e mood**

**O conforto superdimensionado em pelúcia** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Teddy: casacos de pelúcia com ombros de urso, poltronas que engolem e o aconchego levado à escala de engenharia.

**Paleta de cores** caramelo de pelúcia, creme de sherpa, castanho de urso

**Melhores usos:** moda, interiores, produto

**MidJourney:** `[tema], teddy aesthetic, bear-shouldered plush coats armchairs that swallow, comfort overbuilt in faux fur --v 6`

**Prompt universal (Seedream):** `Shot on Phase One IQ4 with 120mm lens, a teddy study, an oversized caramel faux-fur coat with bear-scale shoulders sunk into a sherpa armchair built to swallow its owner, plush pile rendered strand by strand in soft warm light, comfort deliberately overbuilt to engineering scale, sumptuous texture, 8k`

### **Uprising**

**№ 930 / 1001** · *Defiance Printed Large Enough for the Street*

**Nível:** 🟤 Tertiary

**Eixo:** EFFECT ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** o Romantismo revolucionário, o Realismo socialista e a Internacional Situacionista convergem aqui, cada um fornecendo uma camada estrutural que nada mais substitui — o que fixa Uprising como híbrido de múltiplas linhagens, não como revisão de pai único.

**Atmosfera e mood**

**A rebeldia impressa grande o bastante para a rua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Levante: cartazes em serigrafia de duas cores, punhos tipográficos e a palavra de ordem dimensionada para ser lida do outro lado da praça.

**Paleta de cores** vermelho de serigrafia, preto de punho, cru de cartaz

**Melhores usos:** ativismo, design, editorial

**MidJourney:** `[tema], uprising aesthetic, two-color screenprint posters typographic fists, defiance printed for the whole square --v 6`

**Prompt universal (Seedream):** `Shot on Canon EOS-1V with 24mm lens, an uprising in motion, a sea of two-color screenprinted posters and typographic fists raised over the crowd, screenprint red and fist black on raw poster stock sized to be read across the square, defiance printed at street scale, urgent documentary energy, 8k scan`

### **Vanguard**

**№ 937 / 1001** · *Experiment Arrives Before Permission*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → INTENTIONALITY ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** a quebra é o próprio método: cada gesto toma posição contra o passado imediato, e a celebração dispara o abandono — uma gramática que corta cada definição no momento em que ela assenta.

**Atmosfera e mood**

**O experimento chegando antes da permissão** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Vanguarda: a dupla exposição que ninguém aprovou, a forma que ainda não tem nome e a certeza de que o público alcança depois.

**Paleta de cores** preto experimental, prata de laboratório, vermelho de manifesto

**Melhores usos:** arte, editorial, conceito

**MidJourney:** `[tema], vanguard aesthetic, unapproved double exposure form without a name yet, experiment before permission --v 6`

**Prompt universal (Seedream):** `Experimental double-exposure photograph, a vanguard composition, a face and a collapsing structure layered without anyone's approval into a form that has no name yet, laboratory silver and manifesto red bleeding through experimental black, the audience scheduled to catch up later, fearless formal invention, 8k scan`

### **Wellness**

**№ 974 / 1001** · *Mind, Body, and Space Under One Rhythm*

**Nível:** 🔴 Primary

**Eixo:** EFFECT ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** retire a cromoterapia, a cura sonora e o plantio biofílico e uma instrução sobrevive intocada — design como intervenção terapêutica — sem um único movimento-pai rastreável, já que cada afluente alimenta uma lei irredutível em vez de originá-la.

**Atmosfera e mood**

**Mente, corpo e espaço sob um só ritmo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Wellness: o tapete desenrolado ao nascer do sol, chá em cerâmica crua e a respiração marcando o único horário do dia — o cuidado como arquitetura.

**Paleta de cores** verde-sálvia, creme de linho, madeira clara

**Melhores usos:** saúde, lifestyle, branding

**MidJourney:** `[tema], wellness aesthetic, mat unrolled at sunrise tea in raw ceramic breath as the only schedule, care as architecture --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-T50 with 33mm lens, a wellness morning, a yoga mat unrolled toward the sunrise window beside steaming tea in raw ceramic and folded linen, sage green and pale wood breathing in first light, mind body and space agreeing on a single rhythm, restorative calm clarity, 8k`

## Leitura do padrão — o que as 32 estéticas confirmam

EFFECT é o caso mais nítido dos oito já mapeados, porque a lista inteira responde a uma única pergunta: **o campo já estava no ângulo de repouso quando o gesto chegou?**

### **O dado que salta antes de qualquer cluster**

**Zero entradas suprimidas.** Das 32, todas são EFFECT ↑. Nenhuma Naive, nenhuma Hermitcore, nenhuma Liminality — nenhum caso-limite definido pela ausência. Isso repete exatamente o comportamento de THEME, e pelo mesmo motivo estrutural: ☉ e o Bindu são o mesmo ponto (contido e liberado), e ambos são posições de **limiar**. Uma estética classificada aqui só existe porque a agulha já caiu para um lado. "Impacto suprimido" não é uma estética menor — é o estado anterior ao evento, e nada anterior ao evento pode ser catalogado. O registro ↓ da posição continua válido como prompt, mas nenhuma das 1001 o ocupa como identidade.

### **Os cinco clusters**

**1. Ataque perceptual direto — o maior bloco.**

Op Art, Optical Illusion, Hypnoticcore, Psychedelic, Mirrorcore, Distorted, GLITCH, Kineticism, Liminal Space, Oddcore. Aqui a cratera é literalmente retiniana: a retina "reage" (Op Art), o olho não consegue resolver (Hypnoticcore), o quadro se duplica até a realidade escorregar (Mirrorcore). É a definição da posição executada sem metáfora — consequência antes da compreensão, o corpo atingido antes de o nome chegar.

**2. Força aplicada ao campo social.**

Power, Revolutionary, Uprising, Vanguard, Edgy. Os três verbos do Bindu operam explícitos: Power é escala axial produzindo submissão (Transgredir sem território, quando falha), Revolutionary é arte como coquetel molotov, Uprising é desafio impresso grande o bastante para a rua, Vanguard é o experimento que chega antes da permissão. A cratera aqui é política, e a criticalidade auto-organizada é histórica: nenhum desses gestos funciona sem um campo já saturado.

**3. Escala e sublime — a detonação por magnitude.**

Sublime, GIANT, Stormcore, Escapism. Stormcore é o caso perfeito da física da posição: "queda de pressão antes do céu quebrar" é literalmente a pilha de areia um grão antes da avalanche — a estética *é* o campo tensionado, não o raio.

**4. Dose calibrada — e é aqui que o sistema prova que não é sobre volume.**

Lagom, Sensory, Wellness, Sweetcore, Teddy, CITRUS, Summer, Dopamine, Jovial. Lagom é a entrada mais reveladora da lista inteira: "o teste da quantidade certa" classificado sob impacto máximo. Isso confirma o que a página afirma e que seria fácil ler errado — Effect não mede o quanto se grita, mede a largura da cratera. Uma estética que acerta a dose exata deforma o campo com mais precisão do que uma que o inunda. Sensory diz isso na tese: redução reenquadrada como **dosagem ajustável**, não como ausência permanente.

**5. Velocidade e imediatismo.**

Racing, Dynamic, Bold, Artificial Life. Bold nomeia o contrato: "construído para ser atingido, não considerado."

### **O que a lista prova sobre os dois regimes**

A página distingue **carga tenebrista** e **carga luminosa** como correção deliberada contra o default do gerador (que colapsa "carga emocional" em escuridão). A lista prova que a distinção não é teórica: o corpus se parte limpo em dois. De um lado Power, Revolutionary, Edgy, Stormcore, Distorted, Liminal Space. Do outro Wellness, Summer, CITRUS, Teddy, Sweetcore, Lagom, Jovial. Mesma posição, mesma exigência de impacto imediato — regimes opostos de luz. Nenhuma estética da lista habita os dois.

### **O padrão de polaridade**

Onde o mecanismo do golpe é uma **lei física ou perceptual**, a polaridade é XX por transmissão: Power (escala axial produzindo submissão, do Egito a Speer), Optical Illusion, Kineticism, GLITCH. A física do impacto não evolui — ela reaparece idêntica em cada época que precisa dela. Onde o golpe é uma **decisão de gosto ou de política**, a polaridade vira XX por revisão (Lagom, Sublime, Bold, Sweetcore) ou XY (Psychedelic, Revolutionary, Vanguard, Stormcore, Edgy, Dopamine). É um comportamento que nenhuma das outras posições exibe com essa limpeza.

### **O teste único da posição**

Removida a *intenção* do gesto, a imagem ainda entrega consequência? Por isso Op Art, Power e Lagom convivem — quadrado vibrante, colunata imperial e a xícara na medida exata são objetos de natureza incomparável, mas todos passam pela mesma pergunta: **o mundo devolveu alguma coisa, e dá para medir o tamanho do que devolveu?** Se a resposta exige legenda, o golpe não aconteceu — foi só barulho, e barulho é metabolizado e descartado dentro da hora.

# RESONANCE — the Sankofa Bird

<aside>
🦅

**Essência.** Persistência depois da exposição direta — o que continua vibrando quando a cena, o encontro ou a exposição já terminou. O ideograma é o pássaro Sankofa dos Akan: o corpo avança, a cabeça gira totalmente para trás e o ovo — o futuro — viaja em segurança no bico, porque só o que completa a viagem de volta continua vibrando depois. Seu verbo é **Atravessar / Crossing**: cruzar um limiar e voltar transformado — travessia sem retorno é fuga com passaporte. Na imagem, o elemento se prova por um único dispositivo projetado para continuar tocando na memória depois que a página vira: a deformação vale mais que a impressão.

</aside>

## Prompt-mestre (imagem-síntese)

> **↑ RESONANCE — universal prompt.** A figure caught mid-departure at a real threshold with an unambiguous stayer's side and leaver's side — [the aesthetic's own crossing point: a platform, a doorway, a porch, a harbour, a forest edge, a kitchen door] — the torso already committed forward onto the leading foot while the neck and head counter-rotate a hundred degrees back toward the place being left, held rather than glanced, the gaze seeking that place and never the lens so the viewer becomes a second witness to a departure never addressed to them; one hand occupied with a single carried object clutched or steadied against the body — [the aesthetic's own egg: an heirloom, an instrument, a jar, a letter, a garment, a tool that belongs to the world being left] — and the other loose at the side, nothing performed for the camera because the attention is entirely on what is being carried across; the left-behind plane visibly still working after the body has moved on — a second figure completing an action alone, a chair still holding a shape, a door left ajar, dust or steam still drifting along the exact line just walked — because a room that goes inert the instant the protagonist exits reads as a stage rather than a place; trailing negative space kept wider behind the figure than ahead of it, and depth receding through a real architectural throat — [a corridor of doorframes, a line of pillars, a receding road, a row of trees, a colonnade of harbour pilings] — each repetition a fainter echo of the one before so the eye reads distance as delay rather than as recession; wardrobe carrying a documented previous life rather than a fresh one, heirloom logic over trend logic, one clearly older piece worn beside one clearly newer so neither decade wins, with no logo, no season marker, and nothing that dates the image to the day it was taken instead of to the memory it retrieves; end-of-day, half-light, or early-tungsten warmth with a magenta bias in the shadows and a slow continuous falloff, never the neutral clarity of midday, and visible entropy in the architecture — flaking paint, water-stained plaster, a cracked pane — lit so time's prior passage through this place is legible; one small durable mark left on the body as proof an earlier contact was never erased — [a faded tan line, a groove where a ring used to sit, salt-dried hair, a fine scar, a callus] — with skin left true-textured and one single period-specific grooming marker from a decade other than the present; camera held at the height and position of the one who stays behind, at the threshold's own edge and never following past where a person left there could still see, long lens compressing the echo into one plane, the frame found rather than authored; and exactly one strange, structurally specific detail placed once and never repeated — [the aesthetic's own quiet device: a clasp catching the only sharp highlight, a single lit window, one object out of period, one sound-source visible in frame] — engineered to keep replaying in memory an hour after the page is turned, because deformation outranks impression and three competing devices produce spectacle, which is metabolised and discarded within the hour.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre ↑):

> No hard midday clarity, no neutral or cool colour temperature, no fully faced-forward departure with the head unturned, no glance substituted for a held turn, no empty hands and no absent carried object, no cleared single-era set, no left-behind plane already inert, no logo or current-season marker, no smoothed or fully corrected skin, no grooming current enough to date the image to its shooting day, no second competing device in the same frame, no hard-cut light edge, no immediate spectacle readable and discarded in one glance, no gaze seeking the lens, no motion so fast the return is not legible.
> 

### Como adaptar o prompt a cada estética

**Como usar para as ~55 estéticas da lista.** Só quatro decisões mudam; a arquitetura é idêntica.

**1. O limiar** — o ponto de travessia próprio da estética: para **Hygge / Cozy / Nestcore**, a porta iluminada de dentro contra o escuro de novembro; para **Sertanejo / Cuban / Scouse**, a soleira que dá para a rua ou a estrada de terra; para **Summer Camp**, o portão do acampamento na última manhã; para **Cottagecore**, a porteira do jardim; para **Melancholia / Elegiac**, a janela na hora azul.

**2. O ovo (o objeto carregado)** — para **Sertanejo**, a viola; para **Halcyoncore**, o pote de âmbar; para **Bohemian Vintage**, o têxtil antigo dobrado no braço; para **Cluttercore / Grandmillennial**, o objeto herdado retirado da prateleira; para **ASMR / Cymaticism**, a própria fonte sonora visível; para **Rockabilly**, a chave do carro; para **Yugo-Nostalgia**, o distintivo ou o objeto doméstico do regime.

**3. O estado de custódia** — a cláusula de proveniência do Sankofa, escolha um por imagem: **footprint** (rastro perecível, sobrevive só perto da fonte — Anemoia, Halcyoncore, Jovial); **scar** (o que resta é custo não resolvido — Yugo-Nostalgia, DECAY, Eerie, Soft Colonial Wanderlust); **wellspring** (custódia sem controle, continua servindo a quem recebe — Hawaiian, Irish, Cuban, Folkloric, Sertanejo, Scouse).

**4. O dispositivo único** — nunca dois. Para **Cryptidcore**, inverta para o registro de beleza retida (o quadro que se recusa a resolver, ESTHETICS ↓); para **Synthwave / Anemoia**, use a variante de degradação de sinal (grain, aberração cromática, timestamp); para **Cymaticism / Pulsing**, o dispositivo é a própria vibração visível na água ou na superfície.

Nada na arquitetura do prompt nomeia lugar, tribo ou estilo — só os mecanismos que a página já define como RESONANCE: a volta e não só a travessia, o ovo em custódia, a Marca de Campo, o plano deixado para trás ainda em movimento, o eco na profundidade, a luz de tempo já passado, e um dispositivo só.

## Fundamentos do elemento

**Identity.** Persistence after direct exposure — what continues to vibrate once the scene, the encounter, or the exposure has ended. Its ideogram is the Akan Sankofa, the bird that flies forward with its head turned fully back, carrying an egg — the future — in its beak: the body advances, the gaze recovers, and the egg travels safely between the two movements, because only what completes the return journey keeps vibrating afterward. Its verb is **Atravessar / Crossing**: to cross a threshold and come back changed, never to cross and simply keep going — a crossing without return is flight carrying a passport. Continuity/Disruption operates directly in this position, since every threshold is a rupture the continuity must digest; **Transmutar** visits as an accomplice, because a genuine change of state always resonates precisely because it cannot be undone. In an image this element is proven by one device engineered to replay in memory after the page is turned, or by its opposite — a deliberate, contented transience that never asks to be kept. (Distinct from EFFECT, 7 — the Bindu measures the strike at the moment of impact; the Sankofa measures what the strike leaves vibrating once the moment has passed. Distinct from SAGA, 9 — the Tree of Uruk accumulates the whole ringed history; Resonance is concerned only with what a single exposure leaves active after it ends, before it has become a history at all.)

**The return journey, not the crossing.** A threshold crossed and never revisited is not this element — it is only departure, and departure alone reads as escape rather than resonance. What the image must prove is the return half of the arc: the head already turned back before the body has finished leaving, the object carried from one side of the threshold to the other intact. The shadow of Atravessar is exactly this failure kept in motion: a figure who keeps crossing thresholds and never once looks back, using movement itself as an alibi against consequence.

**The carried object — the egg.** Resonance requires custody of one small, specific thing ferried across the crossing: a letter, a camera, a child's coat, a jacket clutched to the chest, a ring worn on the wrong hand. This is not an accessory chosen for style; it is evidence that something survived the crossing undamaged, and the frame must make its handling — held, clutched, protected — more visible than its description.

**Governed inheritance — the Sankofa's provenance clause.** The ideogram's own tradition specifies what happens after the crossing: Sankofa belongs to Akan and Adinkra visual culture specifically, and its use carries a standing demand for provenance, credit, and care against extraction — a lineage that must be citable, not merely evocative. Translated into image terms, this yields three legible states the frame can occupy. **Footprint** (emerging): a brief trace that survives only as long as proximity to its source is maintained — a scene that reads as memory precisely because it feels perishable. **Scar** (compensating): what remains is unresolved cost — a debt, a wound, an obligation the frame does not disguise as legacy; the origin calls it a mark of honor because it cannot govern what became of it. **Wellspring** (integrated): the fullest register — the image keeps offering resource and context without demanding the original source's constant presence or a single authorized reading of it, custody without control. A Resonance image that borrows a visual inheritance — a heirloom garment code, a diasporic gesture, a historical craft mark — should read as one of these three states, and the wellspring state is the aspiration: what is carried forward keeps working for whoever receives it next.

**Marca de Campo — deformation outranks impression.** What impresses passes; what deforms remains. An image built for immediate impact fades from memory at the same rate it arrived; an image built for Resonance leaves a durable dent in how the viewer afterward reads every comparable image — a cognitive resting point the eye keeps returning to. The single most diagnostic failure of this element is loudness: three devices competing for attention produce spectacle, and spectacle is metabolized and discarded within the hour. One quiet, structurally specific device — placed once, never repeated in the same frame — is what a mind cannot fully process on first contact and is forced to keep replaying. Ungoverned, this same mechanism curdles into its own Vale: resonance without custody becomes extraction, nostalgia rented rather than earned, a memory worn as someone else's costume.

**The afterimage, not the encore.** Borrowing the retina's own physics: stare at a strong light and close your eyes, and the image persists, burned in, independent of whether the light is still there. Resonance photographs the burned-in afterimage rather than the light source itself — proof that the scene continues without needing the subject present to sustain it. This is also why absence outperforms presence in this element: the empty chair that still organizes the room, the doorway that keeps admitting light after the figure has already crossed it, the second figure left in the frame still orbiting a gravity that has already exited.

## Corpo — postura, olhar e gesto

**Model posture & structure.** The body is caught mid-departure, never at rest and never at full stride — weight already committed onto the leading foot, torso continuing its forward momentum while the neck and head counter-rotate ninety to a hundred and twenty degrees against the walking line, so the whole figure reads as two decisions occurring in the same instant: leaving and returning. The pause is not a stop; it is suspended motion, a held exhale, the exact frame between the step already taken and the one not yet completed. Hands are rarely empty and rarely free — one hand occupies itself with the kept object, protecting or steadying it, while the other stays loose at the side, because a Resonance body has already allotted its attention to what it is carrying and has none left to spend on performing for the lens. Where a second body appears, it is placed in the plane being left behind, its own motion continuing at the pace the departing figure has already abandoned — a figure still setting a table, still leaning in a doorway, still watching a train no longer visible.

## **Gesture.**

**Atravessar · Crossing** is the position's only verb: to pass through a threshold and come back altered, the head recovering what the body's advance would otherwise leave behind. Photographed, it is the body already walking away while the neck has committed fully to the look back — never a glance, always a held turn, because a glance reads as reflex and a held turn reads as decision. The gaze does not seek the lens; it seeks the place being left, so the viewer becomes a second witness to a departure that was never addressed to them. The shadow of the gesture is motion as alibi — a figure who crosses and crosses and never once turns, using forward momentum to outrun the return the position demands. **Transmutar · Transmuting**, borrowed from Effect, is the position's one complicit gesture: a change of state caught mid-frame that visibly cannot be reversed — fabric already becoming something else, a silhouette altering between exposures — because genuine transmutation is itself a form of resonance; what cannot be undone is what keeps vibrating.

## Regras de imagem — do figurino à prova de eco

**Look & styling continuity.** The wardrobe carries a documented previous life rather than a fresh one: heirloom logic over trend logic, a garment with somebody else's wear already in it, vintage and new worn in the same look so neither generation dominates — a man's watch worn on a woman's wrist, a father's coat recut to a daughter's shoulder, a jacket clutched rather than merely worn. Nothing in the styling is season-stamped; no logo, no current silhouette marker, nothing that would date the image to the year it was taken rather than to the memory it is retrieving. Where the register runs toward engineered nostalgia, period-specific signal is applied at a controlled, precise strength — grain, a slight chromatic fringe at the garment's edge, a compression artifact from an earlier decade's recording technology — so a brand-new object arrives on the body pre-remembered, its actual newness undetectable under the inherited signal.

**Camera.** The camera holds the position of the one who stays behind — at a threshold's own edge, a platform's far end, a doorway's inner side — never following the departing figure past the point where a person left in that place could actually still see them. A long lens compresses the depth of a corridor, a road, or a colonnade of doorframes so that repetition reads as echo: each further frame a fainter, delayed repetition of the same shape, an architecture built to keep answering itself after the first figure has already passed through. Where duration is available, the governing discipline is one long, unbroken dolly or crane movement rather than a cut, because an edit resolves the moment and this element depends on the moment staying open — the viewer must inhabit the space long enough to begin building their own memory of it, since resonance requires proprioceptive time, not information delivered quickly. An anamorphic lens is admissible for exactly this reason: its specific oval bokeh and falloff already read, culturally, as inherited cinema rather than as a document taken today. Where the register is a still frame rather than a sequence, the camera is locked at the height of a genuine bystander, not lifted to an authored vantage — the frame must feel found, not staged, even though every element in it is decided. Where the still frame itself is asked to carry the whole burden of time's passage, the negative or file may be distressed directly — scratched, dust-marked, bleached at the edges — not corrected as flaw but kept as structural proof that time has already touched the image before the viewer reaches it.

**Composition.** Trailing space is left open behind the departing figure — more negative space in the direction just vacated than in the direction of travel — because that emptied plane is where the past is still standing even though nothing occupies it. Depth recedes through a real architectural throat: a corridor of doorframes, a receding road, a line of harbor pilings, each one a fainter repetition of the one before it, so the eye reads distance as echo rather than as simple recession. The over-shoulder turn sits slightly off the frame's center, never dead-centered, so the composition itself performs the asymmetry between advancing and looking back. Wherever a second figure or a doubling device is available, it is placed one beat downstream in the same gesture — a figure in the left-behind plane still completing an action the departing figure has already finished — proof that the frame's own time has not stopped just because the protagonist has moved on.

**Lighting.** The governing light is the light of something already becoming a photograph even as it is taken: end-of-day light, half-light, the amber wash of a tungsten bulb switched on too early or too late — never the neutral clarity of midday, which records rather than remembers. Where the frame draws on the cinema register, the palette runs warm and deliberately desaturated, magenta-biased in the shadows and muted in the greens, because that specific colour displacement is what the visual cortex has already learned to read as recovered memory rather than as a live event. Falloff is slow and continuous rather than hard-edged, so the frame's brightest point fades toward its darkest without a decisive line — nothing in this element is announced with a hard cut of light, because a hard cut belongs to the present tense and this element belongs to the tense of return. Where the setting is architectural, visible decay — flaking paint, a cracked pane, water-stained plaster — is lit so its entropy is legible; the physical evidence that time has already passed through this place is what confirms the memory cannot simply be handed back intact.

**Beauty detail.** Skin and hair carry one precise temporal marker drawn from a decade other than the one the image is dated to — a period-specific parting, a single vintage cosmetic technique (a winged line, a stained lip pressed rather than painted) — so the face itself performs the same return journey as the body, and the marker must be singular and legible rather than layered into full costume. Texture stays true and untouched rather than smoothed: a faded tan line, a groove worn into a finger where a ring used to sit, salt-dried hair, skin that has been outdoors in real weather — small physical deformations that function exactly as Marca de Campo functions, proof that something durable was left by an earlier contact and never fully erased. Where scent or atmosphere needs a visual register, it is rendered as haze or soft blur immediately around the head and shoulders — the visible trace of something that has already dispersed into the air but has not yet finished dispersing. Refused: any grooming decision current enough to date the image to its shooting day, and any polish so complete that no evidence of a prior life on the body remains legible. At the register's most extreme — where the afterimage must outlast the image's own resolution — beauty can be the withheld term entirely: an intentionally unresolved face or figure, grain, scan-line, or fog standing between the viewer and full legibility, because full resolution collapses the memory-tense back into a document and kills the effect; here the beauty detail is the withholding itself, not a feature added to compensate for it.

**Cenography.** The set is a threshold with an unambiguous stayer's side and leaver's side: a station platform, a doorway, a coastline at dusk, a family house's porch, a harbor. Wherever possible, the room being left behind must visibly continue functioning without the departing figure — a chair still holding its sitter's warmth, a door left ajar rather than closed, a meal left half-finished, a second figure completing a task alone — because a set that simply goes dark the moment the protagonist exits reads as a stage, not as a place with its own life. Layered eras are permitted and often necessary: a decor one generation older than the wardrobe, a fixture original to the building beneath a recent renovation, physical evidence that this place has already outlived at least one departure before this one. Refused: a cleared, neutral, single-era set with no evidence that anyone else has ever occupied or will continue to occupy it — a location that dies the instant the camera stops looking is the opposite of this element.

**Afterimage proof.** Wherever the composition allows it, plant one device that proves the scene keeps vibrating without the departing figure's continued presence: a shadow still crossing a threshold the body has already cleared, dust still settling along the path just walked, a reflection or echo in glass or water lagging a beat behind the gesture that produced it, a second figure whose motion visibly continues the rhythm the first figure just set down. This is the position's own retinal afterimage made photographic — the closest a still frame comes to proving that a signal keeps active after its source has moved past the frame line. A device that shows the left-behind plane already inert, with nothing still moving in it, is the single most legible failure this element can produce.

## Praticantes (dos códices)

**Prompt-ready practitioner lines (from the codices).** *Cinema.* Glen Luchford — dramatic chiaroscuro cinema lighting, anamorphic shallow depth of field, warm desaturated Technicolor palette, one long unbroken dolly or crane sequence shot, a decaying architectural setting (old hotel, night road, isolated villa), the weight of celluloid preferred over digital sharpness. *Photography.* Deborah Turbeville — the negative distressed before printing: scratched emulsion, dust, bleached and torn edges kept as structural argument rather than corrected as flaw, a muted narrow band of grey tonal range, models placed in a decaying interior (a municipal bathhouse, a crumbling garden room) physically and psychologically distant from one another, each figure islanded with no shared eye contact — collective isolation photographed as the social frequency Resonance actually transmits. Vincent Peters — black-and-white cinematic key light with venetian-blind or window-shadow patterning, silver rim light, film-noir interiors, a pensive gaze held off-lens, every portrait built to read as already a memory of a film that never existed. Sarah Moon — the undisputed master of the photographic afterimage: soft focus and Polaroid degradation staged so the image feels like a fading memory or an impressionist painting rather than a document. Yelena Yemchuk — soft overcast Eastern European light, faded romantic colour, real locations and real faces, a dreamlike documentary drift between home, exile, and return. Sam Rock — overcast elemental daylight, rural and equestrian settings, wet and coarse textures foregrounded, sober romantic framing, the garment attesting to the land it stands in. Joshua Woods — warm filmic colour in neighborhood and family settings, tailored diasporic styling, a nostalgic light treating memory as a living, present tense. Guy Aroch — end-of-day light staged as a cast member rather than a condition, Seventies haze relayed as inherited code rather than ironic quotation, the Sankofa compound gesture of crossing while looking back over the shoulder. Mert & Marcus — the mid-century sweater-girl code carried forward as "beautifully subdued," close-value knitwear held to a five-dilutions tonal discipline, the heirloom code kept close and guarded rather than offered to the lens. Peter Lindbergh — a protagonist's period coiffure moving through a real landscape as narrative, costume arc doing the work of plot, retro makeup and cinematic feel staged as memory already in motion, thresholds and roads photographed as the crossing itself rather than the arrival. Bruce Weber — Americana memory sustained as a single warm motif season after season. Mario Sorrenti — raw, diary-like emotional proximity. Petra Collins — dreamy neon-and-pastel soft focus staged in a teenage bedroom or bathroom, the surreal interiority of girlhood rendered as an already-nostalgic present tense. Alasdair McLellan — British youth culture and working-class vernacular photographed with a romantic, nostalgic eye, casting and location rooted in specific regional histories that stand as testaments. Jamie Hawkesworth — warm documentary encounters with strangers on real journeys, sun-drenched and serendipitous, the crossing itself the subject. Renell Medrano — kinetic community intimacy, a family album's warmth elevated to high art, subjects sharing real space and real history. Théo de Gueltzl — monumental natural landscapes (jungle, desert) staged as the crossing between human and earth, sculptural form emerging from real environmental immersion. Fanny Latour-Lambert — a timeless, painterly quality blurring eras, subjects left slightly unkempt or stripped of modern artifice inside romantic, somber settings. Dominique Issermann — black-and-white campaigns held in the grey dilutions, intimate and wind-touched, the model's gaze fixed on something the frame withholds. Shaniqwa Jarvis — emotional atmosphere photographed before the garment, communities held in warm, protective frames that keep what the moment felt like. *Styling.* Jacob K's retrieved myth — aged brocade, layered torn tulle, structured Victorian corsetry, black lace and heavy velvet against subtle prosthetics or conceptual facial jewelry, staged inside fog, broken furniture, and dust, statuesque silhouettes echoing gothic church façades. Nell Kalonji's carried egg — garments that read as belonging to forgotten archives or childhood memory of the African and Caribbean diaspora, the crossing held between inherited family memory and the present-day fashion image without losing either register, fabric and pace sustained slowly enough for the memory to breathe. *Cenography.* Gary Card's grotesque persistence — the gargoyle's logic of ornament and warning fused into one figure, melted-look polystyrene monster sculptures, colored resin dripping down the set wall, a labyrinthine layout sprayed with fluorescent club-kid graffiti — proves the position can resonate as anarchic humor kept alive inside a set's own decay rather than only as wistful memory; the after-image here is comic dread, not nostalgia, and it is exactly as durable. *Editorial governance.* Melka Tréanton's inversion of the position — Resonance tuned instead to what is rising rather than what is departing: kinetic mid-jump, mid-laugh framing of a generation still gathering light, the accessible find styled with vanguard authority — is Resonance's own opposite reading, useful as a diagnostic contrast: the position can vibrate with a past being carried forward or a future not yet arrived, but never with the settled present. *Film anchor.* Timothée Chalamet's Elio at the fire in Call Me by Your Name — the held look back as the entire aesthetic in one static shot. *Cryptid document.* The Patterson–Gimlin 16mm Bluff Creek footage as the position's found-footage ancestor; Toriyama Sekien's 1776 yōkai atlas as the printed-monster-catalog lineage it descends from; The Blair Witch Project's diegetic camera; Todd Hido's lit-window night exteriors; the anonymous trail-camera vernacular itself held up as house style — mystery measured only by whether the image still resists resolution on a third look.

## Polaridades — repertório amplificado (↑ presença) e suprimido (↓ ausência)

**↑ Amplified — repertory.** A singular signature engineered for retention rather than impact: one strange, structurally specific detail against a quiet field, a body caught mid-departure with the head already recovering what the advance would otherwise abandon, a kept object visibly protected in the hand, trailing negative space left open behind the figure, echo built into the architecture's own repetition, end-of-day or tungsten-memory light, and one small durable mark on skin or hair proving an earlier contact was never fully erased — an image that keeps working an hour after the page is turned because it deformed rather than merely impressed.

> **↑ Prompt.** On a half-lit station platform at the last minutes of dusk, a figure mid-stride toward the exit with the torso already committed forward and the head turned a hundred degrees back over the shoulder toward the platform's receding line of iron pillars, each pillar a fainter echo of the one before it into the depth of the frame, one hand clutching a worn leather satchel to the chest as the single carried object, the other hand loose and open at the side, a second figure out of focus on a bench in the left-behind plane still lifting a hand mid-wave, warm desaturated tungsten light with a magenta bias in the shadows and a slow continuous falloff from the platform lamp to the dark at the tracks, faded vintage tailoring worn with one clearly newer piece so neither decade wins, a single fine scar visible at the wrist in close crop as the one durable mark the skin kept, steam or dust still drifting along the exact line the figure just walked, the whole image quiet and monochrome-leaning but for the one warm pool of lamplight, one strange precise detail — the satchel's brass clasp catching the only sharp highlight in the frame — engineered to keep replaying in the viewer's memory long after the platform empties.
> 

> **↑ Negative line.** No hard midday clarity, no neutral or cool colour temperature, no fully faced-forward departure with the head unturned, no empty hands, no cleared single-era set with nothing left behind still moving, no logo or current-season marker, no smoothed or fully corrected skin, no second competing device in the same frame, no immediate spectacle that could be read and discarded in one glance.
> 

**↓ Suppressed — repertory.** Lightness and deliberate transience: fugitive colour, real motion blur, weather that will visibly erase the scene by evening, a figure who crosses and keeps walking without ever turning back, no kept object, no durable mark, no bid for permanence of any kind — an image content to be beautiful exactly once.

> **↓ Prompt.** A figure half-dissolved in rising steam on a station platform at midday, walking directly away from the camera with the head never turning, hands empty and swinging loose, garments in fugitive pastel cotton that reads as if it will fade in the wash by evening, real motion blur softening the entire sleeve and hem, the platform behind them already scrubbed of any other figure or object, flat neutral daylight with no warm bias and no falloff, no scar, no mark, no watch, nothing on the body that carries a previous owner or a previous decade, the image content to be beautiful once and unconcerned with being kept.
> 

> **↓ Negative line.** No over-shoulder turn, no kept or protected object, no trailing negative space, no echo or repetition in depth, no tungsten or magenta-biased warmth, no decaying or layered-era architecture, no second figure continuing motion in the left-behind plane, no durable mark on skin or hair, nothing engineered to be replayed.
> 

**Additional ready-made prompts (from the Fashion Codes and Encyclopedia lines).**

> **Engineered-nostalgia prompt (signal degradation).** A brand-new technical jacket photographed as if captured at a decades-old underground gathering: simulated film grain, chromatic aberration fringing the garment's edges, low-resolution early digital compression, artificial light leaks and flash glare, a small timestamp visible in the corner, the model clutching the jacket to her chest while glancing back over her shoulder, the garment's actual newness undetectable beneath the inherited signal, subcultural memory triggered rather than described.
> 

> **Hybrid-signal prompt (memory colliding with the present).** Razor-sharp modern digital detail on an embroidered couture bodice colliding with corrupted analog scan lines and coarse film grain sweeping the lower half of the frame, chromatic aberration fringing the fabric edges, artificial magenta and amber light leaks, the model walking out of frame while looking back over her shoulder, the garment kept pristine inside the decayed signal — the image already becoming a photograph of itself while it is taken.
> 

> **Beauty-withheld prompt (the afterimage outranking resolution — the Cryptidcore register, RESONANCE ↑ → ESTHETICS ↓).** A single ambiguous figure at roughly one-and-a-fifth ordinary stature crosses a clearing once, at their own unhurried pace, occupying about a third of the frame with no verifiable scale reference and the face never delivered to the lens — if the camera catches it, the frame is dead. Overcast light at a cool 7500K, underexposed two stops, camera held at hip height in the Patterson–Gimlin Bluff Creek grammar; a peat-dark loch, cedar fog at hip height, one cabin window's warm rectangle held on wet leaf litter for the duration of a single cigarette, then extinguished. One trail-camera frame at 850-nanometre infrared, monochrome green, stands as the image's centrepiece — the only light source the eye itself cannot see — beside one warm 1900K campfire-amber point at frame-right and one hazard red used exactly once. Waxed cotton and technical fleece carry six months of real, honestly flattened wear rather than performative pre-distressing, plaster dust settled at the boot, every material recording its own decay the way paper yellows and emulsion scratches; nothing in frame is polished. In the grade the finished frame is reduced toward 480p, twelve percent grain added, the green channel pushed toward phosphor — beauty is not added to this image, it is the thing being withheld by law, so the eye is forced to keep working on it after looking away, and any frame that still resolves on a third look has already failed and must be degraded further or cut.
> 

> **Kinetic-afterimage prompt (velocity transmitted, not depicted — the TECHNIQUE ↑ → RESONANCE ↑ rupture line).** A dancer's body shot directly overhead on raw cotton duck spread across the floor, caught mid-swing with a paint-loaded skirt at the exact instant of one uncorrectable three-hundred-millisecond commitment, raking light at a low angle so every ridge of wet pigment casts a real micro-shadow, no beauty light and no smoothing so each mark reads as forensic evidence of the speed that made it, the all-over field of colour running to every edge of the frame as if it continued past it, the image built to leave a mark still vibrating in the viewer's own spine after the eye has already moved on.
> 

## Estéticas relacionadas a RESONANCE (A–Z)

As 46 estéticas classificadas sob RESONANCE presentes na lista, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary · ⚫ Quaternary), eixo secundário com presença (↑) ou ausência (↓), e polaridade (XX — continuidade · XY — disrupção).

**Nota da lista:** a análise da seção fala em "~55 estéticas", mas a lista bruta trouxe 46 entradas classificadas — todas estão abaixo. Jovial, pendência herdada da seção EFFECT, tem sua classificação formal aqui (RESONANCE ↑ → ETERNITY ↓).

### **Anemoia**

**№ 048 / 1001** · *Homesick for a darkroom you never had*

**Nível:** ⚫ Quaternary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Saudade de uma câmara escura que você nunca teve** — (1001 Aesthetics, interpretação)

Nostalgia por uma época não vivida: fotografia analógica, grão, luz de memória alheia.

**Paleta de cores** sépia desbotada, tons kodachrome, vazamentos de luz

**Melhores usos:** nostalgia, editorial, música

**MidJourney:** `[tema], anemoia nostalgic analog photograph --v 6`

**Prompt universal (Seedream):** `Analog snapshot shot on expired Kodachrome with 50mm lens, a sun-faded 1970s scene from an era never lived, warm color shifts and light leaks across the frame, heavy film grain and soft-focus corners, melancholic longing for someone else's memory, authentic vintage photo album artifact`

### **ASMR**

**№ 067 / 1001** · *Whisper recorded two inches from the ear*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → INTENTIONALITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** técnica de gravação binaural, endereçamento íntimo de performance e vídeo amador em rede convergem aqui; retire qualquer um e o gatilho para de funcionar — uma solda de linhagens separadas, não a reinterpretação de um único pai.

**Atmosfera e mood**

**Sussurro gravado a cinco centímetros do ouvido** — (1001 Aesthetics, interpretação)

Estética ASMR: macro extremo, texturas macias, calma tátil quase audível.

**Paleta de cores** pastéis suaves, luz difusa

**Melhores usos:** bem-estar, produto, vídeos

**MidJourney:** `[tema], ASMR macro softness, tactile close-up --v 6`

**Prompt universal (Seedream):** `Extreme macro photograph shot on 100mm macro lens at f/2.8, soft tactile textures — brushed mohair, whipped cream, kinetic sand being sliced — in whisper-quiet pastel tones, diffused shadowless light, satisfying geometric perfection, sensory calm you can almost hear, 8k razor detail`

### **Biophilic**

**№ 096 / 1001** · *Never more than six meters from a leaf*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** uma única linhagem arquitetônica é herdada e reespecificada em torno de uma exigência — proximidade contínua da matéria viva — mantendo planta e estrutura intactas; reinterpretação dentro de uma linha, não fusão de várias.

**Atmosfera e mood**

**Nunca a mais de seis metros de uma folha** — (1001 Aesthetics, interpretação)

Design biofílico: verde vivo integrado à arquitetura, luz natural, espaço que respira.

**Paleta de cores** verdes vivos, madeira, luz natural

**Melhores usos:** interiores, arquitetura, bem-estar

**MidJourney:** `[tema], biophilic interior design, living walls --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm f/2.8, a biophilic atrium interior where living green walls cascade beside warm oak and rough stone, shafts of daylight through a glass roof catching drifting pollen, moss texture and trailing ferns in crisp detail, serene Architectural Digest composition, fresh oxygen-rich atmosphere, natural grading, 8k`

### **Bohemian Vintage**

**№ 105 / 1001** · *Rose a week past bloom*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** vestir boêmio, colecionismo de têxteis antigos e imaginário de decadência romântica se trançam; retire o fio do objeto vintage e a pátina desaparece, retire o pai boêmio e a soltura vira fantasia de época — recombinação, não revisão de um único pai.

**Atmosfera e mood**

**Rosa uma semana depois de abrir** — (1001 Aesthetics, interpretação)

Boho vintage: rendas antigas, flores secas, cartas desbotadas, decadência romântica.

**Paleta de cores** rosa-seco, creme, sépia

**Melhores usos:** casamento, decoração, editorial

**MidJourney:** `[tema], bohemian vintage, dried flowers and lace --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a bohemian vintage still life of dried roses a week past bloom, antique lace and faded handwritten letters on foxed paper, dusty pink and sepia palette in soft window light, drifting dust motes, romantic decay softness like a Sally Mann memory, fine-art texture, 8k`

### **Broadway**

**№ 128 / 1001** · *Joy and grief in the same evening*

**Nível:** 🔴 Primary

**Eixo:** RESONANCE ↑ (presença) → SAGA ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** sua lei fundadora — uma noite deve entregar os dois extremos do sentimento a uma sala pagante — é afirmada na raiz, não herdada de um estilo anterior; remover esse contrato emocional colapsa a forma inteira.

**Atmosfera e mood**

**Alegria e luto na mesma noite** — (1001 Aesthetics, interpretação)

Teatro musical: letreiros de marquise, cortina de veludo vermelho, ribalta e emoção em escala de palco.

**Paleta de cores** dourado de marquise, vermelho de cortina, néon

**Melhores usos:** teatro, pôsteres, música

**MidJourney:** `[tema], Broadway musical theater aesthetic --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a Broadway moment, glowing marquee bulbs and red velvet curtain framing a performer caught in one dramatic spotlight, gold dust drifting in the beam, orchestra pit glowing below, theatrical glamour with emotional intensity, warm tungsten grading and anamorphic flare, cinematic production still, 8k`

### **Cluttercore**

**№ 163 / 1001** · *Layered surfaces, inherited objects, the room that remembers*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → DENSITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** acumulação doméstica vitoriana, vitrine de colecionador e reação anti-minimalista convergem; retire o fio do objeto herdado e as camadas perdem a memória, retire a reação e vira mera bagunça — várias linhagens trançadas em um só cômodo.

**Atmosfera e mood**

**Superfícies em camadas, objetos herdados, o quarto que lembra** — (1001 Aesthetics, interpretação)

Cluttercore: acumulação afetuosa — estantes cheias, quadros até o teto, bibelôs e memória em cada centímetro.

**Paleta de cores** tons quentes mistos, madeira, estampas sobrepostas

**Melhores usos:** interiores, editorial, cenários

**MidJourney:** `[tema], cluttercore maximalist cozy interior --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 24mm f/2.8, a cluttercore interior, lovingly layered shelves of inherited books and trinkets, gallery walls climbing to the ceiling, warm mixed patterns and lamp-lit corners, dust motes in honeyed afternoon light, a room that remembers, richly detailed maximalist warmth, 8k`

### **Cottagecore**

**№ 179 / 1001** · *Pre-industrial hour kept by hand, hearth, and hedgerow*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** romantismo pastoral, revival do artesanato doméstico e cultura digital de nostalgia convergem; retire o fio do ofício e a mão desaparece, retire a circulação online e a lareira nunca vira linguagem visual compartilhada — fusão, não revisão de um único pai.

**Atmosfera e mood**

**A hora pré-industrial guardada pela mão, pela lareira e pela cerca viva** — (1001 Aesthetics, interpretação)

Cottagecore: chalé com jardim de flores, pão caseiro, vestidos de algodão, colheita e vida lenta rural.

**Paleta de cores** creme, verdes de jardim, florais suaves

**Melhores usos:** lifestyle, ilustração, branding acolhedor

**MidJourney:** `[tema], cottagecore aesthetic, cottage garden and homemade bread --v 6`

**LoRA (Civitai):** "Cottagecore Gouache Style" (SDXL) — civitai.com/models/537906; "Witchy Cottagecore" (Illustrious) — civitai.com/models/1146785

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 medium format, a cottagecore scene, stone cottage with overflowing flower garden at golden hour, homemade bread cooling on a windowsill and cotton dresses on the line, hearth light and hedgerows, slow pre-industrial hours kept by hand, painterly warm grain, storybook editorial softness, 8k`

### **Cozy**

**№ 181 / 1001** · *Wool, wax, and the room that pulls closer*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Lã, cera e o quarto que puxa para perto** — (1001 Aesthetics, interpretação)

Aconchego: tricô grosso, velas acesas, chá fumegante e poltrona que abraça.

**Paleta de cores** caramelo, creme, luz de vela

**Melhores usos:** lifestyle, inverno, branding acolhedor

**MidJourney:** `[tema], cozy warm interior, candlelight and knitwear --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a cozy interior scene, chunky knit blankets and flickering candles beside a deep armchair, steam rising from tea in soft lamplight, caramel and cream warmth with deep amber shadows, the room pulling you closer, hygge editorial softness, tactile wool texture, 8k`

### **Cryptidcore**

**№ 182 / 1001** · *Frame the camera refuses to resolve*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → ESTHETICS ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** beleza retida por lei — o quadro que se recusa a resolver; qualquer frame que ainda resolva no terceiro olhar já falhou.

**Atmosfera e mood**

**O quadro que a câmera se recusa a resolver** — (1001 Aesthetics, interpretação)

Criptozoologia: foto granulada de floresta, silhueta ambígua entre árvores, flash noturno e evidência borrada.

**Paleta de cores** verdes escuros, granulação, flash estourado

**Melhores usos:** mistério, horror leve, narrativa

**MidJourney:** `[tema], cryptidcore, grainy blurred forest sighting photo --v 6`

**Prompt universal (Seedream):** `Shot on a disposable 35mm camera with harsh flash, a cryptidcore photograph, grainy blurred forest at dusk with an ambiguous tall silhouette between the trees, motion blur and flash falloff swallowing detail, evidence the frame refuses to resolve, found-footage authenticity, heavy grain and timestamp-era texture, unsettling documentary dread`

### **Cuban**

**№ 185 / 1001** · *Red against white, kept in time by the clave*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → SYNERGY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Vermelho contra branco, mantido no tempo pela clave** — (1001 Aesthetics, interpretação)

Cuba: carros clássicos pastel em Havana, fachadas descascadas coloridas, charuto, salsa e sol do Caribe.

**Paleta de cores** pastel de lataria, coral, turquesa, ocres gastos

**Melhores usos:** viagem, cultura, editorial

**MidJourney:** `[tema], Havana Cuba aesthetic, classic cars and peeling facades --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 400 35mm with 35mm lens, a Havana street scene, pastel 1950s classic cars gleaming against peeling colorful facades, cigar smoke drifting through Caribbean sun, salsa musicians in a doorway shadow, faded grandeur kept in time by the clave, warm saturated film grading, documentary soul, 8k`

### **CYMATICISM**

**№ 190 / 1001** · *Geometry sound draws on water and sand*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → COHERENCE ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A geometria que o som desenha na água e na areia** — (1001 Aesthetics, interpretação)

Cimática: padrões de frequência em placas de areia, ondulações concêntricas na água, mandalas geradas por vibração.

**Paleta de cores** preto, areia, água iluminada

**Melhores usos:** música, abstrato, ciência

**MidJourney:** `[tema], cymatics patterns, sound geometry on water and sand --v 6`

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a cymatics visualization, sound frequency drawing geometric mandala patterns in fine sand on a vibrating steel plate, concentric ripples in dark illuminated water beside it, single hard side light revealing every grain ridge, vibration made visible, scientific fine-art precision, 8k`

### **DECAY**

**№ 210 / 1001** · *Time as editor, not destroyer*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O tempo como editor, não destruidor** — (1001 Aesthetics, interpretação)

Decadência material: tinta descascando em camadas, ferrugem e pátina, ruína que revela história.

**Paleta de cores** ferrugem, verdete, tintas desbotadas

**Melhores usos:** texturas, urbex, arte

**MidJourney:** `[tema], beautiful decay, peeling paint and patina --v 6`

**LoRA (Civitai):** "Decaying Brutalism" — civitai.com/models/2410113 (recorte específico: ruína brutalista)

**Prompt universal (Seedream):** `Shot on Phase One with 120mm macro lens, a beautiful decay study, peeling paint layers and rust patina revealing decades underneath, verdigris and faded pigments on abandoned surfaces in raking side light, time as editor not destroyer, fine-art texture documentation, 8k`

### **Eerie**

**№ 269 / 1001** · *Chair That Faces the Wrong Wall*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → INTENTIONALITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A cadeira virada para a parede errada** — (1001 Aesthetics; código: match aproximado)

Inquietante: cena quase normal com um detalhe fora do lugar, silêncio pesado, errado sem sabermos por quê.

**Paleta de cores** tons apagados, sombra fria, luz doentia

**Melhores usos:** horror sutil, narrativa, arte

**MidJourney:** `--sref 3348285292 --sw 1000` (Futuristic Minimalism with Eerie Elegance — match aproximado)

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, an eerie interior, an almost normal room with one detail wrong, a chair facing the wrong wall in heavy silence, sickly cold fluorescent light flickering faintly, dread without a nameable cause, Kubrick symmetry and A24 horror grading, 8k`

### **Egyptomania**

**№ 270 / 1001** · *Torch Rekindles Three-Thousand-Year Gold*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A tocha reacende o ouro de três mil anos** — (1001 Aesthetics; código: sref-midjourney.com, categoria Egyptian)

Egiptomania: ouro e lápis-lazúli de faraó, hieróglifos e escaravelhos, o Egito redescoberto como febre estética.

**Paleta de cores** ouro, lápis-lazúli, turquesa, preto de kohl

**Melhores usos:** histórico, fantasia, editorial

**MidJourney:** `--sref 422411086 --sw 1000` (categoria Egyptian)

**LoRA (Civitai):** "Art Style Lora — Ancient Egypt" (Pony) — civitai.com/models/629173; "Egypt Art" (Flux.1) — civitai.com/models/1346500

**Prompt universal (Seedream):** `Shot on Mamiya RZ67 with 110mm lens, an Egyptomania scene, pharaonic gold and lapis lazuli rekindled by torchlight, hieroglyphs and scarabs in flickering shadow, kohl black against turquoise, three-thousand-year splendor rediscovered as aesthetic fever, cinematic museum drama, 8k`

### **Elegiac**

**№ 273 / 1001** · *Veil That Refuses the Light*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → THEME ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O véu que recusa a luz** — (1001 Aesthetics, interpretação)

Elegia: luto suave e poético, flores murchando com beleza, memória segurada em meia-luz.

**Paleta de cores** cinza-pérola, lilás de luto, branco velado

**Melhores usos:** arte, poético, editorial

**MidJourney:** `[tema], elegiac mood, veiled figure and fading flowers in half-light --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex with 80mm lens, an elegiac image, veiled figure in pearl-grey half-light from a tall window, flowers fading with beauty on a marble table, soft poetic mourning and held memory, the veil refusing the light, painterly melancholy grading, 8k`

### **Folkloric**

**№ 343 / 1001** · *Wolf, the Forest, and the Hearthside Tale*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → EXPRESSION ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O lobo, a floresta e o conto ao pé da lareira** — (1001 Aesthetics, interpretação)

Folclórico: ilustração de conto tradicional, floresta escura e lareira acesa, o arquétipo narrado há séculos.

**Paleta de cores** vermelho de capuz, verde-escuro de floresta, dourado de fogo

**Melhores usos:** ilustração, infantil, narrativa

**MidJourney:** `[tema], folkloric fairy tale illustration, wolf and dark forest, hearthside storytelling --v 6`

**LoRA (Civitai):** "Folk Tales Art Style" (Flux) — civitai.com/models/1904358

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, a folkloric illustration, the wolf and the dark forest with a hearthside fire glowing, hood red and deep forest green with fire gold, Ivan Bilibin storybook ornamentation, an archetype told for centuries`

### **Gothic IV Modern Gothic Subculture**

**№ 392 / 1001** · *Bauhaus's 1979 Door Into the Batcave*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A porta de 1979 do Bauhaus para o Batcave** — (1001 Aesthetics; código: sref-midjourney.com, match aproximado)

Gótico moderno: subcultura pós-punk, delineador e renda preta, pista escura onde a melancolia dança.

**Paleta de cores** preto absoluto, roxo profundo, pele pálida, prata

**Melhores usos:** subcultura, música, retratos

**MidJourney:** `--sref 3865437604 --sw 1000` (Gothic Elegance in Monochrome — match aproximado)

**Prompt universal (Seedream):** `Shot on Yashica T4 with on-camera flash, a modern gothic subculture portrait, post-punk eyeliner and black lace at a dark club night, absolute black with deep purple and pale skin, Derek Ridgers club documentary rawness, the Batcave door of 1979, melancholy dancing, 8k`

### **Gothic V Gothic Horror**

**№ 393 / 1001** · *Radcliffe's Terror, Lewis's Horror, One Unsealed Door*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → SAGA ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O terror de Radcliffe, o horror de Lewis, uma porta deslacrada** — (1001 Aesthetics; código: sref-midjourney.com, categoria Horror)

Horror gótico: mansão em declínio e corredor de velas, o pavor sugerido e o horror revelado, a porta que não devia abrir.

**Paleta de cores** preto de corredor, âmbar de vela, sépia envelhecido

**Melhores usos:** narrativa, Halloween sofisticado, cinematográfico

**MidJourney:** `--sref 06364 --sv 4 --sw 1000` (Eerie Gothic Horror)

**LoRA (Civitai):** "Halloween: Victorian Gothic Horror" (Flux) — civitai.com/models/785197

**Prompt universal (Seedream):** `Shot on 35mm cine film with 40mm lens, a gothic horror scene, a decaying mansion corridor of candles and one unsealed door, Radcliffe's suggested terror and Lewis's revealed horror, Freddie Francis chiaroscuro, aged sepia and candle amber against corridor black, 8k`

### **Grandmillennial**

**№ 397 / 1001** · *Blue-and-White Ginger Jar Against Chintz*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O pote de gengibre azul e branco contra o chintz** — (1001 Aesthetics, interpretação)

Grandmillennial: herança de vó com curadoria millennial, chintz e babados assumidos, tradicional usado com ironia carinhosa.

**Paleta de cores** azul e branco de porcelana, chintz floral, verde de biblioteca

**Melhores usos:** interiores, lifestyle, editorial

**MidJourney:** `[tema], grandmillennial interior, blue-and-white ginger jars against chintz, curated granny chic --v 6`

**Prompt universal (Seedream):** `Shot on Leica Q2 with 28mm lens, a grandmillennial interior, a blue-and-white ginger jar against floral chintz and ruffled curtains, library green and porcelain blue in soft morning light, granny inheritance curated with affectionate millennial irony, 8k`

### **Haiku**

**№ 410 / 1001** · *Bashō's Frog Breaks the Old Pond's Silence*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → NUANCE ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O sapo de Bashô quebra o silêncio do velho lago** — (1001 Aesthetics, interpretação)

Haicai: imagem mínima e instante suspenso, um detalhe da natureza que contém a estação inteira, vazio que fala.

**Paleta de cores** tinta diluída, verde de lago, papel de arroz

**Melhores usos:** contemplação, wellness, editorial poético

**MidJourney:** `[tema], haiku aesthetic, minimal suspended moment in nature, vast negative space, one seasonal detail --v 6`

**Prompt universal (Seedream):** `Minimalist sumi-e ink composition, a haiku image, an old pond's stillness broken by one frog, vast negative space on rice paper tones, a single seasonal detail holding the whole season, the pause made visible, 8k`

### **Halcyoncore**

**№ 411 / 1001** · *Four Amber Jars Holding the 4 P.M. Sun*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Quatro potes de âmbar segurando o sol das 16h** — (1001 Aesthetics, interpretação)

Halcyoncore: nostalgia dourada de fim de tarde, memória preservada em luz de mel, o verão que não acaba na lembrança.

**Paleta de cores** âmbar, mel, dourado de tarde, branco quente

**Melhores usos:** nostalgia, lifestyle, branding afetivo

**MidJourney:** `[tema], halcyon golden nostalgia, amber jars holding late afternoon sun, honeyed memory light --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 800 with 50mm lens, a halcyoncore image, four amber jars holding the 4 p.m. sun on a windowsill, honeyed golden-hour light preserving memory, William Eggleston domestic glow, the summer that never ends in remembering, 8k`

### **HAWAIIAN**

**№ 422 / 1001** · *Ossipoff's Lanai Opens the Wall to the Trade Wind*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → DOMAIN ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A lanai de Ossipoff abre a parede para o vento alísio** — (1001 Aesthetics, interpretação)

Havaiano: modernismo tropical sem parede, madeira escura e brisa atravessando a casa, dentro e fora sem fronteira.

**Paleta de cores** madeira koa, verde de vale, azul Pacífico, flor de hibisco

**Melhores usos:** arquitetura, viagem, lifestyle

**MidJourney:** `[tema], Hawaiian tropical modernism, open lanai to the trade wind, dark koa wood and Pacific view --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 20mm lens, a Hawaiian image, a modernist lanai opening the wall to the trade wind, dark koa wood and valley green meeting Pacific blue, Vladimir Ossipoff tropical modernism, indoors and outdoors with no border, 8k`

### **Hippie**

**№ 437 / 1001** · *Flower Presses Against the Rifle Barrel*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → INTEGRITY ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A flor pressionada contra o cano do fuzil** — (1001 Aesthetics; código: sref-midjourney.com, categoria Psychedelic, match aproximado)

Hippie: flower power de 1967, túnica e vans floridas, paz oferecida como gesto político.

**Paleta de cores** flores vivas, jeans desbotado, laranja e amarelo de sol

**Melhores usos:** retrô, editorial, música

**MidJourney:** `--sref 1364580036 --sw 1000` (categoria Psychedelic — match aproximado)

**Prompt universal (Seedream):** `Shot on Kodachrome with 50mm lens, a hippie 1967 image, a flower pressed against a rifle barrel, flower-power tunics and painted vans, faded denim with sun orange, Bernie Boston Flower Power framing, peace offered as political gesture, 8k`

### **Hygge**

**№ 444 / 1001** · *Four Candles Hold the November Dark Outside*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → DOMAIN ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Quatro velas seguram o escuro de novembro lá fora** — (1001 Aesthetics, interpretação)

Hygge: aconchego dinamarquês, vela e lã contra o inverno, a intimidade como tecnologia contra o escuro.

**Paleta de cores** branco de vela, cinza nórdico, lã crua, madeira clara

**Melhores usos:** lifestyle, wellness, interiores

**MidJourney:** `[tema], hygge Danish coziness, four candles against the November dark, wool and pale wood warmth --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX50S with 63mm lens, a hygge image, four candles holding the November dark outside a Danish window, raw wool and pale wood, intimacy as technology against winter, 8k`

### **Irish**

**№ 477 / 1001** · *Newgrange Spirals Carved to Catch the Solstice Light*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**As espirais de Newgrange esculpidas para capturar a luz do solstício** — (1001 Aesthetics, interpretação)

Irlandês: pedra neolítica e verde de chuva, espiral tripla e muro de pedra seca, o mito gravado na paisagem.

**Paleta de cores** verde de Irlanda, cinza de pedra, dourado de solstício

**Melhores usos:** cultural, paisagem, editorial

**MidJourney:** `[tema], Irish aesthetic, Newgrange triple spirals carved to catch the solstice light, green fields and drystone walls --v 6`

**Prompt universal (Seedream):** `Shot on Leica S3 with 45mm lens, an Irish image, Newgrange spirals carved to catch the solstice light, neolithic stone against rain-fed green, low winter sun raking the carvings, myth engraved into the landscape itself, 8k`

### **Jovial**

**№ 496 / 1001** · *Shared Pie Leaves One Slice for the Late Arrival*

**Nível:** ⚫ Quaternary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** pendência herdada da seção EFFECT — a lista de EFFECT citava Jovial, mas sua classificação formal é RESONANCE; a ficha vive aqui.

**Atmosfera e mood**

**A torta compartilhada deixa uma fatia para quem chega tarde** — (1001 Aesthetics, interpretação)

Jovial: calor de mesa cheia, riso fácil e generosidade cotidiana, a alegria como hábito doméstico.

**Paleta de cores** dourado de forno, vermelho de toalha xadrez, creme, luz de cozinha

**Melhores usos:** lifestyle, gastronomia, branding acolhedor

**MidJourney:** `[tema], jovial aesthetic, shared pie leaving one slice for the late arrival, warm kitchen table laughter --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm Pro 400H with 35mm lens, a jovial image, a shared pie leaving one slice for the late arrival, oven gold and checked-cloth red around a full table in warm kitchen light, joy as domestic habit, 8k`

### **Melancholia**

**№ 558 / 1001** · *Blue Hour Held Past Its Exit*

**Nível:** 🔴 Primary

**Eixo:** RESONANCE ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Hora azul segurada além da saída** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Melancolia: a tristeza dada uma arquitetura, janela acesa solitária contra o azul profundo do anoitecer.

**Paleta de cores** azul profundo, âmbar de janela, entardecer

**Melhores usos:** arte, cinema still, editorial poético

**MidJourney:** `[tema], melancholia aesthetic, one lit window against deep blue hour, sadness given architecture --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 6 with 75mm lens at blue hour, a melancholia image, one amber-lit window burning against a street of deepening blue, the moment held minutes past its natural exit, Gregory Crewdson suburban stillness with Edward Hopper distances, a figure neither leaving nor arriving, sadness given a precise architecture and a soft light, 8k`

### **Nautical**

**№ 594 / 1001** · *Rope, Brass, and a Horizon Under Orders*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Corda, latão e um horizonte sob ordens** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Náutico: convés esfregado, cabos enrolados em espiral perfeita e o mar mantido em disciplina.

**Paleta de cores** marinho, branco, latão polido

**Melhores usos:** lifestyle, branding, editorial

**MidJourney:** `[tema], nautical aesthetic, coiled rope polished brass, disciplined horizon at sea --v 6`

**Prompt universal (Seedream):** `Shot on Rolleiflex 2.8F with 80mm lens, a nautical composition of coiled rope and polished brass on a scrubbed teak deck, navy and white against a horizon held under orders, salt spray and rigging lines, Beken of Cowes maritime clarity, 8k`

### **Neo Medievalcore**

**№ 598 / 1001** · *Middle Ages, Re-Lived and Reimagined*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → SAGA ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Idade Média revivida e reimaginada** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neomedieval: estandartes costurados à mão, cota de malha de feira e o passado usado como presente.

**Paleta de cores** estandartes heráldicos, couro, ferro fosco

**Melhores usos:** fantasia, eventos, editorial

**MidJourney:** `[tema], neo medievalcore aesthetic, hand-stitched banners and chainmail, middle ages re-lived --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm X-Pro3 with 35mm lens, a neo-medieval gathering, hand-stitched heraldic banners and market-stall chainmail worn in earnest, torch smoke over modern faces living the past forward, leather and matte iron detail in late golden light, 8k`

### **Neo Minimalism**

**№ 599 / 1001** · *Less, but Warmer at the Edges*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Menos, mas mais quente nas bordas** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neominimalismo: a redução que aprendeu textura — gesso quente, madeira crua e um único objeto vivo.

**Paleta de cores** greige, gesso quente, madeira clara

**Melhores usos:** interiores, branding, produto

**MidJourney:** `[tema], neo minimalism aesthetic, warm reduction, plaster and raw wood, single living object --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad X1D II with 65mm lens, a neo-minimalist interior, warm plaster walls and raw pale wood holding one living branch in a clay vessel, greige palette softened at the edges, less that learned warmth, gentle raking daylight, gallery-print quality, 8k`

### **Nestcore**

**№ 612 / 1001** · *Home Curled Around a Single Safe Center*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → DENSITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Casa enrolada em torno de um único centro seguro** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nestcore: forte de cobertas, almofadas em círculo e uma luminária quente como coração da casa.

**Paleta de cores** caramelo, lã crua, âmbar de abajur

**Melhores usos:** lifestyle, interiores, bem-estar

**MidJourney:** `[tema], nestcore aesthetic, blanket nest curled around one warm lamp, safe center --v 6`

**Prompt universal (Seedream):** `Shot on Olympus Pen F with 25mm lens, a nestcore interior, blankets and cushions curled in a ring around one warm reading lamp, caramel wool and raw linen textures, the whole home orbiting a single safe center, soft amber intimacy, 8k`

### **Oceanic Surrealism**

**№ 638 / 1001** · *Unconscious Learns Marine Biology*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**O inconsciente estudando biologia marinha** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Surrealismo oceânico: águas-vivas como lustres de sonho, abissal e onírico fundidos num só azul.

**Paleta de cores** azul abissal, bioluminescência, madrepérola

**Melhores usos:** arte, capas, conceito

**MidJourney:** `[tema], oceanic surrealism aesthetic, the unconscious learning marine biology, jellyfish chandeliers --v 6`

**Prompt universal (Seedream):** `Ultra-detailed surrealist painting, the unconscious learning marine biology, jellyfish hanging like chandeliers over a drowned drawing room, abyssal blue with bioluminescent accents and mother-of-pearl light, Max Ernst strangeness carried into the deep sea, dreamlike museum finish, 8k`

### **Phenomenological**

**№ 681 / 1001** · *Perception Catches Itself in the Act*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**A percepção flagrando a si mesma** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Fenomenológico: o vídro embaçado limpo pela mão, o instante em que ver se torna o assunto.

**Paleta de cores** cinza de névoa, pele de vidro, luz difusa

**Melhores usos:** conceito, arte, editorial

**MidJourney:** `[tema], phenomenological aesthetic, fogged window wiped by hand, perception catching itself --v 6`

**Prompt universal (Seedream):** `Shot on Leica M9 with 50mm lens, a phenomenological image, a fogged window wiped by one bare hand revealing a blurred world beyond, condensation droplets sharp against diffuse gray light, the exact instant when seeing becomes the subject, quiet CCD tonality, 8k`

### **Pixiecore**

**№ 689 / 1001** · *Cottagecore Finds Wings and Mischief*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Asas e travessura na cerca viva** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pixiecore: sininhos, cogumelos e a sensação de que algo pequeno acabou de rir atrás da samambaia.

**Paleta de cores** verde de musgo, rosa de campainha, dourado de pólen

**Melhores usos:** fantasia, editorial, arte

**MidJourney:** `[tema], pixiecore aesthetic, wings and mischief in a bramble hedge, something small just laughed --v 6`

**Prompt universal (Seedream):** `Shot on Pentax MX with 50mm lens, a pixiecore scene inside a bramble hedge, dew-lit spiderwebs and toadstool rings where wings and mischief just passed, moss green harebell pink and pollen gold in fairy-scale light, the feeling that something tiny is still giggling, 8k`

### **Pulsing**

**№ 732 / 1001** · *Beat Made Visible Between Frames*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → SYNERGY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a metáfora do organismo vivo da Arquitetura Orgânica, o loop de feedback da Arquitetura Cibernética e a linha vegetal do Art Nouveau eram posições completas; recombinadas aqui, produzem a única estética em que a mesma superfície parece uma criatura, sente como uma e responde em tempo real — fusão que nenhum dos três pais geraria sozinho.

**Atmosfera e mood**

**A batida tornada visível** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Pulsante: longa exposição cortada por estrobo, o ritmo gravado como camadas de movimento congelado.

**Paleta de cores** vermelho de batida, preto de sala, branco de estrobo

**Melhores usos:** música, editorial, arte

**MidJourney:** `[tema], pulsing aesthetic, long exposure sliced by strobe, the beat made visible --v 6`

**Prompt universal (Seedream):** `Long-exposure concert photograph, a pulsing image where strobe slices a dancer into stacked frozen phases of one movement, beat red and strobe white against room black, rhythm recorded as visible layers of time, kinetic energy held sharp inside the blur, 8k`

### **Rockabilly**

**№ 766 / 1001** · *1950s That Never Died*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → EXPRESSION ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a fusão de Memphis de meados dos anos 1950 — twang country com backbeat de rhythm-and-blues — chega intacta, e o Rockabilly a re-instrumenta por citação estrita de época (jeans de barra dobrada, topete com cera, hot rods cromados, tudo policiado contra um único ano congelado), de modo que um gênero ouvido como futuro vira, uma geração depois, um passado desafiadoramente reencenado.

**Atmosfera e mood**

**Os anos 1950 que nunca morreram** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Rockabilly: topete engomado, hot rod rebaixado e contrabaixo girando no drive-in — a fidelidade eterna a 1956.

**Paleta de cores** vermelho de hot rod, azul de brim, creme de gasolina

**Melhores usos:** música, moda retrô, editorial

**MidJourney:** `[tema], rockabilly aesthetic, pompadour hot rod upright bass at the drive-in, the 1950s that never died --v 6`

**Prompt universal (Seedream):** `Shot on Kodachrome 64 with 50mm lens, a rockabilly scene at a drive-in, a waxed pompadour leaning on a lowered hot rod while an upright bass spins mid-song, hot-rod red and rolled denim under gas-station cream light, 1956 kept faithfully alive, saturated period color, 8k scan`

### **Romantic Revival**

**№ 771 / 1001** · *Nostalgia's Embrace*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a dor romântica europeia pelo medieval e pelo confessional chega intacta, e o Revival a re-instrumenta restaurando o próprio movimento-pai em vez de se rebelar contra uma ordem anterior — de modo que uma formação voltada à ruptura passa, uma geração depois, a mirar a recuperação.

**Atmosfera e mood**

**O abraço da nostalgia** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neorromântico: torres góticas em cottages do século XIX, hera planejada e o passado reconstruído mais bonito do que foi.

**Paleta de cores** pedra coberta de hera, rosa antigo, cinza de névoa

**Melhores usos:** arquitetura, editorial, histórico

**MidJourney:** `[tema], romantic revival aesthetic, 19th century gothic cottage planned ivy, nostalgia's embrace --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a 19th-century Romantic Revival painting, a gothic cottage with pointed windows wrapped in deliberately planted ivy beside a mirror pond, antique rose and mist gray softening every edge, the past rebuilt lovelier than it ever was, nostalgic painted glow, 8k scan`

### **Scouse (Liverpool Working Class)**

**№ 789 / 1001** · *Style With a Mersey Beat*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → SYNERGY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a densidade das casas geminadas e a dignidade sindical da cultura operária britânica chegam como pai único, e o Scouse re-instrumenta essa gramática sob uma pressão transformadora — o porto atlântico e a imigração irlandesa reformando sotaque, música e rua — até virar identidade regional desafiante cantada de volta ao mundo.

**Atmosfera e mood**

**Estilo com batida do Mersey** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Scouse: casas geminadas de tijolo, agasalho esportivo impecável e o humor de Liverpool como armadura de classe.

**Paleta de cores** tijolo de terrace, cinza do Mersey, branco de tênis

**Melhores usos:** documental, moda urbana, editorial

**MidJourney:** `[tema], scouse aesthetic, Liverpool terraced brick immaculate tracksuit, style with a Mersey beat --v 6`

**Prompt universal (Seedream):** `Shot on Olympus OM-1 with 28mm lens, a scouse street scene in Liverpool, an immaculate tracksuit and box-fresh trainers against red terraced brick with the Mersey gray beyond, working-class wit worn as armor, honest overcast light and proud posture, 8k scan`

### **Sertanejo**

**№ 799 / 1001** · *Sound of the Brazilian Heartland*

**Nível:** 🔴 Primary

**Eixo:** RESONANCE ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** nenhuma estética anterior precede a viola caipira e os modos de vida do interior; o sistema nasce da própria vida rural e gera descendentes — romântico, universitário, feminejo — em vez de descender de um, de modo que toda a gramática de fogão a lenha, viola e terra vermelha se ramifica para baixo em formas posteriores e nenhuma pode ser rastreada para cima até ela.

**Atmosfera e mood**

**O som do interior do Brasil** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Sertanejo: viola caipira à beira da fogueira, chapéu e fivela, e a música que atravessa porteiras e gerações.

**Paleta de cores** couro, dourado de fogueira, azul de madrugada rural

**Melhores usos:** música brasileira, cultura, editorial

**MidJourney:** `[tema], sertanejo aesthetic, viola caipira by the campfire hat and buckle, Brazilian heartland sound --v 6`

**Prompt universal (Seedream):** `Shot on Canon 5D Mark IV with 35mm lens, a sertanejo night, a viola caipira played by firelight beside a wooden porteira, worn leather hat and belt buckle catching campfire gold under rural predawn blue, the Brazilian heartland singing across generations, warm honest depth, 8k`

### **Soft Colonial Wanderlust**

**№ 823 / 1001** · *Dreaming of Distant Lands*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** o enquadramento pitoresco do Romantismo — o ponto de vista elevado que deixa o olho metropolitano possuir uma paisagem da poltrona — chega como pai único, e a estética o re-instrumenta redirecionando o quadro para a geografia colonizada: a vista pintada vira, uma volta depois, uma sala de latão envelhecido com o custo cortado do enquadramento.

**Atmosfera e mood**

**Sonhando com terras distantes** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Wanderlust vintage: baús de viagem, mapas desdobrados e linho claro na varanda — a estética de época das grandes travessias, lida hoje com olhar crítico.

**Paleta de cores** linho cru, couro de baú, verde de palmeira

**Melhores usos:** viagem, interiores, editorial

**MidJourney:** `[tema], vintage wanderlust aesthetic, steamer trunks unfolded maps linen veranda, dreaming of distant lands --v 6`

**Prompt universal (Seedream):** `Shot on Bronica ETRS with 75mm lens, a vintage wanderlust study, leather steamer trunks and an unfolded sea map on a shaded veranda, raw linen and brass instruments against palm green light, the period romance of long crossings composed as objects and longing rather than people, 8k`

### **Soft Grunge**

**№ 825 / 1001** · *Angst softened into something wearable*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → EDITING ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** a recusa do Grunge noventista à beleza convencional chega como pai único, e o Soft Grunge re-instrumenta essa herança invertendo a postura que a definia — contrabandeando floral e renda de volta à flanela — até uma posição contra a beleza virar, uma volta depois, um quarto doendo lindamente de propósito.

**Atmosfera e mood**

**A angústia amaciada em algo vestível** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Soft grunge: camiseta de banda com saia de tule, meia rasgada de propósito e o desencanto coado por filtro pastel.

**Paleta de cores** preto desbotado, lilás de filtro, cinza de moletom

**Melhores usos:** moda jovem, editorial, capas

**MidJourney:** `[tema], soft grunge aesthetic, band tee tulle skirt ripped tights pastel filter, angst made wearable --v 6`

**Prompt universal (Seedream):** `Shot on Nikon FM10 with 35mm lens, a soft grunge portrait, a faded band tee over a tulle skirt with deliberately ripped tights against a bedroom wall of torn posters, washed black under a lilac filter haze, angst softened into something wearable, moody 2013 film grain, 8k scan`

### **Solitude**

**№ 828 / 1001** · *Quiet chosen on purpose*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → DENSITY ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** o sublime selvagem romântico e a disciplina monástica do recolhimento contemplativo são soldados numa forma só, nenhum pai sobrevivendo sozinho: paisagem aberta e cela nua fundem-se numa sensibilidade de solidão escolhida que nenhuma das linhagens produziria por si.

**Atmosfera e mood**

**O silêncio escolhido de propósito** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Solitude: cabana à beira do lago parado, uma cadeira virada para a água e a companhia inteira sendo a própria presença.

**Paleta de cores** azul de lago parado, cinza de amanhecer, madeira escurecida

**Melhores usos:** paisagens, editorial, bem-estar

**MidJourney:** `[tema], solitude aesthetic, lone cabin still lake one chair facing the water, quiet chosen on purpose --v 6`

**Prompt universal (Seedream):** `Shot on Plaubel Makina 67 with 80mm lens, a solitude scene, a lone cabin on a windless lake with a single chair turned toward the water, dawn gray dissolving into still blue with darkened timber, silence not suffered but deliberately chosen, vast calm negative space, 8k`

### **Summer Camp**

**№ 862 / 1001** · *Bunk beds, bonfires, and one perfect season*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → SYNERGY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** o recuo do antimodernismo diante da vida industrial chega como pai único, e o Summer Camp o re-instrumenta numa instituição estruturada, com horários e temporada — cabanas, cornetas, uma estação que termina — sem trançar uma segunda linhagem.

**Atmosfera e mood**

**Beliches, fogueiras e uma estação perfeita** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Acampamento de verão: friendship bracelets, marshmallow no graveto e o verão inteiro cabendo entre a chegada do ônibus e a última fogueira.

**Paleta de cores** verde de floresta, laranja de fogueira, vermelho de canoa

**Melhores usos:** nostalgia, lifestyle, editorial

**MidJourney:** `[tema], summer camp aesthetic, bunk beds friendship bracelets bonfire marshmallows, one perfect season --v 6`

**Prompt universal (Seedream):** `Shot on a Fuji QuickSnap disposable camera, a summer camp night, friendship-braceleted hands roasting marshmallows over a bonfire with a red canoe beached beyond the log benches, forest green swallowed by firelight orange, one perfect season compressed between arrival and last embers, flash-lit memory grain, 8k scan`

### **Synthwave**

**№ 888 / 1001** · *Chrome Sunsets Scored in Analog Neon*

**Nível:** 🟣 Secondary

**Eixo:** RESONANCE ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** o retrofuturismo dos anos 1980 fornece o pai único, e o Synthwave o re-instrumenta idealizando o cromo e a grade da década num brilho puramente emitido, de futuro computado.

**Atmosfera e mood**

**Pôr do sol cromado trilhado em neon analógico** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Synthwave: sol listrado sobre grade infinita, palmeiras em silhueta e o 1984 que só existiu nos sintetizadores.

**Paleta de cores** magenta de neon, ciano de grade, laranja de sol listrado

**Melhores usos:** música, capas, arte digital

**MidJourney:** `[tema], synthwave aesthetic, striped sun over infinite grid palm silhouettes, a 1984 that only existed in synthesizers --v 6`

**Prompt universal (Seedream):** `Ultra-vivid digital artwork, a synthwave horizon, a striped chrome sun sinking behind an infinite neon grid as palm silhouettes frame a DeLorean's tail lights, magenta and cyan scored in analog glow, the 1984 that only ever existed inside synthesizers, gleaming retrowave finish, 8k`

### **Twee**

**№ 916 / 1001** · *Whimsy With a Record Collection and Sharp Elbows*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → EXPRESSION ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** a saudade pastoral do Romantismo, a consciência artesanal do Arts and Crafts e a economia de fita cassete e fotocópia do DIY pós-punk convergem aqui, cada um sustentando uma camada que nada substitui — híbrido de múltiplas linhagens, não revisão de pai único.

**Atmosfera e mood**

**O capricho com coleção de discos e cotovelos afiados** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Twee: vestido de gola Peter Pan, bicicleta com cesta e vinil do Belle and Sebastian — a fofura ostensiva escondendo crítica precisa.

**Paleta de cores** mostarda vintage, vermelho de bicicleta, creme de cardigã

**Melhores usos:** moda, editorial, lifestyle

**MidJourney:** `[tema], twee aesthetic, peter pan collar bicycle basket Belle and Sebastian vinyl, whimsy with sharp elbows --v 6`

**Prompt universal (Seedream):** `Shot on Olympus Trip 35, a twee tableau in Wes Anderson symmetry, a Peter Pan collar dress beside a red bicycle with a wicker basket carrying Belle and Sebastian vinyl, vintage mustard and cardigan cream framed dead-center, whimsy fully armed with a record collection and sharp elbows, storybook film charm, 8k scan`

### **Yugo-Nostalgia**

**№ 993 / 1001** · *Socialism Preserved in Collective Amber*

**Nível:** 🟤 Tertiary

**Eixo:** RESONANCE ↑ (presença) → SAGA ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** três linhagens alimentam o sistema e nenhuma sozinha o explica — os monumentos abstratos de concreto do Modernismo iugoslavo, a iconografia heroica 1945–48 do Realismo Socialista e o luto da Nostalgia Pós-socialista depois de 1991; remover qualquer fio produz um animal inteiramente diferente.

**Atmosfera e mood**

**O socialismo preservado em âmbar coletivo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Yugo-nostalgia: o spomenik de concreto contra o céu, o Fića na garagem do avô e a memória de um país que não existe mais guardada com carinho seletivo.

**Paleta de cores** concreto de spomenik, vermelho de estrela desbotada, âmbar de lembrança

**Melhores usos:** histórico, documental, editorial

**MidJourney:** `[tema], yugo-nostalgia aesthetic, concrete spomenik grandfather's Fića, a vanished country kept in selective amber --v 6`

**Prompt universal (Seedream):** `Shot on Praktica MTL with 50mm lens, a Yugo-nostalgia scene, a monumental concrete spomenik rising against overcast sky while a lovingly kept Zastava 750 waits on the cracked road below, monument gray and faded star red warmed by remembrance amber, a country that no longer exists preserved in collective selective memory, wistful monumental melancholy, 8k scan`

# SAGA — the Tree of Uruk

<aside>
🌳

**Essência:** SAGA é a profundidade histórica e mitográfica documentada, convertida em símbolo portátil legível sem contexto. Seu ideograma é a Árvore de Uruk — a árvore gravada na cidade onde a escrita nasceu: tronco vertical, galhos pareados e anéis de crescimento que não podem ser apagados nem falsificados — a única arquitetura que também é uma história. Três verbos habitam a árvore: **Despojar / Renouncing** (a poda visível do que obstrui, nunca autopunição), **Reger / Reigning** (regência como serviço rotativo sobre um campo maior que qualquer trono) e **Guardar / Keeping** (custódia viva que devolve a herança renovada, nunca cofre). O teste é sempre o mesmo: *o que sobreviveu tem anéis, os anéis têm cicatrizes, e há uma mão mais nova recebendo o que a mão mais velha ainda segura?*

</aside>

Segue o prompt universal de SAGA, no mesmo formato dos sete anteriores — com a chave de verbo nos colchetes (como em EFFECT), porque a Árvore de Uruk carrega três verbos e cada quadro executa exatamente um.

## Prompt-mestre (imagem-síntese)

> **↑ SAGA — universal prompt.** A real place with a documented, dated history — [the aesthetic's own custody ground: a family workshop, an archive, a courtyard that has hosted the same ceremony for generations, a stage, a loom room, a studio lot] — holding physical evidence of at least three distinct time layers in one continuous depth of field: an original founding element, a mid-period repair or addition, and a current actively-used layer laid exactly where yesterday's was laid. The composition is built in rings read from the centre outward like a cut trunk — the oldest evidence innermost, each ring outward a documented later stage, the outermost ring the newest addition proving growth has not stopped — and at least one ring carries a visible gap or scar: [the aesthetic's own pruning: an empty hook where a tool was given away, a repaired break left unpolished, a branch-scar, a deliberately cleared shelf], because a frame with no loss anywhere in its rings is bragging, not lineage. One object per frame functions as the Glifo — [the aesthetic's own single emblem: the named blade, the woven medallion, the carved symbol, the roundel, the gourd, the inherited ring] — specific enough that the whole world could be identified by that object alone, captioned in one word and losing nothing if the caption were removed. Exactly one of three operations is performed and never two: [**Guardar** — a two-handed transfer caught mid-crossing between two honestly different generations, the object still in motion, neither grip fully open nor closed, both pairs of hands lit equally / **Reger** — a hand resting flat at the centre of a shared working field it organizes without dominating, the field's own rhythm visibly continuing around the figure rather than orbiting it / **Despojar** — a hand releasing rather than grasping, the gaze already moved past the released thing, the absence made visible as a deliberate emptied section of the frame]. The body is the custodian who already completed the return: weight fully settled, spine long and unforced, holding one object or none, age neither hidden nor performed — real callus and spotting where the inherited tool has been gripped for decades, one genuine laugh line kept legible, a face aged into its authority rather than resisting it. Wardrobe holds two registers at once: one inherited piece visibly older than the rest, worn by choice with continuous-use condition rather than costume revival, beside a current layer dated to now, proving the inheritance is active rather than nostalgic. Light ages visibly across the frame — the oldest ring warmer and lower in contrast as if by decades of accumulated exposure, the newest ring under a cleaner contemporary key, the two temperatures meeting at a legible seam — and shadow holds real information without ever going fully black, because a legacy swallowed by shadow cannot be read forward. The palette is drawn from genuinely aged matter — [the aesthetic's own slow materials: oxidized metal, sun-faded textile, smoke-darkened wood, patinated stone, worn vellum] — desaturating toward the oldest ring and rising toward the newest, with exactly one signal colour recurring unchanged in the oldest object and the newest alike: [the aesthetic's own constant: the ochre cord, the red thread, the gilt edge, the indigo]. Camera at the subject's own eye level, steady, mid-range, never a hero's low angle and never a diminishing high one — a custodian returning to a place it has photographed before — pulling back far enough to hold all three generations of evidence sharp, grain reading as inherited stock rather than a filter. Plant one lineage proof that the tree is still growing rather than merely preserved: [a fresh graft welded onto the oldest tool and clearly in use, a hand demonstrably younger than the object it holds, an empty slot in an otherwise full rank left open on purpose for what comes next]. Nothing in the frame that cannot be dated relative to everything else in it.
> 

**Linha negativa — o que este elemento proíbe** (sempre parear com o prompt-mestre):

> No costume-department antiquing or simulated age on a young face, no printed patina, no uniform light temperature erasing the age difference between generations, no uniform contemporary grade laid evenly across objects of different real ages, no pristine heirloom sealed behind glass, no single figure alone with a trophy and no one to receive it, no accumulation with no visible loss or pruning anywhere, no repair or wear retouched away, no contemporary marker without an older counterpart in frame, no biographical clutter demanding three sentences of caption, no conductor's raised arm or throne posture, no cleared single-era set, no object that could belong to three other lineages, no dated trend marker that starves the glyph, no frame whose elements cannot be placed in chronological order by eye.
> 

### Como adaptar o prompt a cada estética

**Como usar para as ~60 estéticas da lista.** Só quatro decisões mudam; a arquitetura é idêntica.

**1. O verbo (um só por quadro):**

**Guardar** para o bloco de herança viva — Māori, Adinkra, Afghan, Afro-Brazilian, Ethnic, Indigenous North American, Highland, MARACATU, Slavic, Traditional, Argentinian: a transferência entre gerações é o próprio quadro (o tear, o wampum, a cuia que mantém a roda girando).

**Reger** para cânone e instituição — Academicism, Carolingian, Old Hollywood, Noh, Aestheticism, Renaissance Revival: a mão sobre o campo compartilhado (a mesa do júri, o scriptorium, o set).

**Despojar** para Art Brut, Nouvelle Vague, Aestheticism no registro de recusa: o corte visível como método (a cena favorita no chão, a caneta que sobrou depois do confisco).

**2. O Glifo** — o objeto de uma palavra: para **Epic Fantasy / Legendcore**, a espada nomeada; para **Heroic**, a coluna espiralada; para **CHICANO**, o carro baixado; para **Diva**, o microfone/a assinatura do bis; para **London**, o roundel; para **Landmarkcore**, inverta o cenário para DOMAIN ↓ — o glifo fotografado *descolado* do território (o cartão-postal, não o lugar).

**3. A camada de era** — para as eras lacradas (**Dieselpunk, Aeropunk, Arcade, Detective, Old Hollywood**), a "camada atual" é substituída pela assinatura de luz da própria era (o néon do fliperama vindo de baixo, a veneziana do noir, o key light do estúdio): ILLUMINATION ↑ faz o papel do anel mais novo.

**4. O rito anual** (**Christmas, Harvest Festivalcore, Brazilian June Festival**) — o anel se formando diante da câmera: a mesma procissão/fogueira/mesa com evidência física de que aconteceu no ano anterior (a marca de queimado da fogueira passada, a decoração guardada e reusada).

Nada na arquitetura nomeia lugar, tradição ou estilo — só os mecanismos que a página define como SAGA: composição em anéis, a poda visível, a transferência em custódia, o Glifo que dispensa legenda, a luz que envelhece através do quadro, a cor-sinal que atravessa todas as gerações, e a prova de que a árvore ainda cresce.⁠

## Fundamentos do elemento

**Identity.** Documented historical and mythographic depth, converted into a portable symbol legible without context. Its ideogram is the tree engraved in Uruk, the city where writing was born: trunk vertical, branches paired, growth rings that cannot be erased and cannot be faked — the only architecture that is also a history. A tree is inseparable from what it has shed; no ring forms without a branch that fell to make room for it. Three verbs occupy the tree. **Despojar / Renouncing** (pruning what obstructs freedom and attention — pruning, never self-punishment; the shadow is restriction turned into sterile self-negation). **Reger / Reigning** (governing a field larger than any throne — regency as rotating service, never possession; the shadow is governing to preserve one's own authority and its symbols). **Guardar / Keeping** (holding an inheritance in living custody and handing it back renewed — not archival competence but an identity function, the one through whom something survives; the shadow is accumulation that preserves dead forms). In an image this element is proven by lineage markers that carry real, visible loss inside them, or by their total, deliberate removal. (Distinct from RESONANCE, 8 — the Sankofa bird measures what a single exposure leaves vibrating after it ends; Saga measures what an entire ringed, dated history has already survived. Distinct from ETERNITY, 22 — the Djed raised again proves one spine survived exposure; Saga proves a whole tree, with everything it lost, still stands.)

**The Classe Mítica threshold — when the story stops needing a caption.** A biography needs footnotes: names, dates, the causal chain that turns a life into an anecdote. A myth needs none — the name alone triggers the whole architecture of meaning. The diagnostic is exact: when a story stops needing context to be read, it has crossed into Classe Mítica. Photographically this is a frame that could be captioned in one word and lose nothing if the caption were removed — a silhouette, a gesture, a single held object doing the entire narrative's work. The failure state is a frame that still needs three sentences of biography to make sense: too much anecdote attached, not yet myth.

**The pruned ring — Despojar as visible amputation, not implied one.** A tree this old is not additive; it is what remains after five thousand years of cutting back. The amputation must be seen, not assumed: a scar where a branch was, a deliberately emptied section of the frame, an object present in an earlier image of the same series and now conspicuously gone. An image that reads as pure accumulation — trophies stacked with nothing given up to earn them — has failed this element entirely.

**Reger without a throne.** At this table regency is rotating service. Reger governs a field larger than any single self and answers to it, setting its own limits and reading disagreement as information rather than sabotage. Photographed, this is a body with authority over a space it does not dominate — present at the center of a real working field whose own rhythm continues around the figure rather than orbiting it. The shadow is command-and-control: a room arranged to flatter one image rather than to serve a shared inheritance.

**The gift withheld vs. the gift returned — Guardar as circulation, not vault.** *O dom retido* is a refusal of the return legacy demands. Guardar is the opposite discipline: custody that must move to survive. A guarded object photographs differently from a hoarded one — it shows active transfer, a hand receiving as well as a hand giving, an heirloom in current use rather than sealed behind glass. The Jornada do Herói names the failure precisely: the treasure kept in the cave is not a trophy, it is arrest. The hero who does not return with the elixir has not completed the arc; he has only found a richer cave.

**The Corte Final — a life edited backward from its own last scene.** Decide what must be true in the final frame first, then edit everything preceding it so that frame reads as inevitable rather than accidental. Photographed, this becomes retroactive coherence made visible: an early, minor object in the frame that only resolves once the viewer has seen the late, major one; a composition built so the eye reads forward and backward with equal logic, never as a random accumulation of years.

**The Glifo — one word, one image, legible five centuries later.** Every Saga frame carries an implicit test: strip the subject to one word and one object and confirm both would still read five hundred years on. The corollary is sacrifice — biographical noise (the actual meal, the actual complaint, the actual weather) is given up for symbolic density. A frame cluttered with dated contemporary specificity starves the glyph before it can form.

**The mortal machine — vitality as load-bearing detail, not vanity.** The myth runs on a body, and the body has limits it cannot outsource. A Saga image never hides that endurance has a biological cost: posture, breath, and skin must read as a body actively sustained — rested, fed, capable — rather than a body performing martyrdom. A visibly failing machine cannot complete a return; asceticism staged as virtue is this element's most common counterfeit.

**Strategic idleness — the incubation face.** Not every Saga frame is a monument mid-ceremony; some document the myth still forming, in the pause that produces it. A face and body at genuine, unforced rest — no task in hand, no performance of productivity — belong to this element as legitimately as the ceremonial handoff, provided the stillness reads as gestation rather than exhaustion.

## Corpo — postura, peso e gesto

**Model posture & structure.** The body of someone who has already completed the return and now stands as custodian of what the return produced — not the traveler mid-journey, but the figure who came back and stayed. Weight fully settled, spine long and unforced, breath low; the minimum-energy state of a system no longer spending force on its own position — a fusion of the person and the message so complete that nothing negotiates with the lens. Hands are empty or hold exactly one object — the elixir, the inheritance, the single artifact standing for the whole history — never both empty and never more than one thing, because a Saga figure carries a single legacy, not an inventory. Age is neither hidden nor performed: a hand that shows real decades of use, a face aged into its authority rather than resisting it. Where a second figure appears, they occupy a different generational register — younger and receiving, or older and transmitting — because this element completes only when something moves between two positions, never when a single figure poses alone with a trophy. Movement, where present, is the single ceremonial gesture of a transfer caught mid-crossing, neither hand yet released.

### **Gesture.** Three verbs, and only these three; they alternate, never blend in one frame.

**Despojar · Renouncing.** The gesture of removing what a lesser image would keep — setting an object down and stepping back rather than reaching for one more. Photographed as absence made visible: a hand releasing rather than grasping, an empty hook where an object used to hang, a shelf or wall deliberately cleared. The gaze does not follow the released object; it has already moved past it. The shadow is self-erasure performed as humility — pruning so completely that no tree is left standing to inherit anything.

**Reger · Reigning.** A hand set at the center of a field it organizes without dominating — resting flat on a table others also use, a palm open over a shared working surface rather than raised in command. The body does not address a crowd; it works inside the field, its centrality proven by what surrounds it rather than by its own posture. The shadow is the conductor's raised baton — an arm lifted to direct, a body positioned to be obeyed.

**Guardar · Keeping.** Two-handed transfer — an object passed from one generation's grip to another's, neither party's hands fully open nor fully closed, the object visibly still in motion. The gaze goes to the object, not fully to the camera and not fully to the recipient — attention undivided on the thing kept alive. The shadow is the sealed vitrine: an heirloom displayed behind glass, untouched, guardianship calcified into museum.

## Regras de imagem — do figurino à prova de linhagem

**Look & styling continuity.** Wardrobe carries a legible multi-generational signature: one garment or accessory documented across the figure's own history — visibly older than the rest of the outfit, worn by choice rather than necessity, its condition proving continuous use rather than costume revival. Build the look in two registers held at once: the inherited layer (a ring, a fabric, a cut passed down and worn exactly as received) and the current layer (everything else, dated to now, proving the inheritance is active rather than nostalgic). One object per frame functions as the Glifo — a single recurring emblem specific enough that the wearer could be identified by that object alone, without face or name. Refused: costume-department antiquing, a garment aged to look old rather than genuinely carrying age, and any accessory that could belong to three other lineages.

**Camera.** The camera behaves like a custodian returning to a place it has photographed before — height, distance and angle held consistent enough across a series that the repetition itself becomes a claim about persistence. A mid-range lens at the subject's own eye level, steady, never a hero's low angle and never a diminishing high one; authority here is inherited, not staged by the lens. Where a transfer gesture is the subject, the camera moves close enough that both sets of hands and the object between them fill the frame, faces secondary to the exchange. Where the frame surveys an accumulated field — an archive, a workshop, a family table — the camera pulls back far enough to hold three visible generations of evidence in one continuous depth of field. Grain, where used, reads as inherited from an earlier decade's stock rather than as a contemporary filter — evidence that the image has already begun accumulating its own history.

**Composition.** Built in rings, not rows — a structure the eye reads from center outward the way a cut trunk is read. The innermost ring holds the oldest evidence: a dated object, a worn tool, a face aged into authority. Each ring outward is a documented later stage, and the outermost ring is the newest addition — proof growth has not stopped. At least one ring must show a visible gap or scar, proof something was pruned to let a later ring form; a composition with no loss anywhere in its rings is bragging, not lineage. Verticals stay plumb where the trunk logic is invoked; otherwise the composition may curve concentrically but never scatter — every element's position is explainable by its place in the sequence. Negative space is reserved, not generous: this element fills the frame with evidence, arranged so it reads chronologically rather than decoratively.

**Lighting.** Light ages visibly across the frame rather than staying uniform — the oldest ring lit warmer and lower in contrast, as if by decades of accumulated exposure, the newest ring lit with a cleaner, more contemporary key, the two temperatures meeting at a legible seam rather than blending invisibly. Where a single figure and a single inherited object are the subject, one broad source (a window, an open doorway, a skylight) lights both hands equally — unequal light on the giving and receiving hands has already declared one generation more important than the other, which this element forbids. Shadow is allowed to hold real information — the years an object spent unlit in storage before returning to daylight — but it never goes fully black; a legacy fully swallowed by shadow cannot be read forward into the next generation.

**Beauty detail.** Age is the material, not the flaw to correct. Skin, hands and hair carry specific, dated evidence of decades — real callus and real spotting where an inherited tool has been gripped for years, hair showing an honest transition rather than a dyed uniformity, a face whose lines read as chapters rather than an averaged surface. Where two generations share a frame, their finishing differs by an honest degree — sameness across generations reads as costume, not lineage. One inherited detail is mandatory and must be worn rather than displayed: a ring on the hand actually using it, a scar from the actual labor the legacy required, original stitching visible at a cuff. One genuine laugh line is kept legible rather than smoothed away — this element refuses total solemnity; a face polished free of all humor reads as a tyrant in waiting, not a myth. Refused: age simulated on a young face through prosthetic or filter, and any grooming decision so uniform across generations that the years between them become illegible.

**Cenography.** A real place with a documented, dated history — a family workshop, an archive room, a courtyard that has hosted the same ceremony for generations — never a set dressed to look old for one afternoon. The space must contain physical evidence of at least three distinct time layers: an original structural element (the oldest wall, the founding tool), a mid-period addition (a repair, a second-generation extension), and a current, actively used layer (today's tools laid where yesterday's were laid). Objects are ranked by documented age, and the ranking must be legible without a caption — the oldest piece positioned with the most reverence, not necessarily the most light. One object in every Saga cenography shows a repaired break — the visible mend that proves the piece survived rather than simply aged. Refused: a pristine period room with no evidence of ongoing use, and any object whose age cannot be placed relative to the others in the same frame.

**Colour.** One palette drawn from genuinely aged material — oxidized metal, sun-faded textile, smoke-darkened wood, patinated stone — held constant enough across the frame's generations that a viewer can tell the ring-structure is one lineage, not three unrelated objects. Saturation drops with apparent age (the oldest ring desaturates toward monochrome) and rises toward the newest ring, so the palette itself performs the passage of time the composition already argues. Exactly one colour recurs unchanged across every generation in the frame — the Saga's own signal colour, present in the oldest object and the newest alike, proof that something specific, not tradition in the abstract, survived intact. Refused: a uniform contemporary grade applied evenly across objects of different real ages, which erases exactly the information this element exists to preserve.

**Lineage proof.** Wherever the composition allows it, plant one device that proves the tree is still growing rather than merely preserved: a fresh graft or new tool laid beside the oldest one and clearly still in use; a hand demonstrably younger than the object it holds; a repaired break left visible rather than hidden; an empty slot in an otherwise full rank, proving room was made on purpose for what comes next. This is the ring itself made photographic — the closest a still frame comes to proving both that something was lost and that growth continued anyway. A frame whose oldest object shows no evidence of ever being used, or whose newest object shows no debt to what came before it, is the single most legible failure this element can produce.

**Case anchors (from the ID-Mythos codex).** The codex's own worked studies translate directly into direction notes. The nameless-man case (removal of the proper name): no name on screen, no biographical anchor, the figure entering as a force rather than a person — use when the Glifo itself, not a face, must carry the frame. The economy-of-gesture case (stillness read as authority): expressivity reduced toward zero so the frame reads as inevitability rather than performance — the model does less, and the frame's charge rises as movement falls. The threshold-return case (a figure re-entering ordinary space having already completed the mythic passage): eyewear or a visor that hides the eyes without hiding the face, signalling the figure now reads the world differently than the viewer does — use once per series only; repetition flattens the device into costume.

## Polaridades — repertório amplificado (↑) e suprimido (↓)

**↑ Amplified — repertory.** Total lineage commitment: a ring-structured composition carrying a genuine scar of loss, a two-handed transfer gesture with the object still in motion, an inherited object worn rather than displayed, honestly differentiated ages across two real generations, one signal colour surviving unchanged across every ring, a real workshop or archive with three documented time layers, and a repaired break left visible as proof the piece survived.

> **↑ Prompt.** In a working stone-walled archive lit by one broad skylight that ages in temperature from a warm low glow at the far wall to a cleaner cool light near the door, an older craftsman's weathered hand and a younger apprentice's hand meet at the center of the frame passing a single hand-forged tool between them, the handle worn smooth on the elder's side and still sharp-edged where a new graft was welded onto its head last season, both hands mid-transfer with neither fully open nor closed, the elder's skin carrying real spotting and callus built from decades of gripping that exact handle, the apprentice's hands younger and less marked, behind them a wall of ranked tools graded by visible age — the oldest at the center darkened and desaturated near monochrome, a mid-period row showing honest wear, the newest tools at the outer edge brighter and more saturated, one empty hook in the oldest row where a matching tool was deliberately removed and given away, a single ochre cord tied around every tool regardless of age as the one colour that has never changed, a visible weld-repair on the tool being passed left unpolished and legible, the composition built in concentric rings from that central handoff outward through the ranked wall to the working floor, camera at bench height holding the entire ring structure in one continuous depth of field, grain reading like inherited stock rather than a filter, nothing in the frame that could not be dated relative to everything else in it.
> 

> **↑ Negative line.** No costume-aged distressing on a young face, no uniform lighting temperature erasing the age difference between generations, no pristine untouched heirloom sealed behind glass, no cluttered frame with no visible chronology, no single figure alone with a trophy and no one to receive it, no repair or wear retouched away, no contemporary marker with no older counterpart anywhere in frame.
> 

**↓ Suppressed — repertory.** Placeless, unauthored surfaces: no era markers, no provenance, hair and face styled to no decade, a scene scrubbed of anywhere and anywhen, a single figure holding a brand-new object with no visible history and no one to receive it.

> **↓ Prompt.** A seamless white void, a figure alone in an unbranded, unornamented one-piece with no visible closures and no legible construction, one factory-new object held loosely in one hand with no wear anywhere on its surface, hair and face styled to no decade and no visible age, flat even sourceless light with no temperature shift anywhere in the frame, no second figure to receive anything, no ranked or dated objects nearby, no scar, no repair, no empty slot proving anything was ever given away, an image scrubbed of anywhere, anywhen, and anyone before or after this single moment.
> 

> **↓ Negative line.** No ring-structured composition, no two-generation transfer gesture, no aged palette shift, no inherited object, no documented time-layered cenography, no visible repair or scar, no signal colour recurring across generations.
> 

## Estéticas relacionadas a SAGA (A–Z)

As 58 estéticas classificadas sob SAGA, em ordem alfabética. Cada toggle traz: número no catálogo de 1001, epíteto, nível de vínculo (🔴 Primary · 🟣 Secondary · 🟤 Tertiary · ⚫ Quaternary), eixo secundário e polaridade (XX — continuidade · XY — disrupção).

### **Absurdism**

**№ 014 / 1001** · *Universe shrugs back*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**O universo dá de ombros de volta** — (1001 Aesthetics, interpretação)

Cenas impossíveis com lógica interna quebrada: surrealismo cotidiano, humor seco e existencial.

**Paleta de cores** tons neutros e burocráticos quebrados por um elemento impossível

**Melhores usos:** editorial, humor, arte conceitual

**MidJourney:** `[tema], absurdist surreal scene, deadpan humor --v 6`

**Prompt universal (Seedream):** `Cinematic photograph shot on ARRI Alexa with 35mm lens, a mundane fluorescent-lit office where one impossible element quietly breaks reality, deadpan existential humor, muted bureaucratic beige and gray palette, perfectly symmetrical composition in the style of Roy Andersson, ultra photorealistic film still`

### **Academicism**

**№ 015 / 1001** · *Beauty by jury*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Beleza aprovada por júri** — (1001 Aesthetics, interpretação)

Pintura acadêmica do século XIX: técnica impecável, mitologia e alegoria, acabamento polido de salão (Bouguereau, Cabanel).

**Paleta de cores** tons de pele idealizados, drapeados suaves, luz difusa de ateliê

**Melhores usos:** retratos clássicos, alegorias, estética refinada

**MidJourney:** `[tema], 19th century academic salon painting by William-Adolphe Bouguereau --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction captured on Hasselblad with 80mm lens of a 19th century academic salon painting, flawless polished technique with mythological allegory, idealized figures in soft flowing drapery, diffused atelier light and warm varnish glow, Bouguereau-level porcelain skin rendering, exquisite fine detail, 8k`

### **Adinkra**

**№ 020 / 1001** · *West African proverbs as symbols*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Provérbios da África Ocidental como símbolos** — (1001 Aesthetics, interpretação)

Símbolos adinkra de Gana: geometria simbólica estampada em tecido, onde cada forma carrega um provérbio.

**Paleta de cores** preto sobre tecido cru, terracota e dourado

**Melhores usos:** padronagem, identidade visual, arte simbólica

**MidJourney:** `[tema], Adinkra symbols pattern, Ghanaian textile art --v 6`

**Prompt universal (Seedream):** `Macro textile photograph shot on 100mm macro lens, West African Adinkra symbols hand-stamped in black ink on natural woven cloth, visible fabric weave and pigment bleed, terracotta and gold accents, warm directional daylight raking across the textile, Ghanaian craft heritage in extreme tactile detail, 8k`

### **Adirondack**

**№ 021 / 1001** · *Robber barons playing pioneer*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Barões brincando de pioneiros** — (1001 Aesthetics, interpretação)

Grandes acampamentos rústicos de luxo nas montanhas: troncos e pedra, tecidos xadrez, conforto senhorial na floresta.

**Paleta de cores** marrons de madeira, verde-floresta, vermelho xadrez, luz de lareira

**Melhores usos:** interiores, lodges, cenas de outono e inverno

**MidJourney:** `[tema], Adirondack great camp rustic luxury style --v 6`

**Prompt universal (Seedream):** `Interior photograph shot on Canon R5 with 24mm lens, an Adirondack great camp lodge of hand-hewn logs and rough granite, plaid wool textiles and antler chandeliers, warm firelight flickering against honeyed timber, forest dusk beyond the windows, rustic luxury with cinematic amber grading, 8k`

### **Adoniscore**

**№ 022 / 1001** · *Proportional Canon Made Flesh*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Cânone de proporção feito carne** — (1001 Aesthetics, interpretação)

Beleza masculina escultural greco-clássica: mármore, proporção ideal e luz heroica.

**Paleta de cores** mármore branco, dourado, sombras quentes de bronze

**Melhores usos:** fitness, escultura, editorial

**MidJourney:** `[tema], classical Greek sculpture aesthetic, heroic ideal proportions --v 6`

**Prompt universal (Seedream):** `Sculptural portrait shot on Hasselblad with 100mm lens, a male figure with classical Greek canonical proportions posed like living marble, dramatic heroic side light carving muscle into chiaroscuro, white stone and bronze-gold palette, Herb Ritts statuary elegance, ultra sharp fine art quality, 8k`

### **Adventurous**

**№ 024 / 1001** · *Off the map, on purpose*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → ILLUMINATION ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Fora do mapa, de propósito** — (1001 Aesthetics, interpretação)

Exploração romântica: mapas, trilhas, horizontes abertos e luz dourada de fim de tarde.

**Paleta de cores** terrosos com dourado de hora mágica

**Melhores usos:** viagem, storytelling, capas

**MidJourney:** `[tema], adventure exploration aesthetic, golden hour --v 6`

**Prompt universal (Seedream):** `Cinematic travel photograph shot on medium format with 35mm lens, a lone traveler silhouetted on a mountain ridge at golden hour, weathered vintage map and brass compass in hand, open horizon dissolving into amber haze, warm earthy grading with magic-hour rim light, wanderlust film still, 8k`

### **Aeropunk**

**№ 026 / 1001** · *Sky held together with dope and rivets*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Céu preso com verniz e rebites** — (1001 Aesthetics, interpretação)

Aviação retrofuturista: dirigíveis, biplanos, madeira, lona e latão — o irmão aéreo do steampunk e do dieselpunk.

**Paleta de cores** latão, couro, verde-oliva, céus dramáticos

**Melhores usos:** worldbuilding, capas, concept art

**MidJourney:** `[tema], aeropunk retrofuturistic aviation, airships and rivets --v 6`

**Prompt universal (Seedream):** `Epic concept photograph shot on ARRI with 40mm anamorphic lens, retrofuturistic airships and wood-and-canvas biplanes with brass rivets crossing a storm-lit cloudscape, golden light breaking through towering cumulus, leather and olive-drab details, dieselpunk aviation adventure, cinematic matte-painting quality, 8k`

### **Aestheticism**

**№ 027 / 1001** · *Beauty that owes no one an explanation*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Beleza que não deve explicação a ninguém** — (1001 Aesthetics, interpretação)

Movimento esteticista (art for art's sake): ornamento refinado, lírios e pavões, na linha de Whistler e Beardsley.

**Paleta de cores** dourado, azul-pavão, branco-lírio

**Melhores usos:** decoração, ilustração refinada, editorial

**MidJourney:** `[tema], Aesthetic Movement style, art for art's sake, peacocks and lilies --v 6`

**Prompt universal (Seedream):** `Refined still photograph shot on Hasselblad with 80mm lens, an Aesthetic Movement interior with peacock feathers and white lilies, gilded japonisme ornament against peacock-blue walls, soft northern window light, Whistler and Beardsley elegance, art for art's sake composition, exquisite museum detail, 8k`

### **Afghan**

**№ 029 / 1001** · *Loom is the protagonist*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O tear é o protagonista** — (1001 Aesthetics, interpretação)

Tapetes e têxteis afegãos: nós densos, medalhões tradicionais, vermelhos profundos tecidos à mão.

**Paleta de cores** vermelho carmim, índigo, marfim

**Melhores usos:** padronagem, interiores, artesanato

**MidJourney:** `[tema], Afghan carpet weaving patterns, traditional textile --v 6`

**Prompt universal (Seedream):** `Macro textile photograph shot on 100mm macro lens, a hand-knotted Afghan carpet with dense traditional medallions, deep crimson and indigo wool fibers in extreme tactile detail, ivory accents catching warm side light, visible knot structure and artisan loom precision, heritage craft reproduction, 8k`

### **Afro-Brazilian**

**№ 030 / 1001** · *Atabaque before the samba*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Atabaque antes do samba** — (1001 Aesthetics, interpretação)

Cultura afro-brasileira: candomblé e orixás, rendas brancas da Bahia, atabaques e cores rituais.

**Paleta de cores** branco de renda, azul de Iemanjá, dourado de Oxum, vermelho e verde rituais

**Melhores usos:** cultura, espiritualidade, ilustração

**MidJourney:** `[tema], Afro-Brazilian culture, Bahia candomblé aesthetics --v 6`

**Prompt universal (Seedream):** `Documentary editorial photograph shot on 35mm film with 50mm lens, an Afro-Brazilian celebration in Bahia, white lace garments swirling to atabaque drums, orixá ritual colors and candle glow, warm tropical dusk light on dark radiant skin, joyful spiritual energy, rich Kodachrome warmth and film grain`

### **Afrocentricity**

**№ 031 / 1001** · *Design language older than empire*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Linguagem de design mais antiga que o império** — (1001 Aesthetics, interpretação)

Padrões e símbolos pan-africanos: kente, máscaras e geometria ancestral em chave contemporânea e orgulhosa.

**Paleta de cores** dourado, vermelho, verde e preto (kente)

**Melhores usos:** identidade visual, moda, editorial

**MidJourney:** `[tema], Afrocentric design, kente patterns and ancestral symbols --v 6`

**Prompt universal (Seedream):** `Bold editorial photograph shot on Hasselblad with 80mm lens, an Afrocentric composition of kente cloth geometry and carved ancestral masks, gold red green and black in proud contemporary styling, sculptural studio lighting with deep shadows, regal direct gaze, high fashion meets heritage, 8k detail`

### **Afrofuturism**

**№ 032 / 1001** · *Ancestry that learned to code*

**Nível:** ⚫ Quaternary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Ancestralidade que aprendeu a programar** — (1001 Aesthetics, interpretação)

Futuro africano: tecnologia avançada fundida à tradição, realeza cósmica — de Sun Ra a Wakanda.

**Paleta de cores** dourado, roxo cósmico, azul elétrico sobre pele negra iluminada

**Melhores usos:** sci-fi, música, moda conceitual

**MidJourney:** `[tema], afrofuturism, cosmic African royalty with advanced technology --v 6`

**Prompt universal (Seedream):** `Sci-fi editorial portrait shot on medium format with 85mm lens, African royalty fused with advanced technology, golden regalia and glowing circuitry traced over traditional patterns, cosmic purple nebula backdrop, dramatic rim light on dark radiant skin, Sun Ra meets Wakanda majesty, ultra photorealistic, 8k`

### **AfroVictorian**

**№ 033 / 1001** · *Kente inside the crinoline*

**Nível:** ⚫ Quaternary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Kente dentro da crinolina** — (1001 Aesthetics, interpretação)

Moda vitoriana reimaginada com tecidos africanos: crinolinas e espartilhos cortados em kente e wax print.

**Paleta de cores** estampas wax vibrantes sobre tons vitorianos profundos

**Melhores usos:** moda, retratos, editorial de história alternativa

**MidJourney:** `[tema], AfroVictorian fashion, kente and wax print Victorian gowns --v 6`

**Prompt universal (Seedream):** `Studio portrait shot on large format with 90mm lens, an AfroVictorian sitter in a crinoline gown tailored from vibrant kente and wax print, dignified pose against a painted canvas backdrop, Rembrandt lighting with rich fabric texture, alternate-history elegance, daguerreotype gravitas in full color, 8k`

### **Alchemy**

**№ 036 / 1001** · *Sulfur and mercury, courting in glass*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Gramática visual da transmutação** — (1001 Aesthetics, interpretação)

Alquimia: selos e círculos de transmutação, vidraria, pergaminhos — ciência oculta desenhada.

**Paleta de cores** dourado, âmbar, verde-garrafa, pergaminho envelhecido

**Melhores usos:** esotérico, capas, ilustração simbólica

**MidJourney:** `[tema], alchemical illustration, transmutation circles and sigils --v 6`

**Prompt universal (Seedream):** `Atmospheric still life shot on 50mm f/1.4 lens, an alchemist's laboratory with glass alembics and bubbling amber liquids, transmutation circles and esoteric sigils inked on aged parchment, candlelight and gold dust suspended in the air, deep bottle-green shadows, occult scientific detail, cinematic chiaroscuro, 8k`

### **Alebrijes**

**№ 037 / 1001** · *Chimeras stitched from spare parts*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Quimeras costuradas de peças avulsas** — (1001 Aesthetics, interpretação)

Alebrijes mexicanos: criaturas híbridas fantásticas de Oaxaca, pintadas à mão com padrões minuciosos.

**Paleta de cores** fúcsia, turquesa, laranja e amarelo com padrões pontilhados

**Melhores usos:** ilustração, design de personagens, cultura

**MidJourney:** `[tema], Mexican alebrije folk art creature, vibrant patterns --v 6`

**Prompt universal (Seedream):** `Vivid studio photograph shot on 100mm macro lens, a Mexican alebrije carved wood creature, hand-painted fuchsia turquoise and orange dot-and-stripe patterns in extreme detail, visible brushwork and matte pigment texture, warm Oaxacan workshop light, folk art masterpiece against a neutral backdrop, 8k`

### **Arcade**

**№ 054 / 1001** · *Room That Glowed from Below*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → ILLUMINATION ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A sala que brilhava de baixo** — (1001 Aesthetics, interpretação)

Fliperama anos 80: néon, telas CRT, carpete estampado, brilho vindo das máquinas.

**Paleta de cores** neon roxo, ciano e magenta sobre escuro

**Melhores usos:** retro gaming, cenários, capas

**MidJourney:** `[tema], retro 80s arcade aesthetic, neon glow --v 6`

**Prompt universal (Seedream):** `Cinematic photograph shot on 40mm anamorphic lens, a 1980s arcade interior glowing from below, CRT cabinets casting neon purple cyan and magenta onto a patterned carpet, screen flicker and haze in the air, nostalgic gamer atmosphere with retro-thriller color grading, ultra-detailed 8k`

### **Argentinian**

**№ 055 / 1001** · *Gourd that keeps the circle moving*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A cuia que mantém a roda girando** — (1001 Aesthetics, interpretação)

Cultura argentina: mate compartilhado, pampa, tango e o fileteado porteño ornamental.

**Paleta de cores** azul-celeste e branco, couro, dourado do fileteado

**Melhores usos:** cultura, gastronomia, ilustração

**MidJourney:** `[tema], Argentinian culture, fileteado porteño --v 6`

**Prompt universal (Seedream):** `Warm documentary photograph shot on 50mm lens, a mate gourd passed hand to hand in a circle of friends, pampas horizon at golden hour, fileteado porteño ornamental lettering and worn leather details, celeste blue and caramel palette, tango-soul intimacy, gentle film grain warmth`

### **Art Brut**

**№ 057 / 1001** · *Ballpoint the ward couldn't confiscate*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → DENSITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** Uma única linhagem herdada é voltada contra si mesma — a tradição de belas-artes da mão treinada é mantida como ponto de referência e sistematicamente invertida pelo criador não treinado, institucionalizado; a gramática é reinterpretada, não fundada nem fundida.

**Atmosfera e mood**

**A caneta que a enfermaria não confiscou** — (1001 Aesthetics, interpretação)

Arte bruta/outsider: desenho obsessivo, cru, fora de qualquer sistema (Dubuffet, Wölfli).

**Paleta de cores** caneta esferográfica, lápis de cor, tons crus

**Melhores usos:** arte expressiva, editorial, texturas

**MidJourney:** `[tema], art brut outsider art, obsessive ballpoint drawing --v 6`

**Prompt universal (Seedream):** `High-resolution scan of an art brut outsider drawing, obsessive ballpoint pen strokes filling every millimeter of found paper, dense raw symbols and figures layered with colored pencil, untrained ferocious intensity, creased and stained sheet texture, Dubuffet collection artifact quality`

### **Brazilian June Festival**

**№ 122 / 1001** · *Fire, forró, and the saints of June*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → DOMAIN ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Festas de santos ibéricas, ritual rural de colheita e a cultura musical nordestina convergem; sem o calendário católico as datas perdem a razão, sem o fio rural a fogueira não tem campo — fusão, não revisão de um único pai.

**Atmosfera e mood**

**Fogo, forró e os santos de junho** — (1001 Aesthetics, interpretação)

Festa junina: bandeirinhas de papel, fogueira, quadrilha, chapéu de palha e barracas de milho.

**Paleta de cores** bandeirinhas coloridas, laranja de fogueira, xadrez

**Melhores usos:** sazonal, festa, ilustração

**MidJourney:** `[tema], festa junina Brazilian June festival --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a festa junina night in the Brazilian countryside, strings of colorful paper flags glowing above a bonfire, straw hats and plaid shirts spinning in a forró dance, sweet corn stalls and lantern smoke, ember sparks rising through warm orange light, festive documentary charm, 8k`

### **CHICANO**

**№ 148 / 1001** · *Bajito y suavecito, loud and slow*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** Nenhuma estética anterior pode ser nomeada como sua criadora — a gramática rebaixada e lenta nasce na raiz, de uma comunidade que se define em seus próprios termos; remover essa autoafirmação colapsa o sistema inteiro, não um ramo.

**Atmosfera e mood**

**Bajito y suavecito, alto e devagar** — (1001 Aesthetics, interpretação)

Chicano: lowrider com pintura candy e pinstripes, lettering gótico, les etura fina de tatuagem preto-e-cinza.

**Paleta de cores** candy paint, cromado, preto e cinza de tattoo

**Melhores usos:** cultura, tatuagem, automotivo

**MidJourney:** `[tema], Chicano lowrider art, black and grey fineline tattoo style --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Portra 800 with 35mm lens, a Chicano art scene at East LA golden hour, candy-paint lowrider gleaming with chrome and pinstripes, gothic lettering murals and black-and-grey fineline tattoo imagery, low-and-slow pride in warm haze, Estevan Oriol documentary attitude, deep saturated grading, 8k`

### **Chivalric**

**№ 151 / 1001** · *Sword sworn, the lady served, the code held*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Prática militar feudal, poesia do amor cortês e código moral cristão se trançam num só sistema; sem a poesia o serviço desaparece, sem o fio religioso o juramento perde o peso — várias tradições soldadas.

**Atmosfera e mood**

**Espada jurada, dama servida, código mantido** — (1001 Aesthetics, interpretação)

Cavalaria: cavaleiro em armadura, estandartes heráldicos, torneio e juramento em luz de vitral.

**Paleta de cores** aço, carmesim heráldico, dourado

**Melhores usos:** fantasia medieval, ilustração, games

**MidJourney:** `[tema], chivalric medieval romance, knight and heraldry --v 6`

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a chivalric medieval scene, armored knight swearing an oath beneath heraldic banners, stained-glass light scattering colored jewels across polished steel, tournament grounds hazy beyond the chapel door, courtly honor and romance, cinematic Excalibur grading, ultra-detailed armor texture, 8k`

### **Christmas**

**№ 153 / 1001** · *Annual return of light, gift, and gathered kin*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Ritual pré-cristão de solstício, natividade cristã e costume comercial vitoriano convergem; sem o solstício as luzes perdem a razão, sem a camada vitoriana a cena doméstica não se forma — várias linhagens fundidas numa gramática anual.

**Atmosfera e mood**

**Retorno anual da luz, do presente e dos que se reúnem** — (1001 Aesthetics, interpretação)

Natal: árvore iluminada, lareira, presentes embrulhados, neve pela janela e mesa reunida.

**Paleta de cores** vermelho, verde-pinheiro, dourado, branco-neve

**Melhores usos:** sazonal, cartões, campanhas

**MidJourney:** `[tema], cozy Christmas scene --v 6`

**Prompt universal (Seedream):** `Shot on Canon R5 with 35mm f/1.4, a cozy Christmas scene, glowing tree bokeh and crackling fireplace, wrapped gifts in red green and gold, snow falling beyond frosted windows, family hands reaching across a candlelit table, warm tungsten glow with cinnamon-toned grading, nostalgic editorial warmth, 8k`

### **Dark Academia**

**№ 197 / 1001** · *Wall the lamp only half-reaches*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A parede que a lâmpada só alcança pela metade** — (1001 Aesthetics, interpretação)

Academia sombria: biblioteca gótica à meia-luz, livros antigos e tweed, outono perpétuo e conhecimento proibido.

**Paleta de cores** marrons profundos, preto, verde-garrafa, sépia

**Melhores usos:** editorial, retratos, cenários

**MidJourney:** `[tema], dark academia aesthetic, gothic library candlelight --v 6` (estilo nomeado catalogado na MidLibrary)

**LoRA (Civitai):** "V67 Dark Academia" (Flux/Z Image) — civitai.com/models/2487081; "Dark Academia" (SDXL) — civitai.com/models/662189

**Prompt universal (Seedream):** `Shot on 35mm film with 50mm f/1.4, a dark academia scene, gothic library half-reached by green-shaded lamplight, antique books tweed and handwritten Latin notes, dust motes in amber beams between oak stacks, muted vintage grading with heavy film grain, perpetual autumn and the allure of forbidden knowledge, cinematic melancholy, 8k`

### **Dark Romanticism**

**№ 200 / 1001** · *Longing held past resolution*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Anseio mantido além da resolução** — (1001 Aesthetics; código: match aproximado)

Romantismo sombrio: ruínas góticas sob lua, paixão e melancolia, o sublime que assusta (Friedrich, Poe).

**Paleta de cores** azuis noturnos, preto, pálido de lua

**Melhores usos:** arte, literatura visual, retratos

**MidJourney:** `--sref 3089530890 --sw 1000` (Dark Surrealism with Emotional Depth — match aproximado)

**Prompt universal (Seedream):** `Museum-grade reproduction of a dark romanticism painting, gothic ruins under moonlight with a lone figure held in longing, sublime terror and beauty entwined, moon-pale light on nocturnal blues, Caspar David Friedrich meets Poe, visible oil texture and deep varnish glow, 8k archival scan`

### **Detective**

**№ 222 / 1001** · *Covenant of Shadow, Cigarette Smoke, and Buried Evidence*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → ILLUMINATION ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Sombra, fumaça de cigarro e evidência enterrada** — (1001 Aesthetics, interpretação)

Noir de detetive: escritório com persianas riscando luz, fumaça e uísque, arquivo de caso sob a luz da luminária.

**Paleta de cores** preto e branco noir, âmbar de luminária

**Melhores usos:** narrativa, cinema, capas

**MidJourney:** `[tema], detective noir, venetian blind shadows and cigarette smoke --v 6`

**Prompt universal (Seedream):** `Shot on 35mm Tri-X with 50mm lens, a detective noir scene, office striped by venetian blind shadows, cigarette smoke curling over a case file under a desk lamp, whiskey glass and buried evidence, classic noir chiaroscuro, heavy film grain, 1940s pulp atmosphere`

### **Dieselpunk**

**№ 225 / 1001** · *Combustion Mythology Locked Between Two World Wars*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Mitologia da combustão travada entre duas guerras mundiais** — (1001 Aesthetics, interpretação)

Dieselpunk: máquinas de guerra retrofuturistas, riveted steel e fumaça de diesel, anos 1920–40 alternativos.

**Paleta de cores** aço, verde-oliva, sépia de fuligem

**Melhores usos:** sci-fi retrô, jogos, capas

**MidJourney:** `[tema], dieselpunk retrofuturism, riveted machines and diesel smoke --v 6` (estilo nomeado catalogado na MidLibrary)

**LoRA (Civitai):** "DieselpunkAI" (SD 1.5) — civitai.com/models/22462; "Dieselpunk Propaganda Art" — civitai.com/models/1765733

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, a dieselpunk scene, retrofuturistic riveted war machines exhaling diesel smoke, alternate 1930s world locked between two wars, olive steel and soot sepia under industrial floodlights, combustion mythology, cinematic haze and grit, 8k production still`

### **Diva**

**№ 235 / 1001** · *The encore, demanded in advance*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → EMANATIO ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Imperatriz da performance** — (1001 Aesthetics, interpretação)

Diva: figura dominando o palco, vestido dramático e holofote único, presença que exige a plateia inteira.

**Paleta de cores** dourado de palco, vermelho dramático, holofote

**Melhores usos:** música, retratos, editorial

**MidJourney:** `[tema], diva on stage, dramatic gown under single spotlight --v 6`

**Prompt universal (Seedream):** `Shot on Hasselblad with 100mm lens, a diva stage portrait, commanding figure in a dramatic sculptural gown under a single hard spotlight, stage gold and deep red velvet darkness, George Hurrell glamour lighting, empress of performance demanding the entire audience, 8k editorial drama`

### **Early Medieval Carolingian**

**№ 257 / 1001** · *One Script From Tours to Aachen*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → INTEGRITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Uma só escrita de Tours a Aachen** — (1001 Aesthetics, interpretação)

Carolíngio: minúscula uniforme em pergaminho, evangeliários de ouro e púrpura, capela palatina de Aachen.

**Paleta de cores** pergaminho, ouro, púrpura imperial

**Melhores usos:** histórico, manuscritos, arte

**MidJourney:** `[tema], Carolingian illuminated manuscript, gold and purple parchment --v 6`

**Prompt universal (Seedream):** `High-resolution scan of a Carolingian illuminated manuscript, uniform minuscule script on aged parchment, gospel pages in burnished gold and imperial purple, raking light revealing the vellum grain, Aachen palace chapel solemnity, one script from Tours to Aachen, 8k archival detail`

### **Epic**

**№ 296 / 1001** · *One Figure Against a Forty-to-One Wall*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Uma figura contra um muro de quarenta para um** — (1001 Aesthetics; código: match aproximado)

Épico: escala esmagadora, figura minúscula diante do colossal, grandiosidade que humilha e eleva.

**Paleta de cores** tons monumentais, luz dramática, névoa de escala

**Melhores usos:** fantasia, cinema, concept art

**MidJourney:** `--sref 1959519897 --sw 1000` (Mythical Serenity with a Colossal Beast — match aproximado)

**Prompt universal (Seedream):** `Shot on ARRI Alexa with 40mm anamorphic lens, an epic scale composition, one tiny figure against a forty-to-one colossal wall, overwhelming monumental scale in dramatic god-ray light and mist, grandeur that humbles and elevates, Roger Deakins scope, 8k production still`

### **Epic Fantasy**

**№ 297 / 1001** · *Blade That Was Given a Name*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A lâmina que recebeu um nome** — (1001 Aesthetics; código: match aproximado)

Alta fantasia: espadas nomeadas e reinos antigos, linhagem tolkieniana, mito construído com arquitetura própria.

**Paleta de cores** aço, ouro antigo, verdes de floresta profunda

**Melhores usos:** fantasia, capas, concept art

**MidJourney:** `--sref 2046525074 --sw 1000` (Dark Gothic Fantasy Illustrations — match aproximado)

**Prompt universal (Seedream):** `Ultra-detailed digital artwork at 8k, an epic fantasy illustration, a named blade catching torchlight before ancient kingdoms, Tolkienesque sub-created world with mountain citadels in mist, steel and old gold with deep forest greens, myth with its own architecture, cinematic concept-art mastery`

### **Ethnic**

**№ 306 / 1001** · *Regional Weave as Inherited Signature*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → COHERENCE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A trama regional como assinatura herdada** — (1001 Aesthetics, interpretação)

Étnico: tecelagem e padrão tradicionais, identidade cultural em fio e tinta, herança viva sem assinatura individual.

**Paleta de cores** cores de tecelagem regional, pigmentos naturais

**Melhores usos:** moda, editorial cultural, texturas

**MidJourney:** `[tema], traditional regional weaving patterns, inherited textile signature --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 60mm macro lens, an ethnic textile scene, traditional regional weave patterns as inherited signature, natural pigments and handloom texture in warm side light, every thread resolved, living cultural identity in thread and dye, artisan documentary detail, 8k`

### **Etruscan**

**№ 307 / 1001** · *Federation Painted Into the Tuff*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A federação pintada no tufo** — (1001 Aesthetics, interpretação)

Etrusco: afrescos de tumba em ocre e terracota, dançarinos e banquetes, a civilização pré-romana que sorri na pedra.

**Paleta de cores** terracota, ocre, preto de vaso, verde antigo

**Melhores usos:** histórico, arte, editorial

**MidJourney:** `[tema], Etruscan tomb fresco style, ochre dancers and banquet scenes on tuff stone --v 6`

**Prompt universal (Seedream):** `Museum-grade photograph of an Etruscan fresco, dancers and banquet painted in ochre and terracotta on tuff stone walls, vase black and ancient green pigments, raking tomb light revealing the plaster grain, the pre-Roman civilization smiling in stone, 8k archival capture`

### **Harvest Festivalcore**

**№ 419 / 1001** · *Seren Taun Rice Procession Returns to Cigugur*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → COHERENCE ↓ (ausência)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A procissão de arroz Seren Taun volta a Cigugur** — (1001 Aesthetics, interpretação)

Festival de colheita: feixes carregados em procissão, gratidão comunitária à terra, abundância ritualizada em cores de grão.

**Paleta de cores** dourado de arroz, vermelho de festa, verde de terraço

**Melhores usos:** cultura, sazonal, editorial

**MidJourney:** `[tema], harvest festival procession, rice sheaves carried in communal celebration, golden grain and festival red --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm Velvia 50 with 35mm lens, a harvest festival image, a rice procession returning through terraced fields, sheaves of golden grain and festival red textiles, Steve McCurry documentary color, communal gratitude ritualized in harvest colors, 8k`

### **Heroic**

**№ 429 / 1001** · *Trajan's Column Spirals a War Into Stone*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**A Coluna de Trajano espirala uma guerra em pedra** — (1001 Aesthetics, interpretação)

Heróico: monumento em escala épica, relevo que narra em espiral, a história contada de baixo para cima.

**Paleta de cores** mármore imperial, bronze, céu de monumento

**Melhores usos:** histórico, institucional, narrativa épica

**MidJourney:** `[tema], heroic monument style, Trajan's Column spiral relief narrating a war in stone, epic scale --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z8 with 85mm lens, a heroic image, Trajan's Column spiraling a whole war into carved stone, epic relief narrative climbing toward the sky, imperial marble and bronze against raking monument light, 8k`

### **Hiberno-Saxon**

**№ 430 / 1001** · *Lindisfarne Gospel Page Knots Before It Speaks*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A página do Evangelho de Lindisfarne se entrelaça antes de falar** — (1001 Aesthetics, interpretação)

Hiberno-saxão: entrelaçados insulares infinitos, letra capitular que vira labirinto, o texto sagrado dentro do nó.

**Paleta de cores** vermelho de mínio, verde insular, dourado, pergaminho

**Melhores usos:** ilustração, histórico, identidade celta

**MidJourney:** `[tema], Hiberno-Saxon insular art, Lindisfarne Gospels interlace knotwork, illuminated initial letters --v 6`

**LoRA (Civitai):** "Manuscript drolleries" (SDXL) — civitai.com/models/1838572

**Prompt universal (Seedream):** `Ultra-high-resolution manuscript scan, a Hiberno-Saxon image, a Lindisfarne Gospel carpet page knotting before it speaks, infinite insular interlace around an illuminated initial, minium red and gold on vellum, 8k`

### **Highland**

**№ 434 / 1001** · *Harris Tweed Leaves the Hattersley Loom for the Loch*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O Harris Tweed deixa o tear Hattersley rumo ao lago** — (1001 Aesthetics, interpretação)

Highland: tweed e urze sob céu escocês, lã que carrega a cor da paisagem, névoa de loch e xadrez de clã.

**Paleta de cores** urze roxa, verde de charneca, marrom de turfa, cinza de névoa

**Melhores usos:** moda, paisagem, branding de tradição

**MidJourney:** `[tema], Scottish Highland aesthetic, Harris Tweed and heather by a misty loch, clan tartan in peat tones --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya 7 with 65mm lens, a Highland image, Harris Tweed leaving the Hattersley loom for the loch, heather purple and peat brown under Scottish mist, wool carrying the landscape's own colors, 8k`

### **Indigenous Futurisms**

**№ 467 / 1001** · *Skawennati Sends the Longhouse Into Cyberspace*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → SYNTHESIS ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Skawennati envia a casa-longa para o ciberespaço** — (1001 Aesthetics, interpretação)

Futurismos indígenas: tradição projetada no futuro, wampum e código, sci-fi contado por quem sempre esteve aqui.

**Paleta de cores** púrpura de wampum, ciano digital, terra ancestral, aurora

**Melhores usos:** sci-fi, arte, editorial cultural

**MidJourney:** `[tema], Indigenous Futurisms, longhouse sent into cyberspace, wampum patterns meeting digital code --v 6`

**Prompt universal (Seedream):** `Ultra-detailed digital artwork, an Indigenous Futurisms image, a longhouse sent into cyberspace, wampum purple woven into digital cyan code, ancestral earth tones under an aurora, Skawennati machinima spirit, sci-fi told by those who were always here, 8k`

### **Indigenous North American**

**№ 468 / 1001** · *Haudenosaunee Wampum Holds Law in Beadwork*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → COHERENCE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**O wampum haudenosaunee guarda a lei em miçangas** — (1001 Aesthetics, interpretação)

Indígena norte-americano: arte como registro vivo, conta e couro, padrão que carrega tratado e memória.

**Paleta de cores** púrpura e branco de quahog, couro, contas naturais

**Melhores usos:** cultural, histórico, editorial respeitoso

**MidJourney:** `[tema], Haudenosaunee wampum beadwork holding law in pattern, purple and white quahog shell beads --v 6`

**Prompt universal (Seedream):** `Shot on Mamiya RZ67 with 140mm macro lens, an Indigenous North American image, Haudenosaunee wampum holding law in beadwork, purple and white quahog shell patterns on leather in soft raking light, art as living record of treaty and memory, 8k`

### **Isekai**

**№ 478 / 1001** · *Sword Art Online Locks the Player Inside the World*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → DOMAIN ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Sword Art Online tranca o jogador dentro do mundo** — (1001 Aesthetics, interpretação)

Isekai: fantasia de outro mundo em estética anime, interface de RPG flutuando sobre paisagem épica, o portal como premissa.

**Paleta de cores** azul de interface, verde de mundo aberto, dourado de fantasia

**Melhores usos:** anime, games, narrativa

**MidJourney:** `[tema], isekai anime aesthetic, RPG interface floating over an epic fantasy world, portal light --v 6`

**Prompt universal (Seedream):** `Ultra-detailed anime key visual, an isekai image, a player locked inside the game world, floating RPG interface over an epic open landscape, Makoto Shinkai luminous skies, portal light and fantasy gold, another-world premise made visible, 8k`

### **Landmarkcore**

**№ 513 / 1001** · *Eiffel Tower postcards and pilgrimage photos*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → DOMAIN ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Cartões-postais da Torre Eiffel e fotos de peregrinação** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Landmarkcore: o monumento performando a própria imagem, saturação turística e enquadramento de post-card.

**Paleta de cores** azul de céu aberto, saturação postal, dourado de monumento

**Melhores usos:** viagem, editorial, colagem

**MidJourney:** `[tema], landmarkcore aesthetic, Eiffel Tower postcard framing, tourist pilgrimage photo, saturated blue sky --v 6`

**Prompt universal (Seedream):** `Shot on Kodak Ektachrome E100 with 24mm lens, a landmarkcore image, the Eiffel Tower framed dead-center like a pilgrimage postcard, tourist-brochure saturation under a wide-open cobalt sky, monument gold catching late sun above tiny waving figures, vintage travel-poster optimism held with genuine awe, the landmark performing its own famous image, 8k`

### **Legendcore**

**№ 520 / 1001** · *Arthurian sword pulled from stone*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**A espada arturiana arrancada da pedra** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Legendcore: o destino encenado como tableau, névoa e alvorada pálida sobre granito antigo.

**Paleta de cores** névoa, dourado pálido, granito

**Melhores usos:** fantasia, capa, arte narrativa

**MidJourney:** `[tema], legendcore aesthetic, Arthurian sword pulled from stone, forest clearing at pale gold dawn --v 6`

**Prompt universal (Seedream):** `Ultra-detailed fantasy oil painting, a legendcore image, the Arthurian sword drawn from stone in a mist-ringed forest clearing, pale gold dawn breaking over ancient granite and wet moss, John William Waterhouse romanticism with Alan Lee atmospheric restraint, banners of fog hanging between the oaks, destiny staged as a solemn tableau, 8k`

### **London**

**№ 529 / 1001** · *Tube roundel, raincoat, city grid*

**Nível:** ⚫ Quaternary

**Eixo:** SAGA ↑ (presença) → COHERENCE ↓ (ausência)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Roundel do metrô, capa de chuva, grade urbana** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Londres: a cidade composta pelo próprio clima, ônibus vermelho contra cinza-ardósia.

**Paleta de cores** cinza-ardósia, vermelho de ônibus, garoa

**Melhores usos:** street, editorial urbano, viagem

**MidJourney:** `[tema], London aesthetic, tube roundel glowing through drizzle, red bus against slate grid --v 6`

**Prompt universal (Seedream):** `Shot on Olympus XA with 35mm lens, a London image, the tube roundel glowing through drizzle on a raincoat commute, red bus against slate grey city grid, Bill Brandt atmospheric weight, the city composed by its weather, 8k`

### **Māori**

**№ 550 / 1001** · *Koru carving, whakapapa, whenua*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Entalhe koru, whakapapa, whenua** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Māori: a ancestralidade presente em cada curva, espiral koru em madeira totara e verde pounamu.

**Paleta de cores** verde pounamu, vermelho de terra, madeira totara

**Melhores usos:** cultura, artesanato, editorial

**MidJourney:** `[tema], Maori aesthetic, koru spiral carved deep into totara wood, pounamu green, marae light --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX50S II with 80mm lens, a Maori image, a koru spiral carved deep into totara wood, whakapapa held in pounamu green and earth red, soft marae light across the grain, ancestry present in every curve, 8k`

### **MARACATU**

**№ 551 / 1001** · *Royal Court of Pernambuco, Drumming Back at Three Centuries of Erasure*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Corte Real de Pernambuco, tambores contra três séculos de apagamento** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Maracatu: coroas de lantejoulas e calungas em ouro e azul vivo, o rito respondido em ritmo.

**Paleta de cores** ouro de coroa, azul vivo, noite de festa

**Melhores usos:** cultura BR, documental, editorial

**MidJourney:** `[tema], maracatu aesthetic, royal court of Pernambuco drumming, sequined crowns and calunga dolls --v 6`

**Prompt universal (Seedream):** `Shot on Nikon D6 with 35mm lens, a maracatu image, the crowned royal court of Pernambuco advancing under festival night light, alfaia drums thundering while sequined crowns and calunga dolls blaze in gold and vivid blue, velvet capes sweeping the street, ancestral ceremony carried with regal bearing, three centuries of erasure answered in rhythm, 8k`

### **Mythcore**

**№ 586 / 1001** · *Ancient Plot Armor in a Modern Wardrobe*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Atmosfera e mood**

**Armadura de enredo antigo num guarda-roupa moderno** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Mythcore: deuses e heróis reencenados em corpo contemporâneo, louro dourado sobre alfaiataria.

**Paleta de cores** dourado de louro, mármore, púrpura de deus

**Melhores usos:** moda editorial, arte, campanha

**MidJourney:** `[tema], mythcore aesthetic, modern figure styled as ancient deity, golden laurel over tailoring --v 6`

**Prompt universal (Seedream):** `Shot on Nikon Z9 with 50mm lens, a mythcore image, a modern figure styled as an ancient deity with golden laurel over sharp tailoring, marble and royal purple staging, Tim Walker theatrical scale, old plot armor in a new wardrobe, 8k`

### **Newlyn School**

**№ 625 / 1001** · *Working Light on Working Lives*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → NARRATIVE ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Luz de trabalho pintada ao ar livre** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Escola de Newlyn: pescadores da Cornualha em plein air, dignidade do trabalho sob céu de sal.

**Paleta de cores** cinza de maré, prata de peixe, azul de traína

**Melhores usos:** arte, histórico, editorial

**MidJourney:** `[tema], Newlyn School aesthetic, Cornish fisherfolk plein air, working light dignity --v 6`

**Prompt universal (Seedream):** `Museum-grade reproduction of a Newlyn School painting, Cornish fisherfolk unloading the catch in honest plein-air working light, tide gray and fish silver under a salt sky, Stanhope Forbes tonal truth, dignity of labor rendered without sentimentality, 8k archival scan`

### **Noh**

**№ 630 / 1001** · *Slow Theater Where the Dead Refuse to Rest*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Teatro destilado até o gesto essencial** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Noh: máscara lacada sob luz de tocha, um passo por minuto, o drama comprimido em quietude.

**Paleta de cores** dourado de brocado, branco de máscara, sombra de palco

**Melhores usos:** cultura, arte, editorial

**MidJourney:** `[tema], Noh theater aesthetic, lacquered mask torchlight, drama compressed into stillness --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX 100S II with 110mm lens, a Noh performer mid-gesture, lacquered mask and gold brocade robe under flickering torchlight, one step per minute on a bare cypress stage, drama distilled to its essential motion, profound stillness in medium-format detail, 8k`

### **Nouvelle Vague**

**№ 637 / 1001** · *Cinema Jumps the Cut and Keeps Walking*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → TECHNIQUE ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Paris em jump cut e luz disponível** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nouvelle vague: câmera na mão, café e cigarro, o cinema fugindo do estúdio para a calçada de 1960.

**Paleta de cores** preto e branco de rua, cinza parisiense

**Melhores usos:** cinema, retratos, editorial

**MidJourney:** `[tema], nouvelle vague aesthetic, handheld Paris 1960, jump cut café cigarette available light --v 6`

**Prompt universal (Seedream):** `Shot handheld on 35mm with 25mm lens, a nouvelle vague frame on a 1960 Paris sidewalk, a couple mid-argument outside a café in Raoul Coutard available light, black and white street grain with jump-cut spontaneity, cinema escaping the studio, Godard-era freedom, 8k scan`

### **Old Hollywood**

**№ 642 / 1001** · *Glamour Lit to Hide the Machinery*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ILLUMINATION ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Glamour fabricado sob luz de estúdio** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Velha Hollywood: cetim prateado, cílios esculpidos em sombra e a estrela como produto perfeito de 1935.

**Paleta de cores** prata de nitrato, preto profundo, branco de cetim

**Melhores usos:** retratos, moda, capas

**MidJourney:** `[tema], old Hollywood 1935 aesthetic, silver satin studio glamour, sculpted starlight --v 6`

**Prompt universal (Seedream):** `Shot on an 8x10 studio camera with 360mm lens, an Old Hollywood portrait from 1935, silver satin and sculpted lashes under a single carefully feathered key light, Clarence Sinclair Bull MGM glamour, nitrate silver and deep velvet black, flawless manufactured starlight, 8k`

### **Old Norse**

**№ 644 / 1001** · *Sagas Cut Into Wood, Iron, and Memory*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → MATTER ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Atmosfera e mood**

**Memória entalhada em pedra e madeira** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Nórdico antigo: runas, proas de drakkar e nós entrelaçados sob sol baixo do norte.

**Paleta de cores** pedra cínza, madeira escura, ferro frio

**Melhores usos:** histórico, fantasia, editorial

**MidJourney:** `[tema], old norse aesthetic, carved runestones drakkar prows, interlaced knotwork --v 6`

**Prompt universal (Seedream):** `High-resolution documentation photograph of carved runestones under low Nordic sun, interlaced knotwork and drakkar prow serpents cut deep into gray granite, dark weathered wood and cold iron nearby, memory carved to outlast its carvers, raking light revealing every chisel mark, 8k`

### **Olympian Drama**

**№ 646 / 1001** · *Gods Making Human Consequences Larger*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por transmissão

**Atmosfera e mood**

**Deuses ampliando cada consequência** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Drama olimpiano: céus abertos, músculos em espiral e o destino decidido em escala mitológica.

**Paleta de cores** céu tempestuoso, carne dourada, púrpura divina

**Melhores usos:** arte, capas épicas, editorial

**MidJourney:** `[tema], olympian drama aesthetic, gods enlarging every consequence, mythological sky tribunal --v 6`

**Prompt universal (Seedream):** `Ultra-detailed baroque mythological painting at Rubens scale, an Olympian tribunal parting storm clouds to enlarge a mortal consequence, spiraling golden flesh and divine purple drapery, lightning-edged chiaroscuro and wind-torn banners, epic ceiling-fresco drama, 8k`

### **Portuguese Heritage**

**№ 703 / 1001** · *Empire Returns as Ornament*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → EDITING ↓ (ausência)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** O Mosteiro dos Jerónimos de Diogo de Boitaca, iniciado em 1501, soltou a estrutura gótica, a geometria de superfície mourisca e a talha marítima de cordas e corais de suas três origens separadas e as fundiu numa gramática visual que nenhum ancestral sozinho poderia gerar ou desfazer.

**Atmosfera e mood**

**Azulejo e pedra manuelina contando império** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Herança portuguesa: fachadas de azulejo azul, cordas de pedra manuelina e saudade embutida na arquitetura.

**Paleta de cores** azul de azulejo, cal, dourado de talha

**Melhores usos:** cultura, viagem, editorial

**MidJourney:** `[tema], Portuguese heritage aesthetic, blue azulejo facades Manueline stone ropes, built saudade --v 6`

**Prompt universal (Seedream):** `Shot on Nikon F6 with 28mm lens, a Portuguese heritage scene, blue azulejo tile facades meeting carved Manueline stone ropes and armillary spheres, whitewash and gilded woodwork glowing in Atlantic afternoon light, empire remembered as ornament and saudade, rich film color, 8k`

### **Renaissance Revival**

**№ 753 / 1001** · *19th Century's Love Affair with the 15th*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A licença romântica de idealizar e a moldura neoclássica de revival são recombinadas por um filtro de século — a única estética em que precisão emprestada e saudade inventada são virtudes simultâneas: o Quattrocento como vaso do que o século XIX mais gostaria de ter herdado.

**Atmosfera e mood**

**O século XIX vestindo Florença de novo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Neorrenascentista: fachadas de palazzo em bancos e bibliotecas, arcos e corníjas citando o quattrocento com dinheiro industrial.

**Paleta de cores** pedra caramelo, bronze de porta, sombra de arcada

**Melhores usos:** arquitetura, histórico, editorial

**MidJourney:** `[tema], renaissance revival aesthetic, 19th century palazzo bank facade, quattrocento quoted with industrial money --v 6`

**Prompt universal (Seedream):** `Shot on large format with 90mm lens, a Renaissance Revival facade, a 19th-century bank built as a Florentine palazzo with rusticated stone arches and heavy cornice, caramel masonry and bronze doors in raking afternoon light, the quattrocento quoted confidently with industrial money, 8k`

### **Retro**

**№ 756 / 1001** · *Yesterday's Future, Today*

**Nível:** 🟣 Secondary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XX — continuidade por revisão

**Nota:** A licença pós-moderna de citar uma década morta chega intacta, e o Retro a re-instrumenta estreitando o alvo — da citação irônica e simultânea de tudo para a citação afetuosa e precisa de uma era específica do século XX; a permissão herdada de olhar para trás deixa de ser distância crítica e vira o calor de um disco que você realmente toca.

**Atmosfera e mood**

**O passado com o cromo polido** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Retrô: jukebox, vinil e diner de cromo — décadas passadas curadas até brilharem mais que na época.

**Paleta de cores** vermelho de diner, cromo, creme de milkshake

**Melhores usos:** nostalgia, branding, editorial

**MidJourney:** `[tema], retro aesthetic, chrome diner jukebox vinyl, the past polished brighter than it was --v 6`

**Prompt universal (Seedream):** `Shot on Polaroid SX-70, a retro scene, a chrome diner counter with a glowing jukebox and a cherry-red milkshake, past decades curated until they shine brighter than they ever did, diner red and cream in soft instant-film chemistry, warm nostalgic frame, 8k scan`

### **Slavic**

**№ 813 / 1001** · *Echoes of the Old World*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** Nenhum movimento único precede a identidade eslava como pai — um milênio de heranças sobrepostas nunca se resolveu numa só linhagem: o ícone dourado, o bordado geométrico e a igreja de madeira vernacular são raízes irredutíveis. Gera descendentes (transmissão bizantina, revival romântico-nacionalista) sem descender de nenhum deles.

**Atmosfera e mood**

**Ecos do velho mundo eslavo** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Eslavo: linho bordado em vermelho, bétulas ao amanhecer e cúpulas ao longe — a memória antiga tecida no presente.

**Paleta de cores** vermelho de bordado, branco de bétula, dourado de cúpula

**Melhores usos:** cultura, retratos, editorial

**MidJourney:** `[tema], slavic aesthetic, red-embroidered linen birch grove distant domes, echoes of the old world --v 6`

**Prompt universal (Seedream):** `Shot on Zenit-E with Helios 58mm lens, a Slavic portrait in a birch grove at dawn, red-embroidered white linen and a woven crown against swirling bokeh of pale trunks, golden domes soft in the distance, the old world echoing through morning mist, vintage Soviet-glass rendering, 8k`

### **Traditional**

**№ 904 / 1001** · *Living History Without the Museum Glass*

**Nível:** 🔴 Primary

**Eixo:** SAGA ↑ (presença) → RESONANCE ↑ (presença)

**Polaridade:** XY — disrupção por ruptura

**Nota:** As práticas vernaculares reunidas aqui surgiram de forma independente em vários continentes, da mesma condição-raiz, e não têm pai rastreável — assinatura de um nó fundacional do qual descendem a World Music e o revival de patrimônio.

**Atmosfera e mood**

**História viva sem o vidro do museu** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Tradicional: o ofício passado de mão em mão, a receita sem medida escrita e o objeto usado todos os dias há três gerações.

**Paleta de cores** madeira encerada, cobre de cozinha, linho de gerações

**Melhores usos:** cultura, artesanato, editorial

**MidJourney:** `[tema], traditional aesthetic, craft passed hand to hand recipe without written measures, living history without museum glass --v 6`

**Prompt universal (Seedream):** `Shot on Fujifilm GFX100S with 63mm lens, a traditional workshop, weathered hands guiding younger ones through a craft older than both, waxed wood and kitchen copper glowing under window light beside linen worn soft by three generations, living history handled daily instead of displayed, warm honest detail, 8k`

### **Travelcore**

**№ 907 / 1001** · *Passport Becomes a Moodboard*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → SEMIOTICS ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** A errância romântica, a cultura de estrada Beat e a documentação pós-2010 das redes sociais convergem aqui, cada uma como camada estrutural insubstituível — híbrido de múltiplas linhagens, não revisão de pai único.

**Atmosfera e mood**

**O passaporte virando moodboard** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Travelcore: carimbos acumulados, bilhetes de trem no bolso do casaco e a janela do voo das seis — a vida medida em partidas.

**Paleta de cores** azul de passaporte, sépia de bilhete, laranja de janela de voo

**Melhores usos:** viagem, lifestyle, editorial

**MidJourney:** `[tema], travelcore aesthetic, stacked passport stamps train tickets coat pocket six a.m. flight window, life measured in departures --v 6`

**Prompt universal (Seedream):** `Shot on Olympus Mju II with 35mm lens, a travelcore still, a stamp-crowded passport spread over train tickets and a creased map on an airport windowsill at six a.m., ticket sepia warming under runway orange as a jet lifts beyond the glass, the passport curated like a moodboard, wanderer's film grain, 8k scan`

### **Wuxia**

**№ 984 / 1001** · *Martial Poetry Defies Gravity*

**Nível:** 🟤 Tertiary

**Eixo:** SAGA ↑ (presença) → ETERNITY ↑ (presença)

**Polaridade:** XY — disrupção por rearticulação

**Nota:** Três linhagens convergem sem nenhuma decisiva — o código ético xia, a arte marcial de wire-fu e a gramática visual da tinta nanquim clássica chinesa; remover qualquer uma deixa a estética legível mas incompleta, sem colapsar numa fonte.

**Atmosfera e mood**

**A poesia marcial desafiando a gravidade** — (1001 Aesthetics; sem SREF catalogado — prompt nominal)

Wuxia: espadachins correndo sobre o topo do bambuzal, seda flutuando um segundo a mais que a física permite e a honra decidida no ar.

**Paleta de cores** verde de bambuzal, branco de seda em voo, azul de lâmina

**Melhores usos:** cinema, capas, arte digital

**MidJourney:** `[tema], wuxia aesthetic, swordfighters running the bamboo canopy silk hanging a second too long, honor decided midair --v 6`

**Prompt universal (Seedream):** `Cinematic still in the Crouching Tiger manner, a wuxia duel, two swordfighters balanced weightless on the swaying bamboo canopy as white silk robes hang one second longer than physics allows, bamboo green and blade blue in misted light, martial poetry conducting its argument in midair, breathtaking suspended grace, 8k`

## Leitura do padrão — o que a lista confirma

Olhando a lista inteira de SAGA — a maior concentração de 🔴 Primárias de todas as posições já mapeadas — dá para ver um sistema visual muito definido, e ele responde a uma pergunta que nenhuma das outras oito posições faz: **a história inteira está gravada em anéis datáveis, e dá para apontar o que foi podado para que o resto continuasse crescendo?**[[1]](https://app.notion.com/p/Locus-Visual-Translation-Glossary-9-Posi-es-I-D-S-E-T-T-E-R-S-af107dcdad434011a32e0977d58f9dab?pvs=21)

## O primeiro dado, antes de qualquer cluster

**Zero entradas suprimidas — e isso fecha o Ato III inteiro.** EFFECT, RESONANCE e SAGA não têm um único caso ↓ catalogado, enquanto o Ato I tem Liminality (DOMAIN ↓) e o Ato II tem Naive (TECHNIQUE ↓) e Hermitcore (EXPRESSION ↓). A razão é a mesma estrutural das vizinhas: legado é posição de consumação. "Saga suprimida" não é uma estética menor — é uma cultura sem registro, e o que não deixou anéis não pode ser catalogado. O registro ↓ (o vazio sem era, sem procedência, o objeto de fábrica sem história) permanece válido como prompt, mas nenhuma das 1001 o ocupa como identidade.

**O segundo dado: a densidade de Primárias.** Ethnic, Adinkra, Adirondack, Aestheticism, Afghan, Afro-Brazilian, Afrocentricity, Epic, Māori, Olympian Drama, CHICANO, Slavic, Traditional, Old Hollywood, Argentinian, Newlyn School, Academicism — cerca de um terço da lista é nó-raiz. Nenhuma outra posição concentra tanto. Faz sentido tautológico e por isso mesmo confirma o sistema: a posição que mede profundidade documentada atrai naturalmente os sistemas que **são** a documentação. Uma cultura com mil anos de anéis raramente tem pai identificável — o tronco é ela.

## Os seis clusters

**1. Herança em custódia viva (Guardar) — o maior bloco.**

Ethnic, Indigenous North American, Adinkra, Afghan, Afro-Brazilian, Afrocentricity, Māori, Slavic, Traditional, Highland, Etruscan, MARACATU, CHICANO, Argentinian, Harvest Festivalcore. Aqui o mecanismo é literal: o wampum que guarda lei em miçanga, o tear como protagonista, o koru e a whakapapa, o Harris Tweed saindo do tear Hattersley para o lago. A prova visual é sempre a mesma — o objeto herdado **em uso corrente**, nunca na vitrine. "Living History Without the Museum Glass" (Traditional) é quase a definição da posição em cinco palavras.

**2. Mito como glifo portátil (Classe Mítica).**

Epic, Olympian Drama, Epic Fantasy, Mythcore, Legendcore, Heroic, Chivalric, Old Norse, Wuxia, Isekai. A espada **que recebeu um nome** — o momento exato em que a anedota vira mito e dispensa legenda. Trajan's Column é o caso perfeito: uma guerra inteira espiralada em pedra, legível sem contexto. O teste do glifo (uma palavra, um objeto, legível em quinhentos anos) é o que une o kouros grego ao isekai japonês.

**3. Cânone e instituição (Reger).**

Academicism ("beleza por júri"), Carolingian ("uma escrita de Tours a Aachen"), Old Hollywood, Noh, Renaissance Revival, Aestheticism. Regência sobre um campo maior que qualquer trono: o júri, o scriptorium, o studio system, a escola. O visual aqui é o campo governado sem dominação — exatamente a mão aberta sobre a mesa compartilhada que a página descreve.

**4. Enxertos no tronco — a linhagem que aprendeu a crescer.**

Afrofuturism ("ancestralidade que aprendeu a programar"), AfroVictorian ("kente dentro da crinolina"), Indigenous Futurisms ("a longhouse enviada ao ciberespaço"), Alebrijes. Este cluster é o *lineage proof* da página feito estética: o enxerto novo soldado na ferramenta mais velha, a prova de que a árvore ainda cresce em vez de ser apenas preservada. Não por acaso, é o cluster onde XY-rearticulação se concentra.

**5. Eras lacradas — o anel que virou mundo.**

Dieselpunk ("trancado entre duas guerras"), Aeropunk, Arcade, Old Hollywood, Detective, Nouvelle Vague. Períodos que se fecharam em anéis completos e agora são lidos de fora, inteiros. Repare que quatro deles pareiam com ILLUMINATION ↑ — o noir, o brilho do fliperama, a luz que esconde a maquinaria — porque uma era lacrada é reconhecida primeiro pela **assinatura de luz** que ela deixou.

**6. O rito anual — o anel se formando diante da câmera.**

Christmas, Harvest Festivalcore, Brazilian June Festival. O retorno cíclico é a formação do anel tornada visível: a mesma procissão, o mesmo fogo, a mesma mesa, um ano de crescimento entre cada repetição.

## O comportamento de polaridade — a prova mais limpa do sistema

SAGA é dominada por **XX por transmissão** — herança passada **intacta**. Isso a distingue com precisão cirúrgica das vizinhas: EXPRESSION era XY (fusão/ruptura), RESONANCE era XX por *revisão* (herdar e re-instrumentar). SAGA é a única posição onde transmissão pura domina — e é exatamente o que o glifo exige: o anel "não pode ser apagado nem falsificado". Revisar o anel seria falsificá-lo. A viagem de volta (Resonance) transforma o que carrega; a custódia (Saga) entrega o que recebeu, renovado mas íntegro.

E as poucas XY-rupturas da lista — CHICANO, Slavic, Traditional — não contradizem: são os troncos sem pai, sistemas que nasceram na raiz e geram descendentes sem descender de ninguém. Ruptura, aqui, é o nascimento da própria árvore.

## Os casos estranhos que confirmam a regra

- **Landmarkcore** (SAGA ↑ → DOMAIN ↓) é o mais revelador: o cartão-postal da Torre Eiffel é o símbolo portátil **descolado do território** — glifo amplificado, jurisdição suprimida. A definição da posição ("converted into a portable symbol legible without context") com o DOMAIN literalmente desligado para provar que o que viaja é o glifo, não o lugar.
- **Absurdism** parece deslocado até lembrar que o Mito de Sísifo é Classe Mítica em estado puro — um nome que dispara a arquitetura inteira sem nota de rodapé.
- **Diva** ("o bis, exigido de antemão") — a persona que atravessou o limiar do mito: o nome sozinho carrega o contrato.
- **Art Brut** é o Despojar encarnado: a caneta que a enfermaria não confiscou — a linhagem das belas-artes mantida como referência e sistematicamente invertida, a poda como método.

## O que a lista confirma

SAGA não é "estética histórica" nem "tema mitológico" como rótulo. É qualquer estética cuja prova visual exige **três coisas simultâneas que nenhuma outra posição pede juntas**: um registro datável que não pode ser falsificado (o anel), uma perda visível que permitiu o crescimento (a poda), e uma transferência em andamento entre duas gerações (a custódia). Por isso Māori, Dieselpunk e Afrofuturism convivem na mesma posição — whakapapa entalhada, era entre-guerras lacrada e ancestralidade em código são objetos incomparáveis, mas todos passam pelo mesmo teste: *o que sobreviveu tem anéis, os anéis têm cicatrizes, e há uma mão mais nova recebendo o que a mão mais velha ainda segura?* Se a resposta precisa de legenda, ainda é biografia — e biografia, nesta posição, é o que o glifo existe para superar.

---